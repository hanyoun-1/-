# EDA 분석 백엔드 (FastAPI)

프론트(React+TS)에서 무거운 계산을 선택적으로 위임받는 최소 백엔드입니다.
이번 단계는 **회귀 학습(fitRegression) 연동**만 담당합니다.

## 프론트 계약 (src/lib/compute/api.ts 와 1:1)

| 메서드·경로 | 요청 | 응답 |
|-------------|------|------|
| `POST /models/train` | `{task, algo, target, features, testRatio, X, y}` | `{model_id, metrics, coef?, importance?, intercept?, actualVsPred, vizTree?, sampled?}` |
| `POST /models/{model_id}/predict` | `{X}` | `{predictions}` |
| `DELETE /models/{model_id}` | — | `{deleted}` (없으면 404) |

- `algo`는 프론트 키를 그대로 사용: `linear` / `rf` / `xgboost` / `lightgbm` / `catboost` 등.
- 만료/부재 `model_id`로 predict → **404** → 프론트 `MissingModelError`(재학습 유도).

## 실행

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate   # 파이썬 3.11~3.13 권장
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
# 문서: http://127.0.0.1:8000/docs
```

프론트 연동 시(다음 단계): 프론트 `.env`에
```
VITE_COMPUTE_MODE=hybrid   # 또는 server
VITE_API_BASE_URL=http://127.0.0.1:8000
```

## 스모크 테스트

```bash
# (A) 서버 없이 학습/예측 함수 직접 검증
python scripts/smoke_test.py

# (B) 서버 띄운 뒤 HTTP 왕복 검증
uvicorn app.main:app --port 8000 &
python scripts/smoke_test.py --http http://127.0.0.1:8000
```

## 재현성 (브라우저 ↔ 서버)

| 요소 | 일치 수준 |
|------|-----------|
| train/test 분할 (seed=42) | **완전 일치** — `app/repro.py`가 프론트 mulberry32/Fisher-Yates를 32비트까지 포팅 |
| 지표(r2/mae/rmse)·actualVsPred | 산식·반올림 포팅 → 선형은 사실상 일치 |
| vizTree(깊이2) | **완전 일치** — 결정적 SSE 분할 포팅 |
| 선형회귀 계수·예측 | **사실상 일치** — sklearn LinearRegression = TS OLS |
| rf 예측·중요도 | ⚠️ **정확히 일치하지 않음** — 프론트는 자체 트리 구현, 서버는 sklearn(알고리즘 상이). 동일 하이퍼파라미터·seed로 **서버 재현성**만 보장 |

## 구조

```
backend/
├─ requirements.txt
├─ app/
│  ├─ main.py         FastAPI 앱 + CORS + 라우터
│  ├─ schemas.py      pydantic (프론트 계약 1:1)
│  ├─ store.py        인메모리 모델 저장소 + TTL 2h
│  ├─ repro.py        mulberry32·분할·capRows·숫자포맷 포팅
│  ├─ metrics.py      regressionMetrics 포팅
│  ├─ viztree.py      buildVizTree(깊이2) 포팅
│  ├─ models_reg.py   회귀 학습(sklearn)·예측
│  └─ routers/        models.py
└─ scripts/smoke_test.py
```

## 범위 밖(다음 단계)
- 분류(fitClassifier)·상관·전처리·병합 엔드포인트
- 데이터셋 캐싱(dataset_id 재사용), 인증·DB·Redis·Docker
- 프론트 `train()` async 전환 후 실제 연결
