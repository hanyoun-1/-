"""FastAPI 인증 의존성(L2b).

- get_current_user: Authorization: Bearer <access> → JWT 검증 → 활성 User 반환. 실패 시 401.
- require_role: 특정 역할만 허용하는 의존성 팩토리(이번 단계엔 정의만 — 사용은 L2c).
"""
from __future__ import annotations

from collections.abc import Callable

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from .db import get_db
from .models_db import User
from .security import decode_access_token

# tokenUrl 은 Swagger Authorize 연동용(로그인 폼 엔드포인트).
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

_credentials_exc = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="자격 증명이 유효하지 않습니다.",
    headers={"WWW-Authenticate": "Bearer"},
)


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    try:
        payload = decode_access_token(token)
    except jwt.PyJWTError:
        raise _credentials_exc

    user_id = payload.get("sub")
    if not user_id:
        raise _credentials_exc

    user = db.get(User, user_id)
    if user is None or not user.is_active:
        raise _credentials_exc
    return user


def require_role(*roles: str) -> Callable[..., User]:
    """지정 역할만 허용. 예: Depends(require_role('admin', 'instructor'))."""

    def _dep(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="접근 권한이 없습니다.",
            )
        return user

    return _dep
