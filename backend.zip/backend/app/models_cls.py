"""분류 학습 로직 — 프론트 models.ts fitClassifier에 대응.

재현성:
  - 분할 seed=42 (repro), 표준화·지표식 포팅 → 로지스틱은 브라우저와 일치.
  - logistic: 커스텀 경사하강(400 iter, lr 0.3)을 numpy로 벡터화(동일 수식, 부동소수점 오차 ~1e-6).
              이진=시그모이드, 다중=One-vs-Rest. → 브라우저 fitClassifier와 일치.
  - rf: sklearn 분류기. 프론트는 'OvR 회귀 포레스트' 자체 구현이라 값이 다르지만,
        트리는 '항상 서버'라 경계 불일치가 없다.
"""
from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.ensemble import RandomForestClassifier

from .metrics_cls import classification_metrics
from .repro import cap_rows, train_test_split_indices, train_test_split_sequential
from .viztree import build_viz_tree_cls

MAX_TREE_ROWS = 20000
# 이 하드코딩 경로에 도달하는 트리 모델은 rf 뿐이다(xgboost/lightgbm/catboost 는 항상 수동 train_classification_manual 경로).
_TREE_ALGOS = {"rf"}


# ───────────── 로지스틱(커스텀 GD 포팅) ─────────────

def _standardize(X: np.ndarray):
    mu = X.mean(axis=0)
    sd = np.sqrt(((X - mu) ** 2).mean(axis=0))
    sd = np.where(sd == 0, 1.0, sd)  # models.ts: sqrt(...) || 1
    Xs = (X - mu) / sd
    return Xs, mu, sd


def _fit_binary_logistic(Xs: np.ndarray, y01: np.ndarray, iters: int = 400, lr: float = 0.3) -> np.ndarray:
    """models.ts fitBinaryLogistic 포팅(벡터화). w[0]=bias."""
    n, k = Xs.shape
    Xb = np.hstack([np.ones((n, 1)), Xs])  # n×(k+1)
    w = np.zeros(k + 1)
    for _ in range(iters):
        z = np.clip(Xb @ w, -30, 30)
        p = 1.0 / (1.0 + np.exp(-z))
        grad = Xb.T @ (p - y01)
        w -= lr * grad / n
    return w


class LogisticModel:
    """브라우저 fitClassifier(로지스틱)와 동일한 예측/확률을 재현하는 모델."""

    def __init__(self, classes: list[str], mu, sd, binary: bool, w=None, pos=None, ws=None):
        self.classes = classes
        self.mu = np.asarray(mu)
        self.sd = np.asarray(sd)
        self.binary = binary
        self.w = None if w is None else np.asarray(w)  # 이진
        self.pos = pos  # 이진 양성 클래스
        self.ws = ws  # 다중: 클래스별 w 리스트

    def _proj(self, X: np.ndarray) -> np.ndarray:
        return (X - self.mu) / self.sd

    def predict_proba(self, X: list[list[float]]) -> list[list[float]]:
        Xs = self._proj(np.asarray(X, dtype=float))
        Xb = np.hstack([np.ones((Xs.shape[0], 1)), Xs])
        if self.binary:
            p = 1.0 / (1.0 + np.exp(-np.clip(Xb @ self.w, -30, 30)))  # P(pos)
            out = []
            for pi in p:
                out.append([float(pi) if c == self.pos else float(1 - pi) for c in self.classes])
            return out
        # 다중 OvR: raw 시그모이드 → 합으로 정규화
        raws = np.stack([1.0 / (1.0 + np.exp(-np.clip(Xb @ w, -30, 30))) for w in self.ws], axis=1)
        s = raws.sum(axis=1, keepdims=True)
        s[s == 0] = 1
        norm = raws / s
        return [[float(v) for v in row] for row in norm]

    def predict_labels(self, X: list[list[float]]) -> list[str]:
        Xs = self._proj(np.asarray(X, dtype=float))
        Xb = np.hstack([np.ones((Xs.shape[0], 1)), Xs])
        if self.binary:
            p = 1.0 / (1.0 + np.exp(-np.clip(Xb @ self.w, -30, 30)))
            return [self.pos if pi >= 0.5 else self.classes[0] for pi in p]  # 프론트와 동일 임계 0.5
        raws = np.stack([1.0 / (1.0 + np.exp(-np.clip(Xb @ w, -30, 30))) for w in self.ws], axis=1)
        idx = raws.argmax(axis=1)  # 정규화 전 raw argmax(프론트와 동일)
        return [self.classes[i] for i in idx]

    def coef_std(self) -> list[float] | None:
        """이진일 때 표준화 계수(bias 제외) — 프론트 coefStd와 동일."""
        return None if not self.binary else [float(v) for v in self.w[1:]]


def _fit_logistic(x_tr: list[list[float]], y_tr: list[str]) -> LogisticModel:
    classes = sorted(set(y_tr))
    X = np.asarray(x_tr, dtype=float)
    Xs, mu, sd = _standardize(X)
    if len(classes) <= 2:
        pos = classes[-1]  # 정렬상 두 번째를 양성
        y01 = np.array([1.0 if v == pos else 0.0 for v in y_tr])
        w = _fit_binary_logistic(Xs, y01)
        return LogisticModel(classes, mu, sd, True, w=w, pos=pos)
    ws = [_fit_binary_logistic(Xs, np.array([1.0 if v == c else 0.0 for v in y_tr])) for c in classes]
    return LogisticModel(classes, mu, sd, False, ws=ws)


# ───────────── 트리(sklearn) ─────────────

class SklearnClsModel:
    """sklearn 분류기 래퍼 — proba 열을 정렬된 classes 순서로 재정렬."""

    def __init__(self, clf: Any, classes: list[str]):
        self.clf = clf
        self.classes = classes
        self._col = [list(clf.classes_).index(c) for c in classes]

    def predict_proba(self, X: list[list[float]]) -> list[list[float]]:
        P = self.clf.predict_proba(X)
        return [[float(row[j]) for j in self._col] for row in P]

    def predict_labels(self, X: list[list[float]]) -> list[str]:
        P = self.predict_proba(X)
        return [self.classes[max(range(len(self.classes)), key=lambda j: row[j])] for row in P]


def _fit_tree(x_tr, y_tr, algo, classes):
    cap = cap_rows(len(x_tr), 7, MAX_TREE_ROWS)
    x_cap = [x_tr[i] for i in cap]
    y_cap = [y_tr[i] for i in cap]
    clf = RandomForestClassifier(
        # 100: 명세(_RF_PARAMS)의 default 와 통일 → 튜닝 안 한 rf 와 기본값으로 튜닝한 rf 가 같은 숲이 된다.
        n_estimators=100, max_depth=9, min_samples_leaf=4,
        max_features=1.0 / 3.0, bootstrap=True, random_state=7, n_jobs=-1,
    )
    clf.fit(x_cap, y_cap)
    importance = [float(v) for v in clf.feature_importances_]
    sampled = {"used": MAX_TREE_ROWS, "total": len(x_tr)} if len(x_tr) > MAX_TREE_ROWS else None
    return SklearnClsModel(clf, classes), importance, sampled


# ───────────── 학습/예측 엔트리 ─────────────

def train_classification(req) -> dict:
    algo = req.algo
    X = [[float(v) for v in row] for row in req.X]
    y = [str(v) for v in req.y]
    features = req.features
    n = len(X)

    split = train_test_split_sequential(n, req.testRatio) if req.sequentialSplit else train_test_split_indices(n, req.testRatio, 42)
    tr, te = split["train"], split["test"]
    x_tr, y_tr = [X[i] for i in tr], [y[i] for i in tr]
    x_te, y_te = [X[i] for i in te], [y[i] for i in te]

    classes = sorted(set(y_tr))
    is_tree = algo in _TREE_ALGOS
    coef = None
    importance = None
    sampled = None

    if is_tree:
        model, importance, sampled = _fit_tree(x_tr, y_tr, algo, classes)
        viz_tree = build_viz_tree_cls(x_tr, y_tr, features, 2)
    else:  # logistic — sklearn LogisticRegression(표준화 입력). 튜닝 기본값(C=1.0)과 동일 모델이 되게 통일.
        #   Pipeline(StandardScaler, LogisticRegression) → est.coef_ 는 표준화 공간 계수(기존 coef_std 와 같은 의미).
        #   수동 경로 기본값(scale 기본 켜짐)과 정확히 같은 구성 → 튜닝 유무와 무관하게 동일 결과(rf 원칙).
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler

        # solver="saga": 튜닝 경로 명세(estimator_kwargs)와 동일하게 맞춰 두 경로가 완전히 같은 계수를 낸다(rf 원칙).
        pipe = Pipeline([("scaler", StandardScaler()), ("model", LogisticRegression(C=1.0, max_iter=1000, random_state=42, solver="saga"))])
        pipe.fit(x_tr, y_tr)
        model = SklearnClsModel(pipe, classes)
        est = pipe.named_steps["model"]
        coef = [float(v) for v in np.ravel(est.coef_)] if len(classes) == 2 else None  # 이진만
        viz_tree = build_viz_tree_cls(x_tr, y_tr, features, 2)

    # 테스트셋 예측/확률 → 지표(프론트 classificationMetrics와 동일)
    pred = model.predict_labels(x_te)
    proba = model.predict_proba(x_te)
    m = classification_metrics(classes, y_te, pred, proba)

    return {
        "model": model,
        "algo": algo,
        "classes": classes,
        "features": features,
        "response": {
            "classes": classes,
            "accuracy": m["accuracy"],
            "confusion": m["confusion"],
            "report": m["report"],
            "coef": coef,
            "importance": importance,
            "vizTree": viz_tree,
            "sampled": sampled,
            "sequentialSplit": req.sequentialSplit,
        },
    }


def train_classification_manual(req, used: dict) -> dict:
    """수동 하이퍼파라미터 분류 학습(V1) — 명세 기반 모델(예: knn).

    기존 파이프라인 재사용:
      - 분할: train_test_split_indices(seed=42) (기존 분류와 동일 홀드아웃).
      - 지표: classification_metrics (정확도·혼동행렬·리포트 동일 산식).
      - 추정기: hyperparams.build_estimator(검증된 used 로 sklearn 인스턴스).
      - 예측 래퍼: SklearnClsModel(proba 열을 sorted classes 순서로 재정렬) 재사용 →
        predict_classification(=/predict 경로)가 그대로 동작한다.
    coef/importance/vizTree 는 KNN 에 없으므로 None. 반환 dict 형태는 train_classification 과 동일하여
    라우터의 저장·응답 코드를 그대로 재사용한다.
    """
    from .hyperparams import build_estimator, resolve_scaling, supports_scaling

    algo = req.algo
    X = [[float(v) for v in row] for row in req.X]
    y = [str(v) for v in req.y]
    features = req.features
    n = len(X)

    split = train_test_split_sequential(n, req.testRatio) if req.sequentialSplit else train_test_split_indices(n, req.testRatio, 42)
    tr, te = split["train"], split["test"]
    x_tr, y_tr = [X[i] for i in tr], [y[i] for i in tr]
    x_te, y_te = [X[i] for i in te], [y[i] for i in te]

    classes = sorted(set(y_tr))
    # 표준화 여부 결정(KNN=기본 켜짐). scale=True 면 Pipeline. SklearnClsModel 은 pipeline.classes_/
    # predict_proba 를 그대로 위임받아 재정렬하므로 무수정 동작한다(누수: 분할 후 x_tr 로만 fit).
    scaled = resolve_scaling("cls", algo, req.scale)  # 실제 적용 여부(불리언)
    # 응답 에코: 스케일 미지원 모델(dtree 등)은 "미해당"이라 None(배지 안 뜸, rf 와 동일). 지원 모델만 True/False.
    scaled_echo = scaled if supports_scaling("cls", algo) else None
    clf = build_estimator("cls", algo, used, scale=scaled)
    clf.fit(x_tr, y_tr)
    model = SklearnClsModel(clf, classes)  # proba 재정렬 래퍼 재사용 → predict 경로 그대로 동작

    pred = model.predict_labels(x_te)
    proba = model.predict_proba(x_te)
    m = classification_metrics(classes, y_te, pred, proba)

    # 중요도·트리 시각화 일반 추출 — feature_importances_ 가 있는 트리 모델(dtree 등)만.
    #   scale=True 면 Pipeline 이므로 최종 추정기(named_steps["model"])에서 접근. KNN/SVC 는 없어 None(불변).
    #   vizTree 는 rf 와 동일 경로(build_viz_tree_cls, 학습 분할 데이터 기준 깊이-2 설명 트리) 재사용.
    est = clf.named_steps["model"] if hasattr(clf, "named_steps") else clf
    has_importance = hasattr(est, "feature_importances_")
    importance = [float(v) for v in est.feature_importances_] if has_importance else None
    # 계수 추출(선형 계열: logistic·SVC linear 등) — 이진일 때만 낸다.
    #   프론트 coef 는 features 길이의 flat 배열을 기대하므로 다중 클래스 coef_(n_classes×n_features)는 형식이 안 맞아 None.
    #   coef_ 가 없는 트리·KNN·SVM(rbf)·MLP 는 종전처럼 None(무변경). scale=True 면 Pipeline 이라 최종 est 에서 접근.
    coef = None
    if len(classes) == 2 and hasattr(est, "coef_"):
        coef = [float(v) for v in np.ravel(est.coef_)]
    # 시각화 깊이 = min(3, max_depth). max_depth=None(제한 없음)이면 상한 3. (rf 는 이 경로가 아니라 2 유지)
    #   실제 학습 트리는 더 깊을 수 있으나, 가독을 위해 설명용 트리는 3까지만 그린다(프론트가 안내).
    md = used.get("max_depth")
    viz_depth = 3 if md is None else min(3, int(md))
    viz_tree = build_viz_tree_cls(x_tr, y_tr, features, viz_depth) if has_importance else None

    return {
        "model": model,
        "algo": algo,
        "classes": classes,
        "features": features,
        "response": {
            "classes": classes,
            "accuracy": m["accuracy"],
            "confusion": m["confusion"],
            "report": m["report"],
            "coef": coef,
            "importance": importance,
            "vizTree": viz_tree,
            "sampled": None,
            "scaled": scaled_echo,
            "sequentialSplit": req.sequentialSplit,
        },
    }


def predict_classification(model, X: list[list[float]]) -> dict:
    rows = [[float(v) for v in row] for row in X]
    return {
        "predictions": model.predict_labels(rows),
        "proba": model.predict_proba(rows),
        "classes": list(model.classes),
    }
