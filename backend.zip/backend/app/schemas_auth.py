"""인증 API 스키마(L2b·L2c). password_hash·token_hash 는 절대 노출하지 않는다."""
from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class LoginRequest(BaseModel):
    """JSON 로그인 본문(폼 OAuth2PasswordRequestForm 과 별개로 JSON 도 지원)."""

    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # access 만료(초)


class RefreshRequest(BaseModel):
    refresh_token: str


class LogoutRequest(BaseModel):
    refresh_token: str


class UserOut(BaseModel):
    """현재 사용자 공개 정보 — 해시류 필드 없음."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    email: EmailStr
    username: str | None
    role: str
    organization_id: str | None
    group_id: str | None
    auth_provider: str
    is_active: bool
    must_change_password: bool
    created_at: datetime
    last_login_at: datetime | None


# ── 계정 발급(L2c) ────────────────────────────────────────
class UserCreate(BaseModel):
    """계정 발급 요청. password 미지정 시 서버가 임시 비번을 생성한다."""

    email: EmailStr
    role: Literal["admin", "instructor", "member"]
    # 미지정(None) → 서버 생성. 지정 시 최소 길이 강제.
    password: str | None = Field(default=None, min_length=8)
    username: str | None = None
    organization_id: str | None = None
    group_id: str | None = None


class UserCreateOut(UserOut):
    """발급 응답 — 서버가 임시 비번을 생성한 경우에만 temp_password 를 1회 반환(이후 조회 불가)."""

    temp_password: str | None = None


class ResetPasswordOut(BaseModel):
    """비번 재발급 응답 — 새 임시 비번을 1회 반환(이후 조회 불가). password_hash 미포함."""

    temp_password: str


class UserUpdate(BaseModel):
    """멤버 정보 부분 수정(PATCH). 전달된 필드만 수정한다.

    - group_id: None 전달 = 그룹 해제, 미전달 = 변경 안 함(모델 필드 set 여부로 구분).
    - username: None/공백 = 이름 해제.
    - role: 변경 시 권한 정책·자기자신 방지 검증(라우터).
    이메일·organization_id 는 이번 범위에서 수정하지 않는다.
    """

    username: str | None = None
    group_id: str | None = None
    role: Literal["admin", "instructor", "member"] | None = None


class PasswordChange(BaseModel):
    """비밀번호 변경. must_change_password=true 인 최초 변경은 current_password 없이 허용."""

    current_password: str | None = None
    new_password: str = Field(min_length=8)
