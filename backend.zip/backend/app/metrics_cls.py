"""분류 지표 — models.ts classificationMetrics + aucScore 포팅.

브라우저와 동일 산식: 혼동행렬, 정밀도/재현율/F1/support, AUC(Mann-Whitney), 정확도. 모두 소수 3자리.
로지스틱은 예측/확률이 브라우저와 일치하므로 이 지표도 일치한다.
"""
from __future__ import annotations

import math

from .repro import round3


def auc_score(scores: list[float], labels: list[int]) -> float:
    """Mann-Whitney U 순위 기반 AUC. labels: 1(양성)/0(음성). (models.ts aucScore 포팅)"""
    n = len(scores)
    order = sorted(range(n), key=lambda i: scores[i])  # 안정 정렬(프론트 JS sort와 동일 결과)
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and scores[order[j + 1]] == scores[order[i]]:
            j += 1
        avg = (i + j) / 2 + 1  # 1-based 평균 순위(동점 처리)
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    sum_pos = 0.0
    n_pos = 0
    n_neg = 0
    for k in range(n):
        if labels[k] == 1:
            sum_pos += ranks[k]
            n_pos += 1
        else:
            n_neg += 1
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    return (sum_pos - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)


def classification_metrics(classes: list[str], y_true: list[str], pred_labels: list[str], probas: list[list[float]] | None) -> dict:
    ci = {c: i for i, c in enumerate(classes)}
    confusion = [[0 for _ in classes] for _ in classes]
    for i in range(len(y_true)):
        a = ci.get(y_true[i])
        p = ci.get(pred_labels[i])
        if a is None or p is None:
            continue
        confusion[a][p] += 1

    report = []
    correct = 0
    total = 0
    for i, c in enumerate(classes):
        tp = confusion[i][i]
        support = sum(confusion[i])
        pred_count = sum(confusion[r][i] for r in range(len(classes)))
        precision = tp / pred_count if pred_count else 0.0
        recall = tp / support if support else 0.0
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
        correct += tp
        total += support
        auc = None
        if probas is not None:
            a = auc_score([p[i] for p in probas], [1 if v == c else 0 for v in y_true])
            auc = None if math.isnan(a) else round3(a)
        report.append({
            "cls": c,
            "precision": round3(precision),
            "recall": round3(recall),
            "f1": round3(f1),
            "support": support,
            "auc": auc,
        })
    accuracy = round3(correct / total) if total else 0.0
    return {"accuracy": accuracy, "confusion": confusion, "report": report}
