"""모델 라우터 — POST /models/train, /models/{id}/predict, DELETE.

train은 task로 회귀/분류 분기(응답 형태가 달라 dict로 반환).
predict는 저장된 task에 따라 회귀(숫자) / 분류(라벨+확률)를 반환.
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..async_jobs import reap_if_stalled, start_tuning_job
from ..db import get_db
from ..hyperparams import (
    LSTM_TIME_LIMIT_SEC,
    TRANSFORMER_TIME_LIMIT_SEC,
    estimate_lstm_seconds,
    estimate_transformer_seconds,
    list_specs,
    validate_params,
)
from ..models_cls import predict_classification, train_classification, train_classification_manual
from ..models_db import TuningJob
from ..models_reg import predict_regression, train_regression, train_regression_manual
from ..schemas import ClsTrainResponse, PredictRequest, PredictResponse, TrainRequest, TrainResponse
from ..store import store
from ..tuning import TUNABLE_ALGOS

router = APIRouter(prefix="/models", tags=["models"])

# 분류 목표의 최대 허용 클래스 수 — 이보다 많으면 학습 전 400 으로 거부(OOM 방어).
#   프론트는 목표 후보를 고유값 ≤20 으로 더 엄격히 거르지만, 직접 API 호출·엣지 대비 백엔드 백스톱(느슨한 50).
MAX_CLS_CLASSES = 50

# 사전 시간 가드 대상(딥러닝) — 학습 시작 전 예상 시간을 추정해 한도 초과면 400. 모델별 (추정함수, 한도(초), 조정 팁) 매핑.
#   LSTM 하드코딩 분기를 일반화한 것 — lstm 항목은 기존과 완전히 동일(같은 함수·한도·팁 → 같은 추정·같은 400 메시지).
_TIME_GUARDED: dict[str, tuple[Any, int, str]] = {
    "lstm": (estimate_lstm_seconds, LSTM_TIME_LIMIT_SEC, "window·은닉 크기(hidden_units)·층수(num_layers)"),
    "transformer": (estimate_transformer_seconds, TRANSFORMER_TIME_LIMIT_SEC, "모델 차원(d_model)·층수(num_layers)"),
}


@router.get("/hyperparams")
def hyperparams() -> dict:
    """수동 조정용 하이퍼파라미터 명세를 반환(단일 원천, T1).

    인증: models.router 전체에 라우터-레벨 get_current_user 게이트가 걸려 있어(main.py)
    이 엔드포인트도 로그인 필수(무인증 → 401)로 계산 API 정책과 일관된다.
    명세는 정적이라 매 요청 계산 부담이 없다.
    """
    return {"specs": list_specs()}


@router.post("/train")
def train(req: TrainRequest) -> Any:
    if not req.X or not req.features:
        raise HTTPException(status_code=400, detail="X 또는 features가 비어 있습니다.")

    # ⚠ 범주 폭주 방어(분류 전용) — ★★ 비동기 job 생성·튜닝·학습·행렬 생성 어느 것보다 '먼저'.
    #   목표에 고유값이 너무 많으면(예: 날짜·ID) 클래스²(혼동행렬)·계수행렬이 폭발해 OOM 으로 죽는다("서버 연결 실패"로 오인).
    #   방어가 나중이면 job 이 만들어졌다가 백그라운드에서 죽어 failed 로 남고, 사용자는 '진행 중'으로 보다 실패를 겪는다.
    #   그래서 클래스 수만 세어 여기서 즉시 거부한다(프론트 필터를 우회한 직접 호출 대비).
    if req.task == "cls":
        n_classes = len({str(v) for v in req.y})
        if n_classes > MAX_CLS_CLASSES:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"범주가 너무 많아 분류할 수 없습니다(목표 변수를 확인하세요). 현재 범주 {n_classes:,}개 "
                    f"(최대 {MAX_CLS_CLASSES}개). 날짜·ID처럼 값이 거의 다 다른 컬럼은 분류 목표로 적합하지 않아요."
                ),
            )

    # 하이퍼파라미터 검증(항상 호출). params 없는 기존 6종은 {} 반환 → 무영향(하위호환).
    #   위반은 ValueError → 400 으로 변환(어떤 파라미터가 왜 틀렸는지 한글 메시지 그대로 전달).
    try:
        used = validate_params(req.task, req.algo, req.params)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # ⚠ 딥러닝 자원 방어선(과거 사건: 프론트 타임아웃 후에도 서버가 장시간 학습). 학습 시작 전에 예상 시간을 추정해
    #   한도 초과면 400 으로 막는다 → 유령 학습·자원 낭비 차단. 대상(_TIME_GUARDED: lstm·transformer)만 해당, 그 외 무영향.
    guard = _TIME_GUARDED.get(req.algo)
    if guard is not None:
        estimate_fn, limit_sec, tuning_tips = guard
        # 표 데이터 transformer 추정은 피처수(시퀀스 길이)에 의존 → n_features 를 추정 전용 dict 로 주입(used 는 불변).
        #   lstm 추정은 이 키를 무시하므로 동작이 완전히 동일하다(LSTM 무손상).
        est = estimate_fn(len(req.X), req.testRatio, {**used, "n_features": len(req.features)})
        if est > limit_sec:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"예상 학습 시간이 약 {round(est)}초로 한도({limit_sec}초)를 넘어요. "
                    f"{tuning_tips}를 낮추거나 데이터를 줄여 주세요."
                ),
            )

    # 자동 튜닝(Optuna) rf·xgb → 비동기(백그라운드+폴링). 즉시 jobId 반환(학습 완료를 기다리지 않음).
    #   상태는 DB(tuning_jobs)에 저장 → GET /models/train/status/{jobId} 로 폴링(멀티 워커 일관).
    #   ⚠ 일반 학습(tune=false)·미지원 algo 는 아래 기존 동기 경로 그대로(무변경).
    if req.tune and req.algo in TUNABLE_ALGOS:
        job_id = start_tuning_job(req)
        return {"jobId": job_id}

    if req.task == "reg":
        if req.algo not in {"linear", "rf", "knn", "svr", "ridge", "lasso", "elasticnet", "xgboost", "lightgbm", "catboost", "mlp", "lstm", "transformer"}:
            raise HTTPException(status_code=400, detail=f"지원하지 않는 회귀 알고리즘: {req.algo}")
        # 수동 튜닝 경로: knn/svr/ridge/lasso/elasticnet/xgboost/lightgbm/catboost/mlp/lstm/transformer 는 항상, rf 는 params 가 있을 때만(없으면 기존 하드코딩 경로 = 하위호환).
        tuned = req.algo in {"knn", "svr", "ridge", "lasso", "elasticnet", "xgboost", "lightgbm", "catboost", "mlp", "lstm", "transformer"} or (req.algo == "rf" and bool(req.params))
        result = train_regression_manual(req, used) if tuned else train_regression(req)
        model_id = store.put_model(result["model"], result["algo"], result["features"], task="reg")
        return TrainResponse(model_id=model_id, usedParams=((used or None) if tuned else None), bestParams=None, **result["response"])

    if req.task == "cls":
        if req.algo not in {"logistic", "rf", "knn", "svc", "dtree", "xgboost", "lightgbm", "catboost", "mlp"}:
            raise HTTPException(status_code=400, detail=f"지원하지 않는 분류 알고리즘: {req.algo}")
        # 수동 튜닝 경로: knn/svc/dtree/xgboost/lightgbm/catboost/mlp 는 항상, rf·logistic 은 params 가 있을 때만(없으면 기존 하드코딩 경로 = 하위호환).
        #   (클래스 수 방어는 함수 상단에서 이미 통과 — job 생성보다 앞.)
        tuned = req.algo in {"knn", "svc", "dtree", "xgboost", "lightgbm", "catboost", "mlp"} or (req.algo in {"rf", "logistic"} and bool(req.params))
        result = train_classification_manual(req, used) if tuned else train_classification(req)
        model_id = store.put_model(
            result["model"], result["algo"], result["features"], task="cls", classes=result["classes"]
        )
        return ClsTrainResponse(model_id=model_id, usedParams=((used or None) if tuned else None), bestParams=None, **result["response"])

    raise HTTPException(status_code=400, detail=f"알 수 없는 task: {req.task}")


@router.get("/train/status/{job_id}")
def train_status(job_id: str, db: Session = Depends(get_db)) -> Any:
    """비동기 튜닝 작업 상태 폴링 — DB(tuning_jobs)에서 조회하므로 어느 워커가 받아도 일관.

    status: running/done/failed. done 이면 result(동기 학습과 동일한 TrainResponse 형태)를 반환한다.
    조회 시 '멈춘 작업 감지'를 적용 — running 인데 updated_at 이 오래 낡았으면(스레드 증발 등) failed 로 전환.
    """
    job = db.get(TuningJob, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다(만료되었을 수 있음).")
    reap_if_stalled(db, job)  # running 인데 갱신이 오래 끊겼으면 failed 로 전환(영원한 진행바 방지)
    return {
        "jobId": job.id,
        "status": job.status,
        "progress": job.progress,
        "total": job.total,
        "bestScore": job.best_score,
        "bestParams": job.best_params,
        "result": job.result if job.status == "done" else None,
        "error": job.error,
    }


@router.post("/train/cancel/{job_id}")
def train_cancel(job_id: str, db: Session = Depends(get_db)) -> dict:
    """비동기 튜닝 작업 협조적 취소 — cancelled=True 로 세팅한다(DB 라 멀티 워커 간 공유).

    실행부(run_tuning_job)의 튜닝 콜백이 매 trial 이 플래그를 확인해 study.stop() → 다음 trial 을
    시작하지 않고 멈춘다(진행 중 trial 1개는 완주). 스레드 강제 종료가 아니라 '협조적 취소'다.
    멱등: 이미 끝난(done/failed/cancelled) 작업은 그대로 두고 현재 상태만 돌려준다(에러 아님).
    """
    job = db.get(TuningJob, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다(만료되었을 수 있음).")
    if job.status in ("done", "failed", "cancelled"):
        return {"jobId": job.id, "status": job.status, "cancelled": job.cancelled}
    job.cancelled = True
    db.commit()
    return {"jobId": job.id, "status": job.status, "cancelled": True}


@router.post("/{model_id}/predict", response_model=PredictResponse)
def predict(model_id: str, req: PredictRequest) -> PredictResponse:
    entry = store.get_model(model_id)
    if entry is None:
        # 만료/부재 → 404 (프론트 MissingModelError로 재학습 유도)
        raise HTTPException(status_code=404, detail="모델을 찾을 수 없습니다(만료되었을 수 있음). 다시 학습해 주세요.")
    if entry.task == "cls":
        out = predict_classification(entry.model, req.X)
        return PredictResponse(predictions=out["predictions"], proba=out["proba"], classes=out["classes"])
    preds = predict_regression(entry.model, req.X)
    return PredictResponse(predictions=preds)


@router.delete("/{model_id}")
def delete_model(model_id: str) -> dict:
    ok = store.delete_model(model_id)
    if not ok:
        raise HTTPException(status_code=404, detail="이미 없거나 만료된 model_id 입니다.")
    return {"deleted": model_id}
