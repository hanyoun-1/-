"""감사 로그 조회 라우터 — GET /audit-logs.

권한: admin(전체) / instructor(자기 기업 로그만) / member 는 require_role 에서 차단(403).
페이지네이션: limit/offset. 응답에 민감정보 없음(애초에 저장 안 함).
"""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import require_role
from ..models_db import AuditLog, User

router = APIRouter(prefix="/audit-logs", tags=["audit"])


class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    created_at: datetime
    actor_user_id: str | None
    actor_email: str | None
    actor_role: str | None
    action: str
    target_user_id: str | None
    target_email: str | None
    organization_id: str | None
    detail: str | None


@router.get("", response_model=list[AuditLogOut])
def list_audit_logs(
    viewer: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> list[AuditLog]:
    stmt = select(AuditLog).order_by(AuditLog.created_at.desc())
    # instructor 는 자기 기업 대상 로그만(소속 없으면 빈 목록).
    if viewer.role == "instructor":
        if not viewer.organization_id:
            return []
        stmt = stmt.where(AuditLog.organization_id == viewer.organization_id)
    return list(db.scalars(stmt.limit(limit).offset(offset)))
