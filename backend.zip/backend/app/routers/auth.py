"""인증 라우터(L2b) — /auth/login, /auth/refresh, /auth/logout, /auth/me.

- login: 이메일+비밀번호 검증 → access(JWT) + refresh(DB에 해시 저장) 발급.
- refresh: 원문 refresh → 해시 조회 → 유효하면 회전(기존 폐기 + 신규 발급). 폐기된 토큰 재사용 시 유저 전체 폐기 + 401.
- logout: 현재 refresh 폐기.
- me: 현재 사용자 공개 정보(해시류 제외).

계정 발급/시드 admin/계산 API 보호는 다음 단계(L2c) — 여기서는 인증 엔드포인트만.
"""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import get_current_user
from ..models_db import RefreshToken, User
from ..schemas_auth import LogoutRequest, PasswordChange, RefreshRequest, TokenResponse, UserOut
from ..security import (
    create_access_token,
    generate_refresh_token,
    hash_password,
    hash_refresh_token,
    refresh_expiry,
    verify_password,
)
from ..settings import settings

router = APIRouter(prefix="/auth", tags=["auth"])

_bad_credentials = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="이메일 또는 비밀번호가 올바르지 않습니다.",
    headers={"WWW-Authenticate": "Bearer"},
)
_bad_refresh = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="리프레시 토큰이 유효하지 않습니다.",
    headers={"WWW-Authenticate": "Bearer"},
)
# 인증(이메일·비번)은 성공했으나 계정이 비활성인 경우만 별도 안내(존재 노출 위험 없음).
_inactive_account = HTTPException(
    status_code=status.HTTP_403_FORBIDDEN,
    detail="비활성화된 계정입니다. 담당자에게 문의하세요.",
)


def _naive_utc_now() -> datetime:
    """SQLite DateTime 은 tz 를 저장하지 않으므로 naive UTC 로 통일해 비교/기록한다."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _strip_tz(dt: datetime) -> datetime:
    return dt.replace(tzinfo=None) if dt.tzinfo is not None else dt


def _issue_tokens(db: Session, user: User) -> TokenResponse:
    """access + 신규 refresh(DB 저장) 발급 공통 로직."""
    access = create_access_token(user_id=user.id, role=user.role, org_id=user.organization_id)
    raw_refresh, token_hash = generate_refresh_token()
    db.add(
        RefreshToken(
            user_id=user.id,
            token_hash=token_hash,
            expires_at=_strip_tz(refresh_expiry()),
        )
    )
    return TokenResponse(
        access_token=access,
        refresh_token=raw_refresh,
        expires_in=settings.access_token_expire_minutes * 60,
    )


@router.post("/login", response_model=TokenResponse)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)) -> TokenResponse:
    # OAuth2PasswordRequestForm.username 을 email 로 사용.
    user = db.scalar(select(User).where(User.email == form.username))
    # 이메일 없음·비번 틀림은 뭉뚱그려 401(계정 존재 노출 방지).
    if user is None or not verify_password(form.password, user.password_hash or ""):
        raise _bad_credentials
    # 비번은 맞으나 비활성 → 명확 안내(이미 자격증명을 아는 요청자에게만).
    if not user.is_active:
        raise _inactive_account

    user.last_login_at = _naive_utc_now()
    resp = _issue_tokens(db, user)
    db.commit()
    return resp


@router.post("/refresh", response_model=TokenResponse)
def refresh(body: RefreshRequest, db: Session = Depends(get_db)) -> TokenResponse:
    token_hash = hash_refresh_token(body.refresh_token)
    row = db.scalar(select(RefreshToken).where(RefreshToken.token_hash == token_hash))
    if row is None:
        raise _bad_refresh

    # 재사용 감지: 이미 폐기된 토큰이 다시 쓰이면 도난으로 간주 → 해당 유저 전체 폐기.
    if row.revoked_at is not None:
        now = _naive_utc_now()
        for t in db.scalars(
            select(RefreshToken).where(RefreshToken.user_id == row.user_id, RefreshToken.revoked_at.is_(None))
        ):
            t.revoked_at = now
        db.commit()
        raise _bad_refresh

    if _strip_tz(row.expires_at) < _naive_utc_now():
        raise _bad_refresh

    user = db.get(User, row.user_id)
    if user is None or not user.is_active:
        raise _bad_refresh

    # 회전: 기존 refresh 폐기 + 신규 발급.
    row.revoked_at = _naive_utc_now()
    resp = _issue_tokens(db, user)
    db.commit()
    return resp


@router.post("/logout")
def logout(body: LogoutRequest, db: Session = Depends(get_db)) -> dict:
    token_hash = hash_refresh_token(body.refresh_token)
    row = db.scalar(select(RefreshToken).where(RefreshToken.token_hash == token_hash))
    if row is not None and row.revoked_at is None:
        row.revoked_at = _naive_utc_now()
        db.commit()
    # 토큰 존재 여부를 노출하지 않기 위해 항상 동일 응답.
    return {"status": "ok"}


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)) -> User:
    return user


@router.post("/change-password")
def change_password(
    body: PasswordChange,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    # must_change_password(최초 강제 변경)가 아니면 current_password 필수+검증.
    if not user.must_change_password:
        if not body.current_password or not verify_password(body.current_password, user.password_hash or ""):
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "현재 비밀번호가 올바르지 않습니다.")

    user.password_hash = hash_password(body.new_password)
    user.must_change_password = False

    # 정책: 비밀번호 변경 시 기존 refresh 전량 폐기(재로그인 유도).
    now = _naive_utc_now()
    for t in db.scalars(
        select(RefreshToken).where(RefreshToken.user_id == user.id, RefreshToken.revoked_at.is_(None))
    ):
        t.revoked_at = now
    db.commit()
    return {"status": "ok"}
