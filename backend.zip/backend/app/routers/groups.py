"""그룹(groups) 관리 라우터(M1).

권한 정책:
- POST /groups: admin + instructor.
    · admin → 임의 기업에 생성 가능.
    · instructor → organization_id 가 자기 기업이 아니면 403.
                   instructor_id 지정 시 자기 자신만 허용(타인 지정 403). 미지정 허용.
- GET /groups: admin + instructor. organization_id 쿼리로 필터 가능.
    · admin → 전체(또는 organization_id 필터).
    · instructor → 자기 기업 그룹만(필터가 타 기업이면 빈 목록).
- member → 403(require_role 에서 차단).

UNIQUE(organization_id, name) 위반 시 409. 존재하지 않는 기업이면 404.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import require_role
from ..models_db import Group, Organization, User
from ..schemas_org import GroupCreate, GroupOut

router = APIRouter(prefix="/groups", tags=["groups"])


@router.post("", response_model=GroupOut, status_code=status.HTTP_201_CREATED)
def create_group(
    payload: GroupCreate,
    creator: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> Group:
    # 기업 존재 확인.
    if db.get(Organization, payload.organization_id) is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "존재하지 않는 기업(organization)입니다.")

    if creator.role == "instructor":
        if creator.organization_id != payload.organization_id:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "자기 기업에만 그룹을 만들 수 있습니다.")
        # instructor 는 담당 강사를 자기 자신으로만 지정 가능(미지정도 허용).
        if payload.instructor_id not in (None, creator.id):
            raise HTTPException(status.HTTP_403_FORBIDDEN, "다른 강사를 담당으로 지정할 수 없습니다.")

    group = Group(
        organization_id=payload.organization_id,
        name=payload.name.strip(),
        instructor_id=payload.instructor_id,
    )
    db.add(group)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status.HTTP_409_CONFLICT, "같은 기업에 같은 이름의 그룹이 이미 있습니다.")
    db.refresh(group)
    return group


@router.get("", response_model=list[GroupOut])
def list_groups(
    user: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
    organization_id: str | None = Query(default=None),
) -> list[Group]:
    stmt = select(Group).order_by(Group.created_at)

    if user.role == "instructor":
        # 자기 기업으로 강제 스코프. 소속 없으면 빈 목록.
        if not user.organization_id:
            return []
        # 필터가 타 기업을 가리키면 빈 목록(자기 기업 밖은 볼 수 없음).
        if organization_id is not None and organization_id != user.organization_id:
            return []
        stmt = stmt.where(Group.organization_id == user.organization_id)
    elif organization_id is not None:
        stmt = stmt.where(Group.organization_id == organization_id)

    return list(db.scalars(stmt))
