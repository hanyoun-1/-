"""계정 발급 라우터(L2c) — POST /users, GET /users.

발급 정책(서버에서 강제):
- admin: 모든 역할·모든 기관 발급 가능.
- instructor: role='member' 만, 자기 organization_id 범위만. group 지정 시 자기 기관·자기 반이어야 함.
- member: 발급 불가(require_role 에서 차단).

발급 계정은 must_change_password=true, 비밀번호는 해싱 저장. 공개 회원가입은 없음(발급만).
"""
from __future__ import annotations

import secrets
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit import record_audit
from ..db import get_db
from ..deps import require_role
from ..models_db import Group, Organization, RefreshToken, User
from ..schemas_auth import ResetPasswordOut, UserCreate, UserCreateOut, UserOut, UserUpdate
from ..security import hash_password

router = APIRouter(prefix="/users", tags=["users"])


def _naive_utc_now() -> datetime:
    # SQLite DateTime 은 tz 미저장 → naive UTC 로 통일(auth.py 와 동일 규칙).
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _generate_temp_password() -> str:
    """발급/재발급 공통 임시 비번 생성(POST /users 와 동일 방식)."""
    return secrets.token_urlsafe(12)


def _revoke_all_refresh(db: Session, user_id: str) -> None:
    """해당 유저의 미폐기 refresh 를 전량 폐기(즉시 세션 무효화)."""
    now = _naive_utc_now()
    for t in db.scalars(
        select(RefreshToken).where(RefreshToken.user_id == user_id, RefreshToken.revoked_at.is_(None))
    ):
        t.revoked_at = now


def _get_target_in_scope(user_id: str, actor: User, db: Session) -> User:
    """대상 멤버 조회 + 스코프 검사. instructor 는 자기 기업만(타 기업/부재는 404 로 존재 감춤)."""
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "멤버를 찾을 수 없습니다.")
    if actor.role == "instructor" and target.organization_id != actor.organization_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "멤버를 찾을 수 없습니다.")
    return target


def _validate_scope(creator: User, payload: UserCreate, db: Session) -> None:
    """발급자 권한 스코프 검사. 위반 시 403/400."""
    if creator.role == "instructor":
        if payload.role != "member":
            raise HTTPException(status.HTTP_403_FORBIDDEN, "강사는 학생 계정만 발급할 수 있습니다.")
        if not creator.organization_id:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "소속 기관이 없는 강사는 계정을 발급할 수 없습니다.")
        # 자기 기관만: organization_id 미지정이면 강사 기관으로 강제, 지정 시 일치해야 함.
        if payload.organization_id not in (None, creator.organization_id):
            raise HTTPException(status.HTTP_403_FORBIDDEN, "다른 기관에는 계정을 발급할 수 없습니다.")
        if payload.group_id is not None:
            group = db.get(Group, payload.group_id)
            if group is None:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, "존재하지 않는 반(group)입니다.")
            if group.organization_id != creator.organization_id or group.instructor_id != creator.id:
                raise HTTPException(status.HTTP_403_FORBIDDEN, "자기 반에만 학생을 배정할 수 있습니다.")
    else:  # admin — 참조 무결성만 확인.
        if payload.organization_id is not None and db.get(Organization, payload.organization_id) is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "존재하지 않는 기관(organization)입니다.")
        if payload.group_id is not None and db.get(Group, payload.group_id) is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "존재하지 않는 반(group)입니다.")


@router.post("", response_model=UserCreateOut, status_code=status.HTTP_201_CREATED)
def create_user(
    payload: UserCreate,
    creator: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> UserCreateOut:
    _validate_scope(creator, payload, db)

    if db.scalar(select(User).where(User.email == payload.email)) is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "이미 사용 중인 이메일입니다.")

    # 비밀번호: 미지정 시 서버가 임시 생성(1회성으로 응답 반환).
    temp_password = None
    raw_password = payload.password
    if raw_password is None:
        raw_password = secrets.token_urlsafe(12)
        temp_password = raw_password

    # instructor 발급 시 기관은 항상 자기 기관으로 고정.
    org_id = creator.organization_id if creator.role == "instructor" else payload.organization_id

    user = User(
        email=payload.email,
        username=payload.username,
        password_hash=hash_password(raw_password),
        role=payload.role,
        organization_id=org_id,
        group_id=payload.group_id,
        must_change_password=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    record_audit(db, actor=creator, action="create_user", target=user)  # best-effort

    out = UserOut.model_validate(user).model_dump()
    return UserCreateOut(**out, temp_password=temp_password)


@router.get("", response_model=list[UserOut])
def list_users(
    creator: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> list[User]:
    stmt = select(User).order_by(User.created_at)
    # instructor 는 자기 기관으로 스코프 제한(admin 은 전체).
    if creator.role == "instructor":
        stmt = stmt.where(User.organization_id == creator.organization_id)
    return list(db.scalars(stmt))


@router.patch("/{user_id}/deactivate", response_model=UserOut)
def deactivate_user(
    user_id: str,
    actor: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> User:
    # 자기 자신 비활성화 방지(실수로 스스로 잠그는 것 차단).
    if user_id == actor.id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "자기 계정은 비활성화할 수 없습니다.")
    target = _get_target_in_scope(user_id, actor, db)

    target.is_active = False
    _revoke_all_refresh(db, target.id)  # 즉시 로그인 차단
    db.commit()
    db.refresh(target)
    record_audit(db, actor=actor, action="deactivate", target=target)
    return target


@router.patch("/{user_id}/activate", response_model=UserOut)
def activate_user(
    user_id: str,
    actor: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> User:
    target = _get_target_in_scope(user_id, actor, db)
    target.is_active = True
    db.commit()
    db.refresh(target)
    record_audit(db, actor=actor, action="activate", target=target)
    return target


@router.post("/{user_id}/reset-password", response_model=ResetPasswordOut)
def reset_password(
    user_id: str,
    actor: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> ResetPasswordOut:
    target = _get_target_in_scope(user_id, actor, db)

    # 새 임시 비번 생성 → 해싱 저장 → 최초 변경 강제 → 기존 세션 전량 무효화.
    temp_password = _generate_temp_password()
    target.password_hash = hash_password(temp_password)
    target.must_change_password = True
    _revoke_all_refresh(db, target.id)
    db.commit()
    # 임시비번 값은 저장하지 않는다 — '재발급함' 사실만 기록.
    record_audit(db, actor=actor, action="reset_password", target=target)
    return ResetPasswordOut(temp_password=temp_password)


def _apply_role_change(actor: User, target: User, new_role: str) -> None:
    """역할 변경 정책 검증(위반 시 400/403). 통과 시 target.role 을 갱신한다."""
    # 자기 자신 역할 변경 금지(admin·instructor 공통).
    if target.id == actor.id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "자기 계정의 역할은 변경할 수 없습니다.")
    if actor.role == "instructor":
        # 담당자는 관리자 관련 변경 불가, member <-> instructor 만 허용(대상은 이미 자기 기업).
        if new_role == "admin" or target.role == "admin":
            raise HTTPException(status.HTTP_403_FORBIDDEN, "담당자는 관리자 역할을 다룰 수 없습니다.")
        if (target.role, new_role) not in {("member", "instructor"), ("instructor", "member")}:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "허용되지 않은 역할 변경입니다.")
    # admin 은 임의 role 허용(자기 자신 제외 — 위에서 차단).
    target.role = new_role


@router.patch("/{user_id}", response_model=UserOut)
def update_user(
    user_id: str,
    payload: UserUpdate,
    actor: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> User:
    target = _get_target_in_scope(user_id, actor, db)
    fields = payload.model_fields_set  # 전달된 필드만 수정(null 전달과 미전달 구분)

    # 이름: 공백/빈값 → 해제(None).
    if "username" in fields:
        name = (payload.username or "").strip()
        target.username = name or None

    # 그룹 재배정: None = 해제, 값 = 존재 + (instructor면 자기 기업) 검증.
    if "group_id" in fields:
        if payload.group_id is None:
            target.group_id = None
        else:
            group = db.get(Group, payload.group_id)
            if group is None:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, "존재하지 않는 그룹입니다.")
            if actor.role == "instructor" and group.organization_id != actor.organization_id:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, "자기 기업의 그룹만 지정할 수 있습니다.")
            target.group_id = group.id

    # 역할: 실제로 바뀌는 경우에만 검증·폐기.
    role_changed = False
    old_role: str | None = None
    if "role" in fields and payload.role is not None and payload.role != target.role:
        old_role = target.role  # 변경 전 역할(감사 detail 용)
        _apply_role_change(actor, target, payload.role)
        role_changed = True

    # 역할이 바뀌면 기존 토큰의 role claim 이 어긋나므로 refresh 전량 폐기(재로그인 유도).
    if role_changed:
        _revoke_all_refresh(db, target.id)

    db.commit()
    db.refresh(target)
    # 역할이 실제로 바뀐 경우에만 기록(이름·그룹 수정은 기록 대상 아님).
    if role_changed:
        record_audit(db, actor=actor, action="change_role", target=target, detail=f"{old_role}→{target.role}")
    return target
