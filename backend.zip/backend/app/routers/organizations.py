"""기업(organizations) 관리 라우터(M1).

권한 정책:
- POST /organizations: admin 만.
- GET /organizations, GET /organizations/{id}: 로그인 필요.
    · admin → 전체.
    · instructor → 자기 organization_id 만.
    · member → 403(require_role 에서 차단).

기업명(name)은 UNIQUE 를 강제하지 않는다 — 회사명이 겹칠 수 있어 현실적으로 중복을 허용한다
(테이블에도 name UNIQUE 없음). 필요하면 상위(UI)에서 중복 확인.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import require_role
from ..models_db import Organization, User
from ..schemas_org import OrganizationCreate, OrganizationOut

router = APIRouter(prefix="/organizations", tags=["organizations"])


@router.post("", response_model=OrganizationOut, status_code=status.HTTP_201_CREATED)
def create_organization(
    payload: OrganizationCreate,
    _admin: User = Depends(require_role("admin")),
    db: Session = Depends(get_db),
) -> Organization:
    org = Organization(name=payload.name.strip())
    db.add(org)
    db.commit()
    db.refresh(org)
    return org


@router.get("", response_model=list[OrganizationOut])
def list_organizations(
    user: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> list[Organization]:
    stmt = select(Organization).order_by(Organization.created_at)
    if user.role == "instructor":
        # 자기 기업만(보통 1건). 소속이 없으면 빈 목록.
        if not user.organization_id:
            return []
        stmt = stmt.where(Organization.id == user.organization_id)
    return list(db.scalars(stmt))


@router.get("/{org_id}", response_model=OrganizationOut)
def get_organization(
    org_id: str,
    user: User = Depends(require_role("admin", "instructor")),
    db: Session = Depends(get_db),
) -> Organization:
    # instructor 는 자기 기업만 조회 가능(타 기업이면 존재 여부 노출 없이 404).
    if user.role == "instructor" and user.organization_id != org_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "기업을 찾을 수 없습니다.")
    org = db.get(Organization, org_id)
    if org is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "기업을 찾을 수 없습니다.")
    return org
