"""계정 시스템 ORM 모델(L2a) — Organization / Group / User / RefreshToken.

계산 로직 파일(models_reg.py / models_cls.py)과 이름이 겹치지 않도록 models_db.py 로 둔다.
설계 문서(L1)의 MVP 4테이블만 정의한다(다대다 group_instructors 는 제외).

id 는 UUID 문자열(String(36)) — 순차 int 대비 열거·추측 불가(타 기관/계정 ID 노출 방지),
기존 ModelStore 의 UUID model_id 와 일관, DB 이식성 확보.

role / auth_provider 는 문자열 enum:
- role: 'admin' | 'instructor' | 'member'  (CHECK 제약으로 값 강제)
- auth_provider: 'local'(기본) 외 소셜은 나중에 값만 추가(스키마 변경 불필요)
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Enum, Float, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


# native_enum=False → SQLite 등에서 VARCHAR + CHECK 제약으로 표현(마이그레이션 단순).
ROLE_ENUM = Enum("admin", "instructor", "member", name="user_role", native_enum=False)


class Organization(Base):
    """기관."""

    __tablename__ = "organizations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    groups: Mapped[list["Group"]] = relationship(
        back_populates="organization", cascade="all, delete-orphan"
    )
    users: Mapped[list["User"]] = relationship(
        back_populates="organization", foreign_keys="User.organization_id"
    )


class Group(Base):
    """반/그룹 — 기관에 속하며 대표 강사 1명(선택)을 가진다."""

    __tablename__ = "groups"
    __table_args__ = (UniqueConstraint("organization_id", "name", name="uq_group_org_name"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    organization_id: Mapped[str] = mapped_column(
        ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    # 담당 강사(대표 1명). 다대다 확장은 다음 단계.
    instructor_id: Mapped[str | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, nullable=False)

    organization: Mapped["Organization"] = relationship(back_populates="groups")
    instructor: Mapped["User | None"] = relationship(foreign_keys=[instructor_id])
    members: Mapped[list["User"]] = relationship(
        back_populates="group", foreign_keys="User.group_id"
    )


class User(Base):
    """사용자 — admin/instructor/member. 공개 가입이 아닌 발급 방식(다음 단계에서 로직)."""

    __tablename__ = "users"
    __table_args__ = (UniqueConstraint("auth_provider", "provider_sub", name="uq_user_provider_sub"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    email: Mapped[str] = mapped_column(String(320), nullable=False, unique=True)
    username: Mapped[str | None] = mapped_column(String(100), nullable=True)
    # 소셜 전용 계정은 NULL 가능(비밀번호 없음).
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    role: Mapped[str] = mapped_column(ROLE_ENUM, nullable=False)
    organization_id: Mapped[str | None] = mapped_column(
        ForeignKey("organizations.id", ondelete="SET NULL"), nullable=True
    )
    group_id: Mapped[str | None] = mapped_column(
        ForeignKey("groups.id", ondelete="SET NULL"), nullable=True
    )
    auth_provider: Mapped[str] = mapped_column(String(40), nullable=False, default="local")
    provider_sub: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    must_change_password: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    organization: Mapped["Organization | None"] = relationship(
        back_populates="users", foreign_keys=[organization_id]
    )
    group: Mapped["Group | None"] = relationship(
        back_populates="members", foreign_keys=[group_id]
    )
    refresh_tokens: Mapped[list["RefreshToken"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )


class RefreshToken(Base):
    """리프레시 토큰(세션) — 원문이 아닌 해시를 저장, 서버측 폐기(로그아웃/회전) 가능."""

    __tablename__ = "refresh_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    token_hash: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(400), nullable=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, nullable=False)

    user: Mapped["User"] = relationship(back_populates="refresh_tokens")


# 감사 로그 action 값(문자열 enum). 비밀번호/해시/토큰/임시비번 값은 절대 담지 않는다.
AUDIT_ACTION_ENUM = Enum(
    "create_user",
    "change_role",
    "deactivate",
    "activate",
    "reset_password",
    name="audit_action",
    native_enum=False,
)


class AuditLog(Base):
    """관리 동작 감사 로그 — 부가 기록(본 동작과 독립). 행위자/대상은 시점 스냅샷으로 동결 저장.

    민감정보(비밀번호·해시·토큰·임시비번)는 컬럼 자체가 없다. reset_password 는 '재발급함' 사실만,
    change_role 은 detail 에 old→new 만 남긴다.
    """

    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, nullable=False)

    # 행위자(actor) — 삭제/개명/역할변경돼도 로그 의미 보존을 위해 이메일·역할을 시점 스냅샷으로 저장.
    actor_user_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    actor_email: Mapped[str | None] = mapped_column(String(320), nullable=True)
    actor_role: Mapped[str | None] = mapped_column(String(40), nullable=True)

    action: Mapped[str] = mapped_column(AUDIT_ACTION_ENUM, nullable=False)

    # 대상(target) — 스냅샷.
    target_user_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    target_email: Mapped[str | None] = mapped_column(String(320), nullable=True)
    # 대상의 기업(스코프 조회용) — instructor 는 자기 기업 로그만 조회.
    organization_id: Mapped[str | None] = mapped_column(String(36), nullable=True)

    # 부가정보(예: 역할 변경 old→new). 자유 문자열, 민감정보 금지.
    detail: Mapped[str | None] = mapped_column(String(500), nullable=True)


class TuningJob(Base):
    """자동 하이퍼파라미터 튜닝(Optuna) 비동기 작업 상태 — 백그라운드 학습의 진행/결과를 DB에 보관한다.

    ⚠ 메모리 dict 가 아니라 DB 에 두는 이유: 프로덕션은 uvicorn --workers 2(멀티 프로세스)라
      메모리는 워커 간 공유가 안 된다. 학습을 시작한 워커와 폴링(GET status)을 받는 워커가 달라도,
      상태를 DB 에서 읽으므로 일관되게 조회된다. (기존 ModelStore 의 인메모리 모델과는 별개 — 모델 자체는
      아직 인메모리라 예측은 같은 워커에서만 보장; 이는 store.py 가 문서화한 기존 제약으로 이번 범위 밖.)
    """

    __tablename__ = "tuning_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    status: Mapped[str] = mapped_column(String(20), default="running", nullable=False)  # running/done/failed/cancelled
    progress: Mapped[int] = mapped_column(Integer, default=0, nullable=False)  # 완료된 trial 수
    total: Mapped[int] = mapped_column(Integer, default=0, nullable=False)  # 전체 trial 상한(n_trials)
    best_score: Mapped[float | None] = mapped_column(Float, nullable=True)  # 현재까지 최고 CV 점수
    best_params: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # 현재까지 best 파라미터
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # 완료 시 최종 학습 응답(TrainResponse 형태 JSON)
    error: Mapped[str | None] = mapped_column(String(1000), nullable=True)  # 실패 시 메시지
    # 협조적 취소 신호 — 취소 요청(POST /train/cancel)이 True 로 세팅. 튜닝 콜백이 매 trial 확인해 study.stop()
    #   → 다음 trial 을 시작하지 않고 멈춘다(스레드 강제 kill 아님). DB 라 워커/프로세스 간 공유된다.
    cancelled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)
