"""회귀 지표 — models.ts regressionMetrics 포팅.

r2 = max(-1, 1 - ssRes/ssTot), rmse = sqrt(ssRes/n), mae = absSum/n. 모두 소수 3자리 반올림.
actualVsPred는 상위 600개만, pred는 소수 3자리 반올림. (프론트와 동일)
"""
from __future__ import annotations

import math

from .repro import round3


def regression_metrics(y_true: list[float], y_pred: list[float]) -> dict:
    n = len(y_true)
    my = sum(y_true) / n if n else 0.0
    ss_res = 0.0
    ss_tot = 0.0
    abs_sum = 0.0
    avp: list[dict] = []
    for i in range(n):
        p = y_pred[i]
        ss_res += (y_true[i] - p) ** 2
        ss_tot += (y_true[i] - my) ** 2
        abs_sum += abs(y_true[i] - p)
        if len(avp) < 600:
            avp.append({"actual": y_true[i], "pred": round3(p)})
    r2 = 0.0 if ss_tot == 0 else max(-1.0, 1 - ss_res / ss_tot)
    return {
        "metrics": {
            "r2": round3(r2),
            "rmse": round3(math.sqrt(ss_res / max(n, 1))),
            "mae": round3(abs_sum / max(n, 1)),
        },
        "actualVsPred": avp,
    }
