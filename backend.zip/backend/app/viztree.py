"""시각화용 깊이-2 결정 트리 — models.ts buildVizTree 포팅(회귀 SSE / 분류 Gini).

결정적(난수 없음)이라 동일 입력이면 브라우저와 **완전히 같은 트리**가 나온다.
  회귀: 분산(SSE) 감소, 잎 = 목표 평균(numFmt).
  분류: Gini 감소, 잎 = 다수결 클래스(+비율).
"""
from __future__ import annotations

from .repro import fmt_num, fmt_threshold

VIZ_MAX_ROWS = 8000


def _leaf_label(y_num, y_str, idx):
    if y_num is not None:
        return fmt_num(sum(y_num[i] for i in idx) / len(idx))
    # 분류: 다수결 클래스 + 비율
    cnt: dict[str, int] = {}
    for i in idx:
        cnt[y_str[i]] = cnt.get(y_str[i], 0) + 1
    best, bn = "", -1
    for c, n in cnt.items():
        if n > bn:
            bn, best = n, c
    return f"{best} ({round((bn / len(idx)) * 100)}%)"


def _best_split(X, y_num, y_str, idx, k):
    n = len(idx)
    if n < 4:
        return None
    best = None  # (f, thr, i, sorted_idx, gain)
    for f in range(k):
        sorted_idx = sorted(idx, key=lambda a: X[a][f])
        if y_num is not None:
            total = 0.0
            total2 = 0.0
            for i in sorted_idx:
                total += y_num[i]
                total2 += y_num[i] * y_num[i]
            parent = total2 - (total * total) / n
            sum_l = 0.0
            sum_l2 = 0.0
            for i in range(n - 1):
                v = y_num[sorted_idx[i]]
                sum_l += v
                sum_l2 += v * v
                xc = X[sorted_idx[i]][f]
                xn = X[sorted_idx[i + 1]][f]
                if xc == xn:
                    continue
                n_l = i + 1
                n_r = n - n_l
                sse_l = sum_l2 - (sum_l * sum_l) / n_l
                sse_r = total2 - sum_l2 - ((total - sum_l) * (total - sum_l)) / n_r
                gain = parent - sse_l - sse_r
                if best is None or gain > best[4]:
                    best = (f, (xc + xn) / 2, i, sorted_idx, gain)
        else:
            cnt_all: dict[str, int] = {}
            for i in sorted_idx:
                cnt_all[y_str[i]] = cnt_all.get(y_str[i], 0) + 1
            sum_sq_all = sum(c * c for c in cnt_all.values())
            parent = n - sum_sq_all / n
            cnt_l: dict[str, int] = {}
            cnt_r = dict(cnt_all)
            sum_sq_l = 0
            sum_sq_r = sum_sq_all
            for i in range(n - 1):
                c = y_str[sorted_idx[i]]
                old_l = cnt_l.get(c, 0)
                sum_sq_l += 2 * old_l + 1
                cnt_l[c] = old_l + 1
                old_r = cnt_r.get(c, 0)
                sum_sq_r += -2 * old_r + 1
                cnt_r[c] = old_r - 1
                xc = X[sorted_idx[i]][f]
                xn = X[sorted_idx[i + 1]][f]
                if xc == xn:
                    continue
                n_l = i + 1
                n_r = n - n_l
                gain = parent - (n_l - sum_sq_l / n_l) - (n_r - sum_sq_r / n_r)
                if best is None or gain > best[4]:
                    best = (f, (xc + xn) / 2, i, sorted_idx, gain)
    if best is None or best[4] <= 1e-9:
        return None
    f, thr, i, sorted_idx, _ = best
    return {"f": f, "thr": thr, "left": sorted_idx[: i + 1], "right": sorted_idx[i + 1:]}


def _build_viz(X, y_num, y_str, feature_labels, max_depth=2):
    n = len(X)
    k = len(feature_labels)
    if not n or not k:
        return None
    idx0 = list(range(n))
    if n > VIZ_MAX_ROWS:
        step = -(-n // VIZ_MAX_ROWS)
        idx0 = [i for i in idx0 if i % step == 0]

    def build(idx, depth):
        if depth >= max_depth:
            return {"leaf": True, "label": _leaf_label(y_num, y_str, idx)}
        s = _best_split(X, y_num, y_str, idx, k)
        if s is None:
            return {"leaf": True, "label": _leaf_label(y_num, y_str, idx)}
        thr = round(s["thr"] * 100) / 100
        q = f"{feature_labels[s['f']]} ≤ {fmt_threshold(thr)}?"
        return {"leaf": False, "q": q, "left": build(s["left"], depth + 1), "right": build(s["right"], depth + 1)}

    return build(idx0, 0)


def build_viz_tree(X, y, feature_labels, max_depth=2):
    """회귀용 — 잎이 목표 평균."""
    return _build_viz(X, y, None, feature_labels, max_depth)


def build_viz_tree_cls(X, y_str, feature_labels, max_depth=2):
    """분류용 — 잎이 다수결 클래스(+비율)."""
    return _build_viz(X, None, y_str, feature_labels, max_depth)
