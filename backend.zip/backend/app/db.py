"""SQLAlchemy 2.0 DB 기반 — engine / SessionLocal / Base / get_db.

계정 시스템(L2a)의 영속 계층. 기존 계산 API(인메모리 ModelStore)와 완전히 독립이다.
스키마 생성/변경은 Alembic이 담당한다(여기서 create_all 하지 않는다).
"""
from __future__ import annotations

from collections.abc import Generator
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from .settings import DEFAULT_DB_PATH, settings


class Base(DeclarativeBase):
    """모든 ORM 모델의 선언적 베이스. Alembic이 이 metadata 를 참조한다."""


def _guard_test_env(url: str) -> None:
    """검증/테스트 모드(APP_ENV=test)에서 실제 app.db 사용을 원천 차단한다.

    이 함수는 test 모드에서만 작동한다. 일반 개발 서버(APP_ENV 미지정=dev)는 전혀 영향받지 않으며,
    기존과 동일하게 backend/data/app.db 를 사용한다. test 모드인데 DATABASE_URL 을 지정하지 않아
    기본 app.db 를 가리키면(또는 명시적으로 실 app.db 경로를 주면) 즉시 중단시켜 오염을 막는다.
    """
    if not settings.is_testing:
        return
    prefix = "sqlite:///"
    if url.startswith(prefix):
        target = Path(url[len(prefix):]).resolve()
        if target == DEFAULT_DB_PATH.resolve():
            raise RuntimeError(
                "APP_ENV=test에서는 실제 app.db를 사용할 수 없습니다. "
                "DATABASE_URL로 임시 DB를 지정하세요 "
                "(예: DATABASE_URL=sqlite:////tmp/verify.db)."
            )


_url = settings.database_url
_guard_test_env(_url)
_connect_args: dict = {}

if _url.startswith("sqlite"):
    # SQLite + FastAPI(멀티 스레드) 조합에서 필요.
    _connect_args = {"check_same_thread": False}
    # 파일 기반이면 상위 디렉터리를 미리 만들어 둔다(최초 기동 시 자동 생성).
    _prefix = "sqlite:///"
    if _url.startswith(_prefix):
        _db_path = Path(_url[len(_prefix):])
        _db_path.parent.mkdir(parents=True, exist_ok=True)

engine = create_engine(_url, connect_args=_connect_args, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, class_=Session)


def get_db() -> Generator[Session, None, None]:
    """FastAPI Depends 용 세션 제너레이터. 요청 종료 시 세션을 닫는다."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
