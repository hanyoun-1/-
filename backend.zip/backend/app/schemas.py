"""pydantic 스키마 — 프론트 src/lib/compute/api.ts 의 타입과 1:1로 일치시킨다.

프론트 계약(그대로 따름):
  TrainRequest  {task, algo, target, features, testRatio, X, y, seed?}
  TrainResponse {model_id, metrics, coef?, importance?, intercept?, actualVsPred, vizTree?, sampled?}
  PredictRequest(본문) {X}
  PredictResponse {predictions, proba?}

필드명은 camelCase(testRatio·actualVsPred·vizTree)까지 프론트와 동일하게 유지한다.
"""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel


class TrainRequest(BaseModel):
    task: Literal["reg", "cls"]
    algo: str  # 'linear' | 'rf' (프론트 RegAlgo 키) | 'knn'(수동 튜닝) 등
    target: str
    features: list[str]
    testRatio: float
    X: list[list[float]]
    y: list[float | str]  # 회귀=숫자 / 분류=클래스 라벨(문자). 프론트 api.ts (number|string)[] 와 일치.
    # 수동 하이퍼파라미터(T2). 없으면(None) 기존 6종은 하드코딩값으로 동작(하위호환).
    #   명세가 있는 모델(예: knn)만 유효하며, 서버가 hyperparams.validate_params 로 범위/타입을 검증한다.
    params: Optional[dict[str, Any]] = None
    # 표준화(스케일링) 옵션(W1). supports_scaling 모델(KNN 등)에서 None=기본 켜짐, false=끔.
    #   미지원 모델(트리 등)에서는 무시된다. 실제 적용 여부는 응답 scaled 로 에코된다.
    scale: Optional[bool] = None
    # 시간순(순차) 분할 옵션. False(기본)=기존 랜덤 셔플 분할(하위호환). True=앞쪽 학습·뒤쪽 평가(시계열용, 누수 방지).
    #   데이터가 시간순으로 정렬돼 있어야 의미가 있다. 실제 사용 여부는 응답 sequentialSplit 로 에코된다.
    sequentialSplit: bool = False
    # 자동 하이퍼파라미터 튜닝(Optuna). False(기본)=기존 경로 그대로(하위호환). True=rf·xgb 만 5-fold CV 로
    #   best_params 탐색 후 그 값으로 학습(그 외 algo 는 무시). 응답 bestParams 로 찾은 값을 에코한다.
    tune: bool = False


class ActualVsPred(BaseModel):
    actual: float
    pred: float


class TrainResponse(BaseModel):
    model_id: str
    metrics: dict[str, float]  # r2 / mae / rmse
    coef: Optional[list[float]] = None
    importance: Optional[list[float]] = None
    intercept: Optional[float] = None
    actualVsPred: list[ActualVsPred]
    vizTree: Optional[Any] = None  # VizTreeNode 직렬화(재귀 dict)
    sampled: Optional[dict[str, int]] = None
    # 수동 튜닝 시 "기본값이 채워진 최종 사용값" 에코(T2). 튜닝 없는 기존 6종은 None.
    usedParams: Optional[dict[str, Any]] = None
    # 자동 튜닝(Optuna)으로 찾은 best_params 에코. tune=false 거나 미지원 algo 면 None(투명성·UI 표시용).
    bestParams: Optional[dict[str, Any]] = None
    # 실제 적용된 표준화 여부(W1). 스케일링 미적용/미해당 경로는 None.
    scaled: Optional[bool] = None
    # 실제 사용한 분할 방식 에코. True=시간순(순차), False=랜덤. 화면·리포트에서 확인용.
    sequentialSplit: bool = False


class PredictRequest(BaseModel):
    X: list[list[float]]


class PredictResponse(BaseModel):
    # 회귀: predictions=숫자. 분류: predictions=클래스 라벨(문자) + proba + classes.
    predictions: list[Any]
    proba: Optional[list[list[float]]] = None
    classes: Optional[list[str]] = None


# ───────────── 분류 학습 응답 (프론트 api.ts 분류 타입과 1:1) ─────────────

class ClsReportRow(BaseModel):
    cls: str
    precision: float
    recall: float
    f1: float
    support: int
    auc: Optional[float] = None


class ClsTrainResponse(BaseModel):
    model_id: str
    classes: list[str]
    accuracy: float
    confusion: list[list[int]]
    report: list[ClsReportRow]
    # 회귀와 동일하게 값 벡터만 반환 → 프론트가 features로 {name,value}[] 매핑.
    coef: Optional[list[float]] = None  # 이진 로지스틱=표준화 계수
    importance: Optional[list[float]] = None  # 트리 변수 중요도
    vizTree: Optional[Any] = None
    sampled: Optional[dict[str, int]] = None
    # 수동 튜닝(예: knn 분류) 시 기본값 채운 최종 사용값 에코(V1). 튜닝 없는 기존 3종은 None.
    usedParams: Optional[dict[str, Any]] = None
    # 자동 튜닝(Optuna)으로 찾은 best_params 에코. tune=false 거나 미지원 algo 면 None(투명성·UI 표시용).
    bestParams: Optional[dict[str, Any]] = None
    # 실제 적용된 표준화 여부(W1). 스케일링 미적용/미해당 경로는 None.
    scaled: Optional[bool] = None
    # 실제 사용한 분할 방식 에코. True=시간순(순차), False=랜덤.
    sequentialSplit: bool = False
