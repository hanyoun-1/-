"""인증 보안 유틸(L2b) — 비밀번호 해싱 · access JWT · refresh 토큰.

원칙:
- 비밀번호는 bcrypt 해시로만 저장/검증(평문 금지).
- access = 무상태 JWT(HS256). claim: sub(user_id), role, org_id, jti, iat, exp.
- refresh = 서버가 발급하는 랜덤 원문(클라이언트 보관) + sha256 해시(DB 저장). 원문은 DB에 남기지 않는다.
- 시크릿은 settings(환경변수)에서 주입 — 코드 하드코딩 금지.
"""
from __future__ import annotations

import hashlib
import secrets
import uuid
from datetime import datetime, timedelta, timezone

import jwt
from passlib.context import CryptContext

from .settings import settings

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ── 비밀번호 ─────────────────────────────────────────────
def hash_password(password: str) -> str:
    return _pwd.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    if not password_hash:
        return False
    try:
        return _pwd.verify(password, password_hash)
    except ValueError:
        # 손상/비-bcrypt 해시 등 → 검증 실패 처리.
        return False


# ── access JWT ───────────────────────────────────────────
def create_access_token(*, user_id: str, role: str, org_id: str | None) -> str:
    """access 토큰 발급. exp 는 settings 의 만료(분) 기준."""
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "role": role,
        "org_id": org_id,
        "jti": str(uuid.uuid4()),
        "iat": int(now.timestamp()),
        "exp": now + timedelta(minutes=settings.access_token_expire_minutes),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_access_token(token: str) -> dict:
    """서명·만료 검증 후 claim 반환. 실패 시 jwt 예외(PyJWTError 계열) 전파."""
    return jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])


# ── refresh 토큰 ─────────────────────────────────────────
def generate_refresh_token() -> tuple[str, str]:
    """(원문, sha256 해시) 반환. 원문은 클라이언트에, 해시만 DB에 저장한다."""
    raw = secrets.token_urlsafe(48)
    return raw, hash_refresh_token(raw)


def hash_refresh_token(raw: str) -> str:
    """refresh 원문 → sha256 hex. 조회 시 동일 함수로 해시해 비교(원문 저장 안 함)."""
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def refresh_expiry() -> datetime:
    return datetime.now(timezone.utc) + timedelta(days=settings.refresh_token_expire_days)
