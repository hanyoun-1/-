"""회귀 학습 로직 — 프론트 models.ts fitRegression에 대응.

재현성 원칙:
  - train/test 분할: repro.train_test_split_indices(seed=42) 로 브라우저와 동일 분할.
  - 지표/vizTree: metrics.py·viztree.py 포팅으로 브라우저와 동일 산식.
  - linear: sklearn LinearRegression = TS의 OLS와 수학적으로 동일 → 계수·예측 사실상 일치.
  - rf: 프론트는 '자체 구현' 트리라 sklearn과 값이 정확히 같을 수 없음(알고리즘 상이).
        대신 동일 하이퍼파라미터 + seed(rf=7)로 '서버 재현성'을 보장한다.

MAX_TREE_ROWS(20000): 트리 학습 시 학습 행을 상한(프론트와 동일). 초과 시 sampled 정보 반환.
"""
from __future__ import annotations

from typing import Any

from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression

from .metrics import regression_metrics
from .repro import cap_rows, train_test_split_indices, train_test_split_sequential
from .viztree import build_viz_tree

MAX_TREE_ROWS = 20000
# 이 하드코딩 경로에 도달하는 트리 모델은 rf 뿐이다(xgboost/lightgbm/catboost 는 항상 수동 train_regression_manual 경로).
_TREE_ALGOS = {"rf"}


def _subset(rows: list[list[float]], idx: list[int]) -> list[list[float]]:
    return [rows[i] for i in idx]


def _mean(vals: list[float]) -> float:
    return sum(vals) / len(vals) if vals else 0.0


def train_regression(req) -> dict:
    """req: schemas.TrainRequest. 반환: schemas.TrainResponse 에 맞는 dict."""
    algo = req.algo
    X: list[list[float]] = [[float(v) for v in row] for row in req.X]
    y: list[float] = [float(v) for v in req.y]
    features: list[str] = req.features
    n = len(X)

    # 1) train/test 분할 — 기본은 랜덤(seed=42), sequentialSplit=True면 시간순(앞 학습·뒤 평가, 시계열용).
    split = train_test_split_sequential(n, req.testRatio) if req.sequentialSplit else train_test_split_indices(n, req.testRatio, 42)
    tr, te = split["train"], split["test"]
    x_tr, y_tr = _subset(X, tr), [y[i] for i in tr]
    x_te, y_te = _subset(X, te), [y[i] for i in te]

    is_tree = algo in _TREE_ALGOS
    sampled = None
    coef = None
    importance = None
    intercept: float | None = None
    viz_tree = None

    if is_tree:
        # 트리 학습 행 상한 (프론트 capRows: rf seed=7)
        cap = cap_rows(len(x_tr), 7, MAX_TREE_ROWS)
        x_cap = _subset(x_tr, cap)
        y_cap = [y_tr[i] for i in cap]
        if len(x_tr) > MAX_TREE_ROWS:
            sampled = {"used": MAX_TREE_ROWS, "total": len(x_tr)}

        model: Any = RandomForestRegressor(
            # 100: 명세(_RF_PARAMS)의 default 와 통일 → 튜닝 안 한 rf 와 기본값으로 튜닝한 rf 가 같은 숲이 된다.
            n_estimators=100,
            max_depth=9,
            min_samples_leaf=4,
            max_features=1.0 / 3.0,  # 프론트 mtry=round(k/3)에 대응(근사)
            bootstrap=True,
            random_state=7,
            n_jobs=-1,
        )
        intercept = _mean(y_tr)  # 프론트: reg.intercept = mean(ytr)
        model.fit(x_cap, y_cap)
        importance = [float(v) for v in model.feature_importances_]
        # vizTree는 프론트와 동일하게 '학습 분할 전체(x_tr,y_tr)' 기준으로 만든다.
        viz_tree = build_viz_tree(x_tr, y_tr, features, 2)
    else:  # 'linear'
        model = LinearRegression().fit(x_tr, y_tr)
        coef = [float(v) for v in model.coef_]
        intercept = float(model.intercept_)

    # 2) 테스트셋 예측 → 지표·actualVsPred (프론트 regressionMetrics와 동일 산식)
    y_pred = [float(v) for v in model.predict(x_te)]
    m = regression_metrics(y_te, y_pred)

    return {
        "model": model,
        "algo": algo,
        "features": features,
        "response": {
            "metrics": m["metrics"],
            "coef": coef,
            "importance": importance,
            "intercept": intercept,
            "actualVsPred": m["actualVsPred"],
            "vizTree": viz_tree,
            "sampled": sampled,
            "sequentialSplit": req.sequentialSplit,
        },
    }


def train_regression_manual(req, used: dict) -> dict:
    """수동 하이퍼파라미터 회귀 학습(T2) — 명세 기반 모델(예: knn).

    기존 파이프라인 재사용:
      - 분할: train_test_split_indices(seed=42) (기존 6종과 동일 홀드아웃).
      - 지표: regression_metrics (R²/MAE/RMSE/actualVsPred 동일 산식).
      - 추정기: hyperparams.build_estimator(검증된 used 로 sklearn 인스턴스).
    coef/importance/intercept/vizTree 는 KNN 계열에 없으므로 None. 반환 dict 형태는
    train_regression 과 동일하여 라우터의 저장·응답 코드를 그대로 재사용한다.
    """
    from .hyperparams import build_estimator, resolve_scaling, supports_scaling

    X: list[list[float]] = [[float(v) for v in row] for row in req.X]
    y: list[float] = [float(v) for v in req.y]
    features: list[str] = req.features
    n = len(X)

    split = train_test_split_sequential(n, req.testRatio) if req.sequentialSplit else train_test_split_indices(n, req.testRatio, 42)
    tr, te = split["train"], split["test"]
    x_tr, y_tr = _subset(X, tr), [y[i] for i in tr]
    x_te, y_te = _subset(X, te), [y[i] for i in te]

    # 표준화 여부 결정(KNN=기본 켜짐). scale=True 면 Pipeline 으로 감싸 분할 후 x_tr 로만 fit → 누수 없음.
    scaled = resolve_scaling("reg", req.algo, req.scale)
    scaled_echo = scaled if supports_scaling("reg", req.algo) else None  # 미지원 모델(트리 rf 등)은 미해당(None)
    model: Any = build_estimator("reg", req.algo, used, scale=scaled)
    model.fit(x_tr, y_tr)

    y_pred = [float(v) for v in model.predict(x_te)]
    m = regression_metrics(y_te, y_pred)

    # 영향도 추출 일반화 — 최종 추정기 기준:
    #   · coef_ 있으면 계수(Ridge/Lasso 등). scale=True 면 Pipeline 이라 named_steps["model"] 에서 접근.
    #   · feature_importances_ 있으면 변수 중요도 + 트리 시각화(부스팅 xgboost 등, 기존 하드코딩 경로와 동일 깊이 2).
    #   · 둘 다 없으면 None(KNN·SVR rbf).  coef_/intercept_ 는 1D/2D·스칼라/배열 모두 np.ravel 로 안전 처리.
    import numpy as np

    est = model.named_steps["model"] if hasattr(model, "named_steps") else model
    coef = None
    intercept = None
    if hasattr(est, "coef_"):
        coef = [float(v) for v in np.ravel(est.coef_)]
        intercept = float(np.ravel(est.intercept_)[0]) if hasattr(est, "intercept_") else None
    has_importance = hasattr(est, "feature_importances_")
    importance = [float(v) for v in est.feature_importances_] if has_importance else None
    viz_tree = build_viz_tree(x_tr, y_tr, features, 2) if has_importance else None

    return {
        "model": model,
        "algo": req.algo,
        "features": features,
        "response": {
            "metrics": m["metrics"],
            "coef": coef,
            "importance": importance,
            "intercept": intercept,
            "actualVsPred": m["actualVsPred"],
            "vizTree": viz_tree,
            "sampled": None,
            "scaled": scaled_echo,
            "sequentialSplit": req.sequentialSplit,
        },
    }


def predict_regression(model: Any, X: list[list[float]]) -> list[float]:
    rows = [[float(v) for v in row] for row in X]
    return [float(v) for v in model.predict(rows)]
