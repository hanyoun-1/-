"""기업(organizations)·그룹(groups) 관리 API 스키마(M1)."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class OrganizationCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)


class OrganizationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    created_at: datetime
    updated_at: datetime


class GroupCreate(BaseModel):
    organization_id: str
    name: str = Field(min_length=1, max_length=200)
    instructor_id: str | None = None


class GroupOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    organization_id: str
    name: str
    instructor_id: str | None
    created_at: datetime
