"""인메모리 stateful 저장소 — 학습 모델을 model_id로 보관하고 TTL로 만료한다.

설치형(단일 프로세스)에서는 이 인메모리로 충분하다. SaaS/멀티프로세스 확장 시 Redis로 교체(다음 단계).
만료/부재 model_id로 predict 시 라우터에서 404 → 프론트 MissingModelError와 대응.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any

TTL_SECONDS = 2 * 60 * 60  # 2시간


@dataclass
class ModelEntry:
    model: Any  # 학습된 추정기(회귀=sklearn, 분류=LogisticModel/SklearnClsModel)
    algo: str
    features: list[str]
    task: str = "reg"  # 'reg' | 'cls' — predict 응답 형태 결정
    classes: list[str] | None = None  # 분류 클래스 순서
    created: float = field(default_factory=time.time)


class ModelStore:
    def __init__(self, ttl: int = TTL_SECONDS) -> None:
        self._ttl = ttl
        self._models: dict[str, ModelEntry] = {}

    def _expired(self, entry: ModelEntry) -> bool:
        return (time.time() - entry.created) > self._ttl

    def put_model(self, model: Any, algo: str, features: list[str], task: str = "reg", classes: list[str] | None = None) -> str:
        model_id = str(uuid.uuid4())
        self._models[model_id] = ModelEntry(model=model, algo=algo, features=features, task=task, classes=classes)
        return model_id

    def get_model(self, model_id: str) -> ModelEntry | None:
        entry = self._models.get(model_id)
        if entry is None:
            return None
        if self._expired(entry):
            self._models.pop(model_id, None)
            return None
        return entry

    def delete_model(self, model_id: str) -> bool:
        return self._models.pop(model_id, None) is not None


store = ModelStore()
