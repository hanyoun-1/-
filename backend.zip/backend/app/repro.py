"""재현성 유틸 — 프론트 src/lib/models.ts 의 난수/분할/포맷을 32비트 단위까지 정밀 포팅.

목적: 브라우저와 서버가 "같은 train/test 분할"과 "같은 숫자 표기"를 쓰도록 보장한다.
      (선형회귀는 분할만 같으면 지표가 브라우저와 사실상 일치한다.)

주의: mulberry32는 JS의 |0 / >>> / Math.imul 비트연산을 그대로 재현해야 한다.
"""
from __future__ import annotations

import math

_MASK = 0xFFFFFFFF


def _imul(a: int, b: int) -> int:
    """JS Math.imul: 두 값의 하위 32비트 곱(부호는 비트패턴으로만 다룸)."""
    return ((a & _MASK) * (b & _MASK)) & _MASK


def mulberry32(seed: int):
    """JS mulberry32(seed) 정밀 포팅. [0,1) 실수를 반환하는 클로저."""
    a = seed & _MASK  # a |= 0
    state = {"a": a}

    def rng() -> float:
        a = (state["a"] + 0x6D2B79F5) & _MASK  # (a + C) | 0
        state["a"] = a
        # t = Math.imul(a ^ (a >>> 15), 1 | a)
        t = _imul(a ^ (a >> 15), (1 | a) & _MASK)
        # t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
        t = ((t + _imul(t ^ (t >> 7), (61 | t) & _MASK)) & _MASK) ^ t
        t &= _MASK
        # ((t ^ (t >>> 14)) >>> 0) / 4294967296
        return ((t ^ (t >> 14)) & _MASK) / 4294967296.0

    return rng


def _js_round(x: float) -> int:
    """JS Math.round: 0.5는 +무한대 방향으로 반올림(Python round의 뱅커스 반올림과 다름)."""
    return math.floor(x + 0.5)


def train_test_split_indices(n: int, test_ratio: float, seed: int = 42) -> dict:
    """models.ts trainTestSplit 포팅. test = 셔플 후 앞 nTest개, train = 나머지."""
    idx = list(range(n))
    rand = mulberry32(seed)
    for i in range(n - 1, 0, -1):
        j = int(rand() * (i + 1))  # Math.floor(rand()*(i+1))
        idx[i], idx[j] = idx[j], idx[i]
    n_test = max(1, _js_round(n * test_ratio))
    return {"test": idx[:n_test], "train": idx[n_test:]}


def train_test_split_sequential(n: int, test_ratio: float) -> dict:
    """시간순(순차) 분할 — 셔플 없이 앞쪽=학습, 뒤쪽=테스트.

    시계열에서 랜덤 분할은 미래 시점이 학습셋에 섞여 데이터 누수가 된다(미래를 보고 과거 예측 → 성능이
    비현실적으로 높게 나옴). 데이터가 시간순으로 정렬돼 있다는 전제 하에, 앞 (n - n_test)개로 학습하고
    뒤 n_test개로 평가하면 "과거로 학습, 미래를 예측"이라 누수가 없다.
    n_test 규칙은 train_test_split_indices 와 동일(max(1, round(n * test_ratio))). 기존 랜덤 함수는 무변경.
    """
    n_test = max(1, _js_round(n * test_ratio))
    return {"train": list(range(n - n_test)), "test": list(range(n - n_test, n))}


def cap_rows(n: int, seed: int, max_rows: int) -> list[int]:
    """models.ts capRows 포팅. n<=max_rows면 전체, 초과면 시드 셔플 후 앞 max_rows개."""
    idx = list(range(n))
    if n <= max_rows:
        return idx
    rand = mulberry32(seed)
    for i in range(n - 1, 0, -1):
        j = int(rand() * (i + 1))
        idx[i], idx[j] = idx[j], idx[i]
    return idx[:max_rows]


def _group(v: float) -> str:
    """toLocaleString 천단위 콤마 표기. 정수면 소수점 제거."""
    if v == int(v):
        return f"{int(v):,}"
    return f"{v:,}"


def fmt_num(v: float) -> str:
    """models.ts numFmt: |v|>=100 → 정수 반올림, else 소수1자리 반올림. 그 뒤 콤마 표기."""
    if abs(v) >= 100:
        v = float(_js_round(v))
    else:
        v = _js_round(v * 10) / 10
    return _group(v)


def fmt_threshold(thr: float) -> str:
    """models.ts: Math.round(thr*100)/100 후 toLocaleString."""
    t = _js_round(thr * 100) / 100
    return _group(t)


def round3(x: float) -> float:
    """Math.round(x*1000)/1000 (JS 반올림 규칙)."""
    return _js_round(x * 1000) / 1000
