"""자동 튜닝(Optuna) 비동기 실행 — 실행부(run_tuning_job) + 트리거(ThreadPoolExecutor) + DB 상태(tuning_jobs).

동기 학습(tune=false)은 이 모듈을 거치지 않는다(무변경). tune=true·rf/xgb 만 여기서 백그라운드로 돌린다.
상태(진행률·best·결과)는 DB(tuning_jobs)에 저장 → 폴링(GET status)이 어느 워커에서든 DB 에서 읽어 일관 조회된다
(메모리 dict 는 워커 간 공유 불가라 금지).

────────────── Redis 이전 대비: 실행부(run_tuning_job)와 트리거를 분리한다 ──────────────
  · run_tuning_job(job_id, req): "작업 실행부". 이미 생성된 job 을 받아 튜닝→학습→DB 기록만 한다.
      트리거(스레드/큐)와 무관하고 **DB 로만 상태를 주고받는다**. 나중에 Redis 큐 워커가 이 함수를 그대로 호출하면 된다.
  · start_tuning_job(req): "트리거". job 을 DB 에 만들고 run_tuning_job 을 ThreadPoolExecutor 로 실행 제출.
      Redis 로 바꿀 때는 이 함수에서 executor.submit 대신 queue.enqueue(run_tuning_job, ...) 로만 바꾸면 된다.

⚠ 한계: 스레드는 워커 재시작 시 증발한다 → DB 에 영원히 running 으로 남는 것을 '멈춘 작업 감지'(reap_if_stalled)로 완화.
⚠ CPU-bound 학습은 스레드풀에서 돌지만 sklearn/xgboost 의 fit 이 네이티브에서 GIL 을 놓아 폴링 요청 처리를 막지 않는다.
"""
from __future__ import annotations

import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Optional

from .db import SessionLocal
from .models_cls import train_classification_manual
from .models_db import TuningJob
from .models_reg import train_regression_manual
from .schemas import ClsTrainResponse, TrainResponse
from .store import store
from .tuning import TUNE_MAX_TRIALS, subsample_for_tuning, tune_hyperparams

# 백그라운드 튜닝 실행기(트리거) — 소수 워커(동시 학습 CPU 경쟁 제한). 프로세스 수명 동안 유지.
_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="tuning")

# 멈춘 작업 감지 임계값(초) — running 인데 이 시간 넘게 updated_at 갱신이 없으면 '중단됨'으로 본다.
#   워커 재시작으로 스레드가 증발하면 DB 엔 영원히 running 으로 남는데, 이 임계값으로 failed 전환해
#   사용자가 '영원한 진행바' 대신 '실패, 재시도'를 보게 한다. (튜닝 timeout=60초 + 여유를 둔 값.)
STALE_JOB_SECONDS = 5 * 60


def _age_seconds(dt: datetime) -> float:
    """updated_at 이후 경과 초. DB 에서 온 naive/aware 를 모두 UTC 로 간주해 안전 비교."""
    now = datetime.now(timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return (now - dt).total_seconds()


def _is_cancelled(job_id: str) -> bool:
    """job 의 취소 요청 여부를 '새 세션'으로 신선하게 읽는다.

    ⚠ 취소는 별도 요청(POST /train/cancel)이 '다른 커넥션(멀티 워커면 다른 프로세스)'에서 커밋한다.
      실행부의 장수 세션으로 읽으면 식별맵/트랜잭션 스냅샷 때문에 옛 값을 볼 수 있어, 매번 새 세션을 열어
      DB 에서 곧바로 읽는다(공유 DB 라 워커/프로세스 간 즉시 반영). trial 당 1회라 비용은 무시할 수준.
    """
    db = SessionLocal()
    try:
        job = db.get(TuningJob, job_id)
        return bool(job is not None and job.cancelled)
    finally:
        db.close()


def reap_if_stalled(db: Any, job: TuningJob) -> None:
    """status=running 인데 updated_at 이 STALE_JOB_SECONDS 넘게 낡았으면 failed 로 전환(멈춘 작업 감지).

    상태 조회(폴링) 시 호출한다. 실행부와 무관하게 DB 만 본다 → 어느 워커가 조회해도 동일하게 판정.
    """
    if job.status == "running" and _age_seconds(job.updated_at) > STALE_JOB_SECONDS:
        job.status = "failed"
        job.error = "작업이 중단되었습니다(서버 재시작 등). 다시 시도해 주세요."
        db.commit()


def start_tuning_job(req: Any) -> str:
    """[트리거] tuning_jobs 레코드 생성(status=running) 후 실행부를 백그라운드로 제출. jobId 반환(학습 대기 안 함)."""
    job_id = str(uuid.uuid4())
    db = SessionLocal()
    try:
        db.add(TuningJob(id=job_id, status="running", progress=0, total=TUNE_MAX_TRIALS))
        db.commit()
    finally:
        db.close()
    # 지금은 스레드풀. 나중에 Redis 큐로 바꾸면 이 줄만 queue.enqueue(run_tuning_job, job_id, req) 로 교체.
    _executor.submit(run_tuning_job, job_id, req)
    return job_id


def run_tuning_job(job_id: str, req: Any) -> None:
    """[실행부] 이미 생성된 job 을 튜닝→best 로 최종 학습→result DB 저장. 실패 시 status=failed+error.

    ⚠ 트리거(스레드/큐)와 무관 — 오직 DB(tuning_jobs)로만 상태를 갱신한다. 큐 워커가 그대로 호출 가능.
    스레드 전용 DB 세션을 연다(요청 세션은 응답 후 닫히므로 재사용 불가).
    """
    db = SessionLocal()
    try:
        def progress_cb(done: int, total: int, best_score: float, best_params: dict) -> None:
            # 매 trial: 짧은 트랜잭션으로 진행률 커밋 → 폴링이 최신값을 읽는다(updated_at 도 onupdate 로 자동 갱신 → 멈춤 감지 기준).
            job = db.get(TuningJob, job_id)
            if job is None:
                return
            job.progress = done
            job.total = total
            job.best_score = best_score
            job.best_params = best_params
            db.commit()

        # 튜닝은 서브샘플로(svr·svc 만 축소, 그 외는 전체 그대로). 최종 학습(train_*_manual)은 아래에서 전체 req 를 쓴다.
        Xt, yt = subsample_for_tuning(req.algo, req.X, req.y)
        # 튜닝 알고리즘·CV·timeout 은 동기 경로와 동일(tuning.py 재사용). 콜백만 추가(진행률 보고 + 협조적 취소 확인).
        tune_result = tune_hyperparams(
            req.task, req.algo, Xt, yt, progress_cb=progress_cb, cancel_cb=lambda: _is_cancelled(job_id)
        )

        # 협조적 취소: 튜닝이 study.stop() 으로 조기 종료됐으면 '최종 학습(전체 데이터)'을 하지 않고 cancelled 로 마감.
        #   → 취소 후 남은 CPU 비용(가장 큰 전체-데이터 학습)을 실제로 차단한다. tune_result 상태와 무관하게 DB 가 최종 판정.
        if _is_cancelled(job_id):
            job = db.get(TuningJob, job_id)
            if job is not None and job.status == "running":
                job.status = "cancelled"
                db.commit()
            return

        if tune_result is None:
            raise ValueError(f"튜닝 미지원 모델입니다: {req.algo}")
        best = tune_result["bestParams"]

        # best 로 최종 학습 — 전체 데이터(req) 로 수동 경로 학습(서브샘플 아님). rf~svc 동일 로직 재사용.
        if req.task == "reg":
            result = train_regression_manual(req, best)
            model_id = store.put_model(result["model"], result["algo"], result["features"], task="reg")
            resp: Any = TrainResponse(model_id=model_id, usedParams=(best or None), bestParams=best, **result["response"])
        else:
            result = train_classification_manual(req, best)
            model_id = store.put_model(result["model"], result["algo"], result["features"], task="cls", classes=result["classes"])
            resp = ClsTrainResponse(model_id=model_id, usedParams=(best or None), bestParams=best, **result["response"])

        job = db.get(TuningJob, job_id)
        if job is not None:
            job.status = "done"
            job.best_params = best
            job.best_score = tune_result["bestScore"]
            job.result = resp.model_dump()  # TrainResponse 형태 JSON(동기 응답과 동일 스키마)
            db.commit()
    except Exception as e:  # noqa: BLE001 — 어떤 실패든 job 에 기록(백그라운드 스레드가 조용히 죽지 않게).
        db.rollback()
        try:
            job = db.get(TuningJob, job_id)
            if job is not None:
                # 취소로 인한 조기 예외(예: 완료 trial 0개에서 취소)면 failed 가 아니라 cancelled 로 마감.
                if job.cancelled:
                    job.status = "cancelled"
                else:
                    job.status = "failed"
                    job.error = str(e)[:1000]
                db.commit()
        except Exception:
            pass
    finally:
        db.close()
