"""감사 로그 기록 헬퍼 — best-effort(기록 실패가 본 동작을 막지 않는다).

행위자/대상은 로그 시점 스냅샷(email·role)으로 동결 저장한다. 민감정보(비번·해시·토큰·임시비번)는
절대 담지 않는다. 호출부는 본 동작을 커밋한 뒤(또는 같은 트랜잭션 끝에) 이 함수를 호출한다.
"""
from __future__ import annotations

import logging

from sqlalchemy.orm import Session

from .models_db import AuditLog, User

logger = logging.getLogger("audit")


def record_audit(
    db: Session,
    *,
    actor: User,
    action: str,
    target: User,
    detail: str | None = None,
) -> None:
    """감사 로그 1건 기록(별도 커밋). 실패해도 예외를 삼켜 본 동작에 영향 없게 한다."""
    try:
        entry = AuditLog(
            actor_user_id=actor.id,
            actor_email=actor.email,
            actor_role=actor.role,
            action=action,
            target_user_id=target.id,
            target_email=target.email,
            organization_id=target.organization_id,
            detail=detail,
        )
        db.add(entry)
        db.commit()
    except Exception:  # noqa: BLE001 — 감사 로그는 부가 기록, 본 동작을 막지 않는다.
        logger.exception("감사 로그 기록 실패(action=%s) — 본 동작은 유지", action)
        try:
            db.rollback()
        except Exception:  # noqa: BLE001
            pass
