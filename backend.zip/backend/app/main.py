"""FastAPI 앱 진입점 — 라우터 등록 + CORS.

설치형/폐쇄망: 프론트와 같은 내부망에서만 접근하도록 배포. 인증/DB/Redis는 다음 단계.
"""
from __future__ import annotations

import os
import warnings

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .db import engine  # noqa: F401  DB 엔진 초기화(데이터 디렉터리 보장). 스키마는 Alembic 이 관리한다.
from .deps import get_current_user
from .routers import audit, auth, groups, models, organizations, users

# LightGBM 은 이름 없는 입력(리스트/배열)에도 스스로 Column_0.. 이라는 feature name 을 심는다.
#   → predict 시 sklearn 이 "fit 때는 이름이 있었는데 지금 X 엔 없다"며 UserWarning 을 낸다(LGBM 2종 한정).
#   학습 경로는 X 를 항상 리스트로 넘기고 DataFrame 은 어디서도 쓰지 않으므로 이 불일치는 항상 무해하며
#   지표·계수·중요도·vizTree 에 영향이 없다. 이 메시지 하나만 끈다(다른 경고는 그대로 노출).
warnings.filterwarnings("ignore", message="X does not have valid feature names", category=UserWarning)

# MLP 학습 중 numpy 가 내는 matmul 부동소수점 플래그 경고(divide by zero / overflow / invalid value).
#   우리 코드와 무관한 환경 이슈 — 순수 sklearn MLPRegressor + make_regression 으로도 그대로 재현된다
#   (numpy 2.2 + macOS BLAS). 학습 결과에는 영향이 없다(R²·지표 동일). matmul 한정으로만 끈다.
#   (message 는 앞부분부터 매칭이라 ".*" 로 시작 문구를 흡수 — divide by zero/overflow/invalid 3종 모두 포함.)
warnings.filterwarnings("ignore", message=".*encountered in matmul", category=RuntimeWarning)

# LogisticRegression(L-BFGS solver) 학습 시 sklearn 1.6 + SciPy 조합이 내는 "Unknown solver options: iprint".
#   우리 코드와 무관(iprint 를 우리가 넘기지 않음) — 결과에 영향 없다(정확도·계수 정상). 이 메시지만 끈다.
#   category(OptimizeWarning)만으로 끄면 다른 최적화 경고까지 숨겨지므로 message 로 특정한다.
from scipy.optimize import OptimizeWarning  # noqa: E402  (경고 필터 등록용 — import 순서보다 이 위치가 의도적)

warnings.filterwarnings("ignore", message="Unknown solver options: iprint", category=OptimizeWarning)

app = FastAPI(title="Elio 분석 백엔드", version="0.1.0")

# CORS 오리진은 환경변수 ALLOWED_ORIGINS(콤마 구분)로 주입.
#   - 미설정 시 개발 기본값(로컬 프론트 5273).
#   - 설치형/배포 시 실제 프론트 오리진만 지정할 것. "*"도 허용(개발 전용).
_default_origins = "http://localhost:5273,http://127.0.0.1:5273"
_origins = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", _default_origins).split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 계산/데이터 API 는 로그인 필수(hard) — 라우터 전체에 get_current_user 게이트.
#   (핸들러가 user 객체를 쓰지 않으므로 라우터-레벨 dependencies 로 일괄 적용. 401 은 get_current_user 기본 동작.)
app.include_router(models.router, dependencies=[Depends(get_current_user)])
# /auth/* 는 로그인 자체이므로 개방 유지. /users·/organizations·/groups 는 이미 require_role 로 보호됨(중복 적용 안 함).
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(organizations.router)
app.include_router(groups.router)
app.include_router(audit.router)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
