"""Optuna 기반 하이퍼파라미터 자동 튜닝 — rf·xgb(빠름) + gb·lightgbm·catboost·mlp(느림, 비동기 전용).

학습이 비동기(백그라운드+폴링)라 프론트 타임아웃에 묶이지 않는다. 다만 느린 모델(gb·mlp 등)은 무한정 돌 수 있어
모델별 timeout 으로 벽시계 상한을 건다(rf·xgb=60초, 느린 4개=180초). timeout·n_trials 중 먼저 도달 시 종료.

안전장치:
  - study.optimize(timeout, n_trials): 둘 중 먼저 도달하면 종료 → 긴 학습 상한.
  - objective 는 5-fold CV 점수(_cv_score)로 평가 → 홀드아웃 단일 분할 과적합 방지.
탐색 공간은 hyperparams.py 의 해당 모델 스펙(min/max/widget)에서 자동 매핑한다(수동 슬라이더 범위와 동일 원천).
  - 단 고비용 trial 을 막기 위한 '튜닝 전용 상한 캡'만 _SUGGEST_RANGE_OVERRIDE 로 둔다(수동 슬라이더는 불변).
"""
from __future__ import annotations

import warnings
from typing import Any, Callable, Optional

import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import accuracy_score, r2_score
from sklearn.model_selection import KFold, StratifiedKFold

from .hyperparams import build_estimator, get_spec

# 튜닝 지원 모델 — rf·xgboost(빠름) + lightgbm·catboost·mlp(느림) + svr·svc(느림, 서브샘플)
#   + lstm(시계열 딥러닝, 연속 서브샘플+순차 CV) + transformer(표 데이터 딥러닝, 랜덤 서브샘플+일반 CV).
TUNABLE_ALGOS = {"rf", "xgboost", "lightgbm", "catboost", "mlp", "svr", "svc", "lstm", "transformer"}
# 느린 모델 — 기본 180초 timeout. lstm 은 딥러닝이라 300초(아래 _TIMEOUT_BY_ALGO 로 개별 지정).
_SLOW_ALGOS = {"lightgbm", "catboost", "mlp", "svr", "svc"}
CV_FOLDS = 5
TUNE_MAX_TRIALS = 50  # trial 수 상한. timeout 전에 이걸로 먼저 종료될 수도 있다.
TUNE_TIMEOUT_FAST_SEC = 60  # rf·xgb 벽시계 상한(초).
TUNE_TIMEOUT_SLOW_SEC = 180  # 느린 모델 벽시계 상한(초, 최대 3분).
# 모델별 개별 상한(위 기본을 이김). lstm·transformer 는 딥러닝이라 timeout 300초(5분) + trial 20개로 제한.
_TIMEOUT_BY_ALGO: dict[str, int] = {"lstm": 300, "transformer": 300}
_MAX_TRIALS_BY_ALGO: dict[str, int] = {"lstm": 20, "transformer": 20}

# 서브샘플 튜닝 — 전체(35k)로는 느려서 표본으로 '튜닝만' 하고, 최종 학습은 호출부(run_tuning_job)가 전체 데이터로 한다.
#   svr·svc: O(n²) → 랜덤 표본(svr 3000·svc 5000). lstm: 시계열이라 반드시 '연속 블록'(랜덤 금지 — 윈도우 순서 파괴).
#   transformer: 표 데이터(행 독립)라 랜덤 표본 OK(연속 불필요). 딥러닝이라 5-fold CV 가 무거워 3000 으로 줄여 timeout 안에 trial 수를 확보.
_SUBSAMPLE_BY_ALGO: dict[str, int] = {"svr": 3000, "svc": 5000, "lstm": 3000, "transformer": 3000}
_CONTIGUOUS_SUBSAMPLE_ALGOS = {"lstm"}  # 이 모델만 연속 앞 구간으로 서브샘플(랜덤 아님). transformer 는 미포함 → 랜덤 표본.
_SUBSAMPLE_SEED = 42  # 재현성 — 같은 데이터면 같은 표본.

# 튜닝 전용 탐색 범위 캡(수동 슬라이더 범위 hyperparams.py 는 불변). (algo, param) → (min, max).
#   lightgbm: n_estimators 상한 2000→500 — 2000 트리 heavy trial 이 5-fold 에서 40초+ 걸려 예산을 낭비한다(진단).
_SUGGEST_RANGE_OVERRIDE: dict[tuple[str, str], tuple[float, float]] = {
    ("lightgbm", "n_estimators"): (200, 500),
}


def timeout_for(algo: str) -> int:
    """모델별 튜닝 벽시계 상한(초). lstm=300, 그 외 느린 모델=180, rf·xgb=60."""
    if algo in _TIMEOUT_BY_ALGO:
        return _TIMEOUT_BY_ALGO[algo]
    return TUNE_TIMEOUT_SLOW_SEC if algo in _SLOW_ALGOS else TUNE_TIMEOUT_FAST_SEC


def trials_for(algo: str) -> int:
    """모델별 trial 수 상한. lstm=20(딥러닝이라 적게), 그 외=TUNE_MAX_TRIALS(50)."""
    return _MAX_TRIALS_BY_ALGO.get(algo, TUNE_MAX_TRIALS)


def subsample_for_tuning(algo: str, X: Any, y: Any) -> tuple[Any, Any]:
    """느린 모델은 서브샘플로 줄여 튜닝 비용을 낮춘다. 그 외 모델은 전체 그대로 반환.

    ⚠ 튜닝(best_params 탐색)에만 쓴다 — 최종 학습은 호출부가 전체 데이터를 쓴다.
    데이터가 표본 크기보다 작으면 전체를 그대로 사용(에러 없이).
    · lstm(시계열): 반드시 '연속 앞 구간' 서브샘플 — 랜덤은 슬라이딩 윈도우의 시점 연속성을 파괴한다.
      (프론트가 시간 순서 컬럼으로 이미 정렬해 보내므로, 앞 구간 = 연속 시간 블록.)
    · svr·svc: 랜덤 표본(seed 고정, 재현성). 순서 무관 모델이라 랜덤 OK.
    """
    n_sub = _SUBSAMPLE_BY_ALGO.get(algo)
    if n_sub is None or len(X) <= n_sub:
        return X, y
    if algo in _CONTIGUOUS_SUBSAMPLE_ALGOS:
        return X[:n_sub], y[:n_sub]  # 연속 앞 구간(윈도우 순서 보존)
    idx = np.random.default_rng(_SUBSAMPLE_SEED).choice(len(X), size=n_sub, replace=False)
    return [X[i] for i in idx], [y[i] for i in idx]


def _cv_score(task: str, algo: str, params: dict[str, Any], X: Any, y: Any) -> float:
    """5-fold CV 평균 점수(회귀=R², 분류=accuracy). '높을수록 좋음'.

    폴드마다 build_estimator 로 새 추정기를 만들어 sklearn clone 을 피한다
    (_XGBoostClassifier 래퍼는 BaseEstimator 가 아니라 cross_val_score 의 clone 과 비호환).
    """
    Xa = np.asarray(X, dtype=float)
    if task == "cls":
        ya = np.asarray([str(v) for v in y])
        splitter = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=42)
        split_iter = splitter.split(Xa, ya)
    elif algo == "lstm":
        # ⚠ lstm(시계열)은 순차 KFold(shuffle=False) — 섞으면 슬라이딩 윈도우의 시점 연속성이 깨져 CV 점수가 왜곡된다.
        #   폴드 = 연속 블록(각 구간 내부 순서 보존). shuffle=False 라 random_state 는 넘기지 않는다(sklearn 이 거부).
        ya = np.asarray([float(v) for v in y], dtype=float)
        splitter = KFold(n_splits=CV_FOLDS, shuffle=False)
        split_iter = splitter.split(Xa)
    else:
        ya = np.asarray([float(v) for v in y], dtype=float)
        splitter = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=42)
        split_iter = splitter.split(Xa)
    scores: list[float] = []
    # mlp 는 heavy net 이 max_iter(1000) 내 미수렴 시 ConvergenceWarning 을 낸다 — 비치명적이라 objective 를 막지 않지만
    #   로그 소음이라 억제한다(에러는 그대로 전파). CV 산식·결과엔 영향 없음.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", ConvergenceWarning)
        for tr, va in split_iter:
            est = build_estimator(task, algo, params)  # 폴드마다 새 인스턴스(clone 불필요)
            est.fit(Xa[tr].tolist(), ya[tr].tolist())
            pred = est.predict(Xa[va].tolist())
            scores.append(accuracy_score(ya[va], pred) if task == "cls" else r2_score(ya[va], pred))
    return float(np.mean(scores))


def _suggest_params(trial: Any, spec: dict[str, Any], algo: str) -> dict[str, Any]:
    """스펙 파라미터를 Optuna suggest 로 매핑.

    int/enum_or_int → suggest_int(min,max)  · float/enum_or_float → suggest_float(min,max, log=log-slider면 True)
    순수 enum(class_weight·auto_class_weights 등)은 제외 → 추정기 기본값 유지(튜닝 대상 아님).
    _SUGGEST_RANGE_OVERRIDE 에 (algo, param) 캡이 있으면 그 범위로 대체(고비용 trial 방지, 수동 슬라이더는 불변).
    """
    out: dict[str, Any] = {}
    for p in spec["params"]:
        name, typ = p["name"], p["type"]
        lo, hi = p.get("min"), p.get("max")
        ov = _SUGGEST_RANGE_OVERRIDE.get((algo, name))
        if ov is not None:
            lo, hi = ov  # 튜닝 전용 캡
        if typ in ("int", "enum_or_int"):
            # ⚠ transformer 만 step 을 적용해 수동 슬라이더와 같은 그리드로 제한한다 → d_model{64,128,192,256}×n_heads{4,8}
            #   가 항상 나눠떨어져(MultiheadAttention 제약) 크래시를 막는다. suggest_int 는 기본적으로 step 을 무시(임의 정수)라
            #   d_model=100·n_heads=7 같은 off-grid 조합이 나오면 학습이 죽는다. 다른 모델은 종전대로(step 미적용) — LSTM 등 무변경.
            step = int(p["step"]) if (algo == "transformer" and p.get("step")) else None
            out[name] = trial.suggest_int(name, int(lo), int(hi), step=step) if step else trial.suggest_int(name, int(lo), int(hi))
        elif typ in ("float", "enum_or_float"):
            out[name] = trial.suggest_float(name, float(lo), float(hi), log=(p.get("widget") == "log-slider"))
        # "enum"(class_weight·auto_class_weights 등)은 제외
    return out


def tune_hyperparams(
    task: str,
    algo: str,
    X: Any,
    y: Any,
    timeout: Optional[int] = None,
    n_trials: Optional[int] = None,
    progress_cb: Optional[Callable[[int, int, float, dict[str, Any]], None]] = None,
    cancel_cb: Optional[Callable[[], bool]] = None,
) -> Optional[dict[str, Any]]:
    """지원 모델(TUNABLE_ALGOS)을 5-fold CV 로 튜닝(lstm 은 순차 CV). 반환 {bestParams, bestScore, defaultScore, nTrials}.

    timeout·n_trials: None 이면 모델별 기본(timeout_for·trials_for)을 쓴다. timeout·n_trials 중 먼저 도달 시 종료.
    지원 안 되는 algo(svc 등)면 None 반환 → 호출부는 기존 default 경로로 처리(에러 아님).
    progress_cb(선택): 매 trial 종료 후 (완료수, 전체상한, 현재best점수, 현재best파라미터)로 호출 → 비동기 작업의 DB 진행률 갱신용.
      ⚠ 튜닝 알고리즘·CV 로직은 그대로. 콜백은 부수효과(진행률 보고)만이며 결과에 영향 없다.
    cancel_cb(선택): 매 trial 종료 후 호출해 True 면 study.stop() → 다음 trial 을 시작하지 않는다(협조적 취소, 스레드 kill 아님).
      진행 중이던 trial 1개는 완주한 뒤 멈춘다(Optuna 특성). CV·objective 로직은 불변 — 취소 확인만 추가한다.
    """
    if algo not in TUNABLE_ALGOS:
        return None
    spec = get_spec(task, algo)
    if spec is None:
        return None
    if timeout is None:
        timeout = timeout_for(algo)  # 모델별 벽시계 상한
    if n_trials is None:
        n_trials = trials_for(algo)  # 모델별 trial 상한(lstm=20)

    import optuna

    optuna.logging.set_verbosity(optuna.logging.WARNING)

    def objective(trial: Any) -> float:
        params = _suggest_params(trial, spec, algo)
        return _cv_score(task, algo, params, X, y)

    callbacks = None
    if progress_cb is not None or cancel_cb is not None:
        def _cb(study: Any, _trial: Any) -> None:
            if progress_cb is not None:
                try:
                    progress_cb(len(study.trials), n_trials, float(study.best_value), dict(study.best_params))
                except Exception:
                    pass  # 진행률 보고 실패는 튜닝을 막지 않는다(부수효과일 뿐).
            # 협조적 취소: 취소 요청이 있으면 study.stop() → 다음 trial 은 시작하지 않는다(진행 중 trial 은 완주).
            if cancel_cb is not None:
                try:
                    if cancel_cb():
                        study.stop()
                except Exception:
                    pass  # 취소 확인 실패는 튜닝을 막지 않는다(다음 콜백/타임아웃이 처리).

        callbacks = [_cb]

    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=42))
    study.optimize(objective, n_trials=n_trials, timeout=timeout, callbacks=callbacks)  # 둘 중 먼저 도달하면 종료

    # 협조적 취소로 study.stop() 되어 조기 종료된 경우: default 비교 CV(추가 계산)를 건너뛰고 즉시 반환
    #   → 취소 후 불필요한 연산을 최소화한다. best 는 완료된 trial 중 최고값(콜백은 trial 완료 후 호출 → 최소 1개 존재).
    #   호출부(run_tuning_job)가 cancelled 를 최종 판정해 마감하므로 반환 dict 형태는 참고용이다.
    if cancel_cb is not None:
        try:
            if cancel_cb() and study.best_trials:
                return {"bestParams": dict(study.best_params), "bestScore": float(study.best_value),
                        "defaultScore": None, "nTrials": len(study.trials), "cancelled": True}
        except Exception:
            pass  # best 접근/취소 확인 실패 → 아래 정상 경로로(호출부가 취소 최종 판정).

    best = study.best_params
    # 같은 파라미터 집합의 default 값 CV 점수(개선 여부 비교용).
    default_params = {p["name"]: p["default"] for p in spec["params"] if p["name"] in best}
    default_score = _cv_score(task, algo, default_params, X, y)
    # 안전장치: 튜닝이 default 보다 못하면(느린 모델·적은 trial 로 탐색 부족 시) default 로 되돌린다 → '나빠지면 안 됨' 보장.
    #   빠른 모델(rf·xgb)은 trial 이 많아 거의 항상 default 이상 → 실질적으로 무영향(기존 동작 유지).
    if study.best_value < default_score:
        return {"bestParams": default_params, "bestScore": default_score, "defaultScore": default_score, "nTrials": len(study.trials)}
    return {
        "bestParams": best,
        "bestScore": study.best_value,
        "defaultScore": default_score,
        "nTrials": len(study.trials),
    }
