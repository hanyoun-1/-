"""앱 설정 로드 — pydantic-settings.

계정 시스템 도입(L2a)에 필요한 DB 설정만 담는다. 인증 시크릿(JWT 등)은 다음 단계에서 추가.
- DATABASE_URL 환경변수로 주입 가능. 미설정 시 SQLite 로컬 파일(backend/data/app.db)을 절대경로로 사용.
- 절대경로로 고정하므로 uvicorn 실행 위치(cwd)와 무관하게 항상 같은 DB 파일을 가리킨다.
"""
from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# backend/ 디렉터리(= 이 파일 기준 두 단계 위: app/settings.py → app → backend)
BACKEND_DIR = Path(__file__).resolve().parent.parent
_DEFAULT_DB_PATH = BACKEND_DIR / "data" / "app.db"
# 실 DB 오염 가드(db.py)에서 "기본 app.db 경로"를 비교하기 위한 공개 별칭.
DEFAULT_DB_PATH = _DEFAULT_DB_PATH


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # 실행 환경: 'dev'(기본) | 'test'. APP_ENV=test 는 "검증/테스트 모드"이며,
    # 이때 실제 app.db 사용을 금지하는 가드가 db.py 에서 작동한다(정상 개발 서버는 무영향).
    app_env: str = "dev"

    # SQLite 절대경로 URL. 예) sqlite:////abs/path/backend/data/app.db
    database_url: str = f"sqlite:///{_DEFAULT_DB_PATH}"

    # ── JWT / 인증(L2b) ─────────────────────────────────────────────
    #  ⚠️ 운영에서는 반드시 환경변수 JWT_SECRET 로 강한 랜덤값을 주입할 것.
    #     아래 기본값은 "개발 전용" 임시값이며 운영 시크릿이 아니다(코드에 운영 시크릿 금지).
    #     생성 예: python -c "import secrets; print(secrets.token_urlsafe(48))"
    jwt_secret: str = "dev-only-insecure-change-me-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 14

    @property
    def is_testing(self) -> bool:
        """검증/테스트 모드 여부(APP_ENV=test)."""
        return self.app_env.strip().lower() == "test"


settings = Settings()

# 개발 기본 시크릿을 그대로 쓰는 경우 기동 시 경고(운영 오배포 방지).
if settings.jwt_secret == "dev-only-insecure-change-me-in-production":
    import warnings

    warnings.warn(
        "JWT_SECRET 이 개발 기본값입니다. 운영 배포 전 환경변수 JWT_SECRET 을 주입하세요.",
        stacklevel=2,
    )
