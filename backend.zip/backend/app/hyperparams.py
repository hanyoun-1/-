"""하이퍼파라미터 명세(spec) + 추정기 팩토리 — 수동 조정 기능의 단일 원천(T1).

이 파일은 "데이터(명세) + 팩토리"만 담는다. 학습 로직(fit/predict/지표)은 여기 넣지 않는다(T2에서 추가).

설계 결정(D1=A): 명세는 백엔드가 단일 원천으로 보유하고, 프론트는 GET /models/hyperparams 로
받아 입력 UI 렌더·1차 검증에 쓴다. 백엔드는 학습 시 이 명세로 값 범위를 최종 검증한다(T2).

명세 단위 구조(파라미터 1개당):
  - name    : sklearn 생성자 인자명 (예: "n_neighbors")
  - label   : 화면 표시명(한글)
  - type    : "int" | "float" | "enum"
  - min/max/step : 숫자형(int/float) 범위·간격
  - choices : enum 선택지 [{"value":..., "label":...}]
  - default : 권장 기본값(노코딩 사용자가 그대로 학습 가능)
  - widget  : UI 힌트 "slider" | "number" | "dropdown" | "radio"
  - help    : 노코딩 사용자용 설명 문구

새 모델 추가 = HYPERPARAM_SPECS 에 (task, algo) 항목 1개 + _ESTIMATORS 매핑 1줄.
"""
from __future__ import annotations

from typing import Any

from sklearn.ensemble import (
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.linear_model import ElasticNet, Lasso, LogisticRegression, Ridge
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC, SVR
from sklearn.tree import DecisionTreeClassifier
from catboost import CatBoostClassifier, CatBoostRegressor
from lightgbm import LGBMClassifier, LGBMRegressor
from xgboost import XGBClassifier, XGBRegressor

# ─────────────────────────── 명세(spec) 레지스트리 ───────────────────────────
# 키: (task, algo) 튜플.  값: {estimator, server_only, params:[...]}
#   - estimator   : _ESTIMATORS 매핑의 키(사용할 sklearn 클래스 이름)
#   - server_only : (레거시 플래그) 현재 모든 모델은 백엔드에서만 학습 → 전부 True. 브라우저 학습 경로는 제거됨.
#   - params      : 위 "명세 단위 구조" 딕셔너리 리스트

# KNN 공용 파라미터 명세 — 회귀/분류가 동일한 label·help·default·범위를 쓰므로 하나로 공유한다(재사용).
#   validate_params/build_estimator 는 이 리스트를 읽기만 하므로 두 항목이 참조를 공유해도 안전하다.
_KNN_PARAMS: list[dict[str, Any]] = [
    {
        "name": "n_neighbors",
        "label": "이웃 수",
        "type": "int",
        "min": 3,
        "max": 30,
        "step": 1,
        "default": 5,
        "widget": "slider",
        "help": "예측할 때 참고할 가까운 데이터 개수. 작을수록 민감하게, 클수록 부드럽게 예측해요.",
    },
    {
        "name": "weights",
        "label": "이웃 가중 방식",
        "type": "enum",
        "choices": [
            {"value": "uniform", "label": "동일 비중"},
            {"value": "distance", "label": "가까울수록 큰 비중"},
        ],
        "default": "uniform",
        "widget": "dropdown",
        "help": "이웃들을 똑같이 볼지, 가까운 이웃을 더 신뢰할지 정해요.",
    },
    {
        "name": "p",
        "label": "거리 계산법",
        "type": "enum",
        "choices": [
            {"value": 1, "label": "맨해튼(격자) 거리"},
            {"value": 2, "label": "직선(유클리드) 거리"},
        ],
        "default": 2,
        "widget": "radio",
        "help": "데이터 점 사이 거리를 재는 방법이에요.",
    },
]

# supports_scaling: 거리 기반 모델(KNN 등)은 입력 스케일에 민감 → 표준화(StandardScaler) 옵션 제공(기본 켜짐).
#   트리 계열은 스케일 불변이라 미표기(False). 프론트가 이 플래그로 스케일링 체크박스 노출을 판단한다(W2).
# SVM 공용 파라미터 — SVR/SVC 가 C·kernel 을 공유한다(읽기 전용 공유 참조).
_SVM_C = {
    "name": "C",
    "label": "규제 강도(C)",
    "type": "float",
    "min": 0.1,
    "max": 100,
    "step": 0.1,
    "default": 1.0,
    "widget": "log-slider",  # 값은 여전히 float[0.1~100]; 프론트만 log 스케일로 표시(검증 불변).
    "help": "규제 강도. 클수록 훈련데이터에 더 맞추려 해요(과적합 주의).",
}
_SVM_KERNEL = {
    "name": "kernel",
    "label": "커널",
    "type": "enum",
    "choices": [
        {"value": "rbf", "label": "RBF(곡선 경계)"},
        {"value": "linear", "label": "선형"},
    ],
    "default": "rbf",
    "widget": "dropdown",
    "help": "데이터를 나누는 경계의 형태예요.",
}
_SVC_GAMMA = {
    "name": "gamma",
    "label": "커널 폭(gamma)",
    "type": "enum_or_float",  # 문자열 선택지(scale/auto) 또는 숫자 직접 입력(min~max) 혼합.
    "choices": [
        {"value": "scale", "label": "scale (권장 · 분산 반영)"},
        {"value": "auto", "label": "auto (피처 수만)"},
    ],
    "min": 1e-4,
    "max": 1,
    "default": "scale",
    "widget": "enum-or-number",
    "help": "커널 폭(한 점의 영향 범위). scale은 데이터 분산까지 반영해 보통 최선이고, auto는 피처 수만 봐요. 직접 숫자로 지정할 수도 있어요.",
}

# 선형 규제 계열(Ridge/Lasso) 공용 파라미터 — alpha 하나(규제 강도).
_LINEAR_ALPHA = {
    "name": "alpha",
    "label": "규제 강도(alpha)",
    "type": "float",
    "min": 0.01,
    "max": 100,
    "step": 0.01,
    "default": 1.0,
    "widget": "number",
    "help": "규제 강도. 클수록 계수를 더 억제해 과적합을 줄여요.",
}

# ElasticNet 파라미터 — Ridge/Lasso 와 같은 선형 규제 계열이지만 alpha 를 공유하지 않는다:
#   _LINEAR_ALPHA 는 number 위젯(0.01~100)이고, ElasticNet 은 log-slider(1e-3~10)로 쓴다(SVM C·MLP alpha 와 동일 위젯).
#   공용 상수를 고치면 Ridge·Lasso 까지 바뀌므로 전용 정의를 둔다. scaling_help 는 선형 계열과 공유(_SCALE_HELP_LINEAR).
_ELASTIC_PARAMS = [
    {
        "name": "alpha",
        "label": "규제 강도(alpha)",
        "type": "float",
        "min": 1e-3,
        "max": 10,
        "default": 1.0,
        "widget": "log-slider",  # 값 범위가 4자릿수라 로그 스케일 표시(검증은 float 범위 그대로).
        "help": "규제 강도. 클수록 계수를 더 억제해 과적합을 줄여요.",
    },
    {
        "name": "l1_ratio",
        # min=0.05 (0 아님): l1_ratio=0 은 순수 L2 라 좌표하강법이 수렴하지 못해 ConvergenceWarning 이 난다
        #   (sklearn 도 그 경우 Ridge 사용을 권한다). 순수 L2 는 이 툴의 Ridge 가 이미 담당하므로,
        #   경고를 필터로 덮는 대신 구간 자체를 막아 원인을 없앤다.
        "label": "L1 비중(l1_ratio)",
        "type": "float",
        "min": 0.05,
        "max": 1,
        "step": 0.05,
        "default": 0.5,
        "widget": "slider",
        "help": "L1(Lasso)과 L2(Ridge)의 혼합 비율. 1에 가까울수록 불필요한 변수의 계수를 0으로 만들어요. (순수 L2 규제는 Ridge 회귀를 사용하세요)",
    },
]

# 표준화 체크박스의 모델별 안내 문구 — supports_scaling 모델이 "왜 표준화가 권장되는지"를 특성에 맞게 설명.
#   프론트가 curSpec.scaling_help 로 표시(없으면 기본 문구 폴백).
_SCALE_HELP_KNN = "권장 — 이웃까지의 거리로 예측하므로, 변수 크기를 맞추지 않으면 큰 값이 지배해 성능이 크게 떨어질 수 있어요."
_SCALE_HELP_SVM = "권장 — 거리·마진 기반이라 변수 크기를 맞추면 성능이 안정적이에요."
_SCALE_HELP_LINEAR = "권장 — 규제(alpha)가 변수마다 공평하게 적용되도록 크기를 맞춰줘요."
_SCALE_HELP_LOGISTIC = "권장 — 규제(C)가 변수마다 공평하게 적용되도록 크기를 맞춰줘요."

# 로지스틱 회귀 파라미터 — C(규제 강도)·penalty(규제 종류)·class_weight(불균형 대응).
#   C 는 _SVM_C 와 같은 log-slider 패턴이되 범위를 1e-3~100 으로 넓힌다(작을수록 강한 규제).
#   penalty 는 l1/l2 dropdown(solver=saga 로 둘 다 커버). elasticnet 은 l1_ratio 조건부 UI 가 필요해 제외.
#   class_weight 는 dtree/rf 와 동일 dropdown.
_LOGISTIC_PARAMS = [
    {
        "name": "C",
        "label": "규제 강도(C)",
        "type": "float",
        "min": 1e-3,
        "max": 100,
        "default": 1.0,
        "widget": "log-slider",  # 값은 float[1e-3~100]; 프론트만 log 스케일로 표시(검증 불변).
        "help": "규제 강도. 작을수록 계수를 강하게 억제(단순), 클수록 훈련데이터에 더 맞춰요(과적합 주의).",
    },
    {
        # penalty=l1 → 불필요한 변수의 계수를 0 으로 만들어(변수 선택) / l2 → 계수를 완만히 줄인다(기본).
        #   solver 는 estimator_kwargs 에서 saga 로 고정(saga 가 l1·l2 둘 다 커버 → penalty 별 분기 불필요).
        #   elasticnet 은 l1_ratio 가 필수인데 프론트에 조건부 위젯이 없어 제외(먹통 방지). 필요하면 별도 트랙.
        "name": "penalty",
        "label": "규제 종류(penalty)",
        "type": "enum",
        "choices": [
            {"value": "l2", "label": "L2 (기본)"},
            {"value": "l1", "label": "L1 (변수 선택)"},
        ],
        "default": "l2",
        "widget": "dropdown",
        "help": "규제 방식. L2는 계수를 완만히 줄이고, L1은 덜 중요한 변수의 계수를 0으로 만들어 골라내요.",
    },
    {
        "name": "class_weight",
        "label": "클래스 가중치(class_weight)",
        "type": "enum",
        "choices": [
            {"value": None, "label": "없음"},
            {"value": "balanced", "label": "균형(balanced)"},
        ],
        "default": None,
        "widget": "dropdown",
        "help": "클래스 불균형이 심하면 '균형'이 소수 클래스를 더 반영해요.",
    },
]
_SCALE_HELP_MLP = "권장 — 신경망은 입력 크기에 민감해 표준화하면 학습이 안정적이에요."

# Decision Tree(분류) 파라미터 — max_depth 는 None(제한 없음)/정수 혼합형(enum_or_int).
_DTREE_PARAMS = [
    {
        "name": "max_depth",
        "label": "최대 깊이(max_depth)",
        "type": "enum_or_int",  # None(제한 없음) 또는 정수 min~max.
        "choices": [{"value": None, "label": "제한 없음"}],
        "min": 3,
        "max": 20,
        "step": 1,
        "default": 5,
        "widget": "enum-or-number",
        "help": "트리가 자라는 최대 깊이. '제한 없음'은 과적합 위험, 작을수록 단순해요.",
    },
    {
        "name": "min_samples_split",
        "label": "분할 최소 표본(min_samples_split)",
        "type": "int",
        "min": 2,
        "max": 20,
        "step": 1,
        "default": 2,
        "widget": "slider",
        "help": "노드를 나누려면 필요한 최소 표본 수. 클수록 단순해져요.",
    },
    {
        "name": "min_samples_leaf",
        "label": "잎 최소 표본(min_samples_leaf)",
        "type": "int",
        "min": 1,
        "max": 20,
        "step": 1,
        "default": 1,
        "widget": "slider",
        "help": "잎(마지막 노드)에 남아야 할 최소 표본 수. 클수록 단순해져요.",
    },
    {
        "name": "criterion",
        "label": "분할 기준(criterion)",
        "type": "enum",
        "choices": [
            {"value": "gini", "label": "지니(gini)"},
            {"value": "entropy", "label": "엔트로피(entropy)"},
        ],
        "default": "gini",
        "widget": "dropdown",
        "help": "노드 순도를 재는 방식이에요. 보통 결과는 비슷해요.",
    },
    {
        "name": "class_weight",
        "label": "클래스 가중치(class_weight)",
        "type": "enum",
        "choices": [
            {"value": None, "label": "없음"},
            {"value": "balanced", "label": "균형(balanced)"},
        ],
        "default": None,
        "widget": "dropdown",
        "help": "클래스 불균형이 심하면 '균형'이 소수 클래스를 더 반영해요.",
    },
]

# 랜덤 포레스트(rf) 공용 파라미터 — 회귀/분류 동일(리스트 하나를 공유).
#   default 는 하드코딩 경로의 값과 일치시켜 "튜닝 안 한 rf"와 "기본값으로 튜닝한 rf"가 같은 숲이 되게 한다:
#     n_estimators=100(하드코딩도 100으로 통일) · max_depth=9 · max_features≈1/3 · min_samples_leaf=4.
#   비튜닝 인자(bootstrap·random_state·n_jobs)는 estimator_kwargs 로 보존한다.
#   max_depth·max_features 는 "선택지 또는 숫자" 혼합형 → dtree max_depth(enum_or_int)·SVC gamma(enum_or_float) 와 동일 위젯.
_RF_PARAMS = [
    {
        "name": "n_estimators",
        "label": "트리 개수(n_estimators)",
        "type": "int",
        "min": 100,
        "max": 800,
        "step": 10,
        "default": 100,
        "widget": "slider",
        "help": "숲을 이루는 나무 수. 많을수록 안정적이지만 느려져요.",
    },
    {
        "name": "max_depth",
        "label": "트리 깊이(max_depth)",
        "type": "enum_or_int",  # None(제한 없음) 또는 정수 min~max.
        "choices": [{"value": None, "label": "제한 없음"}],
        "min": 5,
        "max": 30,
        "step": 1,
        "default": 9,
        "widget": "enum-or-slider",  # 드롭다운(제한 없음/직접 입력) + 직접 입력 시 슬라이더. dtree 는 enum-or-number 유지.
        "help": "나무가 자라는 최대 깊이. '제한 없음'은 과적합 위험, 작을수록 단순해요.",
    },
    {
        "name": "max_features",
        "label": "분할 후보 변수 수(max_features)",
        "type": "enum_or_float",  # 문자열 선택지(sqrt/log2) 또는 비율 직접 입력(min~max) 혼합.
        "choices": [
            {"value": "sqrt", "label": "sqrt (√변수 수)"},
            {"value": "log2", "label": "log2 (log₂변수 수)"},
        ],
        "min": 0.3,
        "max": 1.0,
        "step": 0.05,  # 슬라이더 간격. 없으면 프론트가 step=1 로 폴백해 0.3 에서 움직이지 않는다(범위가 0.3~1.0 이라).
        "default": 0.333,  # 기존 하드코딩 1/3 에 대응(전체 변수의 약 1/3 을 후보로).
        "widget": "enum-or-slider",  # 드롭다운(sqrt/log2/직접 입력) + 직접 입력 시 슬라이더. SVC gamma 는 enum-or-number 유지.
        "help": "각 분할에서 후보로 볼 변수 수. 적을수록 나무들이 서로 달라져 숲이 다양해져요.",
    },
    {
        "name": "min_samples_leaf",
        "label": "잎 최소 표본(min_samples_leaf)",
        "type": "int",
        "min": 1,
        "max": 10,
        "step": 1,
        "default": 4,
        "widget": "slider",
        "help": "잎(마지막 노드)에 남아야 할 최소 표본 수. 클수록 단순해져요.",
    },
]

# 분류 rf 전용 파라미터 = 공용 4종 + class_weight.
#   class_weight 는 RandomForestClassifier 에만 있는 인자다(Regressor 에 넘기면 TypeError) → _RF_PARAMS(회귀·분류 공용)
#   에는 절대 넣지 않고, 분류 명세에서만 쓰는 새 리스트를 만든다. 명세는 dtree 의 class_weight 와 동일 패턴(dropdown).
#   default=None → 지정 안 하던 기존 동작과 동일(가중치 없음).
_RF_CLS_PARAMS = [
    *_RF_PARAMS,
    {
        "name": "class_weight",
        "label": "클래스 가중치(class_weight)",
        "type": "enum",
        "choices": [
            {"value": None, "label": "없음"},
            {"value": "balanced", "label": "균형(balanced)"},
        ],
        "default": None,
        "widget": "dropdown",
        "help": "클래스 불균형이 심하면 '균형'이 소수 클래스를 더 반영해요.",
    },
]

# 진짜 XGBoost(xgboost 라이브러리) 공용 파라미터 — 부스팅 공통 3종으로 시작.
#   label·widget 패턴(learning_rate=log-slider)은 다른 부스팅과 동일하되 범위·기본값은 XGBoost 관례에 맞춤.
_XGBOOST_PARAMS = [
    {
        "name": "n_estimators",
        "label": "트리 개수(n_estimators)",
        "type": "int",
        "min": 200,
        "max": 2000,
        "step": 50,
        "default": 300,
        "widget": "slider",
        "help": "트리 개수. 많을수록 안정적이지만 느려져요.",
    },
    {
        "name": "learning_rate",
        "label": "학습률(learning_rate)",
        "type": "float",
        "min": 0.01,
        "max": 0.3,
        "step": 0.01,
        "default": 0.1,
        "widget": "log-slider",
        "help": "학습률. 낮을수록 트리가 더 많이 필요해요.",
    },
    {
        "name": "max_depth",
        "label": "트리 깊이(max_depth)",
        "type": "int",
        "min": 3,
        "max": 12,
        "step": 1,
        "default": 6,
        "widget": "slider",
        "help": "트리 깊이. 클수록 복잡해져요.",
    },
]

# 분류 XGB 전용 = 공용 3종 + class_weight.
#   XGBClassifier 는 class_weight 를 무시하므로(먹통) 명세 값은 dropdown 이되, 실제 구현은 _XGBoostClassifier 래퍼가
#   fit 에서 sample_weight 로 변환한다(scale_pos_weight 대신 — 다중 클래스에서도 작동). 회귀(_XGBOOST_PARAMS)엔 넣지 않는다.
#   LGBM class_weight 명세와 동일 dropdown → 세 부스팅 UI 일관. default=None → 지정 안 하던 기존 동작과 동일.
_XGBOOST_CLS_PARAMS = [
    *_XGBOOST_PARAMS,
    {
        "name": "class_weight",
        "label": "클래스 가중치(class_weight)",
        "type": "enum",
        "choices": [
            {"value": None, "label": "없음"},
            {"value": "balanced", "label": "균형(balanced)"},
        ],
        "default": None,
        "widget": "dropdown",
        "help": "클래스 불균형이 심하면 '균형'이 소수 클래스를 더 반영해요.",
    },
]


class _XGBoostClassifier:
    """문자열 라벨 자동 인코딩 XGBClassifier 래퍼.

    XGBClassifier(1.6+)는 정수 0..n-1 라벨만 받는다. 기존 분류 학습 경로(train_classification_manual)는
    문자열 클래스를 그대로 넘기고 SklearnClsModel 이 clf.classes_(문자열)로 proba 열을 재정렬한다.
    이 래퍼가 sklearn 분류기 인터페이스(fit/classes_/predict_proba/feature_importances_)를 문자열 클래스
    기준으로 제공하므로 기존 코드가 무수정 동작한다. 정렬된 클래스를 0..k-1 로 인코딩 → predict_proba
    열 순서 = classes_(정렬) 순서와 일치.
    """

    def __init__(self, **kwargs: Any) -> None:
        # class_weight 는 XGBClassifier 가 **kwargs 로 삼켜 조용히 무시한다(먹통). 여기서 가로채 보관하고
        #   XGBClassifier 엔 넘기지 않는다. 실제 불균형 대응은 fit 에서 y 로 sample_weight 를 계산해 적용한다.
        self._balance = kwargs.pop("class_weight", None)
        self._clf = XGBClassifier(**kwargs)

    def fit(self, X: Any, y: Any) -> "_XGBoostClassifier":
        self.classes_ = sorted({str(v) for v in y})
        enc = {c: i for i, c in enumerate(self.classes_)}
        y_enc = [enc[str(v)] for v in y]
        if self._balance == "balanced":
            # sklearn 'balanced' 와 동일한 표본 가중: 각 샘플에 n / (k * 그 클래스 표본수). 이진·다중 공통.
            #   LGBM class_weight='balanced' 와 계산 의미가 같다 → 세 부스팅의 '균형' 옵션이 일관.
            n, k = len(y), len(self.classes_)
            cnt: dict[str, int] = {}
            for v in y:
                cnt[str(v)] = cnt.get(str(v), 0) + 1
            w = [n / (k * cnt[str(v)]) for v in y]
            self._clf.fit(X, y_enc, sample_weight=w)
        else:
            self._clf.fit(X, y_enc)
        return self

    def predict_proba(self, X: Any) -> Any:
        return self._clf.predict_proba(X)

    def predict(self, X: Any) -> list[str]:
        return [self.classes_[int(i)] for i in self._clf.predict(X)]

    @property
    def feature_importances_(self) -> Any:
        return self._clf.feature_importances_


# ─────────────────── LSTM 학습 시간 추정 (프론트 lib/compute/lstmEstimate.ts 와 동기화) ───────────────────
# ⚠ 아래 계수는 프론트(src/lib/compute/lstmEstimate.ts)와 반드시 같은 값이어야 한다. 한쪽만 바꾸면 이중 방어가 어긋난다.
#   실측 근거: mac arm64 M-series, 1스레드, epochs=10 고정, Steel 규모 등 12점 회귀(hidden 은 제곱이 아니라 오프셋 선형).
#   estimated = COEF × seq × window × (HIDDEN_OFFSET + HIDDEN_SLOPE × hidden_units) × num_layers × MARGIN
#     seq = floor(rows × (1 − testRatio)) − window  (학습 시퀀스 수; 0 이하면 학습 불가 → 폴백, 추정 0)
#   MARGIN 1.5 = 과소추정 방지(명세 범위 내 최대 과소 -13% → 1.3) + 하드웨어 편차(Linux 미확인) 흡수.
#   ⚠ 배포 서버(Linux)에서 재캘리브레이션 시 이 5개 상수만 조정하면 된다(프론트도 동일 값으로).
_LSTM_EST_COEF = 7.1e-7
_LSTM_EST_HIDDEN_OFFSET = 7.3
_LSTM_EST_HIDDEN_SLOPE = 0.26
_LSTM_EST_MARGIN = 1.5
LSTM_TIME_LIMIT_SEC = 120  # API_TIMEOUT_MS(120000) 와 동일 근거


def estimate_lstm_seconds(rows: int, test_ratio: float, params: dict[str, Any]) -> float:
    """LSTM 학습 예상 시간(초). seq<=0(window≥학습행수)이면 학습 불가(평균 폴백)라 0 반환(차단 안 함)."""
    window = int(params.get("window", 10))
    hidden = int(params.get("hidden_units", 32))
    layers = int(params.get("num_layers", 1))
    seq = int(rows * (1.0 - test_ratio)) - window
    if seq <= 0:
        return 0.0
    return _LSTM_EST_COEF * seq * window * (_LSTM_EST_HIDDEN_OFFSET + _LSTM_EST_HIDDEN_SLOPE * hidden) * layers * _LSTM_EST_MARGIN


# ─────────────────── Transformer(표 데이터) 학습 시간 추정 (라우터 사전 가드용) ───────────────────
# ⚠ 표(tabular) 방식이라 window 가 없다 → 기존 window O(w²) 항 제거. 실규모 실측(35,040행×6피처 + 피처수 스윕,
#   epochs 10 고정, 1스레드, mac arm64) 회귀로 재확정.
#   estimated = COEF × train_rows × num_layers × n_tokens × d_model × MARGIN
#     train_rows = floor(rows × (1 − testRatio))   (학습 행수; 각 행이 독립 샘플, 윈도우 없음)
#     n_tokens   = n_features + 1                  (피처 토큰 + CLS 토큰 = 시퀀스 길이)
#   ★ 실측상 fit 은 train_rows·num_layers·n_tokens·d_model 각각에 대략 '선형'이다(계수 C=fit/(train_rows·L·tok·d)
#     가 3.4~4.5e-7 로 안정). 피처수가 매우 클 때(seq~49) 어텐션 O(seq²)로 약간 초선형(C 최대 4.52e-7) → 그 최대를 덮게 잡음.
#   MARGIN 1.3 = 하드웨어 편차 + 초선형 여유. COEF×MARGIN(≈5.07e-7) ≥ 관측 최대 C → 실측 전 구간 '추정 ≥ 실측'(과소추정 0).
#   ⚠ n_features 는 라우터가 params 에 'n_features' 로 주입한다(len(req.features)). 미주입 시 6 으로 폴백.
#   ⚠ Linux 배포 시 재캘리브레이션 권장(이 2개 상수만 조정).
_TF_EST_COEF = 3.9e-7
_TF_EST_MARGIN = 1.3
TRANSFORMER_TIME_LIMIT_SEC = 120  # LSTM 과 동일 근거·시작값(API_TIMEOUT_MS). 이후 독립 조정 가능.


def estimate_transformer_seconds(rows: int, test_ratio: float, params: dict[str, Any]) -> float:
    """표 데이터 Transformer 학습 예상 시간(초). 각 행이 독립 샘플이라 window 없음(rows·layers·(피처+1)·d_model 기반)."""
    d_model = int(params.get("d_model", 64))
    layers = int(params.get("num_layers", 2))
    n_features = int(params.get("n_features", 6))  # 라우터가 주입(len(req.features)). 미주입 시 6.
    train_rows = int(rows * (1.0 - test_ratio))
    if train_rows <= 0:
        return 0.0
    n_tokens = n_features + 1  # 피처 토큰 + CLS 토큰
    return _TF_EST_COEF * train_rows * layers * n_tokens * d_model * _TF_EST_MARGIN


class _LSTMRegressor:
    """PyTorch LSTM 회귀 — sklearn 인터페이스(fit/predict)만 흉내내 build_estimator 일반 경로에 태운다.

    ⚠ 시퀀스 변환은 이 래퍼 안에서만 한다: fit 은 학습 구간(x_tr), predict 는 테스트 구간(x_te)만 각각 받아
       내부에서 슬라이딩 윈도우로 3D((샘플, window, 피처)) 를 만든다 → 두 구간이 분리돼 있어 윈도우가 분할 경계를
       넘지 못한다(테스트 첫 윈도우가 학습값을 참조 불가) = 누수 구조적 차단. 분할 자체는 train_test_split_sequential
       이 이미 수행하므로 여기선 순서를 가정만 한다(sequentialSplit=True 로 학습해야 시간축이 의미 있음).
    하이퍼파라미터는 전부 고정값(튜닝은 다음 단계). coef_/feature_importances_ 를 만들지 않아 결과 경로가 자동 None(MLP 와 동일).
    torch 는 무거우므로 메서드 내부에서 지연 import 한다(모듈 로드 시 torch 없어도 다른 22종은 무영향).
    """

    def __init__(self, window: int = 10, hidden_units: int = 32, num_layers: int = 1, dropout: float = 0.0, learning_rate: float = 0.01, batch: int = 64, epochs: int = 10, seed: int = 42) -> None:
        # 인자명은 명세(문서) 이름과 통일 → build_estimator 의 cls(**params) 가 훅 없이 그대로 전달(MLP 와 달리 1:1).
        self.window = window
        self.hidden_units = hidden_units
        self.num_layers = num_layers
        self.dropout = dropout
        self.learning_rate = learning_rate
        self.batch = batch
        self.epochs = epochs
        self.seed = seed
        self._model: Any = None
        self._n_features = 0
        self._y_mean = 0.0  # 윈도우를 못 만들 만큼 데이터가 짧을 때의 폴백 예측값

    def _make_windows(self, X: Any) -> Any:
        # 각 구간 내부에서만 슬라이딩: i=window..len-1 → 윈도우 X[i-window:i]. 앞 window 개는 윈도우가 없다.
        import numpy as np

        arr = np.asarray(X, dtype=np.float32)
        n = len(arr)
        if n <= self.window:
            return np.empty((0, self.window, arr.shape[1] if arr.ndim == 2 else 0), dtype=np.float32)
        return np.stack([arr[i - self.window : i] for i in range(self.window, n)], axis=0)

    def fit(self, X: Any, y: Any) -> "_LSTMRegressor":
        import numpy as np
        import torch
        from torch import nn

        torch.manual_seed(self.seed)  # 재현성(완전 일치는 아님 — "대략 재현")
        # ⚠ set_num_threads(1) 필수: xgboost·lightgbm·catboost 가 이미 로드한 OpenMP 런타임과 torch 의 OpenMP 가
        #   macOS 에서 충돌해 segfault 한다(KMP_DUPLICATE_LIB_OK 로도 안 풀림). 1스레드면 torch 가 자체 병렬 영역을
        #   안 열어 충돌을 회피한다. 단일 스레드라 느리지만 실측상 10에폭이 여전히 30초 예산 안이다.
        torch.set_num_threads(1)
        arr = np.asarray(X, dtype=np.float32)
        yv = np.asarray(y, dtype=np.float32)
        self._n_features = arr.shape[1]
        self._y_mean = float(yv.mean()) if len(yv) else 0.0

        Xw = self._make_windows(arr)  # (samples, window, feat) — 학습 구간만
        yw = yv[self.window :]  # y 를 window 만큼 밀어 정렬(윈도우 끝 다음 시점 예측)
        if len(Xw) == 0:  # 데이터가 window 보다 짧으면 학습 불가 → 평균 예측 폴백
            self._model = None
            return self

        # ⚠ dropout 은 num_layers>1 일 때만 적용: 1층에 dropout>0 이면 torch 가 UserWarning(무의미)을 낸다 → 원천 차단.
        lstm = nn.LSTM(self._n_features, self.hidden_units, self.num_layers, batch_first=True, dropout=self.dropout if self.num_layers > 1 else 0.0)
        head = nn.Linear(self.hidden_units, 1)

        opt = torch.optim.Adam(list(lstm.parameters()) + list(head.parameters()), lr=self.learning_rate)
        lossf = nn.MSELoss()
        Xt = torch.from_numpy(Xw)
        yt = torch.from_numpy(yw)
        for _ in range(self.epochs):
            perm = torch.randperm(len(Xt))
            for i in range(0, len(Xt), self.batch):
                idx = perm[i : i + self.batch]
                opt.zero_grad()
                out, _ = lstm(Xt[idx])
                pred = head(out[:, -1, :]).squeeze(-1)
                loss = lossf(pred, yt[idx])
                loss.backward()
                opt.step()
        self._model = (lstm, head)
        return self

    def predict(self, X: Any) -> Any:
        import numpy as np
        import torch

        arr = np.asarray(X, dtype=np.float32)
        n = len(arr)
        # ⚠ 반환 길이는 반드시 입력 행 수(n)와 같아야 한다(regression_metrics 가 y_te 와 길이를 맞춤).
        if self._model is None:
            return [self._y_mean] * n
        Xw = self._make_windows(arr)  # (n-window, window, feat) — 테스트 구간만
        if len(Xw) == 0:
            return [self._y_mean] * n
        lstm, head = self._model
        lstm.eval()
        head.eval()
        with torch.no_grad():
            out, _ = lstm(torch.from_numpy(Xw))
            p = head(out[:, -1, :]).squeeze(-1).numpy()
        # 앞 window 개는 윈도우가 없어 예측 불가 → 첫 유효 예측값으로 패딩(길이 정합).
        #   이 앞부분은 이전 시점(학습 구간 끝)을 봐야 정확하나 누수 방지로 안 보므로 어차피 부정확한 소수(영향 미미).
        pad = np.full(self.window, p[0], dtype=np.float32)
        return np.concatenate([pad, p]).tolist()


class _TransformerRegressor:
    """PyTorch FT-Transformer 계열 표(tabular) 회귀 — sklearn 인터페이스(fit/predict)만 흉내내 build_estimator 일반 경로에 태운다.

    ⚠ 시퀀스(윈도우) 방식이 아니라 표 데이터 방식이다: 행 하나가 독립 샘플, window 없음, 시간 순서 컬럼 불필요.
       각 수치 피처를 d_model 차원 토큰으로 임베딩(피처별 개별 projection: token_j = x_j · W_j + b_j)하고
       학습 가능한 CLS 토큰을 앞에 붙여 TransformerEncoder 를 통과시킨 뒤, CLS 출력으로 값을 예측한다.
       피처는 순서 의미가 없어 positional encoding 을 넣지 않는다(피처별 임베딩 W_j 가 위치를 구분한다).
       시퀀스 길이 = 피처수+1(작음)이라 윈도우 방식보다 훨씬 가볍다.
    predict 는 행별 1:1 예측이라 반환 길이 = 입력 행수(패딩 불필요, 자연히 정합). coef_/feature_importances_ 를
    만들지 않아 영향도가 자동 None(LSTM·MLP 와 동일). torch 는 무거우므로 메서드 내부에서 지연 import 한다.

    ⚠ d_model 은 n_heads 로 나눠떨어져야 한다(MultiheadAttention 제약). 스펙 범위(d_model 64 배수 × n_heads {4,8})가
       항상 나눠떨어지게 설계돼 런타임 보정이 불필요하다(validate_params 는 교차 제약을 못 본다).
    """

    def __init__(self, d_model: int = 64, n_heads: int = 4, num_layers: int = 2, dropout: float = 0.0, learning_rate: float = 0.001, batch: int = 64, epochs: int = 10, seed: int = 42) -> None:
        # 인자명 = 명세(문서) 이름과 통일 → build_estimator 의 cls(**params) 가 훅 없이 그대로 전달(1:1).
        self.d_model = d_model
        self.n_heads = n_heads
        self.num_layers = num_layers
        self.dropout = dropout
        self.learning_rate = learning_rate
        self.batch = batch
        self.epochs = epochs
        self.seed = seed
        self._model: Any = None
        self._n_features = 0
        self._y_mean = 0.0  # 학습 데이터가 비었을 때의 폴백 예측값

    def fit(self, X: Any, y: Any) -> "_TransformerRegressor":
        import numpy as np
        import torch
        from torch import nn

        torch.manual_seed(self.seed)  # 재현성(완전 일치는 아님 — "대략 재현")
        # ⚠ set_num_threads(1) 필수: xgboost·lightgbm·catboost 가 로드한 OpenMP 와 torch OpenMP 가 macOS 에서
        #   충돌해 segfault 한다(_LSTMRegressor 와 동일 이유).
        torch.set_num_threads(1)
        arr = np.asarray(X, dtype=np.float32)
        yv = np.asarray(y, dtype=np.float32)
        self._n_features = arr.shape[1]
        self._y_mean = float(yv.mean()) if len(yv) else 0.0
        if len(arr) == 0:  # 학습 행이 없으면 폴백(평균 예측)
            self._model = None
            return self

        # 인코더는 지연 import 된 torch 로만 만들 수 있어 nn.Module 을 fit 내부 지역 클래스로 정의한다
        #   (모듈 최상위에 두면 import 시 torch 가 필요해져 지연 import 원칙이 깨진다).
        class _Net(nn.Module):
            def __init__(self, n_features: int, d_model: int, n_heads: int, num_layers: int, dropout: float) -> None:
                super().__init__()
                # 피처별 개별 임베딩(FT-Transformer 수치 토크나이저): token[:, j, :] = x[:, j] · W_j + b_j.
                self.feat_weight = nn.Parameter(torch.empty(n_features, d_model))
                self.feat_bias = nn.Parameter(torch.zeros(n_features, d_model))
                nn.init.normal_(self.feat_weight, std=0.02)
                self.cls = nn.Parameter(torch.zeros(1, 1, d_model))  # 학습 가능한 CLS 토큰
                # dim_feedforward=2×d_model: 기본값(2048)보다 가벼운 비노출 선택(표 데이터라 이미 충분히 빠름).
                layer = nn.TransformerEncoderLayer(d_model, n_heads, dim_feedforward=d_model * 2, dropout=dropout, batch_first=True)
                self.encoder = nn.TransformerEncoder(layer, num_layers, enable_nested_tensor=False)
                self.head = nn.Linear(d_model, 1)

            def forward(self, x: Any) -> Any:  # x: (batch, n_features)
                tok = x.unsqueeze(-1) * self.feat_weight + self.feat_bias  # (batch, n_features, d_model)
                cls = self.cls.expand(x.shape[0], -1, -1)  # (batch, 1, d_model)
                h = torch.cat([cls, tok], dim=1)  # (batch, n_features+1, d_model) — 순서 의미 없어 위치 인코딩 없음
                h = self.encoder(h)
                return self.head(h[:, 0, :]).squeeze(-1)  # CLS 출력 → 1값

        model = _Net(self._n_features, self.d_model, self.n_heads, self.num_layers, self.dropout)
        opt = torch.optim.Adam(model.parameters(), lr=self.learning_rate)
        lossf = nn.MSELoss()
        Xt = torch.from_numpy(arr)
        yt = torch.from_numpy(yv)
        model.train()
        for _ in range(self.epochs):
            perm = torch.randperm(len(Xt))
            for i in range(0, len(Xt), self.batch):
                idx = perm[i : i + self.batch]
                opt.zero_grad()
                pred = model(Xt[idx])
                loss = lossf(pred, yt[idx])
                loss.backward()
                opt.step()
        self._model = model
        return self

    def predict(self, X: Any) -> Any:
        import numpy as np
        import torch

        arr = np.asarray(X, dtype=np.float32)
        n = len(arr)
        # 행별 1:1 예측 → 반환 길이 = 입력 행수(패딩 불필요).
        if self._model is None or n == 0:
            return [self._y_mean] * n
        self._model.eval()
        with torch.no_grad():
            p = self._model(torch.from_numpy(arr)).numpy()
        return np.atleast_1d(p).astype(np.float32).tolist()


# LightGBM 공용 파라미터 — 부스팅 공통 3종(xgboost 와 동일 구조·범위). LGBM 은 문자열 라벨을 직접 받아
#   래퍼가 필요 없다(_ESTIMATORS 에 LGBMClassifier 직접 매핑). 학습 로그·경고는 estimator_kwargs verbose=-1 로 억제.
_LGBM_PARAMS = [
    {
        "name": "n_estimators",
        "label": "트리 개수(n_estimators)",
        "type": "int",
        "min": 200,
        "max": 2000,
        "step": 50,
        "default": 300,
        "widget": "slider",
        "help": "트리 개수. 많을수록 안정적이지만 느려져요.",
    },
    {
        "name": "learning_rate",
        "label": "학습률(learning_rate)",
        "type": "float",
        "min": 0.01,
        "max": 0.3,
        "step": 0.01,
        "default": 0.1,
        "widget": "log-slider",
        "help": "학습률. 낮을수록 트리가 더 많이 필요해요.",
    },
    {
        "name": "max_depth",
        "label": "트리 깊이(max_depth)",
        "type": "int",
        "min": 3,
        "max": 12,
        "step": 1,
        "default": 6,
        "widget": "slider",
        "help": "트리 깊이. 클수록 복잡해져요.",
    },
    {
        # LGBM 고유 파라미터(잎 수 기준으로 트리를 키우는 leaf-wise 방식이라 depth 보다 이 값이 복잡도를 좌우한다).
        #   default=31 은 LightGBM sklearn 기본값 → 지정 안 하고 학습하던 기존 동작과 동일하다(하드코딩 명시 없었음).
        "name": "num_leaves",
        "label": "잎 개수(num_leaves)",
        "type": "int",
        "min": 15,
        "max": 255,
        "step": 5,
        "default": 31,
        "widget": "slider",
        "help": "트리 하나가 가질 수 있는 잎 개수. 클수록 복잡해져 과적합 위험이 커져요.",
    },
]

# 분류 LGBM 전용 = 공용 3종 + class_weight.
#   class_weight 는 LGBMClassifier 에만 있는 인자다(LGBMRegressor 에 넘기면 무효/오류) → _LGBM_PARAMS(회귀·분류 공용)
#   에는 넣지 않고 분류 명세에서만 쓰는 새 리스트를 만든다(rf 의 _RF_CLS_PARAMS 와 동일 패턴). dtree/rf/logistic 과 같은 dropdown.
#   default=None → 지정 안 하던 기존 동작과 동일(가중치 없음). 'balanced' 는 라이브러리가 y 비율을 알아서 계산(이진·다중 공통).
_LGBM_CLS_PARAMS = [
    *_LGBM_PARAMS,
    {
        "name": "class_weight",
        "label": "클래스 가중치(class_weight)",
        "type": "enum",
        "choices": [
            {"value": None, "label": "없음"},
            {"value": "balanced", "label": "균형(balanced)"},
        ],
        "default": None,
        "widget": "dropdown",
        "help": "클래스 불균형이 심하면 '균형'이 소수 클래스를 더 반영해요.",
    },
]

# CatBoost 공용 파라미터 — 부스팅 3종 공통(n_estimators·learning_rate·max_depth)에 CatBoost 고유 l2_leaf_reg 추가.
#   max_depth 범위는 CatBoost 관례(4~10)로 다른 부스팅(3~12)과 다름. 문자열 라벨 직접 수용(래퍼 불필요).
#   n_estimators·max_depth 는 iterations·depth 의 별칭이라 하나만 지정(동시 지정 금지).
_CATBOOST_PARAMS = [
    {
        "name": "n_estimators",
        "label": "트리 개수(n_estimators)",
        "type": "int",
        "min": 200,
        "max": 2000,
        "step": 50,
        "default": 300,
        "widget": "slider",
        "help": "트리 개수. 많을수록 안정적이지만 느려져요.",
    },
    {
        "name": "learning_rate",
        "label": "학습률(learning_rate)",
        "type": "float",
        "min": 0.01,
        "max": 0.3,
        "step": 0.01,
        "default": 0.1,
        "widget": "log-slider",
        "help": "학습률. 낮을수록 트리가 더 많이 필요해요.",
    },
    {
        "name": "max_depth",
        "label": "트리 깊이(max_depth)",
        "type": "int",
        "min": 4,
        "max": 10,
        "step": 1,
        "default": 6,
        "widget": "slider",
        "help": "트리 깊이. 클수록 복잡해져요.",
    },
    {
        "name": "l2_leaf_reg",
        "label": "L2 규제(l2_leaf_reg)",
        "type": "int",
        "min": 1,
        "max": 10,
        "step": 1,
        "default": 3,
        "widget": "slider",
        "help": "L2 규제 강도. 클수록 과적합을 억제해요.",
    },
]

# 분류 CatBoost 전용 = 공용 4종 + auto_class_weights.
#   CatBoost 의 불균형 대응은 auto_class_weights(문자열 enum) — 라이브러리가 y 비율로 자동 계산해 y 접근 훅이 불필요하다.
#   CatBoostRegressor 엔 없는 개념이라 회귀(_CATBOOST_PARAMS)엔 넣지 않고 분류 전용 리스트로 확장(rf·LGBM 과 동일 패턴).
#   default=None → 지정 안 하던 기존 동작과 동일. "Balanced"=클래스 빈도 역수, "SqrtBalanced"=그 제곱근(완만).
_CATBOOST_CLS_PARAMS = [
    *_CATBOOST_PARAMS,
    {
        "name": "auto_class_weights",
        "label": "클래스 가중치(auto_class_weights)",
        "type": "enum",
        "choices": [
            {"value": None, "label": "없음"},
            {"value": "Balanced", "label": "균형(Balanced)"},
            {"value": "SqrtBalanced", "label": "완만한 균형(SqrtBalanced)"},
        ],
        "default": None,
        "widget": "dropdown",
        "help": "클래스 불균형이 심하면 '균형'이 소수 클래스를 더 반영해요. '완만한 균형'은 그 효과를 약하게 줍니다.",
    },
]


# MLP(다층 퍼셉트론) 공용 파라미터 — 회귀/분류 동일.
#   노코딩 사용자에게 sklearn 의 hidden_layer_sizes 튜플((100,100) 같은)을 직접 입력시키는 건 무리라,
#   "층 수(hidden_layers) × 층당 뉴런 수(units)" 두 슬라이더로 받아 to_estimator_kwargs 훅이 튜플로 합친다.
_MLP_PARAMS = [
    {
        "name": "hidden_layers",
        "label": "은닉층 수(hidden_layers)",
        "type": "int",
        "min": 1,
        "max": 4,
        "step": 1,
        "default": 2,
        "widget": "slider",
        "help": "은닉층 수. 많을수록 복잡한 패턴을 학습해요.",
    },
    {
        "name": "units",
        "label": "층당 뉴런 수(units)",
        "type": "int",
        "min": 32,
        "max": 512,
        "step": 32,
        "default": 128,
        "widget": "slider",
        "help": "층당 뉴런 수.",
    },
    {
        "name": "alpha",
        "label": "L2 규제(alpha)",
        "type": "float",
        "min": 1e-4,
        "max": 1e-1,
        "default": 1e-3,
        "widget": "log-slider",  # 값 범위가 1e-4~1e-1 로 넓어 로그 스케일 표시(검증은 float 범위 그대로).
        "help": "L2 규제 강도. 클수록 과적합을 억제해요.",
    },
    {
        "name": "learning_rate_init",
        "label": "학습률(learning_rate_init)",
        "type": "float",
        "min": 1e-4,
        "max": 1e-2,
        "default": 1e-3,
        "widget": "log-slider",
        "help": "학습률.",
    },
]


# LSTM(시계열 딥러닝) 튜닝 파라미터 5종. 명세 이름 = _LSTMRegressor 인자명(1:1) → 훅 없이 build_estimator 가 그대로 전달.
#   default 는 현재 고정값(window10·hidden32·layers1·dropout0·lr0.01)과 동일 → "튜닝 안 함 == 기본값 튜닝".
#   ⚠ 범위는 실측 안전선으로 축소(문서 스펙 window100·hidden256·layers3 은 742초로 타임아웃 초과 → 응답성 우선).
#     상한 조합(window50·hidden128·layers2)이 타임아웃 120초 안에 든다. epochs·batch 는 비노출(시간 폭주 방지).
_LSTM_PARAMS = [
    {
        "name": "window",
        "label": "입력 시퀀스 길이(window)",
        "type": "int",
        "min": 10,
        "max": 50,
        "step": 5,
        "default": 10,
        "widget": "slider",
        "help": "과거 몇 시점을 보고 다음을 예측할지. 클수록 긴 흐름을 보지만 느려져요. 테스트 구간보다 작아야 해요.",
    },
    {
        "name": "hidden_units",
        "label": "은닉 유닛 수(hidden_units)",
        "type": "int",
        "min": 32,
        "max": 128,
        "step": 16,
        "default": 32,
        "widget": "slider",
        "help": "LSTM 내부 표현 크기. 클수록 복잡한 패턴을 담지만 느리고 과적합 위험이 커져요.",
    },
    {
        "name": "num_layers",
        "label": "층 수(num_layers)",
        "type": "int",
        "min": 1,
        "max": 2,
        "step": 1,
        "default": 1,
        "widget": "slider",
        "help": "LSTM 층 개수. 많을수록 깊지만 느리고 과적합 위험이 커져요.",
    },
    {
        "name": "dropout",
        "label": "드롭아웃(dropout)",
        "type": "float",
        "min": 0.0,
        "max": 0.5,
        "step": 0.05,
        "default": 0.0,
        "widget": "slider",
        "help": "과적합 억제 비율. 층이 2개 이상일 때만 적용돼요(1층이면 무시).",
    },
    {
        "name": "learning_rate",
        "label": "학습률(learning_rate)",
        "type": "float",
        "min": 1e-4,
        "max": 1e-2,
        "default": 0.01,
        "widget": "log-slider",
        "help": "학습 속도. 너무 크면 발산, 너무 작으면 학습이 느려요.",
    },
]


# Transformer(표 데이터) 튜닝 파라미터 5종. 명세 이름 = _TransformerRegressor 인자명(1:1) → 훅 없이 그대로 전달.
#   ⚠ window 없음(표 데이터라 각 행이 독립 샘플). d_model(64 배수) × n_heads {4,8} 는 항상 나눠떨어진다(MultiheadAttention 제약을 범위 설계로 보장 — validate_params 는 교차 제약을 못 봄).
#   ⚠ 상한은 실규모(35,040행×6피처 + 피처수 스윕, epochs 10 고정, 1스레드, mac arm64) 실측으로 120초(TRANSFORMER_TIME_LIMIT_SEC) 예산 안에 확정:
#     윈도우 제거로 훨씬 가벼워져 d_model 을 256(요청 상한)까지 열었다. 확정 상한 조합 d256·h8·l4 = 81초(측정, ~33% 여유; 추정 102초).
#     ⚠ d256·l6 = 119초(여유 없음)라 num_layers 를 4 로 캡했다(d_model 256 유지 우선). 대안: d_model 을 192 로 낮추면 num_layers 6 까지 가능.
#     피처수가 많으면 시퀀스(피처+1)가 길어져 무거워지므로 시간 가드(estimate_transformer_seconds)가 n_features 로 자동 차단한다.
_TRANSFORMER_PARAMS = [
    {
        "name": "d_model",
        "label": "모델 차원(d_model)",
        "type": "int",
        "min": 64,
        "max": 256,
        "step": 64,
        "default": 64,
        "widget": "slider",
        "help": "각 피처 토큰의 표현 차원. 클수록 복잡한 패턴을 담지만 느리고 과적합 위험이 커져요. n_heads 로 나눠떨어져야 해요.",
    },
    {
        "name": "n_heads",
        "label": "어텐션 헤드 수(n_heads)",
        "type": "int",
        "min": 4,
        "max": 8,
        "step": 4,
        "default": 4,
        "widget": "slider",
        "help": "어텐션을 몇 갈래로 나눠 볼지. d_model 이 이 값으로 나눠떨어져야 해요(64·128·192·256 은 4·8 모두 가능).",
    },
    {
        "name": "num_layers",
        "label": "층 수(num_layers)",
        "type": "int",
        "min": 2,
        "max": 4,
        "step": 1,
        "default": 2,
        "widget": "slider",
        "help": "Transformer 인코더 층 개수. 많을수록 깊지만 느리고 과적합 위험이 커져요.",
    },
    {
        "name": "dropout",
        "label": "드롭아웃(dropout)",
        "type": "float",
        "min": 0.0,
        "max": 0.3,
        "step": 0.05,
        "default": 0.0,
        "widget": "slider",
        "help": "과적합 억제 비율. 클수록 규제가 강해져요.",
    },
    {
        "name": "learning_rate",
        "label": "학습률(learning_rate)",
        "type": "float",
        "min": 1e-4,
        "max": 1e-3,
        "default": 1e-3,
        "widget": "log-slider",
        "help": "학습 속도. 너무 크면 발산, 너무 작으면 학습이 느려요.",
    },
]


def _mlp_to_estimator_kwargs(params: dict[str, Any]) -> dict[str, Any]:
    """MLP 전용 변환 훅 — 명세 파라미터(hidden_layers·units) → sklearn 인자(hidden_layer_sizes 튜플).

    예: hidden_layers=2, units=100 → hidden_layer_sizes=(100, 100). alpha·learning_rate_init 은 이름이
    sklearn 과 같아 그대로 통과한다. 원본 params(=라우터가 usedParams 로 에코하는 검증된 dict)는 건드리지
    않고 복사본을 반환한다 → 응답에는 사용자가 조정한 '변환 전' 값(hidden_layers·units)이 그대로 남는다.
    """
    p = dict(params)
    layers = p.pop("hidden_layers")
    units = p.pop("units")
    p["hidden_layer_sizes"] = (units,) * layers
    return p


HYPERPARAM_SPECS: dict[tuple[str, str], dict[str, Any]] = {
    ("reg", "knn"): {"estimator": "KNeighborsRegressor", "server_only": True, "supports_scaling": True, "scaling_help": _SCALE_HELP_KNN, "params": _KNN_PARAMS},
    ("cls", "knn"): {"estimator": "KNeighborsClassifier", "server_only": True, "supports_scaling": True, "scaling_help": _SCALE_HELP_KNN, "params": _KNN_PARAMS},
    ("reg", "svr"): {"estimator": "SVR", "server_only": True, "supports_scaling": True, "scaling_help": _SCALE_HELP_SVM, "params": [_SVM_C, _SVM_KERNEL]},
    # SVC: predict_proba(확률·AUC·확률곡선)를 위해 probability=True 필수 → estimator_kwargs 로 고정 주입.
    #   random_state 고정으로 확률 추정(내부 CV)의 재현성 확보.
    ("cls", "svc"): {
        "estimator": "SVC",
        "server_only": True,
        "supports_scaling": True,
        "scaling_help": _SCALE_HELP_SVM,
        "estimator_kwargs": {"probability": True, "random_state": 42},
        "params": [_SVM_C, _SVM_KERNEL, _SVC_GAMMA],
    },
    # Ridge/Lasso: 계수가 있는 선형 규제 회귀. 규제가 스케일에 민감해 표준화 권장(기본 켜짐).
    ("reg", "ridge"): {"estimator": "Ridge", "server_only": True, "supports_scaling": True, "scaling_help": _SCALE_HELP_LINEAR, "params": [_LINEAR_ALPHA]},
    ("reg", "lasso"): {"estimator": "Lasso", "server_only": True, "supports_scaling": True, "scaling_help": _SCALE_HELP_LINEAR, "params": [_LINEAR_ALPHA]},
    # ElasticNet: L1(Lasso)+L2(Ridge) 혼합 규제 선형 회귀. Ridge/Lasso 와 동일 계열이라 coef_ 가 있고,
    #   train_regression_manual 의 기존 자동 추출이 coef·intercept 를 그대로 내보낸다(트리 아님 → importance·vizTree 없음).
    #   random_state=42: selection="cyclic"(기본)에선 쓰이지 않지만, 좌표하강 순서가 무작위일 때를 대비해 고정(재현성).
    ("reg", "elasticnet"): {
        "estimator": "ElasticNet",
        "server_only": True,
        "supports_scaling": True,
        "scaling_help": _SCALE_HELP_LINEAR,
        "estimator_kwargs": {"random_state": 42},
        "params": _ELASTIC_PARAMS,
    },
    # rf(랜덤 포레스트): "명세 있는 하드코딩 모델"(server_only=True — 모든 학습은 백엔드).
    #   (params 가 올 때만 수동 경로로 튜닝, 없으면 기존 하드코딩 경로 유지 = 하위호환). 트리라 스케일 불필요.
    #   estimator_kwargs 로 비튜닝 인자(bootstrap·random_state=7·n_jobs) 보존 → 기본값 학습 시 하드코딩과 동일한 숲.
    ("reg", "rf"): {
        "estimator": "RandomForestRegressor",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"bootstrap": True, "random_state": 7, "n_jobs": -1},
        "params": _RF_PARAMS,
    },
    ("cls", "rf"): {
        "estimator": "RandomForestClassifier",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"bootstrap": True, "random_state": 7, "n_jobs": -1},
        "params": _RF_CLS_PARAMS,  # 공용 4종 + class_weight(분류 전용). 회귀는 _RF_PARAMS 그대로.
    },
    # XGBoost(진짜 xgboost 라이브러리): 무거운 라이브러리라 browser 구현
    #   없음 → server_only=True(KNN·SVM 처럼 server 전용). 트리 계열이라 supports_scaling=False.
    #   verbosity=0 로 학습 로그 억제, random_state=42 로 재현성. 분류는 _XGBoostClassifier(문자열 라벨 인코딩 래퍼).
    ("reg", "xgboost"): {
        "estimator": "XGBRegressor",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"random_state": 42, "verbosity": 0},
        "params": _XGBOOST_PARAMS,
    },
    ("cls", "xgboost"): {
        "estimator": "XGBClassifier",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"random_state": 42, "verbosity": 0},
        "params": _XGBOOST_CLS_PARAMS,  # 공용 3종 + class_weight(분류 전용, 래퍼가 sample_weight 로 변환). 회귀는 _XGBOOST_PARAMS.
    },
    # LightGBM: xgboost 와 별개 부스팅 모델(키="lightgbm"). browser 구현 없음 → server_only=True. 트리라 스케일 불필요.
    #   문자열 라벨을 직접 받아 래퍼가 필요 없다(_ESTIMATORS 에 LGBMClassifier 직접 매핑). verbose=-1 로 로그·경고 억제.
    ("reg", "lightgbm"): {
        "estimator": "LGBMRegressor",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"random_state": 42, "verbose": -1},
        "params": _LGBM_PARAMS,
    },
    ("cls", "lightgbm"): {
        "estimator": "LGBMClassifier",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"random_state": 42, "verbose": -1},
        "params": _LGBM_CLS_PARAMS,  # 공용 3종 + class_weight(분류 전용). 회귀는 _LGBM_PARAMS 그대로.
    },
    # CatBoost: 부스팅 4번째 모델(키="catboost"). browser 구현 없음 → server_only=True. 트리라 스케일 불필요.
    #   문자열 라벨 직접 수용 → 래퍼 없이 직접 매핑. verbose=0 로 iteration 로그 억제. l2_leaf_reg(고유) 포함.
    #   allow_writing_files=False: 학습 시 catboost_info/ 로그 디렉터리 생성 자체를 막는다(결과는 리포트로 확인 → 파일 불필요,
    #   작업트리 오염 방지). verbose(콘솔 억제)와 별개이며 성능·하이퍼파라미터엔 영향 없다. 튜닝(trial마다 fit)에도 동일 적용.
    ("reg", "catboost"): {
        "estimator": "CatBoostRegressor",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"random_state": 42, "verbose": 0, "allow_writing_files": False},
        "params": _CATBOOST_PARAMS,
    },
    ("cls", "catboost"): {
        "estimator": "CatBoostClassifier",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"random_state": 42, "verbose": 0, "allow_writing_files": False},
        "params": _CATBOOST_CLS_PARAMS,  # 공용 4종 + auto_class_weights(분류 전용). 회귀는 _CATBOOST_PARAMS 그대로.
    },
    # MLP(신경망): browser 구현 없음 + 학습이 느릴 수 있어 server_only=True. 입력 스케일에 민감 → 표준화 기본 켜짐.
    #   트리가 아니라 coef_/feature_importances_ 가 없다 → train_*_manual 이 coef·importance·vizTree 를 자동 None 처리
    #   (KNN·SVR 과 동일 취급, 프론트 hasInfluence=false). to_estimator_kwargs 로 hidden_layers×units → hidden_layer_sizes 변환.
    #   max_iter=1000: 기본값(200)은 물론 500 으로도 회귀가 상한에 걸려 ConvergenceWarning 이 났다(실측).
    #   1000 이면 수렴한다. 수렴 경고를 필터로 덮지 않고 반복 횟수로 푸는 쪽을 택했다(경고가 나면 진짜 미수렴 신호).
    #   random_state=42 로 재현성.
    ("reg", "mlp"): {
        "estimator": "MLPRegressor",
        "server_only": True,
        "supports_scaling": True,
        "scaling_help": _SCALE_HELP_MLP,
        "estimator_kwargs": {"random_state": 42, "max_iter": 1000},
        "to_estimator_kwargs": _mlp_to_estimator_kwargs,
        "params": _MLP_PARAMS,
    },
    # LSTM(시계열 딥러닝, 회귀 전용): PyTorch 래퍼(_LSTMRegressor). 하이퍼파라미터는 전부 고정값(튜닝 없음 → params 빈 리스트).
    #   supports_scaling=True: 신경망이라 입력 스케일에 민감(MLP 와 동일). server_only=True: 브라우저 구현 없음.
    #   ⚠ 시간순 정렬된 데이터 + sequentialSplit=True 에서만 의미가 있다(윈도우가 시간 순서를 가정). 프론트가 안내.
    ("reg", "lstm"): {
        "estimator": "LSTMRegressor",
        "server_only": True,
        "supports_scaling": True,
        "scaling_help": _SCALE_HELP_MLP,
        "estimator_kwargs": {"batch": 64, "epochs": 10, "seed": 42},  # 비노출 고정값. 튜닝 5종은 params 로.
        "params": _LSTM_PARAMS,
    },
    # Transformer(표 데이터, 회귀 전용): FT-Transformer 계열 PyTorch 래퍼(_TransformerRegressor). 행 하나가 독립 샘플(윈도우 없음).
    #   supports_scaling=True(신경망이라 입력 스케일 민감, MLP 와 동일), server_only=True(브라우저 구현 없음).
    #   ⚠ 시간 순서 컬럼 불필요 — 일반 표 데이터에 rf·mlp 처럼 그대로 쓴다(sequentialSplit 강제 없음).
    ("reg", "transformer"): {
        "estimator": "TransformerRegressor",
        "server_only": True,
        "supports_scaling": True,
        "scaling_help": _SCALE_HELP_MLP,
        "estimator_kwargs": {"batch": 64, "epochs": 10, "seed": 42},  # 비노출 고정값. 튜닝 5종은 params 로.
        "params": _TRANSFORMER_PARAMS,
    },
    ("cls", "mlp"): {
        "estimator": "MLPClassifier",
        "server_only": True,
        "supports_scaling": True,
        "scaling_help": _SCALE_HELP_MLP,
        "estimator_kwargs": {"random_state": 42, "max_iter": 1000},
        "to_estimator_kwargs": _mlp_to_estimator_kwargs,
        "params": _MLP_PARAMS,
    },
    # Decision Tree(분류): 변수 중요도·트리 시각화 있음. 트리라 스케일 불필요(supports_scaling=False).
    #   random_state 고정으로 재현성 확보(동점 분할·피처 선택의 무작위성 제거).
    ("cls", "dtree"): {
        "estimator": "DecisionTreeClassifier",
        "server_only": True,
        "supports_scaling": False,
        "estimator_kwargs": {"random_state": 42},
        "params": _DTREE_PARAMS,
    },
    # Logistic: rf 처럼 "명세 있는 하드코딩 모델"(server_only=True — 모든 학습은 백엔드) — params 없으면 하드코딩 경로(C=1.0 동일 모델),
    #   있으면 수동 경로로 튜닝. 규제가 스케일에 민감해 표준화 기본 켜짐(supports_scaling=True). 계수 있는 선형 모델이라
    #   이진일 때 표준화 계수를 낸다. max_iter=1000 로 수렴 여유, random_state=42 로 재현성.
    ("cls", "logistic"): {
        "estimator": "LogisticRegression",
        "server_only": True,
        "supports_scaling": True,
        "scaling_help": _SCALE_HELP_LOGISTIC,
        # solver=saga: penalty l1·l2 를 모두 지원(기본 lbfgs 는 l2 전용). l2 기준 lbfgs 와 결과 차이 미미(계수차 ~0.001).
        "estimator_kwargs": {"max_iter": 1000, "random_state": 42, "solver": "saga"},
        "params": _LOGISTIC_PARAMS,
    },
}

# ─────────────────────────── 추정기 팩토리 ───────────────────────────
# estimator 이름 → sklearn 클래스 매핑. 새 모델은 여기에 1줄씩 추가한다.
_ESTIMATORS: dict[str, type] = {
    "KNeighborsRegressor": KNeighborsRegressor,
    "KNeighborsClassifier": KNeighborsClassifier,
    "SVR": SVR,
    "SVC": SVC,
    "Ridge": Ridge,
    "Lasso": Lasso,
    "ElasticNet": ElasticNet,
    "DecisionTreeClassifier": DecisionTreeClassifier,
    "RandomForestRegressor": RandomForestRegressor,
    "RandomForestClassifier": RandomForestClassifier,
    "XGBRegressor": XGBRegressor,
    "XGBClassifier": _XGBoostClassifier,  # 문자열 라벨 인코딩 래퍼(원본 XGBClassifier 감쌈)
    "LGBMRegressor": LGBMRegressor,
    "LGBMClassifier": LGBMClassifier,  # LGBM 은 문자열 라벨 직접 수용 → 래퍼 없이 직접 매핑
    "CatBoostRegressor": CatBoostRegressor,
    "CatBoostClassifier": CatBoostClassifier,  # CatBoost 도 문자열 라벨 직접 수용 → 래퍼 없이 직접 매핑
    "MLPRegressor": MLPRegressor,
    "LSTMRegressor": _LSTMRegressor,  # PyTorch LSTM 회귀(시퀀스 변환은 래퍼 fit/predict 내부)
    "TransformerRegressor": _TransformerRegressor,  # PyTorch Transformer 인코더 회귀(시퀀스 변환은 래퍼 fit/predict 내부)
    "MLPClassifier": MLPClassifier,  # 문자열 라벨 직접 수용(classes_ 문자열) → SklearnClsModel 무수정
    "LogisticRegression": LogisticRegression,  # 문자열 라벨 직접 수용 → SklearnClsModel 무수정
}


def get_spec(task: str, algo: str) -> dict[str, Any] | None:
    """(task, algo) 명세를 반환. 없으면 None(하이퍼파라미터 미지원 모델)."""
    return HYPERPARAM_SPECS.get((task, algo))


def list_specs() -> list[dict[str, Any]]:
    """GET /models/hyperparams 응답용 직렬화 — 명세 전체를 리스트로 평탄화한다.

    각 항목: {task, algo, estimator, server_only, params:[...]}. 명세는 정적이라 매 요청 계산 부담 없음.
    """
    out: list[dict[str, Any]] = []
    for (task, algo), spec in HYPERPARAM_SPECS.items():
        out.append(
            {
                "task": task,
                "algo": algo,
                "estimator": spec["estimator"],
                "server_only": spec.get("server_only", False),
                "supports_scaling": spec.get("supports_scaling", False),
                "scaling_help": spec.get("scaling_help"),  # 표준화 체크박스 안내(supports_scaling 모델만; 없으면 None)
                "params": spec["params"],
            }
        )
    return out


def supports_scaling(task: str, algo: str) -> bool:
    """(task, algo) 모델이 표준화(스케일링)를 지원하는지."""
    spec = get_spec(task, algo)
    return bool(spec and spec.get("supports_scaling", False))


def resolve_scaling(task: str, algo: str, scale: bool | None) -> bool:
    """실제 적용할 스케일링 여부를 결정한다.

    - 미지원 모델(트리 등): 항상 False(요청의 scale 무시).
    - 지원 모델(KNN 등): scale 이 None(미지정)이면 기본 켜짐(True), 명시값이면 그대로.
    """
    if not supports_scaling(task, algo):
        return False
    return True if scale is None else bool(scale)


def validate_params(task: str, algo: str, raw: dict[str, Any] | None) -> dict[str, Any]:
    """요청 params(raw)를 명세 기준으로 검증하고, 누락값은 기본값으로 채운 유효 dict를 반환한다.

    프레임워크 비의존을 위해 위반 시 ValueError 를 던진다(라우터가 400 으로 변환).
    규칙:
      - 명세 없는 (task,algo) + raw 있음 → ValueError(미지원 안내). raw 없음 → {} (기존 하드코딩 모델).
      - 명세 있음: 알 수 없는 키 → ValueError. 각 파라미터 타입/범위/선택지 검증, 없으면 default 채움.
    """
    spec = get_spec(task, algo)
    if spec is None:
        if raw:
            raise ValueError(f"'{algo}'는 하이퍼파라미터 조정을 지원하지 않습니다.")
        return {}

    raw = raw or {}
    param_defs = spec["params"]
    known = {p["name"]: p for p in param_defs}

    # 1) 알 수 없는 키 거부(오타·주입 방지)
    for key in raw:
        if key not in known:
            allowed = ", ".join(known.keys())
            raise ValueError(f"알 수 없는 설정 '{key}'. 허용된 설정: {allowed}.")

    # 2) 파라미터별 검증 + 기본값 채움
    out: dict[str, Any] = {}
    for p in param_defs:
        name = p["name"]
        label = p["label"]
        if name not in raw:
            out[name] = p["default"]  # 노코딩: 미지정은 권장 기본값
            continue
        v = raw[name]
        ptype = p["type"]

        if ptype in ("int", "float"):
            # bool 은 int 서브클래스라 명시적으로 거부(True/False 를 1/0 으로 오용 방지)
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                raise ValueError(f"{label}: 숫자여야 합니다 (입력: {v!r}).")
            if ptype == "int" and int(v) != v:
                raise ValueError(f"{label}: 정수여야 합니다 (입력: {v}).")
            if not (p["min"] <= v <= p["max"]):
                raise ValueError(f"{label}은(는) {p['min']}~{p['max']} 사이여야 합니다 (입력: {v}).")
            out[name] = int(v) if ptype == "int" else float(v)
        elif ptype == "enum_or_float":
            # 혼합형(예: gamma): 문자열이면 choices 검증, 숫자면 min~max 범위 검증. 값 하나를 그대로 전달.
            allowed = [c["value"] for c in p["choices"]]
            if isinstance(v, bool):
                raise ValueError(f"{label}: 선택지 또는 숫자여야 합니다 (입력: {v!r}).")
            if isinstance(v, str):
                if v not in allowed:
                    allowed_str = ", ".join(str(a) for a in allowed)
                    raise ValueError(f"{label}: 허용된 값({allowed_str}) 또는 {p['min']}~{p['max']} 범위 숫자여야 합니다 (입력: {v!r}).")
                out[name] = v
            elif isinstance(v, (int, float)):
                if not (p["min"] <= v <= p["max"]):
                    raise ValueError(f"{label}: 직접 입력 숫자는 {p['min']}~{p['max']} 사이여야 합니다 (입력: {v}).")
                out[name] = float(v)
            else:
                allowed_str = ", ".join(str(a) for a in allowed)
                raise ValueError(f"{label}: 선택지({allowed_str}) 또는 숫자여야 합니다 (입력: {v!r}).")
        elif ptype == "enum_or_int":
            # 혼합형(예: max_depth): 선택지(None 등) 또는 정수(min~max). 값 하나를 그대로 전달.
            allowed = [c["value"] for c in p["choices"]]
            if isinstance(v, bool):
                raise ValueError(f"{label}: 선택지 또는 정수여야 합니다 (입력: {v!r}).")
            if v in allowed:  # 선택지 값(예: None=제한 없음)
                out[name] = v
            elif isinstance(v, (int, float)):
                if int(v) != v:
                    raise ValueError(f"{label}: 정수여야 합니다 (입력: {v}).")
                if not (p["min"] <= v <= p["max"]):
                    raise ValueError(f"{label}: 직접 입력 정수는 {p['min']}~{p['max']} 사이여야 합니다 (입력: {v}).")
                out[name] = int(v)
            else:
                labels = ", ".join(str(c.get("label", c["value"])) for c in p["choices"])
                raise ValueError(f"{label}: 선택지({labels}) 또는 {p['min']}~{p['max']} 정수여야 합니다 (입력: {v!r}).")
        else:  # enum
            allowed = [c["value"] for c in p["choices"]]
            if v not in allowed:
                allowed_str = ", ".join(str(a) for a in allowed)
                raise ValueError(f"{label}: 허용된 값({allowed_str}) 중 하나여야 합니다 (입력: {v!r}).")
            out[name] = v

    return out


def build_estimator(task: str, algo: str, params: dict[str, Any], scale: bool = False) -> Any:
    """명세의 estimator 이름 → sklearn 클래스를 찾아, 검증된 params 로 인스턴스를 생성한다.

    params 는 T2의 검증(범위/타입/키)을 통과한 값이라고 가정한다(이 팩토리는 검증하지 않는다).
    scale=True 면 StandardScaler 를 앞단에 붙인 Pipeline 으로 감싼다 → fit 시 스케일러가 학습셋으로만
    학습되어 데이터 누수가 없고, predict/predict_proba 는 자동으로 transform 후 예측한다.
    미지원 (task, algo) 이거나 매핑에 클래스가 없으면 ValueError.

    to_estimator_kwargs(선택): 명세 파라미터가 sklearn 인자와 1:1 이 아닌 모델(MLP: hidden_layers×units →
    hidden_layer_sizes)만 이 훅으로 변환한다. 훅이 없는 기존 모델은 종전대로 params 를 그대로 전달한다.
    """
    spec = get_spec(task, algo)
    if spec is None:
        raise ValueError(f"하이퍼파라미터를 지원하지 않는 모델입니다: task={task}, algo={algo}")
    est_name = spec["estimator"]
    cls = _ESTIMATORS.get(est_name)
    if cls is None:
        raise ValueError(f"추정기 매핑에 없는 클래스입니다: {est_name}")
    transform = spec.get("to_estimator_kwargs")
    est_params = transform(params) if transform else params  # 훅은 복사본을 반환 → 호출자의 params(usedParams 에코)는 불변
    # estimator_kwargs: 명세가 지정한 고정 생성자 인자(예: SVC probability=True). 사용자 params 와 병합.
    est = cls(**est_params, **spec.get("estimator_kwargs", {}))
    if scale:
        # Pipeline: 분할 후 fit 하면 scaler 도 학습셋으로만 fit → 누수 없음. predict 시 자동 transform.
        return Pipeline([("scaler", StandardScaler()), ("model", est)])
    return est
