"""관리자 계정 생성 CLI — 빈 DB에서 '첫 로그인'을 가능하게 하는 부트스트랩 수단.

배경: 공개 회원가입이 없고 POST /users 는 로그인(admin/instructor)해야 호출 가능하다.
      새로 클론한 사람은 사용자가 0명이라 로그인도, 계정 발급도 못 하는 '닭-달걀' 상태다.
      이 스크립트가 그 최초 1개의 관리자 계정을 만들어 매듭을 푼다.

★ 기존 인증·권한·해싱 로직을 그대로 재사용한다 — 우회하거나 새로 만들지 않는다.
   · 비밀번호: app.security.hash_password (로그인 검증 verify_password 와 짝).
   · 계정: app.models_db.User (role='admin').
   · 세션: app.db.SessionLocal.

사용법 (backend/ 에서, 마이그레이션 후):
    python scripts/create_admin.py                 # 이메일·비밀번호를 대화형으로 입력
    ADMIN_EMAIL=a@b.com ADMIN_PASSWORD=... python scripts/create_admin.py   # 자동화(CI 등)
    python scripts/create_admin.py --email a@b.com --force        # 이미 사용자가 있어도 강제
    python scripts/create_admin.py --email a@b.com --no-force-change  # 첫 로그인 강제변경 끄기

실행 정책(안전):
    · 사용자가 0명이면 그대로 생성(부트스트랩).
    · 사용자가 이미 있으면 실수 방지를 위해 --force 를 요구한다(운영 DB 오염 방지).
    · 같은 이메일이 이미 있으면 중복 생성하지 않고 안내 후 종료.

비밀번호 입력:
    · CLI 인자로는 받지 않는다(셸 히스토리 노출 방지).
    · 환경변수 ADMIN_PASSWORD 또는 대화형 getpass(확인 재입력)로만 받는다.
    · 최소 8자(백엔드 비밀번호 정책과 동일).
"""
from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path

# backend/ 를 import 경로에 추가(smoke_test.py 와 동일 방식).
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

MIN_PASSWORD_LEN = 8  # 백엔드 스키마(schemas_auth) · 프론트(ChangePasswordPage) 와 동일


def _fail(msg: str) -> "None":
    print(f"❌ {msg}", file=sys.stderr)
    raise SystemExit(1)


def _validate_email(email: str) -> str:
    """기존 스키마와 동일하게 pydantic EmailStr 로 검증(형식 불량 조기 차단)."""
    from pydantic import TypeAdapter, ValidationError
    from pydantic import EmailStr

    try:
        return TypeAdapter(EmailStr).validate_python(email.strip())
    except ValidationError:
        _fail(f"이메일 형식이 올바르지 않습니다: {email!r}")
        return ""  # 도달 불가(위에서 종료) — 타입 체커용


def _resolve_email(arg_email: str | None) -> str:
    email = arg_email or os.environ.get("ADMIN_EMAIL")
    if not email:
        try:
            email = input("관리자 이메일: ").strip()
        except EOFError:
            _fail("이메일이 필요합니다(--email 또는 ADMIN_EMAIL 환경변수, 또는 대화형 입력).")
    if not email:
        _fail("이메일이 비어 있습니다.")
    return _validate_email(email)


def _resolve_password() -> str:
    """ADMIN_PASSWORD(자동화) 우선, 없으면 getpass 로 확인 입력. 인자로는 받지 않는다."""
    env_pw = os.environ.get("ADMIN_PASSWORD")
    if env_pw is not None:
        if len(env_pw) < MIN_PASSWORD_LEN:
            _fail(f"ADMIN_PASSWORD 가 너무 짧습니다(최소 {MIN_PASSWORD_LEN}자).")
        return env_pw

    if not sys.stdin.isatty():
        _fail("비밀번호를 받을 수 없습니다. ADMIN_PASSWORD 환경변수를 쓰거나 대화형 터미널에서 실행하세요.")

    for _ in range(3):
        pw = getpass.getpass(f"관리자 비밀번호(최소 {MIN_PASSWORD_LEN}자): ")
        if len(pw) < MIN_PASSWORD_LEN:
            print(f"  너무 짧습니다(최소 {MIN_PASSWORD_LEN}자). 다시 입력하세요.")
            continue
        pw2 = getpass.getpass("비밀번호 확인: ")
        if pw != pw2:
            print("  두 입력이 일치하지 않습니다. 다시 입력하세요.")
            continue
        return pw
    _fail("비밀번호 입력에 반복 실패했습니다.")
    return ""  # 도달 불가


def main() -> None:
    ap = argparse.ArgumentParser(description="관리자(admin) 계정을 생성합니다.")
    ap.add_argument("--email", help="관리자 이메일(미지정 시 ADMIN_EMAIL 환경변수 또는 대화형 입력)")
    ap.add_argument("--username", help="표시 이름(선택)")
    ap.add_argument(
        "--force",
        action="store_true",
        help="이미 사용자가 있어도 생성을 진행(운영 DB에서 실수 방지용 안전장치).",
    )
    ap.add_argument(
        "--no-force-change",
        action="store_true",
        help="첫 로그인 시 비밀번호 강제 변경을 끕니다(기본: 강제 변경 켜짐).",
    )
    args = ap.parse_args()

    # 기존 로직 그대로 재사용(우회 금지).
    from sqlalchemy import func, select
    from sqlalchemy.exc import OperationalError

    from app.db import SessionLocal
    from app.models_db import User
    from app.security import hash_password

    email = _resolve_email(args.email)

    db = SessionLocal()
    try:
        # 마이그레이션 누락 대비 — 친절한 안내(테이블 없음 = alembic 미실행).
        try:
            user_count = db.scalar(select(func.count()).select_from(User)) or 0
        except OperationalError:
            _fail(
                "users 테이블이 없습니다. 먼저 마이그레이션을 실행하세요: "
                "alembic upgrade head"
            )

        # 실행 정책: 사용자가 이미 있으면 --force 없이는 중단(부트스트랩 외 오용 방지).
        if user_count > 0 and not args.force:
            _fail(
                f"이미 사용자가 {user_count}명 있습니다. 부트스트랩 상황이 아니면 관리자를 함부로 "
                "만들지 않습니다. 정말 추가하려면 --force 를 붙이세요."
            )

        # 중복 이메일 방지(--force 여부와 무관하게 항상).
        existing = db.scalar(select(User).where(User.email == email))
        if existing is not None:
            _fail(
                f"이미 같은 이메일의 사용자가 있습니다: {email} (role={existing.role}). "
                "중복 생성하지 않았습니다."
            )

        password = _resolve_password()

        user = User(
            email=email,
            username=args.username,
            role="admin",
            password_hash=hash_password(password),
            is_active=True,
            # 기본은 강제 변경 켜짐: 제공한 비밀번호를 '임시'로 보고 첫 로그인 때 바꾸게 한다.
            #   프론트 AuthGate 가 must_change_password=true 면 강제 변경 화면을 띄운다(검증됨).
            must_change_password=not args.no_force_change,
        )
        db.add(user)
        db.commit()

        forced = "예(첫 로그인 시 변경 필요)" if user.must_change_password else "아니오"
        print("✅ 관리자 계정을 생성했습니다.")
        print(f"   · 이메일: {email}")
        print(f"   · 역할(role): admin")
        print(f"   · 첫 로그인 시 비밀번호 변경 강제: {forced}")
        print("   이제 프론트 로그인 화면에서 이 이메일/비밀번호로 로그인하세요.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
