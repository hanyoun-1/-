"""스모크 테스트 — 예시 X,y로 train → predict 를 검증한다.

두 가지 방식:
  (A) HTTP 모드: 서버를 띄운 뒤 실행. `python scripts/smoke_test.py --http http://127.0.0.1:8000`
  (B) 직접 호출 모드(기본): FastAPI 없이 학습/예측 함수만 직접 호출(빠른 검증).

의존성(scikit-learn 등) 설치 필요. requirements.txt 참고.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# backend/ 를 import 경로에 추가
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def make_sample(n: int = 400):
    """소득·방문 기반의 간단한 선형+잡음 회귀 데이터. (features 2개)"""
    from app.repro import mulberry32

    rand = mulberry32(123)
    X, y = [], []
    for _ in range(n):
        income = 50 + rand() * 1950
        visits = rand() * 18
        target = 3.0 + 0.004 * income + 0.9 * visits + (rand() - 0.5) * 2
        X.append([income, visits])
        y.append(target)
    return X, y


def make_sample_cls(n: int = 400):
    """구매여부(0/1) 분류용 — 소득·방문 높을수록 구매확률↑."""
    from app.repro import mulberry32

    rand = mulberry32(123)
    X, y = [], []
    for _ in range(n):
        income = 50 + rand() * 1950
        visits = rand() * 18
        score = income / 2000 + visits / 18 + (rand() - 0.5)
        X.append([income, visits])
        y.append("buy" if score > 0.9 else "no")
    return X, y


def run_direct(algo: str):
    from app.models_reg import predict_regression, train_regression
    from app.schemas import TrainRequest

    X, y = make_sample()
    req = TrainRequest(
        task="reg", algo=algo, target="revenue",
        features=["monthly_income", "visit_count"],
        testRatio=0.2, X=X, y=y,
    )
    out = train_regression(req)
    resp = out["response"]
    print(f"[reg:{algo}] metrics = {resp['metrics']}")
    print(f"[reg:{algo}] coef={resp['coef']} importance={resp['importance']} intercept={resp['intercept']}")
    preds = predict_regression(out["model"], [[1200, 8], [300, 1]])
    print(f"[reg:{algo}] predict([[1200,8],[300,1]]) = {preds}")
    print()


def run_direct_cls(algo: str):
    from app.models_cls import predict_classification, train_classification
    from app.schemas import TrainRequest

    X, y = make_sample_cls()
    req = TrainRequest(
        task="cls", algo=algo, target="purchased",
        features=["monthly_income", "visit_count"],
        testRatio=0.2, X=X, y=y,
    )
    out = train_classification(req)
    resp = out["response"]
    print(f"[cls:{algo}] classes={resp['classes']} accuracy={resp['accuracy']}")
    print(f"[cls:{algo}] report[0]={resp['report'][0]}")
    print(f"[cls:{algo}] coef={resp['coef']} importance={resp['importance']}")
    p = predict_classification(out["model"], [[1800, 12], [200, 1]])
    print(f"[cls:{algo}] predict = {p['predictions']}  proba = {[[round(v,3) for v in r] for r in p['proba']]}")
    print()


def run_http(base: str, algo: str):
    import urllib.request

    X, y = make_sample()
    body = json.dumps({
        "task": "reg", "algo": algo, "target": "revenue",
        "features": ["monthly_income", "visit_count"],
        "testRatio": 0.2, "X": X, "y": y,
    }).encode()
    req = urllib.request.Request(f"{base}/models/train", data=body,
                                 headers={"Content-Type": "application/json"}, method="POST")
    res = json.loads(urllib.request.urlopen(req).read())
    mid = res["model_id"]
    print(f"[{algo}] model_id={mid} metrics={res['metrics']}")
    pbody = json.dumps({"X": [[1200, 8], [300, 1]]}).encode()
    preq = urllib.request.Request(f"{base}/models/{mid}/predict", data=pbody,
                                  headers={"Content-Type": "application/json"}, method="POST")
    pres = json.loads(urllib.request.urlopen(preq).read())
    print(f"[{algo}] predictions={pres['predictions']}")
    print()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--http", help="서버 base URL (예: http://127.0.0.1:8000). 없으면 직접 호출")
    args = ap.parse_args()
    for algo in ("linear", "rf"):
        if args.http:
            run_http(args.http, algo)
        else:
            run_direct(algo)
    if not args.http:
        for algo in ("logistic", "rf"):
            run_direct_cls(algo)
    print("스모크 테스트 완료 ✅")
