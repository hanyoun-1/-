"""Alembic 환경 — app.db.Base.metadata 를 대상으로, DB URL 은 app.settings 에서 주입.

- render_as_batch=True: SQLite 는 ALTER 제약이 커서 batch 모드로 테이블 재생성 방식 사용.
- 계정 테이블(organizations/groups/users/refresh_tokens)만 관리. 계산 API 는 무관.
"""
from __future__ import annotations

from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

# 앱 설정/메타데이터 로드 (prepend_sys_path=. 로 backend/ 가 sys.path 에 있음)
from app.db import Base
from app.settings import settings
from app import models_db  # noqa: F401  (모델 등록 — metadata 채우기)

config = context.config
# alembic.ini 자리표시자 대신 실제 설정 URL 을 사용.
config.set_main_option("sqlalchemy.url", settings.database_url)

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=settings.database_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        render_as_batch=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=True,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
