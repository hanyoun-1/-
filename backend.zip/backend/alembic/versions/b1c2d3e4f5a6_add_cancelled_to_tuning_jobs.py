"""add cancelled flag to tuning_jobs

협조적 취소(Optuna study.stop) 신호용 boolean 컬럼. 취소 요청이 True 로 세팅하면
튜닝 콜백이 매 trial 확인해 다음 trial 을 시작하지 않고 멈춘다. DB 라 멀티 워커 간 공유된다.

Revision ID: b1c2d3e4f5a6
Revises: afa10fb59776
Create Date: 2026-07-21 12:00:00.000000
"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b1c2d3e4f5a6'
down_revision: Union[str, None] = 'afa10fb59776'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 기존 행 backfill 위해 server_default=false 로 NOT NULL 추가(SQLite ADD COLUMN 지원).
    op.add_column(
        'tuning_jobs',
        sa.Column('cancelled', sa.Boolean(), nullable=False, server_default=sa.false()),
    )


def downgrade() -> None:
    # SQLite 는 DROP COLUMN 을 배치(테이블 재생성)로 처리.
    with op.batch_alter_table('tuning_jobs') as batch_op:
        batch_op.drop_column('cancelled')
