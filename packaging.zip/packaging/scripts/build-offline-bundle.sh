#!/usr/bin/env bash
#
# build-offline-bundle.sh — [인터넷 되는 빌드 PC]에서 실행.
# 폐쇄망 반입용 오프라인 번들(프론트 dist + 백엔드 소스 + Python 휠 + 설치 스크립트)을 만들어
# 하나의 tar.gz 로 압축한다. (앱 소스는 수정하지 않음)
#
# 사용:  bash packaging/scripts/build-offline-bundle.sh
#   환경변수로 대상 플랫폼 조정 가능(아래 참조).

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"   # 프로젝트 루트
PKG="$ROOT/packaging"
STAGE="$PKG/dist-bundle"
WHEELS="$PKG/offline/wheels"
DATE="$(date +%Y%m%d)"
BUNDLE="$PKG/aimedix-eda-bundle-$DATE.tar.gz"

# ── 대상 서버 플랫폼(오프라인 휠 크로스 다운로드) ────────────────────────────
#  대부분의 폐쇄망 서버는 Linux x86_64 → 기본값을 그에 맞춤.
#  빌드 PC(예: macOS)와 대상 서버의 OS/arch 가 다르므로 --platform 등을 지정해 받는다.
#  · 대상이 빌드 PC와 동일 OS/arch 라면 CROSS_PLATFORM=0 으로 두면 네이티브 휠을 받는다.
CROSS_PLATFORM="${CROSS_PLATFORM:-1}"                 # 1=대상(리눅스)용 / 0=현재 PC 네이티브
TARGET_PLATFORM="${TARGET_PLATFORM:-manylinux2014_x86_64}"
TARGET_PYVER="${TARGET_PYVER:-312}"                   # 대상 파이썬 3.12
TARGET_ABI="${TARGET_ABI:-cp312}"
TARGET_IMPL="${TARGET_IMPL:-cp}"
# 예) ARM64 리눅스 대상:  TARGET_PLATFORM=manylinux2014_aarch64
# 예) 파이썬 3.11 대상:   TARGET_PYVER=311 TARGET_ABI=cp311

echo "▶ [1/5] 프론트 빌드 (npm)"
cd "$ROOT"
if [ -f package-lock.json ]; then npm ci; else npm install; fi
npm run build   # → dist/  (config.json·fonts 포함)

echo "▶ [2/5] Python 오프라인 휠 수집 → $WHEELS"
rm -rf "$WHEELS"; mkdir -p "$WHEELS"
if [ "$CROSS_PLATFORM" = "1" ]; then
  echo "    (크로스: $TARGET_PLATFORM / py$TARGET_PYVER / $TARGET_ABI — 대상 Linux x86_64 가정)"
  python3 -m pip download -r "$ROOT/backend/requirements.txt" -d "$WHEELS" \
    --only-binary=:all: \
    --platform "$TARGET_PLATFORM" \
    --python-version "$TARGET_PYVER" \
    --implementation "$TARGET_IMPL" \
    --abi "$TARGET_ABI"
else
  echo "    (네이티브: 빌드 PC와 동일 OS/arch 서버용)"
  python3 -m pip download -r "$ROOT/backend/requirements.txt" -d "$WHEELS"
fi

echo "▶ [3/5] 스테이징 구성 → $STAGE"
rm -rf "$STAGE"; mkdir -p "$STAGE/backend" "$STAGE/nginx"
cp -R "$ROOT/dist" "$STAGE/dist"
# 백엔드 소스(venv·캐시 제외)
if command -v rsync >/dev/null 2>&1; then
  rsync -a --exclude '.venv' --exclude '__pycache__' --exclude '*.pyc' "$ROOT/backend/" "$STAGE/backend/"
else
  cp -R "$ROOT/backend/." "$STAGE/backend/"
  rm -rf "$STAGE/backend/.venv"; find "$STAGE/backend" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
fi
cp "$ROOT/backend/requirements.txt" "$STAGE/requirements.txt"
cp -R "$WHEELS" "$STAGE/wheels"
cp "$PKG/config.json.sample" "$STAGE/config.json.sample"
cp "$PKG/scripts/install-offline.sh" "$STAGE/install-offline.sh"; chmod +x "$STAGE/install-offline.sh"
cp "$PKG/nginx/nginx.conf.sample" "$STAGE/nginx/nginx.conf.sample"
cp "$PKG/README.md" "$STAGE/README.md"
[ -d "$PKG/docker" ] && cp -R "$PKG/docker" "$STAGE/docker" || true

echo "▶ [4/5] 압축 → $BUNDLE"
tar -czf "$BUNDLE" -C "$PKG" "dist-bundle"

echo "▶ [5/5] 완료"
echo "    번들: $BUNDLE"
du -sh "$BUNDLE" 2>/dev/null || true
echo "    휠 개수: $(find "$WHEELS" -name '*.whl' | wc -l | tr -d ' ')"
echo "    → 이 파일을 USB 등으로 폐쇄망 서버에 반입하세요."
