#!/usr/bin/env bash
#
# install-offline.sh — [폐쇄망 고객 서버]에서 실행. (인터넷 불필요)
# 번들(dist-bundle) 압축을 푼 디렉터리에서 실행하는 것을 가정한다.
#   tar -xzf aimedix-eda-bundle-YYYYMMDD.tar.gz && cd dist-bundle && ./install-offline.sh
#
# 하는 일: Python venv 생성 → 오프라인 휠로 의존성 설치 → 프론트 config.json 준비 → 기동 안내.

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

PORT="${PORT:-8000}"
PY="${PYTHON:-python3}"

echo "▶ [1/4] Python 확인"
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "  ✗ $PY 를 찾을 수 없습니다. Python 3.11~3.13 을 먼저 설치하세요." >&2
  exit 1
fi
"$PY" --version

echo "▶ [2/4] 가상환경 생성 + 오프라인 설치 (--no-index)"
cd "$HERE/backend"
"$PY" -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --no-index --find-links="$HERE/wheels" --upgrade pip >/dev/null 2>&1 || true
python -m pip install --no-index --find-links="$HERE/wheels" -r "$HERE/requirements.txt"
deactivate
cd "$HERE"

echo "▶ [3/4] 프론트 config.json 준비"
if [ ! -f dist/config.json ]; then
  cp config.json.sample dist/config.json
  echo "  dist/config.json 생성(샘플 복사)."
else
  echo "  dist/config.json 이미 존재 → 유지."
fi
echo "  ⚙ dist/config.json 의 API_BASE_URL 을 환경에 맞게 수정하세요. (학습·예측은 백엔드 필수)"
echo "     · nginx 프록시(same-origin) 사용 시 API_BASE_URL=\"\" 권장."

echo "▶ [4/4] 완료 — 기동 방법"
cat <<EOF

──────────────────────────────────────────────
[백엔드 기동]
  cd backend && source .venv/bin/activate
  ALLOWED_ORIGINS="http://localhost" uvicorn app.main:app --host 0.0.0.0 --port $PORT
  헬스체크:  curl http://127.0.0.1:$PORT/health      # {"status":"ok"} 이면 정상

[프론트 서빙]  (백엔드는 정적 서빙 안 함 → 웹서버 필요)
  · nginx 사용(권장): nginx/nginx.conf.sample 을 /etc/nginx/conf.d/ 에 배치.
      - dist 경로와 backend 주소(127.0.0.1:$PORT)를 파일 안에서 확인/수정.
      - same-origin 이라 CORS 불필요, config.json 의 API_BASE_URL 은 "" 로.
  · Docker 사용(선택): docker/ 폴더의 docker-compose 참고(README).
──────────────────────────────────────────────
EOF
