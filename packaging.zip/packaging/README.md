# 폐쇄망 설치형 패키징 가이드

인터넷이 없는 고객 서버에 이 앱(프론트 + FastAPI 백엔드)을 설치하기 위한 **오프라인 반입 패키지**를 만들고 설치하는 절차입니다.
(앱 소스는 수정하지 않습니다. 이 폴더는 배포 도구만 담습니다.)

## 전체 흐름

```
[인터넷 되는 빌드 PC]                         [폐쇄망 고객 서버]
 build-offline-bundle.sh                        install-offline.sh
   · 프론트 빌드(dist/)                            · venv + 오프라인 휠 설치(--no-index)
   · Python 휠 수집(pip download)     ──USB──▶     · config.json 준비
   · dist+backend+wheels+scripts 묶기              · 백엔드 기동(uvicorn) + nginx 서빙
   · aimedix-eda-bundle-YYYYMMDD.tar.gz            · 헬스체크
```

## 반입 방식 — 기관 정책에 따라 택1

### (A) 오프라인 휠 방식 — 기본/권장
Docker 없이 Python venv + 미리 받은 휠로 설치. 대부분의 폐쇄망에서 사용 가능.

### (B) 컨테이너 이미지 방식 — 선택
Docker 를 쓰는 기관용. 이미지를 `docker save`로 저장해 반입하고 `docker load`로 올림.
```bash
# 인터넷 PC (번들 루트에서)
docker build -f docker/Dockerfile -t aimedix-eda-backend:offline .
docker save aimedix-eda-backend:offline nginx:alpine | gzip > images.tar.gz
# 폐쇄망 서버
gunzip -c images.tar.gz | docker load
docker compose -f docker/docker-compose.yml up -d   # nginx conf 의 proxy 대상=backend:8000 로 수정
```

---

## 1) 빌드 PC에서 번들 생성 (인터넷 필요)
```bash
# 대상 서버가 Linux x86_64 인 일반적인 경우(기본값)
bash packaging/scripts/build-offline-bundle.sh

# 대상이 다른 플랫폼이면 환경변수로 조정(예시)
TARGET_PLATFORM=manylinux2014_aarch64 TARGET_PYVER=311 TARGET_ABI=cp311 \
  bash packaging/scripts/build-offline-bundle.sh
```
→ `packaging/aimedix-eda-bundle-YYYYMMDD.tar.gz` 생성. 이 파일을 반입.

## 2) 폐쇄망 서버에서 설치 (인터넷 불필요)
```bash
tar -xzf aimedix-eda-bundle-YYYYMMDD.tar.gz
cd dist-bundle
./install-offline.sh
```

## 3) 기동 & 확인
```bash
# 백엔드
cd backend && source .venv/bin/activate
ALLOWED_ORIGINS="http://localhost" uvicorn app.main:app --host 0.0.0.0 --port 8000
curl http://127.0.0.1:8000/health          # {"status":"ok"}

# 프론트: nginx/nginx.conf.sample 배치 후 브라우저로 접속
curl -I http://localhost/                   # 200 이면 정적 서빙 정상
```
- 프론트 `dist/config.json` 에서 `API_BASE_URL`(same-origin이면 `""`)을 환경에 맞게 설정. 학습·예측은 항상 백엔드가 수행하므로 백엔드가 반드시 떠 있어야 합니다.

---

## 대상 서버 최소 사양 (추정 — 실측 아님)
| 항목 | 권장(추정) |
|------|-----------|
| OS | Linux x86_64 (Ubuntu 22.04 등) |
| Python | 3.11 ~ 3.13 (**휠은 3.12 기준으로 수집**) |
| CPU | 4 코어 이상(트리 학습 병렬) |
| RAM | 8GB 이상(대용량 학습 시 여유) |
| 디스크 | 3GB+ (휠·이미지·데이터) — PyTorch CPU 휠(~654MB)·CatBoost(~300MB) 포함 |

> 위 수치는 **추정**입니다. 실제 데이터 규모(행 수)에 따라 RAM 요구가 달라집니다.

## 트러블슈팅
| 증상 | 원인 · 대응 |
|------|-------------|
| `install-offline.sh` 설치 중 휠 오류 | **휠 플랫폼 불일치**. 빌드 시 `TARGET_PLATFORM/PYVER/ABI` 를 대상 서버에 맞춰 다시 수집. 대상 파이썬 마이너 버전과 `TARGET_PYVER`(cp312 등) 일치 필수 |
| 화면은 뜨는데 학습이 실패 | 백엔드 미기동 또는 `config.json` 의 `API_BASE_URL`/프록시 불일치. 헬스체크(`/health`) 확인 |
| 콘솔에 `[config] 잘못된 …` 경고 | `dist/config.json` 오타(모드 철자·숫자 아닌 임계값). 경고 메시지대로 수정(값은 폴백되어 동작은 함) |
| CORS 오류 | 별도 호스트로 백엔드를 둔 경우. 백엔드 `ALLOWED_ORIGINS` 에 프론트 오리진 추가하거나, nginx same-origin 프록시로 전환 |
| 포트 충돌(8000/80) | `--port` 변경 또는 nginx `listen` 변경. 방화벽 오픈 확인 |
| 폰트가 기본 글꼴로 보임 | `dist/fonts/` 에 Pretendard woff2 미포함. 있어도/없어도 동작하며, 브랜드 폰트 원하면 파일 반입 |

## 보안 주의
- **실제 내부망 IP·API 주소·`config.json` 실값을 저장소에 커밋하지 마세요.** 샘플엔 플레이스홀더만.
- 반입 매체(USB 등)는 반입 후 안전하게 관리/폐기.
- 백엔드는 내부망에서만 접근되도록 방화벽·바인딩 주소 제한. 외부 노출 시 인증 계층 추가 검토(현재 백엔드에 인증 없음).
- `packaging/offline/`·`packaging/dist-bundle/`·`*-bundle.tar.gz` 는 `.gitignore` 처리됨(대용량 바이너리 커밋 금지).
