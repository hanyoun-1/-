/// <reference types="vite/client" />

// 백엔드 연결 환경변수 타입(API 주소·타임아웃). 미설정 시 같은 오리진·기본 타임아웃으로 동작한다.
interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
  readonly VITE_API_TIMEOUT_MS?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
