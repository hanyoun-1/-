import type { VizTreeNode } from '../lib/models';

// 트리 모델 설명 — 같은 학습 데이터로 만든 깊이-2 결정 트리를 실제 변수·실제 예측값으로 렌더.
// 실제 모델(앙상블)은 이런 트리를 더 깊게 수십 개 사용한다. algo는 설명 문구, task는 잎 의미(예측값/범주).
export default function DecisionTreeConcept({ algo, task, tree, targetLabel, maxDepth }: { algo: string; task: 'reg' | 'cls'; tree?: VizTreeNode; targetLabel?: string; maxDepth?: number | string | null }) {
  const second =
    algo === 'xgboost'
      ? '실제 XGBoost는 이런 트리를 하나씩 차례로 더하면서 앞 트리가 틀린 부분을 보완합니다(규제가 추가된 부스팅).'
      : algo === 'lightgbm'
      ? '실제 LightGBM은 이런 트리를 하나씩 차례로 더하면서 앞 트리가 틀린 부분을 보완합니다(잎 중심으로 빠르게 성장).'
      : algo === 'catboost'
      ? '실제 CatBoost는 이런 트리를 하나씩 차례로 더하면서 앞 트리가 틀린 부분을 보완합니다(대칭 트리 + L2 규제).'
      : algo === 'dtree'
      ? '결정 트리는 실제로 이렇게 하나의 트리로 예측합니다.'
      : '실제 랜덤 포레스트는 이런 트리를 수십 그루 만들어 각 예측을 평균냅니다.';
  const leafMeaning = task === 'cls' ? '가장 많은 범주(비율)' : '목표값의 평균';

  if (!tree) {
    return (
      <div className="mt-5 rounded-card border border-border bg-surface-muted/40 p-4">
        <h4 className="text-sm font-semibold text-text">트리는 어떻게 판단하나요?</h4>
        <p className="mt-2 text-xs text-text-muted">트리 구조를 표시할 수 없습니다.</p>
      </div>
    );
  }

  // ─ 레이아웃 계산 (깊이 ≤ 3 이진 트리) ─
  const padX = 22;

  const leaves: VizTreeNode[] = [];
  const collect = (n: VizTreeNode) => {
    if (n.leaf) leaves.push(n);
    else { collect(n.left); collect(n.right); }
  };
  collect(tree);
  const nLeaf = Math.max(1, leaves.length);
  // 잎 수에 맞춰 폭 확대(잎당 150) → 깊이 2(≤4잎)=600 그대로, 깊이 3(≤8잎)=최대 1200.
  //   viewBox 가 컨테이너 폭에 스케일되므로 가로 스크롤 없이 겹침 없이 그려진다.
  const W = Math.max(600, nLeaf * 150);
  const leafX = new Map<VizTreeNode, number>();
  leaves.forEach((l, i) => leafX.set(l, padX + (i + 0.5) * ((W - 2 * padX) / nLeaf)));

  const depthOf = (n: VizTreeNode): number => (n.leaf ? 0 : 1 + Math.max(depthOf(n.left), depthOf(n.right)));
  const D = depthOf(tree);
  // 세로 레이아웃 — 단(레벨)마다 일정 간격. 폭 확대(W)로 viewBox 가 컨테이너 폭에 다운스케일되므로,
  //   세로 좌표도 s=W/600 로 비례 확대해 "렌더 단 간격"을 깊이·잎수와 무관하게 일정하게 유지한다.
  //   깊이 2(W=600 → s=1)는 기존 값(topY 30·botY 250·H 300)과 완전히 동일 → rf/gb 불변.
  const s = W / 600;
  const topY = 30 * s;
  const botY = topY + D * (110 * s); // 단 수(D)만큼 세로로 늘어나 답답하지 않게
  const H = botY + 50 * s; // 하단 여백(잎 상자)
  // 폰트·박스 세로 높이도 s 로 상쇄해 렌더 크기를 일정하게(읽힘) 유지. 가로 폭은 잎 간격 제약(≈150)으로
  //   s 스케일 금지 → 커진 폰트가 넘치지 않게 텍스트 clip 길이를 1/s 로 줄인다. s=1(깊이 2)은 기존과 동일.
  const fs = 11 * s;
  // 분기 노드는 잎보다 드물어(같은 레벨에 잎의 절반 이하) 폭을 넓혀도 겹치지 않음 → 긴 조건을 담게 넓힌다.
  //   조건은 "컬럼명 / ≤ 임계값?" 2줄로 나눠 세로 여유를 활용(가로 잘림 완화). 잎은 폭 제약이 커 1줄 유지.
  //   clip 길이는 박스 폭·폰트로 산출(넓을수록 더 많은 글자). s=1(깊이 2)이면 기존과 유사한 값.
  const branchW = 200;
  const branchH = 44;
  const leafW = 132;
  const leafH = 32;
  // 실제 학습 트리가 시각화 깊이(D)보다 깊을 수 있으면 안내(dtree 한정).
  const deeperNote =
    algo === 'dtree'
      ? maxDepth === null
        ? ` 실제 트리는 최대 깊이 제한이 없어 더 깊을 수 있고, 여기서는 깊이 ${D}까지만 보여줘요.`
        : typeof maxDepth === 'number' && maxDepth > D
        ? ` 설정한 최대 깊이는 ${maxDepth}이고, 여기서는 깊이 ${D}까지만 보여줘요.`
        : ''
      : '';
  const xOf = (n: VizTreeNode): number => (n.leaf ? leafX.get(n)! : (xOf(n.left) + xOf(n.right)) / 2);
  const yOf = (level: number): number => (D === 0 ? H / 2 : topY + level * ((botY - topY) / D));

  type Placed = { n: VizTreeNode; x: number; y: number };
  const placed: Placed[] = [];
  const edges: { x1: number; y1: number; x2: number; y2: number; label: string }[] = [];
  const walk = (n: VizTreeNode, level: number) => {
    const x = xOf(n);
    const y = yOf(level);
    placed.push({ n, x, y });
    if (!n.leaf) {
      edges.push({ x1: x, y1: y + 18 * s, x2: xOf(n.left), y2: yOf(level + 1) - 18 * s, label: '예' });
      edges.push({ x1: x, y1: y + 18 * s, x2: xOf(n.right), y2: yOf(level + 1) - 18 * s, label: '아니오' });
      walk(n.left, level + 1);
      walk(n.right, level + 1);
    }
  };
  walk(tree, 0);

  const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
  // 회귀 잎에는 목표 컬럼명을 함께 표기(예: "연봉 3,215"). 분류 잎은 이미 범주가 목표값이라 그대로.
  const leafText = (label: string) => (task === 'reg' && targetLabel ? `${targetLabel} ${label}` : label);

  // 길이 적응 폰트 — 텍스트가 노드 가용 폭(availW, viewBox)을 넘으면 그 텍스트만 폰트를 줄여 담는다.
  //   짧으면 기존 fs 유지, 길면 축소(하한 = fs×0.72, 읽을 만한 크기). 하한에서도 넘칠 때만 최소한으로 clip(드묾).
  const CHAR_W = 0.6; // 폰트 크기 대비 평균 글자 폭 비율(대략)
  const fitText = (text: string, availW: number) => {
    const len = Math.max(1, text.length);
    const ideal = availW / (len * CHAR_W); // 이 글자수가 딱 들어가는 폰트 크기
    const size = Math.min(fs, Math.max(fs * 0.72, ideal)); // 기존 fs 이하, 하한 이상으로 클램프
    const maxChars = Math.max(4, Math.floor(availW / (size * CHAR_W)));
    return { size, label: clip(text, maxChars) };
  };

  return (
    <div className="mt-5 rounded-card border border-border bg-surface-muted/40 p-4">
      <h4 className="text-sm font-semibold text-text">트리는 어떻게 판단하나요? (학습 데이터 기반 · 깊이 {D}){targetLabel ? ` · 예측 대상: ${clip(targetLabel, 16)}` : ''}</h4>
      <div className="mt-3">
        <svg viewBox={`0 0 ${W} ${H}`} className="mx-auto w-full max-w-4xl" role="img" aria-label="학습된 결정 트리(깊이 2)">
          {/* 가지 */}
          <g stroke="var(--border)" strokeWidth={1.5} fill="none">
            {edges.map((e, i) => (
              <line key={i} x1={e.x1} y1={e.y1} x2={e.x2} y2={e.y2} />
            ))}
          </g>
          {/* 가지 라벨(예/아니오) */}
          <g fill="var(--text-muted)" fontSize={fs} textAnchor="middle">
            {edges.map((e, i) => (
              <text key={i} x={(e.x1 + e.x2) / 2 + (e.label === '예' ? -8 * s : 8 * s)} y={(e.y1 + e.y2) / 2}>{e.label}</text>
            ))}
          </g>
          {/* 노드 */}
          {placed.map((p, i) => {
            if (p.n.leaf) {
              const lf = fitText(leafText(p.n.label), leafW - 16);
              return (
                <g key={i}>
                  <rect x={p.x - leafW / 2} y={p.y - (leafH / 2) * s} width={leafW} height={leafH * s} rx={16 * s} fill="var(--primary-soft)" stroke="var(--primary)" strokeWidth={1} />
                  <text x={p.x} y={p.y + 4 * s} textAnchor="middle" fontSize={lf.size} fontWeight={600} fill="var(--primary)">{lf.label}</text>
                </g>
              );
            }
            // 분기 조건 "컬럼명 ≤ 임계값?" → 2줄(컬럼명 / ≤ 임계값?)로 분리. 형식이 다르면 1줄로 폴백.
            const qi = p.n.q.indexOf(' ≤ ');
            const l1 = qi < 0 ? p.n.q : p.n.q.slice(0, qi);
            const l2 = qi < 0 ? '' : p.n.q.slice(qi + 1);
            const f1 = fitText(l1, branchW - 16); // 컬럼명(긴 경우 이 노드만 폰트 축소)
            const f2 = fitText(l2, branchW - 16); // 임계값 줄(짧아 대개 fs 유지)
            return (
              <g key={i}>
                <rect x={p.x - branchW / 2} y={p.y - (branchH / 2) * s} width={branchW} height={branchH * s} rx={8 * s} fill="var(--surface)" stroke="var(--primary)" strokeWidth={1.5} />
                {l2 ? (
                  <>
                    <text x={p.x} y={p.y - 3 * s} textAnchor="middle" fontSize={f1.size} fill="var(--text)">{f1.label}</text>
                    <text x={p.x} y={p.y + 14 * s} textAnchor="middle" fontSize={f2.size} fill="var(--text-muted)">{f2.label}</text>
                  </>
                ) : (
                  <text x={p.x} y={p.y + 4 * s} textAnchor="middle" fontSize={f1.size} fill="var(--text)">{f1.label}</text>
                )}
              </g>
            );
          })}
        </svg>
        <p className="mt-2 text-xs leading-relaxed text-text-muted">
          위 트리는 <b className="text-text">지금 학습한 데이터</b>로 만든 깊이 {D}짜리 결정 트리입니다. 조건(예/아니오)을 따라 내려가 도착한 <b className="text-text">잎</b>의 값이 {targetLabel ? <><b className="text-text">{targetLabel}</b> 예측</> : '예측'}이며, 그 조건에 해당하는 데이터의 <b className="text-text">{leafMeaning}</b>입니다. {second}{deeperNote}
        </p>
      </div>
    </div>
  );
}
