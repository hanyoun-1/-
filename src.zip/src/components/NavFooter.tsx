import { useStepStore } from '../store/useStepStore';
import Button from './Button';

interface Props {
  prevLabel?: string;
  nextLabel?: string;
  onNext?: () => void;
  hidePrev?: boolean;
  hideNext?: boolean;
}

export default function NavFooter({
  prevLabel,
  nextLabel,
  onNext,
  hidePrev,
  hideNext,
}: Props) {
  const { next, prev } = useStepStore();
  return (
    <div className="mt-8 flex items-center justify-between border-t border-border pt-5">
      {!hidePrev ? (
        <Button variant="secondary" onClick={prev}>
          ← {prevLabel ?? '이전'}
        </Button>
      ) : (
        <span />
      )}
      {!hideNext ? (
        <Button onClick={onNext ?? next}>{nextLabel ?? '다음'} →</Button>
      ) : (
        <span />
      )}
    </div>
  );
}
