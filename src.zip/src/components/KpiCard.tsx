import type { ReactNode } from 'react';

interface Props {
  icon?: ReactNode;
  label: string;
  value: ReactNode;
  hint?: string;
  accent?: string; // tailwind text color class
}

export default function KpiCard({ icon, label, value, hint, accent = 'text-primary' }: Props) {
  return (
    <div className="rounded-card border border-border bg-surface p-5 shadow-card">
      <div className="flex items-center gap-2 text-sm text-text-muted">
        {icon && (
          <span className={`grid h-7 w-7 place-items-center rounded-chip bg-surface-muted ${accent}`}>
            {icon}
          </span>
        )}
        {label}
      </div>
      <div className="mt-3 text-3xl font-bold tracking-tight text-text">{value}</div>
      {hint && <div className="mt-1 text-xs text-text-muted">{hint}</div>}
    </div>
  );
}
