import { Component, type ReactNode } from 'react';
import { useDatasetStore } from '../store/useDatasetStore';

interface State {
  error: Error | null;
}

// 렌더 중 발생한 예외를 잡아 흰 화면 대신 복구 UI를 보여준다.
// (전처리 스텝이 localStorage에 남아 새로고침해도 같은 에러가 반복될 수 있어, 여기서 초기화 수단을 제공)
export default class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error) {
    // 콘솔에도 남겨 진단 가능하게
    console.error('[ErrorBoundary]', error);
  }

  private undoLastStep = () => {
    try {
      useDatasetStore.getState().undoStep();
    } catch {
      /* ignore */
    }
    this.setState({ error: null });
  };

  private resetSteps = () => {
    try {
      useDatasetStore.getState().resetSteps();
    } catch {
      /* ignore */
    }
    this.setState({ error: null });
  };

  private deleteData = () => {
    try {
      useDatasetStore.getState().deleteData();
    } catch {
      /* ignore */
    }
    this.setState({ error: null });
  };

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div className="grid min-h-screen place-items-center bg-bg p-6">
        <div className="w-full max-w-lg rounded-card border border-border bg-surface p-6 shadow-card">
          <h1 className="text-lg font-bold text-text">화면에 문제가 발생했어요</h1>
          <p className="mt-2 text-sm text-text-muted">
            마지막 동작(주로 전처리)에서 예기치 못한 오류가 발생했습니다. 아래에서 복구할 수 있어요.
          </p>
          <pre className="mt-3 max-h-40 overflow-auto rounded-btn bg-surface-muted p-3 text-xs text-danger">
            {error.message}
          </pre>
          <div className="mt-5 flex flex-wrap gap-2">
            <button onClick={this.undoLastStep} className="rounded-btn bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
              이전 전처리 단계 취소
            </button>
            <button onClick={this.resetSteps} className="rounded-btn border border-border bg-surface px-4 py-2 text-sm font-medium text-text hover:bg-surface-muted">
              전처리 전체 초기화
            </button>
            <button onClick={this.deleteData} className="rounded-btn border border-danger/40 bg-surface px-4 py-2 text-sm font-medium text-danger hover:bg-danger/10">
              데이터 삭제(처음부터)
            </button>
          </div>
          <p className="mt-3 text-xs text-text-muted">
            버튼이 안 통하면 브라우저 콘솔(F12)의 빨간 에러 메시지를 캡처해 알려주세요.
          </p>
        </div>
      </div>
    );
  }
}
