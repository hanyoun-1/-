interface Option<T extends string> {
  value: T;
  label: string;
  disabled?: boolean;
}

interface Props<T extends string> {
  options: Option<T>[];
  value: T;
  onChange: (v: T) => void;
}

export default function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
}: Props<T>) {
  return (
    <div className="inline-flex flex-wrap gap-1 rounded-btn border border-border bg-surface-muted p-1">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            disabled={o.disabled}
            onClick={() => onChange(o.value)}
            className={`rounded-chip px-4 py-1.5 text-sm font-medium transition-all
              ${active ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text'}
              ${o.disabled ? 'cursor-not-allowed opacity-40' : ''}`}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
