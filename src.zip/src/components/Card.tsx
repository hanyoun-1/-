import type { ReactNode } from 'react';

interface Props {
  title?: ReactNode;
  subtitle?: ReactNode;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}

export default function Card({ title, subtitle, right, children, className = '' }: Props) {
  return (
    <section
      className={`rounded-card border border-border bg-surface p-6 shadow-card ${className}`}
    >
      {(title || right) && (
        <header className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
          <div className="min-w-0">
            {title && <h3 className="text-base font-semibold text-text whitespace-nowrap">{title}</h3>}
            {subtitle && <p className="mt-1 text-sm text-text-muted">{subtitle}</p>}
          </div>
          {right}
        </header>
      )}
      {children}
    </section>
  );
}
