import type { ButtonHTMLAttributes, ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'success';

const styles: Record<Variant, string> = {
  primary:
    'bg-primary text-white hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed',
  secondary:
    'bg-surface border border-border text-text hover:bg-surface-muted disabled:opacity-40',
  ghost: 'text-text-muted hover:text-text hover:bg-surface-muted disabled:opacity-40',
  danger: 'bg-danger text-white hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed',
  success: 'bg-success/15 text-success hover:bg-success/25',
};

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  loading?: boolean; // 처리 중 스피너 + 자동 비활성
  children: ReactNode;
}

function Spinner() {
  return (
    <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
    </svg>
  );
}

export default function Button({
  variant = 'primary',
  className = '',
  loading = false,
  disabled,
  children,
  ...rest
}: Props) {
  return (
    <button
      disabled={disabled || loading}
      aria-busy={loading}
      className={`inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-btn px-4 py-2 text-sm font-medium transition-all ${styles[variant]} ${className}`}
      {...rest}
    >
      {loading && <Spinner />}
      {children}
    </button>
  );
}
