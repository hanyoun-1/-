// 무거운 작업 중 화면 위에 표시하는 처리 중 오버레이.
export default function BusyOverlay({ show, label = '처리 중…' }: { show: boolean; label?: string }) {
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/20 backdrop-blur-[1px]">
      <div className="flex items-center gap-3 rounded-card border border-border bg-surface px-5 py-4 shadow-card">
        <svg className="h-5 w-5 animate-spin text-primary" viewBox="0 0 24 24" fill="none" aria-hidden>
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
        </svg>
        <span className="text-sm font-medium text-text">{label}</span>
      </div>
    </div>
  );
}
