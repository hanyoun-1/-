interface Props {
  children: React.ReactNode;
  title?: string;
}

export default function InsightCard({ children, title = '해석' }: Props) {
  return (
    <div className="rounded-card border border-ai/30 bg-ai/5 p-5">
      <div className="mb-1 flex items-center gap-2 text-sm font-semibold text-ai">
        {title}
      </div>
      <p className="text-sm leading-relaxed text-text">{children}</p>
    </div>
  );
}
