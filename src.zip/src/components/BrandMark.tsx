// Elio 브랜드 로고 마크 — bg-primary(=var(--primary)) 둥근 사각 배경 + 흰 막대 3개
//   (왼→오로 높아지며 농도도 0.5→0.75→1.0 로 진해짐). 배경색은 테마 변수라 라이트/다크 자동 대응.
// Topbar·로그인·비밀번호 변경 화면에서 공용으로 쓰기 위해 추출. 표시 크기는 className(h-*/w-*)으로 지정.
export default function BrandMark({ className = 'h-7 w-7' }: { className?: string }) {
  return (
    <span className={`grid flex-none place-items-center rounded-lg bg-primary text-white ${className}`}>
      <svg viewBox="0 0 56 56" className="h-full w-full" role="img" aria-label="Elio">
        <rect x="15" y="32" width="6" height="12" rx="3" fill="#fff" fillOpacity="0.5" />
        <rect x="25" y="25" width="6" height="19" rx="3" fill="#fff" fillOpacity="0.75" />
        <rect x="35" y="18" width="6" height="26" rx="3" fill="#fff" />
      </svg>
    </span>
  );
}
