import { useDatasetStore } from '../store/useDatasetStore';
import type { Dataset } from '../types';

// 모든 화면이 읽는 단일 데이터 소스 — 전처리 스텝이 반영된 activeDataset.
// 스텝이 없으면 원본과 동일하다.
export function useActiveDataset(): Dataset | null {
  return useDatasetStore((s) => s.activeDataset);
}
