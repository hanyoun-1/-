import { useCallback, useState } from 'react';

// 무거운 동기 작업(전처리 재프로파일·모델 학습) 실행 시 스피너가 실제로 보이도록,
// busy=true 로 바꾼 뒤 한 프레임 양보(브라우저 페인트)하고 작업을 실행한다.
//   const [busy, run] = useBusy();
//   <Button loading={busy} onClick={() => run(() => heavyWork())} />
export function useBusy(): [boolean, (fn: () => void | Promise<void>) => Promise<void>] {
  const [busy, setBusy] = useState(false);

  // fn은 동기/비동기 모두 허용. 비동기면 완료까지 await 하여 스피너를 유지한다(동기 호출과 하위호환).
  const run = useCallback(async (fn: () => void | Promise<void>) => {
    setBusy(true);
    // 스피너가 그려질 시간을 준다(두 프레임 양보).
    await new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
    try {
      await fn();
    } finally {
      setBusy(false);
    }
  }, []);

  return [busy, run];
}
