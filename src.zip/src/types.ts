export type ColumnType = 'int' | 'float' | 'string' | 'bool' | 'datetime';
export type ColumnRole =
  | '식별자'
  | '수치형'
  | '범주형'
  | '날짜형'
  | '예측 후보';

// datetime 컬럼의 날짜 표기 형식 — 정렬·래그가 원본 문자열을 올바르게 파싱하는 데 쓴다(원본 값은 안 바꿈).
//   'ISO'=YYYY-MM-DD / 'DMY'=DD/MM/YYYY(유럽·아시아) / 'MDY'=MM/DD/YYYY(미국) / 'unknown'=애매(판정 불가 → 시간 컬럼 후보 제외).
export type DateFormat = 'ISO' | 'DMY' | 'MDY' | 'unknown';

export interface ColumnMeta {
  name: string;
  label: string; // 한글 표시명
  type: ColumnType;
  role: ColumnRole;
  dateFormat?: DateFormat; // type==='datetime' 일 때만 채워진다(profile 이 판정).
}

export type Row = Record<string, string | number | boolean | null>;

export interface StatRow {
  name: string;
  label: string;
  mean: number;
  median: number;
  std: number; // 표준편차
  min: number;
  max: number;
  skewness: number; // 왜도(+ 오른쪽 치우침 / − 왼쪽 치우침)
  q1: number; // 하위 25% 지점
  q3: number; // 상위 75% 지점
  iqr: number; // Q3 - Q1
}

// 변수별 이상치 — 실제 행/값/판정기준
export interface OutlierRow {
  row: number; // 행번호(1부터)
  value: number;
  reason: string; // IQR: 'Q3 + 1.5×IQR 초과' | 'Q1 - 1.5×IQR 미만' / 로버스트 Fallback: '로버스트 상한 초과' 등
}

export interface OutlierVar {
  name: string;
  label: string;
  q1: number;
  q3: number;
  iqr: number;
  lower: number; // 이상치 하한(IQR: Q1-1.5×IQR / 로버스트: median-3.5σ)
  upper: number; // 이상치 상한(IQR: Q3+1.5×IQR / 로버스트: median+3.5σ)
  count: number; // 전체 이상치 개수
  ratio: number; // 이상치 비율(%) = count / 유효(비결측) 값 수 × 100
  sample: OutlierRow[]; // 표시용(최대 50건)
}

export interface QualityReport {
  missingPct: number;
  duplicateCount: number;
  outlierCount: number; // 전체 변수 이상치 합계
  outliers: OutlierVar[]; // 변수별 이상치 상세(개수 내림차순)
}

export interface Dataset {
  fileName: string;
  rows: Row[];
  columns: ColumnMeta[];
  rowCount: number;
  colCount: number;
  sizeMB: number;
  periodStart: string;
  periodEnd: string;
  periodLabel: string;
  predictTargets: PredictTarget[];
  statistics: StatRow[];
  quality: QualityReport;
}

export interface PredictTarget {
  key: string;
  label: string;
  kind: 'categorical' | 'numeric';
  model: 'Decision Tree' | 'Regression';
}

// 시각화에서 고를 수 있는 차트 종류
export type ManualChart = 'histogram' | 'box' | 'scatter' | 'heatmap' | 'bar' | 'line' | 'pie' | 'treemap' | 'area';

// 대시보드에 추가한 차트 1개 — 단일 차트에서 고른 구성을 그대로 보관해 재렌더한다.
export interface DashboardItem {
  id: string;
  chart: ManualChart;
  v1?: string;
  v2?: string;
  cat?: string;
  agg?: string;
  date?: string;
  cumulative?: boolean; // 막대그래프(개수) 누적비율선(파레토) 표시 여부
  donut?: boolean; // 파이차트를 도넛(가운데 구멍 + 중앙 컬럼명)으로 표시할지
  // 추가 시점 데이터 스냅샷(차트가 쓰는 컬럼만) — 있으면 이걸로 렌더해 전처리 변경에도 고정된다.
  //   localStorage 엔 저장하지 않고(용량) IndexedDB 로 별도 영속화한다(store partialize 에서 제거).
  snapshot?: Dataset;
}

export type StepId =
  | 'upload'
  | 'overview'
  | 'statistics'
  | 'preprocess'
  | 'visualize'
  | 'merge'
  | 'predict'
  | 'report';

/* ───────────────── 전처리 파이프라인 ───────────────── */

// 결측치 처리 방법
export type MissingMethod = 'drop' | 'mean' | 'median' | 'mode' | 'value';
// 타입 변환 대상
export type CastType = 'float' | 'int' | 'str' | 'datetime' | 'category';

// 순서가 있는 단일 전처리 변형. applySteps 가 원본 rows 에 차례로 적용한다.
export type PreprocessStep =
  | { type: 'missing'; columns: string[]; method: MissingMethod; value?: string }
  | { type: 'dropColumns'; columns: string[] }
  | { type: 'rename'; from: string; to: string }
  // astype: 타입 변환.
  //   to==='datetime' 일 때 dateFormat 으로 날짜 표기 형식 지정 가능(미지정=자동 감지).
  //     애매한 날짜(05/06/2018 등)는 자동 감지가 unknown → 파싱 실패하므로 사용자가 DMY/MDY 를 직접 지정해 해결.
  //   to==='int'|'float' 일 때 extractNumber=true 면 "1회"→1 처럼 문자 섞인 값에서 선행 숫자를 추출(opt-in).
  | { type: 'astype'; column: string; to: CastType; dateFormat?: DateFormat; extractNumber?: boolean }
  | { type: 'outlierIQR'; column: string; k: number }
  | { type: 'outlierClip'; column: string; lower: number | null; upper: number | null }
  | { type: 'encode'; column: string; method: 'onehot' | 'label' }
  | { type: 'scale'; columns: string[]; method: 'standard' | 'minmax' }
  // 구간화(Binning): 숫자 컬럼을 [min,max) 구간으로 나눠 라벨을 붙인 새 컬럼 생성.
  | {
      type: 'binning';
      column: string; // 대상(숫자) 컬럼
      newColumn: string; // 생성할 컬럼명(기존과 같으면 덮어씀)
      bins: { min: number; max: number; label: string }[]; // [min,max) 이상~미만
      otherLabel: string; // 구간 밖 값 라벨(기본 '기타')
    }
  // 수식 파생 컬럼(Formula): 사칙연산·괄호·컬럼명으로 계산한 값을 새 컬럼(숫자)으로 생성.
  | {
      type: 'formula';
      newColumn: string; // 생성할 컬럼명
      formula: string; // 예: 'monthly_income * 12', '(income - expense) / expense'
    }
  // 래그(Lag) 파생 컬럼: sortBy 기준으로 시간순 정렬 후 'periods 시점 전' 값을 새 컬럼으로 생성(시계열 피처).
  //   정렬은 이 step 안에서 원자적으로 수행한다 — 정렬 안 된 데이터에 래그를 만들면 조용히 미래 값이 섞이므로.
  | {
      type: 'lag';
      column: string; // 래그를 만들 대상(숫자) 컬럼
      periods: number; // 몇 시점 전 (1 이상 정수)
      sortBy: string; // 시간순 정렬 기준 컬럼(datetime 또는 숫자) — 필수(원자성 보장)
      newColumn: string; // 생성할 컬럼명
      groupBy?: string; // 선택: 그룹(패널) 컬럼 — 지정 시 그룹별로 나눠 각 그룹 안에서만 래그 계산(경계 누출 방지). 미지정=전체 하나(기존 동작).
      timeBased?: boolean; // 선택: 시간 기준(그리드 스냅) — true 면 간격을 자동 추론해 'N×간격 전 시각' 값을 당기고 빠진 슬롯은 결측. 미지정/false=기존 'N행 앞'.
    };

// 이력 표시용 — 적용한 스텝 + 사람이 읽는 로그 문자열
export interface AppliedStep {
  step: PreprocessStep;
  log: string;
}
