import type { Dataset } from '../types';

// 업로드 데이터 전체(rows 포함)는 localStorage가 아닌 IndexedDB에 보관한다.
// (localStorage 용량 한계 회피 + 사용자 제약 준수). 무의존성 최소 래퍼.

const DB_NAME = 'eda-dashboard';
const STORE = 'dataset';
const KEY = 'current';
const VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// 데이터셋 전체를 IndexedDB에 저장(덮어쓰기).
export async function saveDataset(dataset: Dataset): Promise<void> {
  const db = await openDB();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(dataset, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

// 저장된 데이터셋을 복원(없으면 null).
export async function loadDataset(): Promise<Dataset | null> {
  const db = await openDB();
  try {
    return await new Promise<Dataset | null>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const req = tx.objectStore(STORE).get(KEY);
      req.onsuccess = () => resolve((req.result as Dataset) ?? null);
      req.onerror = () => reject(req.error);
    });
  } finally {
    db.close();
  }
}

// 대시보드 차트별 "추가 시점 스냅샷" 맵({itemId: Dataset})을 같은 store 의 별도 키에 저장한다.
//   대시보드 아이템은 config 만 localStorage 에 저장되고, 고정용 rows 스냅샷은 용량 때문에 여기(IndexedDB)에 둔다.
const SNAP_KEY = 'dashboardSnapshots';

export async function saveDashboardSnapshots(map: Record<string, Dataset>): Promise<void> {
  const db = await openDB();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(map, SNAP_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

export async function loadDashboardSnapshots(): Promise<Record<string, Dataset>> {
  const db = await openDB();
  try {
    return await new Promise<Record<string, Dataset>>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const req = tx.objectStore(STORE).get(SNAP_KEY);
      req.onsuccess = () => resolve((req.result as Record<string, Dataset>) ?? {});
      req.onerror = () => reject(req.error);
    });
  } finally {
    db.close();
  }
}

// 저장된 데이터셋 삭제.
export async function clearDataset(): Promise<void> {
  const db = await openDB();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}
