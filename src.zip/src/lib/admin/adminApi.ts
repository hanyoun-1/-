// 관리(기업·그룹) API 클라이언트 — Bearer 주입 + 401 시 refresh 1회 재시도.
// authApi/http 패턴 재사용. 화면 라벨은 컴포넌트에서 처리(여기선 원 필드명 유지).

import { apiBase, getAccessToken, refreshAccessToken } from '../http';

export interface OrganizationOut {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
}

export interface GroupOut {
  id: string;
  organization_id: string;
  name: string;
  instructor_id: string | null;
  created_at: string;
}

export type UserRole = 'admin' | 'instructor' | 'member';

export interface UserOut {
  id: string;
  email: string;
  username: string | null;
  role: UserRole;
  organization_id: string | null;
  group_id: string | null;
  is_active: boolean;
  must_change_password: boolean;
  created_at: string;
  last_login_at: string | null;
}

// 발급 응답 = UserOut + temp_password(서버 생성 시 1회). 발급 입력.
export interface UserCreateOut extends UserOut {
  temp_password: string | null;
}

export interface UserCreateInput {
  email: string;
  role: UserRole;
  username?: string | null;
  organization_id?: string | null;
  group_id?: string | null;
}

// 인증 fetch — 토큰 주입 후 401 이면 refresh 후 1회 재시도.
async function authFetch(path: string, init?: RequestInit): Promise<Response> {
  const build = (): RequestInit => {
    const token = getAccessToken();
    return {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init?.headers ?? {}),
      },
    };
  };
  let res = await fetch(`${apiBase()}${path}`, build());
  if (res.status === 401) {
    const t = await refreshAccessToken();
    if (t) res = await fetch(`${apiBase()}${path}`, build());
  }
  return res;
}

async function detailOr(res: Response, fallback: string): Promise<string> {
  try {
    const j = (await res.json()) as { detail?: string };
    if (j?.detail) return j.detail;
  } catch {
    /* 본문 없음/파싱 실패 → fallback */
  }
  return fallback;
}

/* ───────────── 기업(organizations) ───────────── */

export async function listOrganizations(): Promise<OrganizationOut[]> {
  const res = await authFetch('/organizations');
  if (!res.ok) throw new Error(await detailOr(res, `기업 목록 조회 실패(HTTP ${res.status})`));
  return (await res.json()) as OrganizationOut[];
}

export async function createOrganization(name: string): Promise<OrganizationOut> {
  const res = await authFetch('/organizations', {
    method: 'POST',
    body: JSON.stringify({ name }),
  });
  if (!res.ok) throw new Error(await detailOr(res, `기업 생성 실패(HTTP ${res.status})`));
  return (await res.json()) as OrganizationOut;
}

/* ───────────── 그룹(groups) ───────────── */

export async function listGroups(organizationId?: string): Promise<GroupOut[]> {
  const q = organizationId ? `?organization_id=${encodeURIComponent(organizationId)}` : '';
  const res = await authFetch(`/groups${q}`);
  if (!res.ok) throw new Error(await detailOr(res, `그룹 목록 조회 실패(HTTP ${res.status})`));
  return (await res.json()) as GroupOut[];
}

export async function createGroup(
  organizationId: string,
  name: string,
  instructorId?: string,
): Promise<GroupOut> {
  const res = await authFetch('/groups', {
    method: 'POST',
    body: JSON.stringify({
      organization_id: organizationId,
      name,
      instructor_id: instructorId ?? null,
    }),
  });
  if (res.status === 409) {
    throw new Error('이미 같은 이름의 그룹이 있습니다.');
  }
  if (!res.ok) throw new Error(await detailOr(res, `그룹 생성 실패(HTTP ${res.status})`));
  return (await res.json()) as GroupOut;
}

/* ───────────── 멤버(users) ───────────── */

export async function listUsers(): Promise<UserOut[]> {
  const res = await authFetch('/users');
  if (!res.ok) throw new Error(await detailOr(res, `멤버 목록 조회 실패(HTTP ${res.status})`));
  return (await res.json()) as UserOut[];
}

// 계정 발급 — password 는 보내지 않아 서버가 임시 비번을 생성(temp_password 로 1회 반환).
export async function createUser(payload: UserCreateInput): Promise<UserCreateOut> {
  const res = await authFetch('/users', {
    method: 'POST',
    body: JSON.stringify({
      email: payload.email,
      role: payload.role,
      username: payload.username ?? null,
      organization_id: payload.organization_id ?? null,
      group_id: payload.group_id ?? null,
    }),
  });
  if (res.status === 409) throw new Error('이미 등록된 이메일입니다.');
  if (res.status === 403) throw new Error(await detailOr(res, '이 멤버를 발급할 권한이 없습니다.'));
  if (!res.ok) throw new Error(await detailOr(res, `멤버 발급 실패(HTTP ${res.status})`));
  return (await res.json()) as UserCreateOut;
}

// 관리 액션 공통 에러 변환(400 자기계정 / 403 권한 / 404 대상 없음).
async function throwMemberActionError(res: Response, fallback: string): Promise<never> {
  if (res.status === 400) throw new Error(await detailOr(res, '자기 계정은 비활성화할 수 없습니다.'));
  if (res.status === 403) throw new Error('권한이 없습니다.');
  if (res.status === 404) throw new Error('대상을 찾을 수 없습니다.');
  throw new Error(await detailOr(res, fallback));
}

export async function deactivateUser(id: string): Promise<UserOut> {
  const res = await authFetch(`/users/${encodeURIComponent(id)}/deactivate`, { method: 'PATCH' });
  if (!res.ok) await throwMemberActionError(res, `비활성화 실패(HTTP ${res.status})`);
  return (await res.json()) as UserOut;
}

export async function activateUser(id: string): Promise<UserOut> {
  const res = await authFetch(`/users/${encodeURIComponent(id)}/activate`, { method: 'PATCH' });
  if (!res.ok) await throwMemberActionError(res, `활성화 실패(HTTP ${res.status})`);
  return (await res.json()) as UserOut;
}

// 비번 재발급 → 새 임시 비번(1회) 반환.
export async function resetUserPassword(id: string): Promise<string> {
  const res = await authFetch(`/users/${encodeURIComponent(id)}/reset-password`, { method: 'POST' });
  if (!res.ok) await throwMemberActionError(res, `비번 재발급 실패(HTTP ${res.status})`);
  const j = (await res.json()) as { temp_password: string };
  return j.temp_password;
}

/* ───────────── 감사 로그(audit-logs) ───────────── */

export type AuditAction = 'create_user' | 'change_role' | 'deactivate' | 'activate' | 'reset_password';

export interface AuditLogOut {
  id: string;
  created_at: string;
  actor_user_id: string | null;
  actor_email: string | null;
  actor_role: string | null;
  action: AuditAction;
  target_user_id: string | null;
  target_email: string | null;
  organization_id: string | null;
  detail: string | null;
}

// 조회 전용. admin=전체 / instructor=자기 기업 / member=403(백엔드 강제).
export async function listAuditLogs(opts?: { limit?: number; offset?: number }): Promise<AuditLogOut[]> {
  const limit = opts?.limit ?? 50;
  const offset = opts?.offset ?? 0;
  const res = await authFetch(`/audit-logs?limit=${limit}&offset=${offset}`);
  if (res.status === 403) throw new Error('권한이 없습니다.');
  if (!res.ok) throw new Error(await detailOr(res, `감사 로그 조회 실패(HTTP ${res.status})`));
  return (await res.json()) as AuditLogOut[];
}

// 멤버 정보 부분 수정 — payload 에 담긴 필드만 전송(PATCH 규약). group_id: null = 그룹 해제.
export interface UserUpdateInput {
  username?: string | null;
  group_id?: string | null;
  role?: UserRole;
}

export async function updateUser(id: string, payload: UserUpdateInput): Promise<UserOut> {
  const res = await authFetch(`/users/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify(payload),
  });
  if (res.status === 400) throw new Error(await detailOr(res, '잘못된 요청입니다.'));
  if (res.status === 403) throw new Error('권한이 없습니다.');
  if (res.status === 404) throw new Error('대상을 찾을 수 없습니다.');
  if (!res.ok) throw new Error(await detailOr(res, `수정 실패(HTTP ${res.status})`));
  return (await res.json()) as UserOut;
}
