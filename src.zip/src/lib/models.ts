// 예측 모델 타입 — 학습·예측은 전부 백엔드(FastAPI + scikit-learn 계열)가 수행한다.
//
// 과거에는 이 파일에 순수 TypeScript 로 구현한 학습기(선형·로지스틱·랜덤포레스트·부스팅)가 있었고
// COMPUTE_MODE(browser/hybrid/server)에 따라 브라우저에서 직접 학습하기도 했다. 지금은 프론트+백엔드
// 세트 배포가 전제라 계산 위치를 나눌 이유가 없어졌고, 다음 문제까지 있어 로컬 학습 경로를 걷어냈다:
//   · 브라우저 구현이 없는 모델(KNN·SVM·부스팅·MLP 등 16종)은 애초에 로컬에서 쓸 수 없었다.
//   · 로컬 경로는 하이퍼파라미터(params)를 무시해 튜닝값이 조용히 반영되지 않았다.
//   · 같은 모델을 두 언어로 유지해야 해(브라우저 JS ↔ 서버 Python) 파리티 부담이 컸다.
// → 이 파일은 이제 화면·스토어·리포트가 공유하는 "결과 타입"만 정의한다.
//   학습 호출은 lib/compute/regression.ts · classification.ts (항상 서버).

import type { Dataset } from '../types';

// 트리 앙상블·부스팅은 선형 계수가 없으므로 coef 자리에 변수 중요도(0~1, 양수)를 담는다.
export type RegAlgo = 'linear' | 'rf' | 'knn' | 'svr' | 'ridge' | 'lasso' | 'elasticnet' | 'xgboost' | 'lightgbm' | 'catboost' | 'mlp' | 'lstm' | 'transformer';

export interface RegResult {
  algo: RegAlgo;
  features: string[];
  coef: number[];
  intercept: number;
  r2: number;
  mae: number;
  rmse: number;
  actualVsPred: { actual: number; pred: number }[];
  sequentialSplit?: boolean; // 시간순 분할로 학습됐는지(에코). true면 결과 화면에서 시간축 선그래프 표시.
  n: number;
  sampled?: { used: number; total: number }; // 트리 모델에서 학습 행 상한 초과로 표본 학습한 경우
  vizTree?: VizTreeNode; // 트리 모델 설명용 깊이-2 결정 트리
  usedParams?: Record<string, string | number | null>; // 수동 튜닝 사용값(리포트 표시용). 튜닝 없는 모델은 없음.
  scaled?: boolean; // 표준화 적용 여부(리포트 표시용). 미해당 모델은 없음.
}

export type ClsAlgo = 'logistic' | 'rf' | 'knn' | 'svc' | 'dtree' | 'xgboost' | 'lightgbm' | 'catboost' | 'mlp';

export interface ClsReportRow {
  cls: string;
  precision: number;
  recall: number;
  f1: number;
  support: number;
  auc?: number; // AUC-ROC (One-vs-Rest)
}

export interface ClsResult {
  features: string[];
  classes: string[];
  accuracy: number;
  confusion: number[][]; // [실제][예측]
  report: ClsReportRow[];
  n: number;
  algo?: ClsAlgo; // 분류 알고리즘(미지정=로지스틱)
  sampled?: { used: number; total: number }; // 트리 모델에서 학습 행 상한 초과로 표본 학습한 경우
  vizTree?: VizTreeNode; // 트리 모델 설명용 깊이-2 결정 트리
  coef?: { name: string; value: number }[]; // 이진일 때 표준화 계수(영향도)
  usedParams?: Record<string, string | number | null>; // 수동 튜닝 사용값(리포트 표시용). 튜닝 없는 모델은 없음.
  scaled?: boolean; // 표준화 적용 여부(리포트 표시용). 미해당 모델은 없음.
}

// 설명용 결정 트리(서버가 만들어 내려준다 — backend/app/viztree.py).
export type VizTreeNode =
  | { leaf: true; label: string }
  | { leaf: false; q: string; left: VizTreeNode; right: VizTreeNode };

// 리포트가 쓰는 "예측 데이터 + 학습 결과" 컨텍스트(인메모리, 미영속). 여러 개를 리포트에 담을 수 있다.
export interface PredictionContext {
  id: string;
  label: string; // 예: "구매 여부 · 로지스틱 회귀"
  dataset: Dataset; // 예측에 실제로 쓴 데이터(전처리본 또는 병합본)
  task: 'reg' | 'cls';
  target: string;
  features: string[];
  algo?: RegAlgo;
  reg?: RegResult;
  cls?: ClsResult;
}
