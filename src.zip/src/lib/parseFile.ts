import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import type { Row } from '../types';

export interface ParseResult {
  rows: Row[];
  warnings: string[];
}

/* ───────────────── 컬럼명/값 정리 ───────────────── */

// 제어문자(0x00-0x1F, 0x7F)·zero-width(0x200B-0x200D, 0x2060)·BOM(0xFEFF) 제거.
// 코드포인트로 직접 판별해 인코딩/정규식 모호함을 피한다.
function stripUnwanted(s: string): string {
  let out = '';
  for (const ch of s) {
    const c = ch.codePointAt(0) as number;
    if (c <= 0x1f || c === 0x7f) continue; // 제어문자(개행/탭 포함)
    if (c >= 0x200b && c <= 0x200d) continue; // zero-width space/non-joiner/joiner
    if (c === 0x2060 || c === 0xfeff) continue; // word-joiner / BOM
    out += ch;
  }
  return out;
}

// 예: " 고객명 " → "고객명"
function cleanName(s: string): string {
  return stripUnwanted(String(s ?? ''))
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanValue(s: string): string {
  return stripUnwanted(s).trim();
}

// 천 단위 콤마로 묶인 숫자(통화기호 허용)만 숫자로 변환한다.
//  "1,234" · "1,234.56" · "₩1,200" · "$1,000" · "-12,000" → number
//  3자리 그룹 형태일 때만 처리(지역명·문자 데이터 오변환 방지). 그 외는 원본 유지.
const GROUPED_NUMBER_RE = /^[₩$€£¥]?\s*-?\d{1,3}(,\d{3})+(\.\d+)?\s*[%]?$/;
function tryParseGroupedNumber(s: string): number | null {
  if (!GROUPED_NUMBER_RE.test(s)) return null;
  const cleaned = s.replace(/[₩$€£¥%\s]/g, '').replace(/,/g, '');
  const n = Number(cleaned);
  return Number.isNaN(n) ? null : n;
}

function coerce(v: unknown): string | number | boolean | null {
  if (v === null || v === undefined || v === '') return null;
  if (v instanceof Date) return v.toISOString().slice(0, 10); // 날짜 → YYYY-MM-DD 보존
  if (typeof v === 'boolean' || typeof v === 'number') return v;
  const s = cleanValue(String(v));
  if (s === '') return null;
  if (s === 'true' || s === 'false') return s === 'true';
  // 천 단위 콤마/통화기호 숫자 자동 정리
  const grouped = tryParseGroupedNumber(s);
  if (grouped !== null) return grouped;
  return s;
}

// 원본 키(fields)를 정리된 컬럼명으로 매핑하며 값 정규화
function normalizeRows(raw: Record<string, unknown>[], fields: string[]): Row[] {
  const cleaned = fields.map(cleanName);
  return raw.map((r) => {
    const out: Row = {};
    fields.forEach((f, i) => {
      const key = cleaned[i] || f; // 정리 후 빈 이름이면 원본 유지
      out[key] = coerce(r[f]);
    });
    return out;
  });
}

/* ───────────────── CSV 인코딩 감지 디코딩 ───────────────── */

// UTF-8(BOM 포함) 우선 → 실패 시 CP949/EUC-KR 폴백
function decodeCsv(bytes: Uint8Array): string {
  // UTF-8 BOM
  if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
    return new TextDecoder('utf-8').decode(bytes.subarray(3));
  }
  // 엄격 UTF-8 시도(유효하지 않으면 throw)
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch {
    // CP949 / EUC-KR (브라우저 'euc-kr' 디코더 = CP949 상위호환)
    try {
      return new TextDecoder('euc-kr').decode(bytes);
    } catch {
      return new TextDecoder('utf-8').decode(bytes); // 마지막 수단(관대)
    }
  }
}

/* ───────────────── 업로드 직후 검증 ───────────────── */

// 한글 깨짐 추정: 치환문자(U+FFFD) 또는 Latin-1 보충영역(0xA0-0xFF) 문자 다수
function isLikelyMojibake(s: string): boolean {
  let suspicious = 0;
  for (const ch of s) {
    const c = ch.codePointAt(0) as number;
    if (c === 0xfffd) return true; // 치환문자(�)
    if (c >= 0x00a0 && c <= 0x00ff) suspicious++;
  }
  return suspicious >= 2;
}

function validate(headerList: string[], rows: Row[]): string[] {
  const warnings: string[] = [];
  const clean = headerList.map(cleanName);

  // 빈 컬럼명
  if (clean.some((h) => h === '')) warnings.push('이름이 비어 있는 컬럼이 있어요.');

  // 중복 컬럼명
  const seen = new Set<string>();
  const dup = new Set<string>();
  clean.forEach((h) => {
    if (!h) return;
    if (seen.has(h)) dup.add(h);
    else seen.add(h);
  });
  if (dup.size) warnings.push(`중복된 컬럼명이 있어요: ${[...dup].join(', ')}`);

  // 한글 깨짐
  if (headerList.some((h) => isLikelyMojibake(h))) {
    warnings.push('일부 컬럼명이 깨진 것으로 보입니다. (파일 인코딩을 확인해 주세요)');
  }

  // 값이 전부 비어 있는 컬럼
  const keys = rows.length ? Object.keys(rows[0]) : [];
  const emptyCols = keys.filter((k) => rows.every((r) => r[k] === null));
  if (emptyCols.length) warnings.push(`값이 모두 비어 있는 컬럼이 있어요: ${emptyCols.join(', ')}`);

  return warnings;
}

/* ───────────────── 진입점 ───────────────── */

export async function parseFile(file: File): Promise<ParseResult> {
  const ext = file.name.split('.').pop()?.toLowerCase();

  if (ext === 'csv') {
    const text = decodeCsv(new Uint8Array(await file.arrayBuffer()));
    // 원본 헤더(중복 감지용) — PapaParse가 header:true에서 중복을 자동 개명하므로 별도 추출
    const head = Papa.parse<string[]>(text, { preview: 1, skipEmptyLines: true });
    const rawHeaders = (head.data[0] ?? []).map((h) => String(h ?? ''));

    const res = Papa.parse<Record<string, unknown>>(text, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      transformHeader: cleanName,
    });
    const fields = (res.meta.fields ?? []).map((f) => f ?? '');
    const rows = normalizeRows(res.data, fields);
    return { rows, warnings: validate(rawHeaders.length ? rawHeaders : fields, rows) };
  }

  if (ext === 'xlsx' || ext === 'xls') {
    const wb = XLSX.read(new Uint8Array(await file.arrayBuffer()), {
      type: 'array',
      cellDates: true, // 날짜를 Date로 읽어 손실 방지
    });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    // 원본 헤더 행(중복/깨짐 검증용)
    const headerRow = (XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, blankrows: false })[0] ??
      []) as unknown[];
    const headerList = headerRow.map((h) => String(h ?? ''));
    const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
      defval: null,
      raw: true,
    });
    const rawFields = json.length ? Object.keys(json[0]) : headerList;
    const rows = normalizeRows(json, rawFields);
    return { rows, warnings: validate(headerList.length ? headerList : rawFields, rows) };
  }

  throw new Error('지원하지 않는 형식입니다. CSV 또는 Excel 파일을 올려주세요.');
}
