// 하이퍼파라미터 명세 로더 — 백엔드가 단일 원천(GET /models/hyperparams).
// 명세는 프론트에 하드코딩하지 않고 앱에서 1회 받아 캐시한다(입력 UI·1차 검증에 사용).
// 인증은 기존 방식 재사용(getAccessToken). browser 모드에선 백엔드가 없을 수 있으므로
// 호출자(PredictPage)가 실패를 조용히 처리(KNN 옵션 비활성 + 안내)한다.

import { getConfig } from '../config/runtimeConfig';
import { apiBase, getAccessToken } from '../http';

export interface HyperparamChoice {
  value: string | number | null; // null = 예: max_depth "제한 없음", class_weight "없음"
  label: string;
}

export interface HyperparamDef {
  name: string; // sklearn 인자명
  label: string; // 화면 표시명(한글)
  type: 'int' | 'float' | 'enum' | 'enum_or_float' | 'enum_or_int';
  min?: number;
  max?: number;
  step?: number;
  choices?: HyperparamChoice[];
  default: string | number | null;
  // enum-or-slider: enum-or-number 와 값 형식(문자열/숫자/null)은 같고, "직접 입력" 시 숫자칸 대신 슬라이더를 쓴다(rf).
  widget: 'slider' | 'log-slider' | 'number' | 'dropdown' | 'radio' | 'enum-or-number' | 'enum-or-slider';
  help?: string;
}

export interface ModelSpec {
  task: string; // 'reg' | 'cls'
  algo: string; // 'knn' 등
  estimator: string;
  server_only: boolean;
  supports_scaling?: boolean; // 거리 기반 모델(KNN 등) → 표준화 체크박스 노출(W2)
  scaling_help?: string; // 표준화 체크박스의 모델별 안내 문구(없으면 프론트 기본 문구 폴백)
  params: HyperparamDef[];
}

export type ParamValues = Record<string, string | number | null>;

// 모듈 레벨 캐시 — 성공 결과는 재사용, 진행 중 요청은 공유(중복 GET 방지).
let cache: ModelSpec[] | null = null;
let inflight: Promise<ModelSpec[]> | null = null;

export async function loadHyperparamSpecs(): Promise<ModelSpec[]> {
  if (cache) return cache;
  if (inflight) return inflight;

  inflight = (async () => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), getConfig().API_TIMEOUT_MS);
    try {
      const headers: Record<string, string> = {};
      const tok = getAccessToken();
      if (tok) headers.Authorization = `Bearer ${tok}`;
      // no-store: 명세는 백엔드 버전에 따라 바뀌므로(예: 모델 추가) 브라우저 HTTP 캐시의 옛 응답을
      //   재사용하면 새 모델이 안 보인다. config.json 로더와 동일하게 항상 최신을 받는다.
      const res = await fetch(`${apiBase()}/models/hyperparams`, { headers, signal: ctrl.signal, cache: 'no-store' });
      if (!res.ok) throw new Error(`명세 조회 실패: HTTP ${res.status}`);
      const json = (await res.json()) as { specs?: ModelSpec[] };
      cache = json.specs ?? [];
      return cache;
    } finally {
      clearTimeout(timer);
      inflight = null;
    }
  })();
  return inflight;
}

export function getSpec(specs: ModelSpec[] | null, task: string, algo: string): ModelSpec | undefined {
  return specs?.find((s) => s.task === task && s.algo === algo);
}

// 명세의 default 로 초기 파라미터 값 생성.
export function defaultParams(spec: ModelSpec | undefined): ParamValues {
  const out: ParamValues = {};
  if (!spec) return out;
  for (const p of spec.params) out[p.name] = p.default;
  return out;
}

// usedParams(백엔드 에코)를 명세 라벨 기준 한글 요약으로 — 예: "이웃 수 5 · 동일 비중 · 직선(유클리드) 거리".
export function formatUsedParams(spec: ModelSpec | undefined, used: ParamValues | undefined): string {
  if (!spec || !used) return '';
  return spec.params
    .map((p) => {
      const v = used[p.name];
      if (v === undefined) return null;
      // 값이 선택지에 해당하면 그 라벨을 쓴다(enum·enum_or_float·enum_or_int 공통; 예: null→"제한 없음").
      const choice = p.choices?.find((c) => c.value === v);
      if (p.type === 'enum') return choice?.label ?? String(v);
      return `${p.label} ${choice ? choice.label : v}`;
    })
    .filter((s): s is string => s !== null)
    .join(' · ');
}
