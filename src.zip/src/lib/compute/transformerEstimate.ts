// Transformer(표 데이터) 학습 시간 추정 — 학습 시작 전 예상 시간을 계산해 상시 표시·초과 차단에 쓴다.
//
// ⚠ 아래 계수는 백엔드(backend/app/hyperparams.py 의 _TF_EST_* / TRANSFORMER_TIME_LIMIT_SEC)와 반드시 같은 값이어야
//    한다. 한쪽만 바꾸면 프론트(UX 차단)와 백엔드(자원 방어선)가 어긋난다(프론트 통과→백엔드 400 불일치).
// ⚠ 표(tabular) 방식이라 window 없음 — 각 행이 독립 샘플. 실규모(35,040행×6피처 + 피처수 스윕, epochs 10 고정, 1스레드, mac arm64) 회귀.
//   estimated = COEF × train_rows × num_layers × n_tokens × d_model × MARGIN
//     train_rows = floor(rows × (1 − testRatio))   (학습 행수)
//     n_tokens   = n_features + 1                  (피처 토큰 + CLS 토큰 = 시퀀스 길이)
//   실측상 fit 은 각 인자(행수·층수·토큰수·d_model)에 대략 선형(계수 C 3.4~4.5e-7).
//   MARGIN 1.3 = 하드웨어 편차 + 피처수 클 때(어텐션 O(seq²)) 약한 초선형 여유 → 실측 전 구간 추정 ≥ 실측(과소추정 0).
const COEF = 3.9e-7;
const MARGIN = 1.3;
export const TRANSFORMER_TIME_LIMIT_SEC = 120; // LSTM 과 동일 근거·시작값(API_TIMEOUT_MS)

export interface TransformerEstimate {
  seconds: number; // 예상 학습 시간(초). tooShort 면 0.
  overLimit: boolean; // 한도(120초) 초과 예상 → 차단 대상
  tooShort: boolean; // train_rows<=0(학습 행 없음) — 추정 무의미
}

// Transformer(표 데이터) 예상 학습 시간. nFeatures = 학습에 쓰는 피처 수(시퀀스 길이 = 피처+1).
//   params 는 명세 기본값이 채워진 값(d_model·num_layers)을 기대하되, 누락 시 명세 기본값(64·2)으로 폴백한다.
export function estimateTransformerSeconds(
  rows: number,
  testRatio: number,
  params: Record<string, string | number | null> | undefined,
  nFeatures: number,
): TransformerEstimate {
  const dModel = Number(params?.d_model ?? 64);
  const layers = Number(params?.num_layers ?? 2);
  const trainRows = Math.floor(rows * (1 - testRatio));
  if (trainRows <= 0) return { seconds: 0, overLimit: false, tooShort: true };
  const nTokens = nFeatures + 1; // 피처 토큰 + CLS 토큰
  const seconds = COEF * trainRows * layers * nTokens * dModel * MARGIN;
  return { seconds, overLimit: seconds > TRANSFORMER_TIME_LIMIT_SEC, tooShort: false };
}
