// 컴퓨트 어댑터 계층 진입점 — 학습·예측 호출을 한 곳으로 모은다.
//   계산은 전부 백엔드가 수행한다(프론트+백엔드 세트 배포 전제).
//   과거의 browser/hybrid 로컬 분기와 컴퓨트 라우터(router.ts)는 제거했다.
export {
  runRegression,
  resumeRegression,
  type RunRegressionParams,
  type NormalizedRegression,
} from './regression';
export { runClassification, resumeClassification, type RunClassificationParams, type NormalizedClassification } from './classification';
export { MissingModelError, CancelledError, type TrainRequest, type TrainResponse, type PredictRequest, type PredictResponse } from './api';
export {
  loadHyperparamSpecs,
  getSpec,
  defaultParams,
  formatUsedParams,
  type ModelSpec,
  type HyperparamDef,
  type HyperparamChoice,
  type ParamValues,
} from './hyperparams';
export { estimateLstmSeconds, LSTM_TIME_LIMIT_SEC, type LstmEstimate } from './lstmEstimate';
export { estimateTransformerSeconds, TRANSFORMER_TIME_LIMIT_SEC, type TransformerEstimate } from './transformerEstimate';
export { tuneTimeoutSec, fmtDuration } from './tuneTimeout';
