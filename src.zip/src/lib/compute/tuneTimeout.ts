// 자동최적화(Optuna) 튜닝 벽시계 상한(초) — 예상 소요 시간 표시용(계산 아님, 표시 전용).
//
// ⚠ 백엔드 tuning.py 의 timeout_for()와 반드시 같은 값이어야 한다. 한쪽만 바꾸면 프론트 표시와 실제 튜닝 시간이 어긋난다.
//   rf·xgb = 60(빠름) / gb·lightgbm·catboost·mlp·svr·svc = 180(느림) / lstm·transformer = 300(딥러닝, _TIMEOUT_BY_ALGO).
const TUNE_TIMEOUT_FAST_SEC = 60;
const TUNE_TIMEOUT_SLOW_SEC = 180;
const TUNE_TIMEOUT_BY_ALGO: Record<string, number> = { lstm: 300, transformer: 300 };
const TUNE_SLOW_ALGOS = new Set(['lightgbm', 'catboost', 'mlp', 'svr', 'svc']);

// 모델별 튜닝 timeout(초). 백엔드 timeout_for 와 동일 규칙(개별 지정 > 느린 모델 180 > 나머지 60).
export function tuneTimeoutSec(algo: string): number {
  if (algo in TUNE_TIMEOUT_BY_ALGO) return TUNE_TIMEOUT_BY_ALGO[algo];
  return TUNE_SLOW_ALGOS.has(algo) ? TUNE_TIMEOUT_SLOW_SEC : TUNE_TIMEOUT_FAST_SEC;
}

// 초 → 사람이 읽는 대략 표기(예상 시간 표시용). 60초 미만은 '초', 그 외는 '분'(반올림).
export function fmtDuration(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  if (s < 60) return `${s}초`;
  return `${Math.round(s / 60)}분`;
}
