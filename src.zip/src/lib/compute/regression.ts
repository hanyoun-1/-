// 회귀 학습 어댑터 — PredictPage 는 이 함수 하나로 학습을 요청한다.
//
// 학습은 항상 백엔드에서 수행한다(프론트+백엔드 세트 배포 전제).
//   · 분할(seed=42)·지표·vizTree·행 상한 표본추출은 전부 서버가 담당한다(backend/app/models_reg.py).
//   · 서버 모델은 클로저가 없으므로 predict 는 predictWithModel(model_id) 로 원격 호출한다.
// 과거의 브라우저 로컬 학습 경로(COMPUTE_MODE=browser/hybrid)는 제거했다 — 튜닝 params 가 무시되고,
// 브라우저 구현이 없는 모델(KNN·SVM·부스팅·MLP 등)은 쓸 수도 없었기 때문이다.

import type { RegAlgo, VizTreeNode } from '../models';
import { MissingModelError, predictModel, pollTrainingJob, resumeTrainingJob, trainModel, type TrainRequest, type TrainResponse } from './api';

export interface RunRegressionParams {
  X: number[][];
  y: number[];
  algo: RegAlgo;
  target: string;
  features: string[];
  testRatio: number;
  params?: Record<string, string | number | null>; // 수동 하이퍼파라미터(명세 있는 모델).
  scale?: boolean; // 표준화 여부(supports_scaling 모델).
  sequentialSplit?: boolean; // 시간순 분할(시계열). 기본 false=랜덤.
  tune?: boolean; // 자동 튜닝(Optuna). rf·xgb 만 유효, 그 외는 서버가 무시.
  onProgress?: (done: number, total: number, best: number | null) => void; // 비동기 튜닝 진행률(폴링마다)
  signal?: AbortSignal; // 사용자 취소 신호(폴링·요청 중단)
  onJobId?: (jobId: string) => void; // 비동기 job 시작 시 jobId 통지(전역 보존 → 페이지 복귀 복원용)
}

// 서버 학습 결과의 정규화 형태. coef 는 선형=계수, 트리=중요도(기존 RegResult.coef 의미와 동일).
export interface NormalizedRegression {
  modelId: string;
  coef?: number[];
  intercept: number;
  metrics: { r2: number; mae: number; rmse: number };
  actualVsPred: { actual: number; pred: number }[];
  vizTree?: VizTreeNode;
  sampled?: { used: number; total: number };
  usedParams?: Record<string, string | number | null>; // 기본값까지 채운 최종 사용값
  bestParams?: Record<string, string | number | null>; // 자동 튜닝 best_params(있으면 튜닝됨).
  scaled?: boolean; // 실제 적용된 표준화 여부. 미해당은 undefined.
  sequentialSplit?: boolean; // 실제 사용한 분할 방식(true=시간순).
  predict: (x: number[]) => Promise<number>; // 새 값 예측(원격 호출)
}

export async function runRegression(p: RunRegressionParams): Promise<NormalizedRegression> {
  const req: TrainRequest = {
    task: 'reg',
    algo: p.algo,
    target: p.target,
    features: p.features,
    testRatio: p.testRatio,
    X: p.X,
    y: p.y,
    params: p.params, // 없으면 서버가 기본값 사용.
    scale: p.scale, // 없으면 서버가 기본값(지원 모델=켜짐) 적용.
    sequentialSplit: p.sequentialSplit, // 시간순 분할 여부(시계열).
    tune: p.tune, // 자동 튜닝(rf·xgb).
  };
  // tune=true → 비동기(백그라운드+폴링). 그 외 → 기존 동기 학습. 어느 쪽이든 res 는 동일한 TrainResponse 형태. signal 로 취소 가능.
  const res: TrainResponse = p.tune ? await pollTrainingJob<TrainResponse>(req, p.onProgress, p.signal, p.onJobId) : await trainModel(req, p.signal);
  return normalizeRegression(res);
}

// 서버 학습 결과(TrainResponse) → NormalizedRegression 매핑. 학습 경로(runRegression)와 복원 경로(resumeRegression)가 공유한다.
//   ⚠ 순수 매핑 — 계산·학습 로직 없음(기존 runRegression 동작을 그대로 옮긴 것).
function normalizeRegression(res: TrainResponse): NormalizedRegression {
  const modelId = res.model_id;
  return {
    modelId,
    coef: res.coef ?? res.importance, // 선형=coef, 트리=importance
    intercept: res.intercept ?? 0,
    metrics: {
      r2: res.metrics.r2 ?? 0,
      mae: res.metrics.mae ?? 0,
      rmse: res.metrics.rmse ?? 0,
    },
    actualVsPred: res.actualVsPred,
    vizTree: res.vizTree as VizTreeNode | undefined,
    sampled: res.sampled,
    usedParams: res.usedParams,
    bestParams: res.bestParams, // 자동 튜닝 시 찾은 값(없으면 undefined)
    scaled: res.scaled ?? undefined, // null(미해당) → undefined
    sequentialSplit: res.sequentialSplit, // 서버가 실제 사용한 분할 방식 에코
    predict: async (x: number[]) => {
      const preds = await predictWithModel(modelId, [x]);
      return preds[0];
    },
  };
}

// 이미 시작된 비동기 튜닝 job(jobId)을 이어서 폴링해 결과를 복원한다(페이지 복귀 시). 새 학습을 시작하지 않는다.
export async function resumeRegression(
  jobId: string,
  onProgress?: (done: number, total: number, best: number | null) => void,
  signal?: AbortSignal,
): Promise<NormalizedRegression> {
  const res = await resumeTrainingJob<TrainResponse>(jobId, onProgress, signal);
  return normalizeRegression(res);
}

// 서버 보관 모델로 예측. model_id 없음/만료(404) → MissingModelError 로 재학습을 유도.
export async function predictWithModel(modelId: string | undefined, X: number[][]): Promise<number[]> {
  if (!modelId) throw new MissingModelError();
  const res = await predictModel({ model_id: modelId, X });
  return res.predictions;
}
