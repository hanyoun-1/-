// LSTM 학습 시간 추정 — 학습 시작 전 예상 시간을 계산해 상시 표시·초과 차단에 쓴다.
//
// ⚠ 아래 계수는 백엔드(backend/app/hyperparams.py 의 _LSTM_EST_* / LSTM_TIME_LIMIT_SEC)와 반드시 같은 값이어야
//    한다. 한쪽만 바꾸면 프론트(UX 차단)와 백엔드(자원 방어선)가 어긋난다.
// 실측 근거: mac arm64 M-series, 1스레드, epochs=10 고정, Steel 규모 등 12점 회귀.
//   ⚠ hidden 은 제곱이 아니라 오프셋 선형(HIDDEN_OFFSET + HIDDEN_SLOPE × hidden) — 실측 확정. 제곱으로 바꾸지 말 것.
//   estimated = COEF × seq × window × (HIDDEN_OFFSET + HIDDEN_SLOPE × hidden_units) × num_layers × MARGIN
//     seq = floor(rows × (1 − testRatio)) − window  (학습 시퀀스 수)
//   MARGIN 1.5 = 과소추정 방지(명세 범위 내 최대 과소 -13% → 1.3) + 하드웨어 편차(Linux 미확인) 흡수.
const COEF = 7.1e-7;
const HIDDEN_OFFSET = 7.3;
const HIDDEN_SLOPE = 0.26;
const MARGIN = 1.5;
export const LSTM_TIME_LIMIT_SEC = 120; // API_TIMEOUT_MS(120000) 와 동일 근거

export interface LstmEstimate {
  seconds: number; // 예상 학습 시간(초). tooShort 면 0.
  overLimit: boolean; // 한도(120초) 초과 예상 → 차단 대상
  tooShort: boolean; // seq<=0(window ≥ 학습 행수) — 학습 불가(평균 폴백), 시간 추정 무의미
}

// LSTM 예상 학습 시간. params 는 명세 기본값이 채워진 값(window·hidden_units·num_layers)을 기대하되,
//   누락 시 명세 기본값(10·32·1)으로 폴백한다.
export function estimateLstmSeconds(
  rows: number,
  testRatio: number,
  params: Record<string, string | number | null> | undefined,
): LstmEstimate {
  const window = Number(params?.window ?? 10);
  const hidden = Number(params?.hidden_units ?? 32);
  const layers = Number(params?.num_layers ?? 1);
  const seq = Math.floor(rows * (1 - testRatio)) - window;
  if (seq <= 0) return { seconds: 0, overLimit: false, tooShort: true };
  const seconds = COEF * seq * window * (HIDDEN_OFFSET + HIDDEN_SLOPE * hidden) * layers * MARGIN;
  return { seconds, overLimit: seconds > LSTM_TIME_LIMIT_SEC, tooShort: false };
}
