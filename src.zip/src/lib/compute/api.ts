// FastAPI 백엔드 호출 클라이언트.
// 서버 모드가 아닌 한(=기본 browser) 이 함수들은 호출되지 않는다.
// 설정(베이스 URL·타임아웃)은 런타임 config(getConfig)에서 읽는다.

import { getConfig } from '../config/runtimeConfig';
import { getAccessToken, refreshAccessToken } from '../http';

// 서버 모델이 없거나 만료된 상태로 예측을 시도할 때 던지는 에러(재학습 유도용).
export class MissingModelError extends Error {
  constructor(message = '학습된 서버 모델이 없습니다. 모델을 다시 학습해 주세요.') {
    super(message);
    this.name = 'MissingModelError';
  }
}

// 사용자가 학습을 취소했을 때 던지는 에러 — 호출부가 '취소됨'으로 조용히 처리(서버 오류 배너 아님).
//   ⚠ 프론트 폴링/요청만 중단한다. 백엔드 job(스레드)은 계속 돌 수 있다(취소 엔드포인트 부재).
export class CancelledError extends Error {
  constructor(message = '학습을 취소했습니다.') {
    super(message);
    this.name = 'CancelledError';
  }
}

/* ───────────── 요청/응답 타입 (설계 문서 기준) ───────────── */

export interface TrainRequest {
  task: 'reg' | 'cls';
  algo: string;
  target: string;
  features: string[];
  testRatio: number;
  X: number[][];
  y: (number | string)[];
  // 재현성: 서버는 브라우저와 동일한 seed(분할 seed=42, 트리 seed=7)를 사용해야
  // browser/server 결과가 어긋나지 않는다. (models.ts의 trainTestSplit·fitRandomForest 참고)
  seed?: number;
  // 수동 하이퍼파라미터(T3). 명세 있는 모델(knn 등)만 유효. 없으면 서버가 기본값으로 학습(하위호환).
  params?: Record<string, string | number | null>;
  // 표준화(스케일링) 옵션(W2). supports_scaling 모델에서 유효(생략 시 서버 기본 켜짐). 미지원 모델은 무시.
  scale?: boolean;
  // 시간순(순차) 분할. false(기본)=랜덤 셔플 분할, true=앞 학습·뒤 평가(시계열용, 누수 방지).
  sequentialSplit?: boolean;
  // 자동 하이퍼파라미터 튜닝(Optuna). false(기본)=기존 경로. true=rf·xgb 만 5-fold CV 로 best_params 탐색 후 학습.
  //   그 외 algo 는 서버가 무시(기존 default 학습). 결과는 응답 bestParams 로 에코된다.
  tune?: boolean;
}

export interface TrainResponse {
  model_id: string;
  metrics: Record<string, number>; // 회귀: r2/mae/rmse · 분류: accuracy 등
  coef?: number[]; // 선형/로지스틱 계수
  importance?: number[]; // 트리 변수 중요도
  intercept?: number;
  actualVsPred: { actual: number; pred: number }[];
  vizTree?: unknown; // VizTreeNode 직렬화(프론트에서 타입 단언)
  sampled?: { used: number; total: number };
  usedParams?: Record<string, string | number | null>; // 수동 튜닝 시 기본값 채운 최종 사용값(에코)
  bestParams?: Record<string, string | number | null>; // 자동 튜닝(Optuna) best_params 에코. tune=false/미지원이면 없음.
  scaled?: boolean; // 실제 적용된 표준화 여부(W2). 미해당 경로는 null/미포함.
  sequentialSplit?: boolean; // 실제 사용한 분할 방식 에코(true=시간순, false=랜덤).
}

export interface PredictRequest {
  model_id: string;
  X: number[][];
}

export interface PredictResponse {
  predictions: number[];
  proba?: number[][]; // 분류 확률(클래스 순서)
}

/* ───────────── 호출 함수 ───────────── */

// API 베이스 URL. 런타임 config(getConfig)에서 읽는다.
//  · 빈 값이면 same-origin(빈 문자열 반환) → fetch('/models/...')가 현재 오리진으로 간다.
//    (리버스 프록시로 프론트와 백엔드를 같은 오리진에 두는 설치형 구성에 적합)
function apiBase(): string {
  const base = getConfig().API_BASE_URL;
  return base ? base.replace(/\/$/, '') : '';
}

const MAX_RETRIES = 2; // 일시적 실패(네트워크·5xx)만

function timeoutMs(): number {
  return getConfig().API_TIMEOUT_MS;
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

// POST JSON — 타임아웃(AbortController) + 지수 백오프 재시도.
//  · 4xx(클라이언트 오류: 404 등)는 재시도하지 않고 Response 그대로 반환(호출자가 처리).
//  · 5xx·네트워크 오류·타임아웃은 최대 MAX_RETRIES회 재시도(500ms·1s·2s…).
async function postJson(path: string, body: unknown, signal?: AbortSignal): Promise<Response> {
  const url = `${apiBase()}${path}`;
  let lastErr: unknown;
  let authRetried = false; // 401 → refresh 재시도는 요청당 1회만(무한루프 방지)
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    if (signal?.aborted) throw new CancelledError(); // 사용자 취소 → 재시도·타임아웃 메시지 없이 즉시 중단
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs());
    signal?.addEventListener('abort', () => ctrl.abort(), { once: true }); // 외부 취소 → 진행 중 요청도 중단
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      // 토큰이 있을 때만 Authorization 주입(무인증 계산 API 는 그대로 동작 — soft).
      const tok = getAccessToken();
      if (tok) headers.Authorization = `Bearer ${tok}`;
      const res = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      // 인증 만료(401): 토큰을 실어 보냈던 요청만 refresh 후 1회 재시도.
      if (res.status === 401 && !authRetried && tok) {
        authRetried = true;
        const newTok = await refreshAccessToken(); // 단일 in-flight 공유
        if (newTok) { attempt--; continue; } // 새 access 로 재시도(재시도 횟수 미소모)
        return res; // refresh 실패 → 401 전파(로그인 유도는 상위/L3b)
      }
      if (res.status >= 400 && res.status < 500) return res; // 클라이언트 오류 → 재시도 안 함
      if (res.status >= 500) {
        lastErr = new Error(`서버 오류(HTTP ${res.status})`);
        if (attempt < MAX_RETRIES) { await sleep(500 * 2 ** attempt); continue; }
        return res;
      }
      return res; // 2xx/3xx
    } catch (e) {
      clearTimeout(timer);
      if (signal?.aborted) throw new CancelledError(); // 사용자 취소로 abort 된 것 → 타임아웃/재시도 아님
      lastErr = e instanceof Error && e.name === 'AbortError'
        ? new Error(`요청 시간 초과(${Math.round(timeoutMs() / 1000)}초). 서버 응답이 없습니다.`)
        : new Error('서버에 연결할 수 없습니다. 네트워크나 백엔드 상태를 확인하세요.');
      if (attempt < MAX_RETRIES) { await sleep(500 * 2 ** attempt); continue; }
      throw lastErr;
    }
  }
  throw lastErr ?? new Error('요청 실패');
}

// POST /models/train — 모델 학습 후 model_id + 요약 반환. signal 로 사용자 취소 가능(동기 경로).
export async function trainModel(req: TrainRequest, signal?: AbortSignal): Promise<TrainResponse> {
  const res = await postJson('/models/train', req, signal);
  if (!res.ok) throw new Error(`모델 학습 요청 실패: HTTP ${res.status}`);
  return (await res.json()) as TrainResponse;
}

// 자동 튜닝(tune=true)은 비동기 — POST 는 즉시 jobId 만 반환하고, 학습은 백그라운드에서 돈다.
export interface TrainJobStatus {
  jobId: string;
  status: 'pending' | 'running' | 'done' | 'failed' | 'cancelled';
  progress: number; // 완료 trial 수
  total: number; // 전체 trial 상한
  bestScore?: number | null;
  bestParams?: Record<string, string | number | null> | null;
  result?: unknown; // status='done' 이면 TrainResponse/ClsTrainResponse 형태
  error?: string | null;
}

// 폴링 상태 조회(GET). 짧은 요청(인증 헤더 포함, 타임아웃만; 재시도는 폴링 루프가 담당). signal 로 사용자 취소 가능.
async function getTrainingStatus(jobId: string, signal?: AbortSignal): Promise<TrainJobStatus> {
  if (signal?.aborted) throw new CancelledError();
  const headers: Record<string, string> = {};
  const tok = getAccessToken();
  if (tok) headers.Authorization = `Bearer ${tok}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs());
  signal?.addEventListener('abort', () => ctrl.abort(), { once: true });
  try {
    const res = await fetch(`${apiBase()}/models/train/status/${jobId}`, { headers, signal: ctrl.signal, cache: 'no-store' });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`상태 조회 실패: HTTP ${res.status}`);
    return (await res.json()) as TrainJobStatus;
  } catch (e) {
    clearTimeout(timer);
    if (signal?.aborted) throw new CancelledError();
    throw e instanceof Error ? e : new Error('상태 조회 실패');
  }
}

// 비동기 학습 폴링 루프 — POST 로 jobId 받고 2초 간격으로 상태 조회. done 이면 result(T) 반환, failed 면 throw.
//   onProgress: 폴링마다 (완료 trial, 전체, 현재 best 점수) 를 UI 로 전달(진행률 표시).
const POLL_INTERVAL_MS = 2000; // 폴링 간격
const POLL_MAX_MS = 10 * 60 * 1000; // 폴링 상한(10분) — 서버가 응답 없이 멈춰도 무한 폴링을 막는다.

export async function pollTrainingJob<T>(
  req: TrainRequest,
  onProgress?: (done: number, total: number, best: number | null) => void,
  signal?: AbortSignal,
  onJobId?: (jobId: string) => void, // 백그라운드 job 시작 즉시 jobId 통지(전역 보존 → 페이지 이동 후 복원용)
): Promise<T> {
  const res = await postJson('/models/train', req, signal);
  if (!res.ok) throw new Error(`자동 최적화 시작 실패: HTTP ${res.status}`);
  const started = (await res.json()) as { jobId?: string };
  if (!started.jobId) throw new Error('작업 ID를 받지 못했습니다.');
  const jobId = started.jobId;
  onJobId?.(jobId); // 호출자가 jobId 를 전역 store 에 보관 → 언마운트 후 복귀 시 재폴링 복원
  const deadline = Date.now() + POLL_MAX_MS;
  try {
    for (;;) {
      if (signal?.aborted) throw new CancelledError(); // 취소 → 이후 진행률·결과 반영 안 함(옛 결과가 새 UI에 안 박힘)
      await sleep(POLL_INTERVAL_MS);
      if (signal?.aborted) throw new CancelledError();
      const st = await getTrainingStatus(jobId, signal);
      onProgress?.(st.progress, st.total, st.bestScore ?? null);
      if (st.status === 'done') {
        if (!st.result) throw new Error('완료됐지만 결과가 비어 있습니다.');
        return st.result as T;
      }
      if (st.status === 'failed') throw new Error(st.error || '자동 최적화에 실패했습니다.');
      if (st.status === 'cancelled') throw new CancelledError(); // 백엔드가 취소를 반영 → 취소로 종료
      if (Date.now() > deadline) throw new Error('자동 최적화가 너무 오래 걸려 폴링을 중단했습니다. 잠시 후 다시 시도해 주세요.');
    }
  } catch (e) {
    // 사용자 취소(프론트 폴링 중단)면 백엔드 튜닝 잡도 협조적 취소 요청(best-effort). aborted signal 은 넘기지 않는다.
    if (e instanceof CancelledError) void cancelTrainingJob(jobId);
    throw e;
  }
}

// POST /models/train/cancel/{jobId} — 백엔드 튜닝 잡 협조적 취소 요청. best-effort(실패해도 프론트 폴링은 이미 멈춤).
//   ⚠ 취소 signal 을 넘기지 않는다 — 이 호출 자체가 '취소 상황'에서 나가므로, aborted signal 을 주면 전송 전에 막힌다.
export async function cancelTrainingJob(jobId: string): Promise<void> {
  try {
    await postJson(`/models/train/cancel/${encodeURIComponent(jobId)}`, {});
  } catch {
    // 무시 — 백엔드 취소는 부가 조치(프론트는 이미 중단됨). 서버가 없거나 이미 끝났어도 문제 없음(멱등).
  }
}

// 이미 시작된 job(jobId) 을 '이어서' 폴링한다 — POST 학습을 새로 시작하지 않는다(페이지 복귀 시 복원 전용).
//   pollTrainingJob 과 동일한 종료 규칙(done→result, failed→throw, cancelled→CancelledError, 취소 시 백엔드 cancel).
//   ⚠ done 을 즉시 반영하기 위해 sleep 전에 먼저 상태를 조회한다(이미 끝난 job 은 대기 없이 바로 반환).
export async function resumeTrainingJob<T>(
  jobId: string,
  onProgress?: (done: number, total: number, best: number | null) => void,
  signal?: AbortSignal,
): Promise<T> {
  const deadline = Date.now() + POLL_MAX_MS;
  try {
    for (;;) {
      if (signal?.aborted) throw new CancelledError();
      const st = await getTrainingStatus(jobId, signal); // 먼저 조회 → 완료된 job 은 즉시 반환(대기 없음)
      onProgress?.(st.progress, st.total, st.bestScore ?? null);
      if (st.status === 'done') {
        if (!st.result) throw new Error('완료됐지만 결과가 비어 있습니다.');
        return st.result as T;
      }
      if (st.status === 'failed') throw new Error(st.error || '자동 최적화에 실패했습니다.');
      if (st.status === 'cancelled') throw new CancelledError(); // 백엔드가 취소를 반영 → 취소로 종료
      if (Date.now() > deadline) throw new Error('자동 최적화가 너무 오래 걸려 폴링을 중단했습니다. 잠시 후 다시 시도해 주세요.');
      if (signal?.aborted) throw new CancelledError();
      await sleep(POLL_INTERVAL_MS);
    }
  } catch (e) {
    if (e instanceof CancelledError) void cancelTrainingJob(jobId); // 복귀 후 취소도 백엔드 협조적 취소 요청
    throw e;
  }
}

// POST /models/{model_id}/predict — 서버 보관 모델로 예측.
export async function predictModel(req: PredictRequest): Promise<PredictResponse> {
  if (!req.model_id) throw new MissingModelError();
  const res = await postJson(`/models/${encodeURIComponent(req.model_id)}/predict`, { X: req.X });
  if (res.status === 404) throw new MissingModelError('서버 모델을 찾을 수 없습니다(만료되었을 수 있습니다). 다시 학습해 주세요.');
  if (!res.ok) throw new Error(`예측 요청 실패: HTTP ${res.status}`);
  return (await res.json()) as PredictResponse;
}

/* ───────────── 분류(classification) ───────────── */

export interface ClsReportRow {
  cls: string;
  precision: number;
  recall: number;
  f1: number;
  support: number;
  auc?: number;
}

export interface ClsTrainResponse {
  model_id: string;
  classes: string[];
  accuracy: number;
  confusion: number[][];
  report: ClsReportRow[];
  coef?: number[]; // 이진 로지스틱=표준화 계수(값 벡터)
  importance?: number[]; // 트리 변수 중요도
  vizTree?: unknown;
  sampled?: { used: number; total: number };
  usedParams?: Record<string, string | number | null>; // 수동 튜닝(knn 분류) 시 기본값 채운 최종 사용값(에코)
  bestParams?: Record<string, string | number | null>; // 자동 튜닝(Optuna) best_params 에코. tune=false/미지원이면 없음.
  scaled?: boolean; // 실제 적용된 표준화 여부(W2). 미해당 경로는 null/미포함.
  sequentialSplit?: boolean; // 실제 사용한 분할 방식 에코(true=시간순, false=랜덤).
}

export interface ClsPredictResponse {
  predictions: string[]; // 예측 클래스 라벨
  proba?: number[][]; // classes 순서 확률
  classes?: string[];
}

// POST /models/train (task='cls') — 분류 학습. signal 로 사용자 취소 가능(동기 경로).
export async function trainClassifier(req: TrainRequest, signal?: AbortSignal): Promise<ClsTrainResponse> {
  const res = await postJson('/models/train', req, signal);
  if (!res.ok) throw new Error(`분류 학습 요청 실패: HTTP ${res.status}`);
  return (await res.json()) as ClsTrainResponse;
}

// POST /models/{id}/predict — 분류 예측(라벨 + 확률).
export async function predictClassifier(modelId: string, X: number[][]): Promise<ClsPredictResponse> {
  if (!modelId) throw new MissingModelError();
  const res = await postJson(`/models/${encodeURIComponent(modelId)}/predict`, { X });
  if (res.status === 404) throw new MissingModelError('서버 모델을 찾을 수 없습니다(만료되었을 수 있습니다). 다시 학습해 주세요.');
  if (!res.ok) throw new Error(`예측 요청 실패: HTTP ${res.status}`);
  return (await res.json()) as ClsPredictResponse;
}
