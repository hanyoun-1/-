// 예측 전용 데이터 병합 — 두 가지 방식.
//   · joinByKey(가로/컬럼 추가): key 컬럼 기준으로 두 번째 파일의 컬럼을 옆에 붙인다.
//       LEFT(기본): 기존 행 전부 유지 + 매칭되는 컬럼 결합. INNER: 양쪽에 key가 있는 행만.
//   · concatRows(세로/행 추가): 같은 형식의 데이터를 아래로 이어붙인다. 컬럼이 다르면 합집합으로 정렬하고 없는 값은 null.
import type { Row } from '../types';

export type JoinType = 'left' | 'inner';
// 컬럼명 충돌 처리: suffix = _2,_3 으로 둘 다 유지 / overwrite = 기존 컬럼을 새 값으로 완전 교체
export type DupMode = 'suffix' | 'overwrite';

const norm = (v: Row[string]): string => (v === null || v === undefined ? '' : String(v).trim());

export interface JoinResult {
  rows: Row[];
  addedColumns: string[]; // 새로 붙은 컬럼명
  matched: number; // 매칭된 기존 행 수
  total: number; // 결과 행 수
}

export function joinByKey(
  base: Row[],
  extra: Row[],
  baseKey: string,
  extraKey: string,
  type: JoinType,
  dupMode: DupMode = 'suffix',
): JoinResult {
  const baseCols = base.length ? Object.keys(base[0]) : [];
  const extraCols = extra.length ? Object.keys(extra[0]) : [];

  // 붙일 컬럼(키 제외)의 최종 이름 결정.
  // 충돌 시: suffix → _2,_3 으로 둘 다 유지 / overwrite → 같은 이름에 새 값 완전 교체.
  const baseColSet = new Set(baseCols);
  const used = new Set(baseCols);
  const uniqueName = (name: string): string => {
    if (!used.has(name)) {
      used.add(name);
      return name;
    }
    let i = 2;
    while (used.has(`${name}_${i}`)) i += 1;
    const result = `${name}_${i}`;
    used.add(result);
    return result;
  };
  const addCols = extraCols.filter((c) => c !== extraKey);
  const rename = new Map<string, string>();
  const addedColumns: string[] = [];
  for (const c of addCols) {
    if (dupMode === 'overwrite' && baseColSet.has(c)) {
      rename.set(c, c); // 기존 컬럼을 그대로 덮어씀(새 컬럼 아님 → addedColumns 제외)
      continue;
    }
    const name = uniqueName(c);
    rename.set(c, name);
    addedColumns.push(name);
  }

  // extra: key → 첫 매칭 행
  const lookup = new Map<string, Row>();
  for (const r of extra) {
    const k = norm(r[extraKey]);
    if (k !== '' && !lookup.has(k)) lookup.set(k, r);
  }

  const rows: Row[] = [];
  let matched = 0;
  for (const r of base) {
    const k = norm(r[baseKey]);
    const hit = lookup.get(k);
    if (hit) matched += 1;
    if (type === 'inner' && !hit) continue;
    const out: Row = { ...r };
    for (const c of addCols) {
      out[rename.get(c)!] = hit ? hit[c] : null;
    }
    rows.push(out);
  }

  return { rows, addedColumns, matched, total: rows.length };
}

export interface ConcatResult {
  rows: Row[];
  addedColumns: string[]; // base 에는 없고 extra 에만 있던 새 컬럼
  addedRows: number; // 이어붙인 행 수
  total: number; // 결과 행 수(base + extra)
}

// 행 이어붙이기(세로 결합) — extra 를 base 아래로 붙인다.
//   컬럼이 다르면 합집합(base 순서 우선 + extra 고유 컬럼)으로 맞추고, 각 행에 없는 컬럼은 null 로 채운다.
//   ⚠ 모든 행이 합집합 컬럼을 전부 갖게 채우는 것이 핵심: profileDataset 이 첫 행의 키만 보고 컬럼을 정하므로,
//     채우지 않으면 뒤 파일에만 있던 컬럼이 통째로 누락된다.
export function concatRows(base: Row[], extra: Row[]): ConcatResult {
  const baseCols = base.length ? Object.keys(base[0]) : [];
  const extraCols = extra.length ? Object.keys(extra[0]) : [];
  const baseColSet = new Set(baseCols);
  const addedColumns = extraCols.filter((c) => !baseColSet.has(c));
  const allCols = [...baseCols, ...addedColumns];

  const fill = (r: Row): Row => {
    const out: Row = {};
    for (const c of allCols) out[c] = c in r ? r[c] : null;
    return out;
  };
  const rows: Row[] = [...base.map(fill), ...extra.map(fill)];
  return { rows, addedColumns, addedRows: extra.length, total: rows.length };
}
