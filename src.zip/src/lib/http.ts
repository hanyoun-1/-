// 공유 HTTP 유틸 — API 베이스 URL + 인증 훅 레지스트리.
// auth store 와 api 래퍼(compute/api.ts)의 순환 의존을 피하기 위한 중간 계층이다.
//  · store 는 registerAuthHooks 로 토큰 접근/갱신 방법을 등록한다.
//  · api 래퍼는 getAccessToken/refreshAccessToken 만 호출한다(store 를 직접 import 하지 않음).

import { getConfig } from './config/runtimeConfig';

// API 베이스 URL. 빈 값이면 same-origin(상대경로). compute/api.ts 와 동일 규칙.
export function apiBase(): string {
  const base = getConfig().API_BASE_URL;
  return base ? base.replace(/\/$/, '') : '';
}

interface AuthHooks {
  getAccessToken: () => string | null;
  // 성공 시 새 access 토큰, 실패(만료·폐기·재사용 감지) 시 null.
  refresh: () => Promise<string | null>;
  onAuthFailure: () => void;
}

let hooks: AuthHooks | null = null;

export function registerAuthHooks(h: AuthHooks): void {
  hooks = h;
}

export function getAccessToken(): string | null {
  return hooks?.getAccessToken() ?? null;
}

// 단일 in-flight refresh — 동시 다발 401 이 refresh 를 여러 번 돌리지 않도록 공유한다.
let refreshInFlight: Promise<string | null> | null = null;

export function refreshAccessToken(): Promise<string | null> {
  if (!hooks) return Promise.resolve(null);
  if (!refreshInFlight) {
    refreshInFlight = hooks
      .refresh()
      .then((tok) => {
        if (!tok) hooks?.onAuthFailure();
        return tok;
      })
      .finally(() => {
        refreshInFlight = null;
      });
  }
  return refreshInFlight;
}
