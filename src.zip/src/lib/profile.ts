import type {
  ColumnMeta,
  ColumnType,
  ColumnRole,
  DateFormat,
  Dataset,
  OutlierVar,
  PredictTarget,
  Row,
  StatRow,
} from '../types';
import { DATE_RE, detectDateFormat, dupKey, isMissing, outlierBounds } from './dataQuality';

// 한글 표시명 매핑(없으면 원래 이름 사용)
const LABELS: Record<string, string> = {
  customer_id: '고객 ID',
  age: '나이',
  gender: '성별',
  region: '지역',
  signup_date: '가입일',
  monthly_income: '소득(만원)',
  visit_count: '방문 횟수',
  tenure_months: '가입 기간(개월)',
  purchased: '구매 여부',
  churned: '이탈 여부',
  monthly_revenue: '월 매출(만원)',
};

const labelOf = (name: string) => LABELS[name] ?? name;

function inferType(values: (string | number | boolean | null)[]): ColumnType {
  const sample = values.filter((v) => v !== null && v !== '').slice(0, 200);
  if (sample.length === 0) return 'string';

  const allBool = sample.every(
    (v) => typeof v === 'boolean' || v === 'true' || v === 'false',
  );
  if (allBool) return 'bool';

  const allDate = sample.every((v) => typeof v === 'string' && DATE_RE.test(v));
  if (allDate) return 'datetime';

  const allNum = sample.every((v) => typeof v === 'number' || !isNaN(Number(v)));
  if (allNum) {
    const allInt = sample.every((v) => Number.isInteger(Number(v)));
    return allInt ? 'int' : 'float';
  }
  return 'string';
}

function inferRole(name: string, type: ColumnType, uniqueRatio: number): ColumnRole {
  if (type === 'bool') return '예측 후보';
  if (/id$|_id|^id$/i.test(name) && uniqueRatio > 0.9) return '식별자';
  if (type === 'datetime') return '날짜형';
  if (type === 'string') return '범주형';
  // 수치형 중 매출/금액류는 예측 후보로 노출
  if (/revenue|sales|amount|매출|금액/i.test(name)) return '예측 후보';
  return '수치형';
}

function toNum(v: string | number | boolean | null): number | null {
  if (v === null || v === '') return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  const n = Number(v);
  return isNaN(n) ? null : n;
}

function quantile(sorted: number[], q: number): number {
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return sorted[base + 1] !== undefined
    ? sorted[base] + rest * (sorted[base + 1] - sorted[base])
    : sorted[base];
}

const round1 = (n: number) => Math.round(n * 10) / 10;
const round2 = (n: number) => Math.round(n * 100) / 100;

// typeOverrides: 전처리에서 사용자가 강제한 타입(예: 숫자처럼 보이는 컬럼을 범주형으로) 존중.
export function profileDataset(
  fileName: string,
  rows: Row[],
  typeOverrides?: Record<string, ColumnType>,
  formatOverrides?: Record<string, DateFormat>,
): Dataset {
  const columnNames = rows.length ? Object.keys(rows[0]) : [];

  const columns: ColumnMeta[] = columnNames.map((name) => {
    const values = rows.map((r) => r[name]);
    const type = typeOverrides?.[name] ?? inferType(values);
    const uniq = new Set(values.map((v) => String(v))).size;
    const role = inferRole(name, type, uniq / Math.max(rows.length, 1));
    // datetime 표기 형식: 사용자 지정(formatOverrides)이 있으면 우선(타입 override 와 동일 원칙), 없으면 자동 판정.
    const dateFormat: DateFormat | undefined =
      type === 'datetime' ? (formatOverrides?.[name] ?? detectDateFormat(values)) : undefined;
    return { name, label: labelOf(name), type, role, dateFormat };
  });

  // 기초 통계량(수치형/예측후보 수치)
  const statistics: StatRow[] = columns
    .filter((c) => c.type === 'int' || c.type === 'float')
    .filter((c) => c.role !== '식별자')
    .map((c) => {
      const nums = rows
        .map((r) => toNum(r[c.name]))
        .filter((v): v is number => v !== null)
        .sort((a, b) => a - b);
      const n = Math.max(nums.length, 1);
      const mean = nums.reduce((s, v) => s + v, 0) / n;
      const variance = nums.reduce((s, v) => s + (v - mean) ** 2, 0) / n;
      const std = Math.sqrt(variance);
      // 왜도(skewness): 표준편차가 0이면 정의되지 않으므로 0 처리
      const skewness =
        std === 0
          ? 0
          : nums.reduce((s, v) => s + ((v - mean) / std) ** 3, 0) / n;
      const q1 = quantile(nums, 0.25);
      const q3 = quantile(nums, 0.75);
      return {
        name: c.name,
        label: c.label,
        mean: round1(mean),
        median: round1(quantile(nums, 0.5)),
        std: round1(std),
        min: round1(nums[0] ?? 0),
        max: round1(nums[nums.length - 1] ?? 0),
        skewness: round2(skewness),
        q1: round1(q1),
        q3: round1(q3),
        iqr: round1(q3 - q1),
      };
    });

  // 데이터 품질
  // 결측치: null·undefined·NaN·공백·'N/A'·'NA'·'NULL'·'-'·'*' 등을 결측으로 인식(isMissing)
  let missingCells = 0;
  let totalCells = rows.length * Math.max(columnNames.length, 1);
  for (const r of rows)
    for (const name of columnNames)
      if (isMissing(r[name])) missingCells++;
  const missingPct = round1((missingCells / Math.max(totalCells, 1)) * 100);

  // 중복치: 정규화(trim·대소문자 통일·숫자 포맷 통일) 후 비교 → "SEOUL"="seoul", 1="1.0" 동일 취급
  const seen = new Set<string>();
  let duplicateCount = 0;
  for (const r of rows) {
    const key = dupKey(r, columnNames);
    if (seen.has(key)) duplicateCount++;
    else seen.add(key);
  }

  // 이상치: 모든 수치형 변수(식별자 제외)에 대해 IQR(1.5×IQR) 기준 검출.
  //         IQR=0(과반 동일값)이면 로버스트(수정 Z-점수) Fallback으로 누락 방지(outlierBounds).
  let outlierCount = 0;
  const outliers: OutlierVar[] = [];
  for (const c of columns) {
    if (c.type !== 'int' && c.type !== 'float') continue;
    if (c.role === '식별자') continue;
    // 행 인덱스와 함께 유효(비결측) 값 수집
    const pairs: { idx: number; v: number }[] = [];
    rows.forEach((r, i) => {
      const v = toNum(r[c.name]);
      if (v !== null) pairs.push({ idx: i, v });
    });
    const b = outlierBounds(pairs.map((p) => p.v));
    if (!b) continue; // 값 부족 또는 모두 동일 → 판정 불가
    const outRows = pairs.filter((p) => p.v > b.upper || p.v < b.lower);
    if (!outRows.length) continue;
    outlierCount += outRows.length;
    outliers.push({
      name: c.name,
      label: c.label,
      q1: round1(b.q1),
      q3: round1(b.q3),
      iqr: round1(b.iqr),
      lower: round1(b.lower),
      upper: round1(b.upper),
      count: outRows.length,
      // 변수별 이상치 비율(%) = 이상치 수 / 유효 값 수
      ratio: round1((outRows.length / pairs.length) * 100),
      sample: outRows.slice(0, 50).map((p) => ({
        row: p.idx + 1,
        value: round1(p.v),
        reason:
          b.method === 'iqr'
            ? p.v > b.upper
              ? 'Q3 + 1.5×IQR 초과'
              : 'Q1 - 1.5×IQR 미만'
            : p.v > b.upper
              ? '로버스트 상한 초과(수정 Z>3.5)'
              : '로버스트 하한 미만(수정 Z>3.5)',
      })),
    });
  }
  outliers.sort((a, b) => b.count - a.count);

  // 날짜 기간
  const dateCol = columns.find((c) => c.type === 'datetime');
  let periodStart = '';
  let periodEnd = '';
  let periodLabel = '기간 정보 없음';
  if (dateCol) {
    const dates = rows
      .map((r) => String(r[dateCol.name]))
      .filter((d) => DATE_RE.test(d))
      .sort();
    if (dates.length) {
      periodStart = dates[0].slice(0, 7).replace('-', '.');
      periodEnd = dates[dates.length - 1].slice(0, 7).replace('-', '.');
      periodLabel = `${periodStart} ~ ${periodEnd}`;
    }
  }

  // 예측 가능 항목
  const predictTargets: PredictTarget[] = columns
    .filter((c) => c.role === '예측 후보')
    .map((c) => ({
      key: c.name,
      label: c.label,
      kind: c.type === 'bool' ? 'categorical' : 'numeric',
      model: c.type === 'bool' ? 'Decision Tree' : 'Regression',
    }));

  // 용량 추정 — 전체 직렬화는 대용량에서 매우 느리므로 샘플(최대 100행) 평균으로 추정.
  const sampleN = Math.min(rows.length, 100);
  let sampleBytes = 0;
  for (let i = 0; i < sampleN; i++) sampleBytes += JSON.stringify(rows[i]).length;
  const sizeMB = round1((sampleN ? (sampleBytes / sampleN) * rows.length : 0) / (1024 * 1024));

  return {
    fileName,
    rows,
    columns,
    rowCount: rows.length,
    colCount: columnNames.length,
    sizeMB,
    periodStart,
    periodEnd,
    periodLabel,
    predictTargets,
    statistics,
    quality: { missingPct, duplicateCount, outlierCount, outliers },
  };
}
