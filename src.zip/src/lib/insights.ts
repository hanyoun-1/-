import type { Dataset, DashboardItem } from '../types';
import { barData, boxStats, correlation, targetCorrelations, lineData, multiLineData, stackedAreaData } from './charts';

// 비전공자용 해석 문구 생성기(룰 기반).
export function summaryInsight(d: Dataset): string {
  const targets = d.predictTargets.map((t) => `'${t.label}'`).slice(0, 2).join('이나 ');
  const people = Math.round(d.rowCount / 1000);
  return `약 ${people}천 건의 데이터예요. ${d.colCount}개의 변수가 있어 ${
    targets || '주요 항목'
  } 같은 값을 예측하기 좋은 데이터입니다.`;
}

export function structureInsight(d: Dataset): string {
  const cand = d.predictTargets[0];
  return `총 ${d.colCount}개의 변수로 구성된 데이터이며 ${
    cand ? `'${cand.label}' 예측에 활용 가능합니다.` : '탐색적 분석에 적합합니다.'
  }`;
}

const labelOf = (d: Dataset, name: string | null) =>
  d.columns.find((c) => c.name === name)?.label ?? name ?? '변수';

// 첫↔마지막 값 변화율로 추세 표현(선그래프·영역 공용). |변화|<5% 유지, ≥20% 크게.
const trendPhrase = (first: number, last: number): string => {
  const pct = first !== 0 ? (last - first) / Math.abs(first) : last > 0 ? 1 : last < 0 ? -1 : 0;
  const a = Math.abs(pct);
  if (a < 0.05) return '큰 변화 없이 유지되는';
  return `${a >= 0.2 ? '크게' : '소폭'} ${pct > 0 ? '증가' : '감소'}하는`;
};

/* 대시보드 차트 1개 → 정중체(~습니다) 한 줄 소견(룰 기반).
   리포트 종합소견과 시각화 페이지 실시간 소견이 이 함수를 공유해 문구가 항상 일치한다.
   히트맵은 기준 컬럼(it.v1) 지정 시 그 컬럼과 상관 1·2위 변수를 보고한다. */
export function chartInsight(d: Dataset, it: DashboardItem): string {
  const L = (n?: string) => labelOf(d, n ?? null);
  const countNonEmpty = (name: string) => d.rows.reduce((a, r) => (r[name] !== null && r[name] !== undefined && r[name] !== '' ? a + 1 : a), 0);
  switch (it.chart) {
    case 'histogram': {
      if (!it.v1) return '';
      const s = d.statistics.find((x) => x.name === it.v1);
      if (!s) return `'${L(it.v1)}'의 분포를 살펴보았습니다.`;
      if (s.skewness >= 0.5) return `'${L(it.v1)}'은(는) 낮은 값에 몰려 있으며 일부 큰 값으로 인해 오른쪽으로 치우친 분포를 보입니다.`;
      if (s.skewness <= -0.5) return `'${L(it.v1)}'은(는) 큰 값에 몰려 있으며 왼쪽으로 치우친 분포를 보입니다.`;
      return `'${L(it.v1)}'은(는) 대부분 ${s.q1.toLocaleString()}~${s.q3.toLocaleString()} 구간에 집중되어 있습니다.`;
    }
    case 'box': {
      // 박스플롯은 '치우침'이 아니라 박스(가운데 50%·중앙값)와 수염 밖 '이상치 점'을 본다.
      if (!it.v1) return '';
      const b = boxStats(d, it.v1);
      if (!b) return `'${L(it.v1)}'의 분포를 살펴보았습니다.`;
      let s = `'${L(it.v1)}'의 가운데 50%는 ${b.q1.toLocaleString()}~${b.q3.toLocaleString()}(중앙값 ${b.median.toLocaleString()}) 구간에 분포합니다.`;
      if (b.outlierCount > 0) {
        const above = b.outliers.filter((v) => v > b.q3).length;
        const below = b.outliers.filter((v) => v < b.q1).length;
        const side = above && below ? '위·아래 양쪽' : above ? '위쪽(큰 값)' : below ? '아래쪽(작은 값)' : '';
        s += ` 정상 범위를 벗어난 이상치가 ${b.outlierCount.toLocaleString()}개${side ? ` ${side}에` : ''} 나타납니다.`;
      } else {
        s += ' 정상 범위를 벗어난 이상치는 두드러지지 않습니다.';
      }
      return s;
    }
    case 'bar': {
      const name = it.cat;
      if (!name) return '';
      const rows = barData(d, name);
      if (!rows.length) return `'${L(name)}'의 분포를 살펴보았습니다.`;
      const pct = Math.round((rows[0].count / Math.max(countNonEmpty(name), 1)) * 100);
      return `'${L(name)}'은(는) '${rows[0].category}' 비율이 ${pct}%로 가장 높습니다.`;
    }
    case 'pie':
    case 'treemap': {
      // 구성/비중 차트 — 범주 수 + 최대 비중 + 상위 집중도까지 분석적으로 서술.
      const name = it.cat;
      if (!name) return '';
      const rows = barData(d, name);
      const total = countNonEmpty(name);
      if (!rows.length || !total) return `'${L(name)}'의 구성을 살펴보았습니다.`;
      const pct = (c: number) => Math.round((c / total) * 100);
      const nCat = new Set(d.rows.map((r) => r[name]).filter((v) => v !== null && v !== undefined && v !== '')).size;
      const top1 = pct(rows[0].count);
      const top3 = pct(rows.slice(0, 3).reduce((s, r) => s + r.count, 0));
      const tail = top1 >= 50
        ? '전체의 절반 이상이 이 범주에 편중되어 있습니다.'
        : nCat > 3 && top3 >= 70
          ? `상위 3개 범주가 전체의 ${top3}%를 차지해 상위 그룹에 집중된 구성입니다.`
          : '여러 범주에 비교적 고르게 분포되어 있습니다.';
      return `'${L(name)}'은(는) 총 ${nCat}개 범주로 구성되며, 가장 큰 비중은 '${rows[0].category}'(${top1}%)입니다. ${tail}`;
    }
    case 'scatter': {
      // X(v1)가 커질 때 Y(v2)가 어떻게 변하는지 방향형으로 서술.
      if (!it.v1 || !it.v2) return '';
      const r = correlation(d, it.v1, it.v2);
      const a = Math.abs(r);
      if (a < 0.2) return `'${L(it.v1)}'과(와) '${L(it.v2)}' 사이에는 뚜렷한 관계가 나타나지 않습니다 (상관계수=${r.toFixed(2)}).`;
      const adv = a >= 0.7 ? '뚜렷하게' : a >= 0.4 ? '어느 정도' : '다소';
      return r > 0
        ? `'${L(it.v1)}'이(가) 높을수록 '${L(it.v2)}'도 ${adv} 높아지는 경향이 나타납니다 (상관계수=${r.toFixed(2)}).`
        : `'${L(it.v1)}'이(가) 높을수록 '${L(it.v2)}'은(는) ${adv} 낮아지는 경향이 나타납니다 (상관계수=${r.toFixed(2)}).`;
    }
    case 'line': {
      if (!it.date || !it.v1) return '';
      // 계열(그룹) 지정 → 계열별 평균 중 가장 높은 계열을 보고
      if (it.cat) {
        const { rows, groups } = multiLineData(d, it.date, it.v1, it.cat);
        if (!groups.length) return `'${L(it.date)}'에 따른 '${L(it.v1)}' 평균의 추세를 확인할 수 있습니다.`;
        const avgs = groups.map((g) => {
          let sum = 0, n = 0;
          for (const row of rows) { const v = row[g]; if (typeof v === 'number') { sum += v; n += 1; } }
          return { g, avg: n ? sum / n : -Infinity };
        }).sort((a, b) => b.avg - a.avg);
        return `'${L(it.cat)}'별 '${L(it.v1)}' 평균 추세이며, '${avgs[0].g}'의 평균이 가장 높습니다.`;
      }
      // 단일 계열 → 첫↔마지막 버킷 평균 비교로 추세 판정
      const series = lineData(d, it.date, it.v1);
      if (series.length < 2) return `'${L(it.v1)}' 평균의 추세를 확인할 수 있습니다.`;
      const first = series[0].value, last = series[series.length - 1].value;
      return `'${L(it.v1)}' 평균이 ${first}에서 ${last}로 ${trendPhrase(first, last)} 추세입니다.`;
    }
    case 'area': {
      // 시간별 구성 차트 — 그룹 수 + 최대 비중(%) + 전체 추세 + 최다 시점까지 분석적으로 서술.
      if (!it.date || !it.cat) return '';
      const { rows, groups } = stackedAreaData(d, it.date, it.cat);
      if (!groups.length || !rows.length) return `'${L(it.date)}'에 따른 '${L(it.cat)}' 구성의 변화를 확인할 수 있습니다.`;
      const bucketTotal = (row: Record<string, number | string>) => groups.reduce((sum, g) => sum + (typeof row[g] === 'number' ? (row[g] as number) : 0), 0);
      const totals = groups.map((g) => {
        let t = 0;
        for (const row of rows) { const v = row[g]; if (typeof v === 'number') t += v; }
        return { g, t };
      }).sort((a, b) => b.t - a.t);
      const grand = totals.reduce((s, x) => s + x.t, 0);
      const topPct = grand ? Math.round((totals[0].t / grand) * 100) : 0;
      let s = `'${L(it.date)}' 기간 동안 '${L(it.cat)}' 기준으로 나누면 가장 큰 비중은 '${totals[0].g}'(${topPct}%)입니다.`;
      if (rows.length >= 2) {
        const f = bucketTotal(rows[0]), l = bucketTotal(rows[rows.length - 1]);
        const trend = l > f ? '증가하는' : l < f ? '감소하는' : '비슷하게 유지되는';
        let peak = rows[0], peakT = bucketTotal(rows[0]);
        for (const row of rows) { const t = bucketTotal(row); if (t > peakT) { peakT = t; peak = row; } }
        s += ` 전체 건수는 기간에 따라 ${trend} 흐름이며, '${String(peak.x)}' 시점에 가장 많았습니다.`;
      }
      return s;
    }
    case 'heatmap': {
      if (it.v1) {
        const { ok, items } = targetCorrelations(d, it.v1);
        if (ok && items.length) {
          const ranked = [...items].sort((a, b) => Math.abs(b.r) - Math.abs(a.r));
          const dir = (r: number) => (r >= 0 ? '양' : '음');
          const annot = (x: { label: string; r: number }) => `'${x.label}'(${dir(x.r)}의 상관, 상관계수=${x.r.toFixed(2)})입니다`;
          let s = `'${L(it.v1)}'과(와) 상관관계가 가장 높은 변수는 ${annot(ranked[0])}.`;
          if (ranked[1]) s += ` 그다음으로 높은 변수는 ${annot(ranked[1])}.`;
          return s;
        }
      }
      return '수치형 변수 간 상관관계를 종합적으로 확인할 수 있습니다.';
    }
    default:
      return '';
  }
}
