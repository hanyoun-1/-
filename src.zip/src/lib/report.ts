import type { AppliedStep, Dataset, StatRow } from '../types';
import { summaryInsight, structureInsight } from './insights';

export interface ReportData {
  dataInfo: { fileName: string; date: string; rowCount: number; colCount: number; period: string };
  structure: { label: string; type: string; role: string }[];
  predictCandidates: string[];
  preprocessing: string[]; // 적용한 전처리 이력(로그)
  statistics: StatRow[];
  charts: {
    histVar?: string;
    boxVar?: string;
    barVar?: string;
    scatter?: { x: string; y: string };
    heatmap: boolean;
  };
  ai: { summary: string; structure: string };
  fileBase: string;
}

const pad = (n: number) => String(n).padStart(2, '0');

// 분석 결과만 수집한다(원본 rows는 포함하지 않음). d는 전처리 반영본(activeDataset).
export function buildReportData(d: Dataset, steps: AppliedStep[]): ReportData {
  const now = new Date();
  const y = now.getFullYear();
  const mo = pad(now.getMonth() + 1);
  const da = pad(now.getDate());
  const hh = pad(now.getHours());
  const mi = pad(now.getMinutes());

  const usable = d.columns.filter((c) => c.role !== '식별자');
  const numeric = usable.filter((c) => c.type === 'int' || c.type === 'float');
  const categorical = usable.filter((c) => c.type === 'string' || c.type === 'bool');

  return {
    dataInfo: {
      fileName: d.fileName,
      date: `${y}-${mo}-${da} ${hh}:${mi}`,
      rowCount: d.rowCount,
      colCount: d.colCount,
      period: d.periodLabel,
    },
    structure: d.columns.map((c) => ({ label: c.label, type: c.type, role: c.role })),
    predictCandidates: d.predictTargets.map((t) => t.label),
    preprocessing: steps.map((s) => s.log),
    statistics: d.statistics,
    charts: {
      histVar: numeric[0]?.name,
      boxVar: numeric[0]?.name,
      barVar: categorical[0]?.name,
      scatter: numeric.length >= 2 ? { x: numeric[0].name, y: numeric[1].name } : undefined,
      heatmap: numeric.length >= 2,
    },
    ai: {
      summary: summaryInsight(d),
      structure: structureInsight(d),
    },
    fileBase: `EDA_Report_${y}${mo}${da}_${hh}${mi}`,
  };
}

// 리포트 DOM을 새 창에 복제해 인쇄(브라우저의 "PDF로 저장") — 추가 라이브러리 없이 PDF 생성.
export function printReport(el: HTMLElement, fileBase: string) {
  const w = window.open('', '_blank', 'width=920,height=1200');
  if (!w) {
    alert('팝업이 차단되어 인쇄 창을 열 수 없어요. 팝업 허용 후 다시 시도해 주세요.');
    return;
  }
  const styles = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'))
    .map((n) => n.outerHTML)
    .join('\n');

  w.document.write(
    `<!doctype html><html lang="ko"><head><meta charset="utf-8" /><title>${fileBase}</title>${styles}` +
      `<style>` +
      `@page{margin:14mm;} body{background:#fff;}` +
      // 배경색(히트맵 셀·막대·뱃지 등)을 인쇄/ PDF에 그대로 출력 — 미설정 시 브라우저가 배경을 비움
      `*{-webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; color-adjust:exact !important;}` +
      `</style></head>` +
      `<body class="bg-white">${el.outerHTML}</body></html>`,
  );
  w.document.close();

  const go = () => {
    w.focus();
    w.print();
  };
  if (w.document.readyState === 'complete') setTimeout(go, 400);
  else w.onload = () => setTimeout(go, 400);
}
