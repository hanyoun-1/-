import type { ColumnMeta, Dataset, Row } from '../types';

function numericValues(d: Dataset, name: string): number[] {
  return d.rows
    .map((r) => r[name])
    .filter((v): v is number => typeof v === 'number');
}

// 큰 배열에서도 안전한 min/max (Math.min(...arr)은 인자 수 한계로 스택 오버플로 발생).
function minMax(vals: number[]): [number, number] {
  let min = Infinity;
  let max = -Infinity;
  for (const v of vals) {
    if (v < min) min = v;
    if (v > max) max = v;
  }
  return [min, max];
}

export function histogramData(d: Dataset, name: string, bins = 12) {
  const vals = numericValues(d, name);
  if (!vals.length) return [];
  // 고유값이 적은(이산) 컬럼(예: 0/1, 1~5 등급) → 임의 구간 대신 값마다 막대 하나로. 라벨도 실제 값 그대로.
  const uniq = new Set(vals);
  if (uniq.size <= bins) {
    const counts = new Map<number, number>();
    for (const v of vals) counts.set(v, (counts.get(v) ?? 0) + 1);
    return [...uniq]
      .sort((a, b) => a - b)
      .map((v) => ({ range: `${v}`, count: counts.get(v) ?? 0 }));
  }
  const [min, max] = minMax(vals);
  const width = (max - min) / bins || 1;
  const buckets = Array.from({ length: bins }, (_, i) => ({
    range: `${Math.round(min + i * width)}`,
    count: 0,
  }));
  for (const v of vals) {
    let idx = Math.floor((v - min) / width);
    if (idx >= bins) idx = bins - 1;
    if (idx < 0) idx = 0;
    buckets[idx].count++;
  }
  return buckets;
}

function quantile(sorted: number[], q: number) {
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return sorted[base + 1] !== undefined
    ? sorted[base] + rest * (sorted[base + 1] - sorted[base])
    : sorted[base];
}

// 정식 박스플롯 통계 코어 — 수치 배열 하나 → 5수치 + 수염 끝점 + 이상치(1.5×IQR 기준).
//   단일(boxStats)·그룹별(boxStatsBy)이 공유한다. 반환 형태·계산은 기존 boxStats 와 동일(+ n=표본수 추가).
export type BoxStats = ReturnType<typeof boxStatsFromValues>;
function boxStatsFromValues(raw: number[]) {
  const vals = [...raw].sort((a, b) => a - b);
  if (!vals.length) return null;
  const r1 = (n: number) => Math.round(n * 10) / 10;

  const q1 = quantile(vals, 0.25);
  const median = quantile(vals, 0.5);
  const q3 = quantile(vals, 0.75);
  const iqr = q3 - q1;
  const lowerFence = q1 - 1.5 * iqr;
  const upperFence = q3 + 1.5 * iqr;

  // 수염 끝: 펜스 안쪽의 최소/최대 실제 데이터 값
  let whiskerLow = vals[0];
  for (const v of vals) {
    if (v >= lowerFence) { whiskerLow = v; break; }
  }
  let whiskerHigh = vals[vals.length - 1];
  for (let i = vals.length - 1; i >= 0; i--) {
    if (vals[i] <= upperFence) { whiskerHigh = vals[i]; break; }
  }

  const outliers = vals.filter((v) => v < lowerFence || v > upperFence);
  // 렌더 성능을 위해 이상치는 최대 200개만 샘플링
  const step = outliers.length > 200 ? Math.ceil(outliers.length / 200) : 1;
  const sampled = outliers.filter((_, i) => i % step === 0).map(r1);

  return {
    min: r1(vals[0]),
    q1: r1(q1),
    median: r1(median),
    q3: r1(q3),
    max: r1(vals[vals.length - 1]),
    iqr: r1(iqr),
    whiskerLow: r1(whiskerLow),
    whiskerHigh: r1(whiskerHigh),
    outliers: sampled,
    outlierCount: outliers.length,
    n: vals.length,
  };
}

// 정식 박스플롯용(단일 컬럼) — 5수치 + 수염 끝점 + 이상치(1.5×IQR 기준).
export function boxStats(d: Dataset, name: string) {
  return boxStatsFromValues(numericValues(d, name));
}

// 그룹별 박스플롯 — groupName 값으로 버킷팅해 각 그룹에 boxStats 계산(groupMeanData 와 동일 패턴).
//   ⚠ 선택된 컬럼의 그룹은 '전부' 표시한다(자르지 않음) — 일부 그룹이 조용히 사라져 '이게 전부'로 오해되지 않게.
//   그룹 폭주는 UI(VisualizePage)가 X 후보를 '고유값 15개 이하' 컬럼으로 제한해 원천 차단한다.
//   표본 많은 그룹 순으로 정렬. Smart Label 로 그룹명을 친화 라벨로 치환.
export function boxStatsBy(d: Dataset, valueName: string, groupName: string) {
  const groups = new Map<string, number[]>();
  for (const r of d.rows) {
    const v = r[valueName];
    if (typeof v !== 'number') continue; // numericValues 와 동일한 수치 판정
    const g = String(r[groupName] ?? '(없음)');
    const arr = groups.get(g) ?? [];
    arr.push(v);
    groups.set(g, arr);
  }
  const col = d.columns.find((c) => c.name === groupName);
  const labelMap = col ? smartLabelMap(col, [...groups.keys()]) : new Map<string, string>();
  return [...groups.entries()]
    .sort((a, b) => b[1].length - a[1].length) // 표본 많은 그룹 우선(전부 표시, 자르지 않음)
    .map(([group, vals]) => {
      const b = boxStatsFromValues(vals);
      return b ? { group: labelMap.get(group) ?? group, ...b } : null;
    })
    .filter((x): x is NonNullable<typeof x> => x !== null);
}

/* ───────── Smart Labeling — 컬럼명 + 값을 분석해 사용자 친화 라벨 생성 ─────────
   이진(불리언·Y/N·1/0·yes/no)·성별 패턴을 감지해 의미 있는 한글 라벨로 바꾼다.
   변환이 불가능하면 원본값을 그대로 유지한다(매핑에서 제외). 집계 카운트는 바뀌지 않는다. */
const POSITIVE_TOKENS = new Set(['true', 't', 'y', 'yes', '1', 'o', '예', '참']);
const NEGATIVE_TOKENS = new Set(['false', 'f', 'n', 'no', '0', 'x', '아니오', '거짓']);

function genderLabel(raw: string): string | null {
  const v = raw.trim().toLowerCase();
  if (['m', 'male', '남', '남성', '남자'].includes(v)) return '남성';
  if (['f', 'female', '여', '여성', '여자'].includes(v)) return '여성';
  return null;
}

function tokenMeaning(raw: string): 'pos' | 'neg' | null {
  const v = raw.trim().toLowerCase();
  if (POSITIVE_TOKENS.has(v)) return 'pos';
  if (NEGATIVE_TOKENS.has(v)) return 'neg';
  return null;
}

// 컬럼 의미(이름/라벨 키워드) → 긍정/부정 라벨 쌍
function binaryLabelsFor(text: string): { pos: string; neg: string } {
  const n = text.toLowerCase();
  if (/churn|이탈/.test(n)) return { pos: '이탈', neg: '유지' };
  if (/purchas|buy|order|구매|주문/.test(n)) return { pos: '구매', neg: '미구매' };
  if (/member|회원|가입/.test(n)) return { pos: '회원', neg: '비회원' };
  if (/subscrib|구독/.test(n)) return { pos: '구독', neg: '미구독' };
  if (/active|활성|사용/.test(n)) return { pos: '활성', neg: '비활성' };
  if (/pass|합격/.test(n)) return { pos: '합격', neg: '불합격' };
  return { pos: '예', neg: '아니오' };
}

/** 컬럼 + 원본값 집합 → { 원본값: 표시라벨 } 매핑. 변환 불가 값은 미포함(=원본 유지). */
function smartLabelMap(col: ColumnMeta, rawValues: string[]): Map<string, string> {
  const map = new Map<string, string>();
  const vals = rawValues.filter((v) => v !== '(없음)');
  if (!vals.length) return map;
  const text = `${col.name} ${col.label}`;

  // 성별: M/F·남/여 → 남성/여성 (모든 값이 성별로 해석될 때만)
  if (/gender|sex|성별/i.test(text) && vals.every((v) => genderLabel(v) !== null)) {
    for (const v of vals) map.set(v, genderLabel(v)!);
    return map;
  }

  // 이진(불리언/Y·N/1·0/yes·no): 값이 2종이고 모두 토큰이며 긍/부정이 섞여 있을 때만
  if (vals.length <= 2) {
    const meanings = vals.map(tokenMeaning);
    const allTokens = meanings.every((m) => m !== null);
    const hasBoth = meanings.includes('pos') && meanings.includes('neg');
    if (allTokens && hasBoth) {
      const { pos, neg } = binaryLabelsFor(text);
      vals.forEach((v, i) => map.set(v, meanings[i] === 'pos' ? pos : neg));
      return map;
    }
  }

  // 변환 불가 → 원본 유지
  return map;
}

export function barData(d: Dataset, name: string) {
  const counts = new Map<string, number>();
  for (const r of d.rows) {
    const key = String(r[name] ?? '(없음)');
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  // 집계는 원본값 기준, 표시 직전 category만 Smart Label로 치환(카운트 불변)
  const col = d.columns.find((c) => c.name === name);
  const labelMap = col ? smartLabelMap(col, [...counts.keys()]) : new Map<string, string>();
  return Array.from(counts.entries())
    .map(([category, count]) => ({ category: labelMap.get(category) ?? category, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 12);
}

export function scatterData(d: Dataset, xName: string, yName: string) {
  const pts: { x: number; y: number }[] = [];
  for (const r of d.rows) {
    const x = r[xName];
    const y = r[yName];
    if (typeof x === 'number' && typeof y === 'number') pts.push({ x, y });
    if (pts.length >= 600) break; // 성능을 위해 샘플링
  }
  return pts;
}

// 파이차트용 — barData 와 동일한 {category,count} 형태(재사용)
export function pieData(d: Dataset, name: string) {
  return barData(d, name);
}

// X 버킷 키 생성기 — "적응형" 시간 단위 자동 선택.
//   날짜형(YYYY-MM… 로 시작)이면 데이터 범위에 맞춰 시→일→월→년 중 "버킷 수가 상한 이하가 되는 가장 촘촘한" 단위를 고른다.
//     (예: 2개월치면 일 단위 ≈ 59점, 5년치면 월 단위, 그보다 길면 년). 점이 너무 적거나(월 고정) 너무 많아지는 문제를 함께 해결.
//   날짜형이 아니면(문자·숫자 X) 원본 값을 그대로 버킷 키로 쓴다(앞 7글자 자르던 옛 버그 제거).
//   반환: (raw) => key. lineData·multiLineData 공용.
const DATE_LIKE = /^\d{4}-\d{2}/;
const BUCKET_MAX = 200; // 선 위 점 개수 상한(가독)
function makeBucketKey(rows: Row[], name: string): (raw: Row[string]) => string {
  const dates: string[] = [];
  let total = 0;
  for (const r of rows) {
    const raw = r[name];
    if (raw == null || raw === '') continue;
    total += 1;
    const s = String(raw);
    if (DATE_LIKE.test(s)) dates.push(s);
  }
  // 과반이 날짜형이 아니면 원본 값 그대로 버킷(문자/숫자 X축)
  if (total === 0 || dates.length < total * 0.5) return (raw) => String(raw);
  // 촘촘한 단위부터: 시(13)·일(10)·월(7)·년(4). 버킷 수 ≤ 상한인 첫(=가장 촘촘한) 단위 선택.
  const UNITS = [13, 10, 7, 4];
  let len = 4;
  for (const u of UNITS) {
    const set = new Set(dates.map((v) => v.slice(0, u)));
    if (set.size <= BUCKET_MAX) { len = u; break; }
  }
  return (raw) => String(raw).slice(0, len).replace(/-/g, '.');
}

// 날짜별 집계 → {date, value}[]. X는 적응형(시/일/월/년 자동)으로 버킷팅한 뒤 각 버킷 평균을 낸다.
export function lineData(d: Dataset, dateName: string, valueName: string) {
  const keyOf = makeBucketKey(d.rows, dateName);
  const groups = new Map<string, { sum: number; n: number }>();
  for (const r of d.rows) {
    const raw = r[dateName];
    const val = r[valueName];
    if (raw == null || raw === '' || typeof val !== 'number') continue;
    const key = keyOf(raw);
    const g = groups.get(key) ?? { sum: 0, n: 0 };
    g.sum += val;
    g.n += 1;
    groups.set(key, g);
  }
  return Array.from(groups.entries())
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([date, g]) => ({ date, value: Math.round((g.sum / g.n) * 10) / 10 }));
}

// 다중계열 선 그래프 — X(기준) 버킷 × 계열(범주)별 "평균값"을 넓은(wide) 형태로 만든다.
//   lineData(단일 평균) + stackedAreaData(그룹 분리)의 결합: 버킷·계열마다 sum/n 으로 평균을 낸다.
//   x 버킷 규칙은 lineData 와 동일(YYYY.MM). 계열은 전체 빈도 상위 12개로 제한(색·범례 폭주 방지).
//   반환: { rows:[{ x, [계열1]:평균, [계열2]:평균, ... }], groups: 계열명 배열 }. 값 없는 (버킷,계열)은 키 생략 → 선 자연 끊김.
export function multiLineData(
  d: Dataset,
  dateName: string,
  valueName: string,
  groupName: string,
): { rows: Record<string, number | string>[]; groups: string[] } {
  const keyOf = makeBucketKey(d.rows, dateName); // 적응형 X 버킷(lineData 와 동일 규칙)
  const buckets = new Map<string, Map<string, { sum: number; n: number }>>();
  const counts = new Map<string, number>(); // 계열 전체 빈도(상위 12 선정용)
  for (const r of d.rows) {
    const raw = r[dateName];
    const val = r[valueName];
    if (raw == null || raw === '' || typeof val !== 'number') continue; // lineData 와 동일: 숫자 y만 집계
    const x = keyOf(raw);
    const g = String(r[groupName] ?? '(없음)');
    const m = buckets.get(x) ?? new Map<string, { sum: number; n: number }>();
    const cell = m.get(g) ?? { sum: 0, n: 0 };
    cell.sum += val;
    cell.n += 1;
    m.set(g, cell);
    buckets.set(x, m);
    counts.set(g, (counts.get(g) ?? 0) + 1);
  }
  const groups = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([g]) => g);
  const rows = [...buckets.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([x, m]) => {
      const row: Record<string, number | string> = { x };
      for (const g of groups) {
        const c = m.get(g);
        if (c && c.n > 0) row[g] = Math.round((c.sum / c.n) * 10) / 10; // 없는 버킷은 미기입(선 끊김)
      }
      return row;
    });
  return { rows, groups };
}

// 누적 영역 그래프 — X(시간/정렬) 버킷 × 그룹(범주)별 건수를 넓은(wide) 형태로 만든다.
//   x 버킷 규칙은 lineData 와 동일(YYYY.MM 등). 그룹은 전체 빈도 상위 12개로 제한(색·범례 폭주 방지).
//   반환: { rows: [{ x, [그룹1]:건수, [그룹2]:건수, ... }], groups: 그룹명 배열 }
export function stackedAreaData(d: Dataset, xName: string, groupName: string): { rows: Record<string, number | string>[]; groups: string[] } {
  const buckets = new Map<string, Map<string, number>>();
  for (const r of d.rows) {
    const raw = r[xName];
    if (raw == null || raw === '') continue;
    const x = String(raw).slice(0, 7).replace('-', '.');
    const g = String(r[groupName] ?? '(없음)');
    const m = buckets.get(x) ?? new Map<string, number>();
    m.set(g, (m.get(g) ?? 0) + 1);
    buckets.set(x, m);
  }
  const totals = new Map<string, number>();
  for (const m of buckets.values()) for (const [g, c] of m) totals.set(g, (totals.get(g) ?? 0) + c);
  const groups = [...totals.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([g]) => g);
  const rows = [...buckets.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([x, m]) => {
      const row: Record<string, number | string> = { x };
      for (const g of groups) row[g] = m.get(g) ?? 0;
      return row;
    });
  return { rows, groups };
}

// 피어슨 상관계수(-1 ~ 1). 짝이 맞는 수치 쌍만 사용.
export function correlation(d: Dataset, xName: string, yName: string): number {
  const xs: number[] = [];
  const ys: number[] = [];
  for (const r of d.rows) {
    const x = r[xName];
    const y = r[yName];
    if (typeof x === 'number' && typeof y === 'number') {
      xs.push(x);
      ys.push(y);
    }
  }
  const n = xs.length;
  if (n < 2) return 0;
  const mx = xs.reduce((s, v) => s + v, 0) / n;
  const my = ys.reduce((s, v) => s + v, 0) / n;
  let cov = 0;
  let vx = 0;
  let vy = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - mx;
    const dy = ys[i] - my;
    cov += dx * dy;
    vx += dx * dx;
    vy += dy * dy;
  }
  const denom = Math.sqrt(vx * vy);
  if (denom === 0) return 0;
  return Math.round((cov / denom) * 100) / 100;
}

// target 컬럼 기준 상관계수 — 수치형 컬럼만 대상, target 자기 자신은 제외.
// target이 수치형(d.statistics에 존재)이 아니면 ok=false 로 안내한다.
export function targetCorrelations(
  d: Dataset,
  targetName: string,
): { ok: boolean; items: { name: string; label: string; r: number }[] } {
  const isNumericTarget = d.statistics.some((s) => s.name === targetName);
  if (!isNumericTarget) return { ok: false, items: [] };
  const items = d.statistics
    .filter((s) => s.name !== targetName)
    .map((s) => ({ name: s.name, label: s.label, r: correlation(d, targetName, s.name) }));
  return { ok: true, items };
}

// 수치형 변수 상관행렬 — { labels, values }.
// 성능: 컬럼별 숫자 배열을 한 번만 추출하고 상삼각만 계산해 대칭 복사(O(C²·R) 1패스).
// 컬럼이 매우 많으면(원-핫 등) C²로 폭발하므로 상위 maxCols개로 제한한다.
export function correlationMatrix(d: Dataset, maxCols = 20): {
  labels: string[];
  values: number[][];
  truncated: number; // 표시에서 제외된 컬럼 수(0이면 전체)
} {
  const all = d.statistics.map((s) => ({ name: s.name, label: s.label }));
  const cols = all.slice(0, maxCols);
  const labels = cols.map((c) => c.label);
  const C = cols.length;
  const R = d.rows.length;

  // 컬럼별 숫자 배열(결측은 NaN) 1회 추출
  const data: Float64Array[] = cols.map((c) => {
    const arr = new Float64Array(R);
    for (let i = 0; i < R; i++) {
      const v = d.rows[i][c.name];
      arr[i] = typeof v === 'number' ? v : NaN;
    }
    return arr;
  });

  const corr = (a: Float64Array, b: Float64Array): number => {
    let n = 0;
    let sx = 0;
    let sy = 0;
    let sxx = 0;
    let syy = 0;
    let sxy = 0;
    for (let i = 0; i < R; i++) {
      const x = a[i];
      const y = b[i];
      if (Number.isNaN(x) || Number.isNaN(y)) continue;
      n++;
      sx += x;
      sy += y;
      sxx += x * x;
      syy += y * y;
      sxy += x * y;
    }
    if (n < 2) return 0;
    const cov = sxy - (sx * sy) / n;
    const vx = sxx - (sx * sx) / n;
    const vy = syy - (sy * sy) / n;
    const denom = Math.sqrt(vx * vy);
    return denom === 0 ? 0 : Math.round((cov / denom) * 100) / 100;
  };

  const values: number[][] = Array.from({ length: C }, () => new Array(C).fill(1));
  for (let i = 0; i < C; i++) {
    for (let j = i + 1; j < C; j++) {
      const r = corr(data[i], data[j]);
      values[i][j] = r;
      values[j][i] = r;
    }
  }
  return { labels, values, truncated: all.length - C };
}

// 그룹별 평균/중앙값 — { group, mean, median }[]
export function groupMeanData(d: Dataset, catName: string, numName: string) {
  const groups = new Map<string, number[]>();
  for (const r of d.rows) {
    const g = String(r[catName] ?? '(없음)');
    const v = r[numName];
    if (typeof v !== 'number') continue;
    const arr = groups.get(g) ?? [];
    arr.push(v);
    groups.set(g, arr);
  }
  // Smart Label: 그룹(범주)명을 친화 라벨로 치환(평균/중앙값 계산은 불변)
  const col = d.columns.find((c) => c.name === catName);
  const labelMap = col ? smartLabelMap(col, [...groups.keys()]) : new Map<string, string>();
  return Array.from(groups.entries())
    .map(([group, arr]) => {
      const sorted = [...arr].sort((a, b) => a - b);
      const mean = arr.reduce((s, v) => s + v, 0) / arr.length;
      const median = quantile(sorted, 0.5);
      return {
        group: labelMap.get(group) ?? group,
        mean: Math.round(mean * 10) / 10,
        median: Math.round(median * 10) / 10,
      };
    })
    .sort((a, b) => b.mean - a.mean)
    .slice(0, 12);
}
