import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import type { Row } from '../types';

// 데이터 파일 내보내기(다운로드) — 시각화 화면 하단의 "전처리 데이터 저장"에서 사용.

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function downloadCsv(rows: Row[], filename = 'processed_data.csv') {
  const csv = Papa.unparse(rows);
  // BOM 추가 → Excel에서 한글 깨짐 방지
  triggerDownload(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8;' }), filename);
}

export function downloadXlsx(rows: Row[], filename = 'processed_data.xlsx') {
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'data');
  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' }) as ArrayBuffer;
  triggerDownload(
    new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
    filename,
  );
}
