// 저수준 인증 API 호출 — 토큰 자동 주입/401 인터셉트를 "타지 않는" 원시 호출.
// (refresh 요청이 다시 401 인터셉트를 타 무한루프가 되는 것을 막기 위해 compute/api.ts 와 분리)
// 백엔드 스키마: backend/app/schemas_auth.py 의 TokenResponse / UserOut 과 일치.

import { apiBase } from '../http';

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
}

export interface AuthUser {
  id: string;
  email: string;
  username: string | null;
  role: 'admin' | 'instructor' | 'member';
  organization_id: string | null;
  group_id: string | null;
  auth_provider: string;
  is_active: boolean;
  must_change_password: boolean;
  created_at: string;
  last_login_at: string | null;
}

// POST /auth/login — 백엔드가 OAuth2PasswordRequestForm(form-urlencoded)을 받는다.
export async function loginRequest(email: string, password: string): Promise<TokenResponse> {
  const body = new URLSearchParams({ username: email, password });
  const res = await fetch(`${apiBase()}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!res.ok) {
    // 상태 코드로 고정 한글 메시지 매핑(백엔드 detail 원문 대신 일관 처리).
    if (res.status === 403) throw new Error('비활성화된 계정입니다. 담당자에게 문의하세요.');
    throw new Error(
      res.status === 401 ? '이메일 또는 비밀번호가 올바르지 않습니다.' : `로그인 실패(HTTP ${res.status})`,
    );
  }
  return (await res.json()) as TokenResponse;
}

// POST /auth/refresh — refresh 원문 → 새 access + 새 refresh(회전).
export async function refreshRequest(refreshToken: string): Promise<TokenResponse> {
  const res = await fetch(`${apiBase()}/auth/refresh`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  if (!res.ok) throw new Error(`리프레시 실패(HTTP ${res.status})`);
  return (await res.json()) as TokenResponse;
}

// POST /auth/logout — refresh 폐기(best-effort; 실패해도 클라이언트는 로컬 상태를 비운다).
export async function logoutRequest(refreshToken: string): Promise<void> {
  try {
    await fetch(`${apiBase()}/auth/logout`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
  } catch {
    /* 네트워크 실패는 무시 — 로컬 상태 초기화가 우선 */
  }
}

// POST /auth/change-password — Bearer access 필요. 성공 시 {"status":"ok"}(새 토큰 없음).
//  · 강제 모드(must_change_password=true): currentPassword 불요.
//  · 일반 모드: currentPassword 필수(백엔드가 검증).
//  변경 성공 시 백엔드가 기존 refresh 를 전량 폐기 → 호출부는 재로그인을 유도한다.
export async function changePasswordRequest(
  accessToken: string,
  newPassword: string,
  currentPassword?: string,
): Promise<void> {
  const res = await fetch(`${apiBase()}/auth/change-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` },
    body: JSON.stringify({ new_password: newPassword, current_password: currentPassword ?? null }),
  });
  if (!res.ok) {
    let msg = `비밀번호 변경 실패(HTTP ${res.status})`;
    try {
      const j = (await res.json()) as { detail?: string };
      if (j?.detail) msg = j.detail;
    } catch {
      /* 본문 파싱 실패 시 기본 메시지 */
    }
    throw new Error(msg);
  }
}

// GET /auth/me — Bearer access → 사용자 정보.
export async function meRequest(accessToken: string): Promise<AuthUser> {
  const res = await fetch(`${apiBase()}/auth/me`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`사용자 정보 조회 실패(HTTP ${res.status})`);
  return (await res.json()) as AuthUser;
}
