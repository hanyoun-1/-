// 런타임 설정 로더 — "빌드 1개로 고객별 환경 대응"을 위해 public/config.json 을 앱 시작 시 1회 로드한다.
//
// 우선순위: config.json 값 > 빌드타임 VITE_ 환경변수 > 하드코딩 기본값.
//   - 빈 문자열/undefined/유효하지 않은 값은 "미설정"으로 보고 다음 우선순위로 넘어간다.
//   - config.json 이 없거나 로드 실패해도 조용히 무시하고 폴백 → 안전한 기본값으로 동작.
//
// 계산 위치 설정(COMPUTE_MODE·SIZE_THRESHOLD_*)은 제거했다. 학습·예측은 항상 백엔드가 수행한다
// (프론트+백엔드 세트 배포 전제) → 남는 설정은 백엔드 주소와 타임아웃뿐이다.

export interface RuntimeConfig {
  API_BASE_URL: string; // '' = same-origin
  API_TIMEOUT_MS: number;
}

const DEFAULTS: RuntimeConfig = {
  API_BASE_URL: '',
  // 120초: LSTM 무거운 조합(window100·hidden256·layers3)이 최대 2분까지 걸린다(다른 모델은 초 단위).
  API_TIMEOUT_MS: 120_000,
};

let fromFile: Partial<RuntimeConfig> = {};
let loaded = false;

const trimStr = (v: unknown): string | undefined => (typeof v === 'string' && v.trim() !== '' ? v.trim() : undefined);
const posNum = (v: unknown): number | undefined => {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) && n > 0 ? n : undefined;
};

// 개발 모드 여부(Vite가 정적 치환: vite dev=true / vite build=false).
//   dev 에서만 VITE_(.env.development.local)를 config.json 보다 우선한다(로컬 개발 편의).
//   build 경로에선 항상 false → 아래 pick 호출이 기존과 동일한 (config.json > VITE_ > default) 순서로 동작.
const DEV = import.meta.env.DEV;

// 우선순위 병합 헬퍼 — 두 후보 중 유효한 첫 값을 채택(순서는 호출부에서 결정).
//   두 번째 인자 타입을 unknown 으로 둬(내부 trimStr/posNum/isMode 가 unknown 을 받음) 호출부에서 자유롭게 스왑 가능.
function pickStr(a: unknown, b: unknown, def: string): string {
  return trimStr(a) ?? trimStr(b) ?? def;
}
function pickNum(a: unknown, b: unknown, def: number): number {
  return posNum(a) ?? posNum(b) ?? def;
}
/* ───────────── 진단 로그 (병합/폴백 동작은 바꾸지 않음 — 경고·요약만) ───────────── */

const LOG = '[config]';
type Source = 'file' | 'env' | 'default';

// config.json 에 실제로 들어온 값만 검증해 경고한다(폴백은 getConfig가 그대로 수행).
function validateFile(raw: Record<string, unknown>): void {
  const numFields: [string, string][] = [['API_TIMEOUT_MS', 'API 타임아웃(ms)']];
  for (const [key, label] of numFields) {
    if (raw[key] !== undefined && posNum(raw[key]) === undefined) {
      console.warn(`${LOG} 잘못된 ${key}(${label})=${JSON.stringify(raw[key])} — 0보다 큰 숫자여야 합니다. env/기본값으로 폴백합니다.`);
    }
  }
  const api = raw.API_BASE_URL;
  if (typeof api === 'string' && api.trim() !== '' && !/^https?:\/\//i.test(api.trim())) {
    // 폴백하지 않고 경고만(같은 오리진 상대경로일 수 있음).
    console.warn(`${LOG} API_BASE_URL=${JSON.stringify(api)} 가 http(s):// 로 시작하지 않습니다. same-origin 상대경로가 아니라면 오타인지 확인하세요. (값은 그대로 사용)`);
  }
}

// 각 필드가 어느 소스에서 채택됐는지(요약용). getConfig의 pick 규칙과 동일 기준(dev면 env 우선).
const srcStr = (cfg: unknown, env: unknown): Source =>
  DEV
    ? (trimStr(env) !== undefined ? 'env' : trimStr(cfg) !== undefined ? 'file' : 'default')
    : (trimStr(cfg) !== undefined ? 'file' : trimStr(env) !== undefined ? 'env' : 'default');
const srcNum = (cfg: unknown, env: unknown): Source =>
  DEV
    ? (posNum(env) !== undefined ? 'env' : posNum(cfg) !== undefined ? 'file' : 'default')
    : (posNum(cfg) !== undefined ? 'file' : posNum(env) !== undefined ? 'env' : 'default');
function logSummary(fileFound: boolean): void {
  const env = import.meta.env;
  const c = getConfig();
  const parts = [
    `API_BASE_URL=${c.API_BASE_URL || '(same-origin)'}(${srcStr(fromFile.API_BASE_URL, env.VITE_API_BASE_URL)})`,
    `TIMEOUT_MS=${c.API_TIMEOUT_MS}(${srcNum(fromFile.API_TIMEOUT_MS, env.VITE_API_TIMEOUT_MS)})`,
  ];
  const note = fileFound ? '' : ' · config.json 없음 → env/기본값 사용';
  console.info(`${LOG} 적용 설정: ${parts.join(', ')}${note}`);
}

// 앱 시작 시 1회 호출(main.tsx). 실패해도 throw 하지 않는다.
export async function loadRuntimeConfig(): Promise<void> {
  if (loaded) return;
  let fileFound = false;
  try {
    const base = import.meta.env.BASE_URL ?? '/';
    const res = await fetch(`${base}config.json`, { cache: 'no-store' });
    if (res.ok) {
      const json = (await res.json()) as unknown;
      if (json && typeof json === 'object') {
        fromFile = json as Partial<RuntimeConfig>;
        fileFound = true;
      }
    }
  } catch {
    // 파일 없음/네트워크 오류 → 무시하고 VITE_/기본값으로 폴백
  } finally {
    loaded = true;
  }
  // 로드된 파일 값만 검증(정상이면 warn 없음). 마지막에 소스 요약 1줄.
  if (fileFound) validateFile(fromFile as Record<string, unknown>);
  logSummary(fileFound);
}

// 병합된 설정을 동기 반환. (loadRuntimeConfig 이전에 호출되면 VITE_/기본값 기준으로 안전 폴백)
export function getConfig(): RuntimeConfig {
  const env = import.meta.env;
  // dev(DEV=true): VITE_ 를 앞에 둬 config.json 보다 우선. build(DEV=false): 기존 순서(config.json 우선) 그대로.
  const s = (cfg: unknown, e: unknown, def: string): string => (DEV ? pickStr(e, cfg, def) : pickStr(cfg, e, def));
  const n = (cfg: unknown, e: unknown, def: number): number => (DEV ? pickNum(e, cfg, def) : pickNum(cfg, e, def));
  return {
    API_BASE_URL: s(fromFile.API_BASE_URL, env.VITE_API_BASE_URL, DEFAULTS.API_BASE_URL),
    API_TIMEOUT_MS: n(fromFile.API_TIMEOUT_MS, env.VITE_API_TIMEOUT_MS, DEFAULTS.API_TIMEOUT_MS),
  };
}
