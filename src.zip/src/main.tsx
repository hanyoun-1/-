import React from 'react';
import ReactDOM from 'react-dom/client';
import AuthGate from './features/auth/AuthGate';
import ErrorBoundary from './components/ErrorBoundary';
import './index.css';
import { useDatasetStore } from './store/useDatasetStore';
import { STEPS, useStepStore } from './store/useStepStore';
import { useAuthStore } from './store/useAuthStore';
import { loadRuntimeConfig } from './lib/config/runtimeConfig';

void (async () => {
  // 1) 런타임 설정 확정 후 렌더. config.json은 로컬 파일이라 빠르고, 없거나 실패해도
  //    조용히 폴백(VITE_/기본값)되어 렌더가 진행된다 → 기존 동작과 동일.
  await loadRuntimeConfig();

  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <ErrorBoundary>
        <AuthGate />
      </ErrorBoundary>
    </React.StrictMode>,
  );

  // 2) 세션 복구: 저장된 refresh 토큰이 있으면 access 재발급 + 사용자 로드(비차단).
  //    refresh 토큰이 없으면 네트워크 호출 없이 즉시 종료 → 비로그인 상태 유지(기존 화면 그대로).
  void useAuthStore.getState().loadMe();

  // 3) IndexedDB 데이터 복원은 렌더 후 백그라운드에서 진행(첫 페인트 비차단).
  await useDatasetStore.getState().hydrateDataset();
  // 복원 후 단계 보정: 데이터 없거나(=업로드 전) 옛 단계가 저장돼 있으면 정리.
  const validStep = STEPS.some((s) => s.id === useStepStore.getState().current);
  if (!useDatasetStore.getState().dataset || !validStep) {
    useStepStore.getState().goto(useDatasetStore.getState().dataset ? 'overview' : 'upload');
  }
})();
