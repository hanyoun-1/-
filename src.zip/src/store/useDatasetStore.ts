import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AppliedStep, DashboardItem, Dataset, ManualChart, PreprocessStep, Row } from '../types';
import type { PredictionContext } from '../lib/models';
import { profileDataset } from '../lib/profile';
import { applySteps, stepLog, typeOverridesFromSteps } from '../lib/preprocess';
import { useStepStore } from './useStepStore';
import { generateSampleRows, SAMPLE_FILE_NAME } from '../data/sampleCustomers';
import { saveDataset, loadDataset, clearDataset as clearDatasetIDB, saveDashboardSnapshots, loadDashboardSnapshots } from '../lib/idb';

// 대시보드 차트 "추가 시점 고정" 스냅샷 — 차트가 쓰는 컬럼만 담아 크기를 줄인 Dataset.
//   전처리를 바꿔도 이미 담은 차트는 이 스냅샷으로 그려 안 바뀐다. 히트맵은 상관행렬이라 전 수치형 컬럼 필요.
function subsetDataset(active: Dataset | null, item: DashboardItem): Dataset | undefined {
  if (!active) return undefined;
  const need = new Set<string>();
  for (const c of [item.v1, item.v2, item.cat, item.date]) if (c) need.add(c);
  if (item.agg && item.agg !== '개수') need.add(item.agg); // 막대 집계(평균) 대상 수치 컬럼
  if (item.chart === 'heatmap') for (const s of active.statistics) need.add(s.name); // 상관행렬=전 수치형
  if (!need.size) return active; // 사용 컬럼 불명 → 전체 스냅샷(안전 폴백)
  const columns = active.columns.filter((c) => need.has(c.name));
  const rows = active.rows.map((r) => { const o: Row = {}; for (const c of columns) o[c.name] = r[c.name]; return o; });
  const statistics = active.statistics.filter((s) => need.has(s.name));
  return { ...active, rows, columns, statistics, colCount: columns.length };
}

// dashboardItems 에서 {id: snapshot} 맵을 뽑아 IndexedDB 에 저장(스냅샷 있는 아이템만).
function persistSnapshots(items: DashboardItem[]): void {
  const map: Record<string, Dataset> = {};
  for (const it of items) if (it.snapshot) map[it.id] = it.snapshot;
  void saveDashboardSnapshots(map).catch(() => {});
}

// 원본 rows + 전처리 스텝 → 파생 activeDataset 을 만든다(모든 화면이 이것을 읽음).
function deriveActive(original: Dataset, steps: AppliedStep[]): Dataset {
  if (!steps.length) return original;
  const plain = steps.map((s) => s.step);
  const rows = applySteps(original.rows, plain);
  const { types, dateFormats } = typeOverridesFromSteps(plain);
  return profileDataset(original.fileName, rows, types, dateFormats);
}

// 리포트 저장 경량화(U1) — 영속화 시 용량 폭증·IndexedDB 중복을 피한다.
//   · dataset 에서 대용량 rows 만 제거(컬럼 메타/통계/품질은 유지 → 라벨 등 다시보기에 필요).
//   · 원본 dataset 은 불변 — 항상 새 객체를 만든다(라이브 데이터 오염 금지).
//   결과 복원용 필드(reg/cls·task·target·features·algo·label·id)는 그대로 보존한다.
//   (학습이 전부 백엔드로 옮겨간 뒤로 결과에는 예측 클로저가 아예 없다 — 예측은 model_id 로 원격 호출.)
function lightenReport(ctx: PredictionContext): PredictionContext {
  return {
    ...ctx,
    dataset: { ...ctx.dataset, rows: [] },
  };
}

const EMPTY = {
  dataset: null as Dataset | null,
  activeDataset: null as Dataset | null,
  steps: [] as AppliedStep[],
  manualChart: 'histogram' as ManualChart,
  dashboardItems: [] as DashboardItem[],
  predictionReports: [] as PredictionContext[],
  mergeApplied: false, // 이번 세션에 병합이 적용됐는지(병합 화면의 편집·시각화·안내 노출 조건)
  mergedResetSteps: 0, // 마지막 병합 승격 시 병합본에 접혀 초기화된 전처리 단계 수(안내 표시용)
};

interface DatasetState {
  hydrated: boolean; // IndexedDB 복원 시도 완료 여부(앱 시작 로딩 표시용)
  dataset: Dataset | null; // 원본(불변)
  activeDataset: Dataset | null; // 전처리 반영 파생본 — 모든 화면이 사용
  steps: AppliedStep[];
  manualChart: ManualChart; // 시각화 단일차트 선택
  dashboardItems: DashboardItem[]; // 시각화 대시보드에 담은 차트
  predictionReports: PredictionContext[]; // 결과 리포트에 담은 예측 모델
  mergeApplied: boolean; // 이번 세션에 병합이 적용됐는지(병합 화면 편집·시각화·안내 노출 조건)
  mergedResetSteps: number; // 마지막 병합 승격 시 초기화된 전처리 단계 수(안내 표시 조건)

  loadRows: (fileName: string, rows: Row[]) => void;
  loadSample: () => void;
  hydrateDataset: () => Promise<void>;
  deleteData: () => void;
  resetProject: () => void;

  addStep: (step: PreprocessStep) => void;
  undoStep: () => void;
  resetSteps: () => void;

  setManualChart: (c: ManualChart) => void;
  addDashboardItem: (item: DashboardItem) => void;
  removeDashboardItem: (id: string) => void;
  clearDashboard: () => void;
  addPredictionReport: (ctx: PredictionContext) => void;
  removePredictionReport: (id: string) => void;
  clearPredictionReports: () => void;
  setMergedBase: (d: Dataset | null) => void;
}

export const useDatasetStore = create<DatasetState>()(
  persist(
    (set, get) => ({
      ...EMPTY,
      hydrated: false,

      loadRows: (fileName, rows) => {
        const dataset = profileDataset(fileName, rows);
        set({
          dataset,
          activeDataset: dataset,
          steps: [],
          manualChart: 'histogram',
          dashboardItems: [],
          predictionReports: [],
          mergeApplied: false,
          mergedResetSteps: 0,
        });
        void saveDataset(dataset).catch(() => {});
        persistSnapshots([]); // 새 데이터 업로드 → 대시보드 초기화되므로 고정 스냅샷도 비운다
      },

      loadSample: () => get().loadRows(SAMPLE_FILE_NAME, generateSampleRows()),

      hydrateDataset: async () => {
        if (get().dataset) {
          set({ hydrated: true });
          return;
        }
        try {
          const stored = await loadDataset();
          if (stored && !get().dataset) {
            const dataset =
              Array.isArray(stored.rows) && stored.rows.length
                ? profileDataset(stored.fileName, stored.rows)
                : stored;
            // 저장된 스텝(localStorage)을 원본에 다시 적용해 activeDataset 복원
            set({ dataset, activeDataset: deriveActive(dataset, get().steps ?? []) });
          }
          // 대시보드 고정 스냅샷 복원 → 담긴 차트가 추가 시점 그대로 유지되도록 attach(새로고침 후에도 불변).
          const snaps = await loadDashboardSnapshots();
          if (Object.keys(snaps).length) {
            set((s) => ({ dashboardItems: s.dashboardItems.map((it) => (snaps[it.id] ? { ...it, snapshot: snaps[it.id] } : it)) }));
          }
        } catch {
          /* 복원 실패 → 업로드부터 */
        } finally {
          set({ hydrated: true });
        }
      },

      deleteData: () => {
        set({ ...EMPTY });
        void clearDatasetIDB().catch(() => {});
        persistSnapshots([]); // 대시보드 고정 스냅샷도 함께 정리
        useStepStore.getState().reset();
      },

      resetProject: () => {
        set({ ...EMPTY });
        void clearDatasetIDB().catch(() => {});
        persistSnapshots([]); // 대시보드 고정 스냅샷도 함께 정리
        useStepStore.getState().reset();
      },

      addStep: (step) => {
        const { dataset, steps } = get();
        if (!dataset) return;
        const nextSteps = [...steps, { step, log: stepLog(step) }];
        set({ steps: nextSteps, activeDataset: deriveActive(dataset, nextSteps) });
      },

      undoStep: () => {
        const { dataset, steps } = get();
        if (!dataset || !steps.length) return;
        const nextSteps = steps.slice(0, -1);
        set({ steps: nextSteps, activeDataset: deriveActive(dataset, nextSteps) });
      },

      resetSteps: () => {
        const { dataset } = get();
        if (!dataset) return;
        set({ steps: [], activeDataset: dataset });
      },

      setManualChart: (c) => set({ manualChart: c }),
      // 추가 시점의 activeDataset 을 컬럼-서브셋 스냅샷으로 고정해 담는다(전처리 바뀌어도 불변). 스냅샷은 IndexedDB 에 영속화.
      addDashboardItem: (item) => {
        const withSnap: DashboardItem = { ...item, snapshot: subsetDataset(get().activeDataset, item) };
        const items = [...get().dashboardItems, withSnap];
        set({ dashboardItems: items });
        persistSnapshots(items);
      },
      removeDashboardItem: (id) => {
        const items = get().dashboardItems.filter((it) => it.id !== id);
        set({ dashboardItems: items });
        persistSnapshots(items);
      },
      clearDashboard: () => { set({ dashboardItems: [] }); persistSnapshots([]); },
      addPredictionReport: (ctx) => set((s) => ({ predictionReports: [...s.predictionReports, lightenReport(ctx)] })),
      removePredictionReport: (id) => set((s) => ({ predictionReports: s.predictionReports.filter((p) => p.id !== id) })),
      clearPredictionReports: () => set({ predictionReports: [] }),

      // 병합 결과를 기준 데이터로 자동 승격 → 개요·기초 통계·시각화·예측·결과 리포트 등 모든 화면(activeDataset)이 바로 쓴다.
      //   병합 화면의 편집·시각화는 별도 파이프라인 없이 메인(steps/dashboardItems)을 공유하므로, 여기서는 '승격'만 하면 된다.
      //   MergePanel 의 base 는 이미 전처리가 반영된 activeDataset → 병합본에 baked-in, 메인 steps 는 비워 이중 적용을 막는다.
      //   d=null(병합 실패/해제)이면 메인 데이터는 건드리지 않고 병합 표시 상태만 정리(실패가 기존 데이터를 지우지 않게 방어).
      //   dashboardItems/predictionReports 는 보존(담은 차트·예측 리포트가 남도록).
      setMergedBase: (d) => {
        if (!d) {
          set({ mergeApplied: false, mergedResetSteps: 0 });
          return;
        }
        // get().steps.length 는 set() 적용 전(=승격 직전) 값 → 병합본에 접혀 초기화되는 전처리 단계 수를 캡처.
        set({ dataset: d, activeDataset: d, steps: [], mergeApplied: true, mergedResetSteps: get().steps.length });
        void saveDataset(d).catch(() => {});
      },
    }),
    {
      name: 'eda-dataset',
      // 데이터 본문(rows)은 IndexedDB. localStorage 에는 경량 상태 + 전처리 스텝만 보존.
      //   predictionReports 는 lightenReport 로 rows 를 제거해 저장하므로 경량이다(새로고침 후 유지, U1).
      version: 1,
      partialize: (s) => ({
        steps: s.steps,
        manualChart: s.manualChart,
        // 고정 스냅샷(rows 포함)은 용량 때문에 localStorage 에 넣지 않는다 → snapshot 만 제거(IndexedDB 로 별도 영속화).
        dashboardItems: s.dashboardItems.map((it) => ({ ...it, snapshot: undefined })),
        predictionReports: s.predictionReports,
        // mergeApplied 는 저장하지 않는다 — 편집·시각화 섹션은 데이터(activeDataset) 기준으로 항상 노출되고,
        //   이 플래그는 '방금 병합함' 배너 전용(전환형)이라 새로고침 후엔 꺼지는 게 자연스럽다(메모리 only).
      }),
    },
  ),
);
