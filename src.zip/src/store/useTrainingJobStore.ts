import { create } from 'zustand';
import type { ClsResult, RegResult } from '../lib/models';
import type { ModelSpec, ParamValues } from '../lib/compute';

// 학습 결과 객체 — 예측 화면(PredictPage)이 결과 렌더·새값 예측에 쓴다.
//   ⚠ predict/probaFn 은 클로저(model_id 로 원격 호출)라 직렬화 불가 → 이 store 는 메모리 전용(persist 안 함).
//     페이지 이동(언마운트)에는 살아남지만 새로고침엔 사라진다(범위: 전역 store 로 충분, localStorage 제외).
export interface Trained {
  isReg: boolean;
  features: string[];
  means: number[];
  predict: (x: number[]) => number | string | Promise<number | string>;
  probaFn?: (X: number[][]) => number[][] | Promise<number[][]>;
  reg?: RegResult;
  cls?: ClsResult;
  serverModelId?: string; // 서버 학습 시 model_id (예측 방식 판별·디버깅용)
  usedParams?: ParamValues; // 수동 튜닝(knn 등) 시 서버가 에코한 최종 사용값
  bestParams?: ParamValues; // 자동 튜닝(Optuna) 시 서버가 찾은 best_params(투명성 표시용)
  paramSpec?: ModelSpec; // usedParams 를 한글 라벨로 포맷하기 위한 명세(결과 표시용)
  scaled?: boolean; // 실제 적용된 표준화 여부(W2). 미해당 모델은 undefined.
  timeCol?: string; // LSTM 등 시간순 정렬에 쓴 '시간 순서 기준 컬럼'(결과 투명성 표시용)
  timeLabels?: string[]; // 시간순 분할 시 테스트 구간의 시간 컬럼 원본값(시간축 그래프 x축 라벨용). 복원 경로에선 없음(순번 폴백).
}

// 학습을 시작한 '맥락' — 복귀 시 결과를 올바른 화면 상태로 재구성하고, 데이터셋이 바뀌었는지 판정한다.
export interface TrainingJobCtx {
  datasetKey: string; // 데이터셋 지문(fileName#행수#열수) — 복귀 시 옛 결과 오박음 방지용 불일치 판정
  task: 'reg' | 'cls';
  algo: string; // 사용한 알고리즘(reg=RegAlgo / cls=ClsAlgo 키)
  target: string;
  features: string[];
  means: number[]; // 학습에 쓴 입력 평균(예측 입력 기본값 복원용) — 데이터 파생값이라 함께 보관
  n: number; // 학습 행수(X.length) — 결과 표시용
  testRatio: number;
  tune: boolean;
  scale?: boolean;
  sequentialSplit: boolean;
  timeCol?: string; // 시간순 정렬 기준 컬럼(seqSend && curTimeCol)
  params?: ParamValues; // 명세 있는 모델의 수동 하이퍼파라미터(panelSpec 있을 때만)
}

export interface JobProgress {
  done: number;
  total: number;
  best: number | null;
}

interface TrainingJobState {
  jobId: string | null; // 진행 중(폴링 대상) 비동기 job. 완료·정리 후엔 null.
  ctx: TrainingJobCtx | null; // 진행 중/완료 결과의 학습 맥락(복원·불일치 판정). 정리 전까지 유지.
  progress: JobProgress | null; // 마지막 진행률(복귀 즉시 표시용)
  result: Trained | null; // 완료된 결과(메모리) — 복귀 시 네트워크 없이 그대로 복원

  // 학습 시작(jobId 확보 시): 이전 상태를 싹 비우고 진행 중으로 세팅.
  startJob: (jobId: string, ctx: TrainingJobCtx) => void;
  setProgress: (p: JobProgress) => void;
  // 학습 완료: jobId·progress 는 비우고 결과만 보관(ctx 유지 → 복귀 시 맥락·불일치 판정).
  completeJob: (result: Trained) => void;
  // 취소·실패·데이터 변경 → 전부 비운다(다음 학습에 잔재 없게).
  clearJob: () => void;
}

// ⚠ persist 미사용 — 메모리 전용. 페이지 이동(PredictPage 언마운트)에는 살아남고, 새로고침엔 초기화된다.
export const useTrainingJobStore = create<TrainingJobState>((set) => ({
  jobId: null,
  ctx: null,
  progress: null,
  result: null,
  startJob: (jobId, ctx) => set({ jobId, ctx, progress: null, result: null }),
  setProgress: (progress) => set({ progress }),
  completeJob: (result) => set({ jobId: null, progress: null, result }),
  clearJob: () => set({ jobId: null, ctx: null, progress: null, result: null }),
}));
