import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { StepId } from '../types';

// 흐름: 업로드 → 데이터 개요 → 기초 통계 → 전처리 → 시각화 → 병합 → 예측 → 리포트
export const STEPS: { id: StepId; label: string }[] = [
  { id: 'upload', label: '데이터 업로드' },
  { id: 'overview', label: '데이터 개요' },
  { id: 'statistics', label: '기초 통계' },
  { id: 'preprocess', label: '전처리' },
  { id: 'visualize', label: '시각화' },
  { id: 'merge', label: '데이터 병합' },
  { id: 'predict', label: '예측 분석' },
  { id: 'report', label: '결과 리포트' },
];

interface StepState {
  current: StepId;
  maxReached: number;
  goto: (id: StepId) => void;
  next: () => void;
  prev: () => void;
  reset: () => void;
}

const indexOf = (id: StepId) => STEPS.findIndex((s) => s.id === id);

export const useStepStore = create<StepState>()(
  persist(
    (set, get) => ({
      current: 'upload',
      maxReached: 0,
      goto: (id) => {
        const idx = indexOf(id);
        set({ current: id, maxReached: Math.max(get().maxReached, idx) });
      },
      next: () => {
        const idx = Math.min(indexOf(get().current) + 1, STEPS.length - 1);
        set({ current: STEPS[idx].id, maxReached: Math.max(get().maxReached, idx) });
      },
      prev: () => {
        const idx = Math.max(indexOf(get().current) - 1, 0);
        set({ current: STEPS[idx].id });
      },
      reset: () => set({ current: 'upload', maxReached: 0 }),
    }),
    {
      name: 'eda-step',
      partialize: (s) => ({ current: s.current, maxReached: s.maxReached }),
    },
  ),
);
