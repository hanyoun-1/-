import { create } from 'zustand';

type Theme = 'light' | 'dark';

function getInitial(): Theme {
  const saved = localStorage.getItem('eda-theme') as Theme | null;
  if (saved) return saved;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function apply(theme: Theme) {
  document.documentElement.classList.toggle('dark', theme === 'dark');
  localStorage.setItem('eda-theme', theme);
}

interface ThemeState {
  theme: Theme;
  toggle: () => void;
  set: (t: Theme) => void;
}

export const useThemeStore = create<ThemeState>((set, get) => {
  const initial = getInitial();
  apply(initial);
  return {
    theme: initial,
    toggle: () => {
      const next = get().theme === 'dark' ? 'light' : 'dark';
      apply(next);
      set({ theme: next });
    },
    set: (t) => {
      apply(t);
      set({ theme: t });
    },
  };
});
