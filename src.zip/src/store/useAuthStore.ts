// 인증 상태 store — access(메모리) + refresh(localStorage persist) + user(/auth/me).
//
// 보관 위치 트레이드오프:
//  · accessToken: 메모리 전용(persist 안 함). 짧은 만료 → 새로고침 시 refresh 로 재발급.
//  · refreshToken: localStorage persist → 새로고침 후 세션 유지. 단 XSS 에 노출될 수 있음.
//    이상적으로는 httpOnly 쿠키지만 백엔드가 JSON 으로 refresh 를 반환하므로 현 단계에선 localStorage.
//    (백엔드가 쿠키 방식으로 바뀌면 이 저장을 제거하고 쿠키로 이관)

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

import { registerAuthHooks } from '../lib/http';
import {
  loginRequest,
  logoutRequest,
  meRequest,
  refreshRequest,
  type AuthUser,
} from '../lib/auth/authApi';

interface AuthState {
  user: AuthUser | null;
  accessToken: string | null;
  refreshToken: string | null;
  loading: boolean;
  initializing: boolean; // 앱 시작 시 세션 복구(loadMe) 진행 중 — 라우팅 가드 깜빡임 방지
  sessionExpired: boolean; // refresh 실패로 세션이 끊긴 경우 — 로그인 화면 안내용

  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  loadMe: () => Promise<void>;
  // 내부: refresh 로 새 access 발급(성공 시 토큰, 실패 시 null + 상태 초기화).
  _refresh: () => Promise<string | null>;
  clear: () => void;
  // 인증 만료(refresh 실패) — 상태 초기화 + 만료 플래그(로그인 화면에서 안내).
  notifyExpired: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      loading: false,
      initializing: true,
      sessionExpired: false,

      login: async (email, password) => {
        set({ loading: true, sessionExpired: false }); // 새 로그인 시 만료 안내 해제
        try {
          const t = await loginRequest(email, password);
          set({ accessToken: t.access_token, refreshToken: t.refresh_token });
          const me = await meRequest(t.access_token);
          set({ user: me });
        } finally {
          set({ loading: false });
        }
      },

      logout: async () => {
        const rt = get().refreshToken;
        if (rt) await logoutRequest(rt);
        get().clear();
      },

      loadMe: async () => {
        try {
          // 세션 복구: 메모리 access 가 없으면(새로고침 직후) refresh 로 먼저 발급.
          let access = get().accessToken;
          if (!access) {
            access = await get()._refresh();
            if (!access) return; // refresh 토큰 없음/무효 → 비로그인 상태 유지
          }
          try {
            set({ user: await meRequest(access) });
          } catch {
            // access 가 무효면 refresh 1회 시도 후 재조회.
            const na = await get()._refresh();
            if (!na) return;
            try {
              set({ user: await meRequest(na) });
            } catch {
              get().clear();
            }
          }
        } finally {
          set({ initializing: false }); // 성공/실패 무관 — 초기화 종료(가드 해제)
        }
      },

      _refresh: async () => {
        const rt = get().refreshToken;
        if (!rt) return null;
        try {
          const t = await refreshRequest(rt);
          set({ accessToken: t.access_token, refreshToken: t.refresh_token });
          return t.access_token;
        } catch {
          get().clear();
          return null;
        }
      },

      clear: () => set({ user: null, accessToken: null, refreshToken: null }),

      notifyExpired: () =>
        set({ user: null, accessToken: null, refreshToken: null, sessionExpired: true }),
    }),
    {
      name: 'eda-auth',
      // refreshToken 만 저장(access·user 는 메모리 전용).
      partialize: (s) => ({ refreshToken: s.refreshToken }),
    },
  ),
);

// 파생 셀렉터 — 로그인 여부.
export const useIsAuthenticated = (): boolean =>
  useAuthStore((s) => s.user != null && s.accessToken != null);

// api 래퍼(compute/api.ts)가 store 를 직접 import 하지 않고 토큰을 얻고 갱신하도록 훅 등록.
registerAuthHooks({
  getAccessToken: () => useAuthStore.getState().accessToken,
  refresh: () => useAuthStore.getState()._refresh(),
  // refresh 실패(만료·폐기·재사용 감지) → 상태 초기화 + 만료 안내 플래그.
  onAuthFailure: () => useAuthStore.getState().notifyExpired(),
});
