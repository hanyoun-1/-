// 관리 화면(기업·그룹) 표시 토글 — 분석 흐름(useStepStore)과 독립.
import { create } from 'zustand';

interface AdminState {
  open: boolean;
  openAdmin: () => void;
  closeAdmin: () => void;
}

export const useAdminStore = create<AdminState>((set) => ({
  open: false,
  openAdmin: () => set({ open: true }),
  closeAdmin: () => set({ open: false }),
}));
