import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Label,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  Treemap,
  XAxis,
  YAxis,
  ZAxis,
} from 'recharts';
import PageHeader from '../../components/PageHeader';
import Card from '../../components/Card';
import Button from '../../components/Button';
import NavFooter from '../../components/NavFooter';
import { useActiveDataset } from '../../hooks/useActiveDataset';
import { useDatasetStore } from '../../store/useDatasetStore';
import { useStepStore } from '../../store/useStepStore';
import {
  barData,
  boxStats,
  boxStatsBy,
  correlation,
  correlationMatrix,
  targetCorrelations,
  groupMeanData,
  stackedAreaData,
  histogramData,
  lineData,
  multiLineData,
  pieData,
  scatterData,
} from '../../lib/charts';
import { chartInsight } from '../../lib/insights';
import type { DashboardItem, Dataset, ManualChart } from '../../types';

// 다중 계열 팔레트 — 앞 8색은 기존 값·순서 고정(파이·막대 등이 [0]·[1]로 참조하므로 절대 변경 금지).
//   뒤 7색은 박스플롯 그룹(최대 15개) 구분용으로 append — 앞 8색과 겹치지 않는 중채도 hue(라이트·다크 공용).
const COLORS = [
  '#4f46e5', '#16a34a', '#f59e0b', '#dc2626', '#7c3aed', '#0891b2', '#db2777', '#65a30d', // 기존 8색(고정)
  '#2563eb', '#0d9488', '#ea580c', '#c026d3', '#f43f5e', '#475569', '#a16207', // 추가 7색: 블루·틸·오렌지·푸시아·로즈·슬레이트·다크골드
];
const labelOf = (d: Dataset, name: string | null) => d.columns.find((c) => c.name === name)?.label ?? name ?? '';

// 막대·히스토그램 그라데이션 — 왼쪽(진함)→오른쪽(연함). 색을 흰색과 t만큼 섞어 밝게(테마 무관).
function mixWhite(hex: string, t: number): string {
  const c = hex.replace('#', '');
  const r = parseInt(c.slice(0, 2), 16), g = parseInt(c.slice(2, 4), 16), b = parseInt(c.slice(4, 6), 16);
  const m = (v: number) => Math.round(v + (255 - v) * t).toString(16).padStart(2, '0');
  return `#${m(r)}${m(g)}${m(b)}`;
}
// 막대 n개에 대해 왼쪽→오른쪽으로 점점 옅어지는 Cell 배열(최대 72%까지 흰색과 혼합).
const gradientCells = (n: number, color: string) =>
  Array.from({ length: n }, (_, i) => <Cell key={i} fill={mixWhite(color, (i / Math.max(n - 1, 1)) * 0.72)} />);

const selectCls = 'rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

// 박스플롯 그룹(X) 후보 상한 — 고유값이 이보다 많은 컬럼은 그룹으로 노출하지 않는다(박스 폭주 방지).
const MAX_GROUP_UNIQUE = 15;
// 히스토그램 값(X) 후보 상한 — 고유값이 이보다 많은 수치형(ID·고분산 등)은 후보에서 제외한다.
const MAX_HIST_UNIQUE = 50;
// 막대 범주(X) 후보 상한 — 고유값이 이보다 많은 컬럼(ID·연속형 등)은 범주 후보에서 제외한다(막대는 상위 12개만 표시).
const MAX_BAR_UNIQUE = 50;

// ── 상관 히트맵 크기 기준 (여기 숫자만 바꾸면 1칸↔2칸 전환·셀 크기 동작이 조정됨) ──
const HM = {
  LABEL_FONT: 12,    // 행/열 라벨 폰트(px)
  LABEL_W_MAX: 160,  // 좌측 라벨열 최대 폭(px) — 초과 시 말줄임(…)
  LABEL_W_MIN: 32,   // 좌측 라벨열 최소 폭(px)
  LABEL_PAD: 10,     // 라벨 텍스트 + 여유(px, 8~12)
  CELL_GAP: 4,       // 셀 간격(px, border-spacing-1)
  MIN_CELL: 40,      // 셀 최소 크기(px) — '-0.01'(셀폰트 ~9px)이 잘리지 않는 크기
  MAX_CELL: 64,      // 셀 최대 크기(px)
  SPLIT_GAP: 20,     // 히트맵–패널 간격(px, 1.25rem — CSS .heatmap-split gap과 일치)
  ASIDE_MIN: 260,    // 오른쪽 패널 최소 폭(px, CSS flex-basis 260px와 일치)
  CARD_PAD: 32,      // 카드(대시보드 칸) 좌우 padding 합(p-4 = 16*2)
  BESIDE_MIN: 640,   // 이 폭(=40rem) 이상이면 패널이 히트맵 오른쪽에 배치(아니면 아래)
  // ── 대시보드에서 '한 줄 전체(span)'로 띄울지 판단 ──
  FULL_COLS: 8,      // 컬럼 수가 이 값 이상이면 무조건 한 줄 전체
  FULL_MIN_CELL: 36, // 한 칸에 넣었을 때(축소 전) 셀 크기가 이보다 작으면 한 줄 전체
  FULL_HYST: 6,      // 셀 크기 경계 떨림 방지 여유(px)
};

// 라벨의 '실제 픽셀 폭' 측정 — 문자수 추정 대신 canvas measureText로 라틴/한글 혼재도 정확히.
let _measureCanvas: HTMLCanvasElement | null = null;
function measureTextWidth(text: string, fontPx: number): number {
  if (typeof document === 'undefined') return text.length * fontPx * 0.6; // SSR 방어
  _measureCanvas = _measureCanvas ?? document.createElement('canvas');
  const ctx = _measureCanvas.getContext('2d');
  if (!ctx) return text.length * fontPx * 0.6;
  ctx.font = `${fontPx}px Pretendard, Inter, system-ui, sans-serif`;
  return ctx.measureText(text).width;
}

// 좌측 라벨열 너비 = 가장 긴 라벨의 실제 폭 + 여유, [MIN, MAX] 로 클램프.
function labelColWidth(labels: string[], fontPx = HM.LABEL_FONT): number {
  const maxW = labels.reduce((m, l) => Math.max(m, measureTextWidth(l, fontPx)), 0);
  return Math.min(HM.LABEL_W_MAX, Math.max(HM.LABEL_W_MIN, Math.round(maxW) + HM.LABEL_PAD));
}

// 요소의 '실제 폭'을 디바운스(기본 100ms)로 추적 — 리사이즈 시 깜빡임 방지. 히트맵·박스플롯 공용.
function useElementWidth<T extends Element>(fallback = 0, delay = 100) {
  const ref = useRef<T | null>(null);
  const [w, setW] = useState(fallback);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let t: ReturnType<typeof setTimeout>;
    const ro = new ResizeObserver((e) => {
      const nw = e[0].contentRect.width;
      clearTimeout(t);
      t = setTimeout(() => setW(nw || fallback), delay);
    });
    ro.observe(el);
    return () => { clearTimeout(t); ro.disconnect(); };
  }, [fallback, delay]);
  return [ref, w] as const;
}

// ── 차트 글씨 크기(컨테이너 폭 기준, clamp 최소/최대) — 모든 recharts/커스텀 SVG 차트 공통 ──
//   SVG <text>엔 CSS cqi가 안 먹어서 JS로 계산해 fontSize prop으로 직접 전달한다.
//   최소/최대값은 전부 여기 한 곳에서 관리.
export type ChartFonts = { tick: number; axis: number; legend: number; tooltip: number; dataLabel: number; pie: number };
function chartFonts(w: number): ChartFonts {
  const c = (min: number, coef: number, max: number) => Math.round(Math.max(min, Math.min(max, w * coef)));
  return {
    tick: c(10, 0.024, 13),      // 축 눈금 10~13
    axis: c(11, 0.026, 14),      // 축 제목 11~14
    legend: c(11, 0.026, 14),    // 범례 11~14
    tooltip: c(12, 0.024, 14),   // 툴팁 12~14
    dataLabel: c(9, 0.022, 12),  // 트리맵 이름/값 9~12
    pie: c(11, 0.03, 14),        // 파이 중앙 라벨 11~14
  };
}
const ChartFontCtx = createContext<ChartFonts>(chartFonts(600));
const useChartFonts = () => useContext(ChartFontCtx);

// 히트맵을 '그리드 한 칸'에 넣었다고 가정했을 때 나오는 셀 크기(축소 전, clamp 적용 전).
// 이 값이 FULL_MIN_CELL 보다 작으면 → 한 칸에선 너무 작아지므로 한 줄 전체로 띄운다.
function oneCellCellSize(labels: string[], oneCellW: number): number {
  const n = labels.length;
  if (!n || !oneCellW) return HM.MAX_CELL;
  const wrap = oneCellW - HM.CARD_PAD; // 카드 padding 제외한 내부 폭
  // 한 칸 내부가 넓으면(≥BESIDE_MIN) 패널이 오른쪽에 붙어 그만큼 매트릭스 폭이 줄고, 좁으면 패널이 아래로 가 전체 폭 사용.
  const matrixW = wrap >= HM.BESIDE_MIN ? wrap - HM.ASIDE_MIN - HM.SPLIT_GAP : wrap;
  const avail = matrixW - labelColWidth(labels) - HM.CELL_GAP * (n + 1);
  return avail / n;
}

export default function VisualizePage() {
  const d = useActiveDataset();
  const goto = useStepStore((s) => s.goto);

  if (!d) return null;
  const numericCols = d.columns.filter((c) => c.type === 'int' || c.type === 'float').map((c) => c.name);
  const categoricalCols = d.columns.filter((c) => c.type === 'string' || c.type === 'bool').map((c) => c.name);
  const dateCols = d.columns.filter((c) => c.type === 'datetime').map((c) => c.name);
  const allCols = d.columns.map((c) => c.name);

  return (
    <>
      <PageHeader title="시각화" subtitle="원하는 차트를 만들어 ＋ 대시보드에 추가하면 아래에 모아 볼 수 있어요." />

      {/* 단일 차트 만들기 */}
      <h3 className="mb-3 text-base font-semibold text-text">차트 만들기</h3>
      <ManualMode d={d} numericCols={numericCols} categoricalCols={categoricalCols} dateCols={dateCols} allCols={allCols} />

      {/* 대시보드 */}
      <h3 className="mb-3 mt-8 text-base font-semibold text-text">대시보드</h3>
      <Dashboard d={d} />

      <NavFooter prevLabel="전처리" nextLabel="데이터 병합" onNext={() => goto('merge')} />
    </>
  );
}


/* ───────────────── 대시보드 (사용자가 추가한 차트 모음) ───────────────── */

const CHART_NAME: Record<ManualChart, string> = {
  histogram: '히스토그램',
  box: '박스플롯',
  scatter: '산점도',
  heatmap: '상관 히트맵',
  bar: '막대그래프',
  line: '선그래프',
  pie: '파이 차트',
  treemap: '트리맵',
  area: '누적 영역 그래프',
};

export function chartTitle(d: Dataset, it: DashboardItem): string {
  const L = (n?: string) => (n ? labelOf(d, n) : '');
  const name = CHART_NAME[it.chart];
  switch (it.chart) {
    // X·Y 두 축이 모두 변수/의미를 가지는 차트 → "이름 : X · Y"
    case 'histogram':
      return `${name} : ${L(it.v1)} · 빈도`;
    case 'scatter':
      return `${name} : ${L(it.v1)} · ${L(it.v2)}`;
    case 'bar':
      return `${name} : ${L(it.cat)} · ${it.agg && it.agg !== '개수' ? `${L(it.agg)} 평균` : '빈도'}`;
    case 'line':
      return `${name} : ${L(it.date)} · ${L(it.v1)}(평균)${it.cat ? ` · ${L(it.cat)}별` : ''}`;
    case 'area':
      return `${name} : ${L(it.date)} · ${L(it.cat)}별`;
    // 박스플롯 — 값 + (있으면) 그룹 컬럼(it.cat)
    case 'box':
      return `${name} · ${L(it.v1)}${it.cat ? ` (${L(it.cat)}별)` : ''}`;
    // 단일 변수/축 없는 차트 → "이름 · 변수"
    case 'pie':
    case 'treemap':
      return `${name} · ${L(it.cat)}`;
    case 'heatmap':
      return name;
    default:
      return name;
  }
}

export function Dashboard({ d }: { d: Dataset }) {
  const items = useDatasetStore((s) => s.dashboardItems);
  const removeItem = useDatasetStore((s) => s.removeDashboardItem);
  const clearDashboard = useDatasetStore((s) => s.clearDashboard);

  // 그리드 '한 칸'의 실제 폭을 측정 → 히트맵이 1칸↔2칸을 다시 판단(창 크기 변화 반영).
  const gridRef = useRef<HTMLDivElement>(null);
  const [gridW, setGridW] = useState(0);
  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;
    const ro = new ResizeObserver((e) => setGridW(e[0].contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, [items.length]);
  // 2열(lg) 기준 한 칸 폭 = (그리드폭 − 열간격 16px) / 2. 1열 모드에선 span이 무의미해 그대로 둬도 됨.
  const oneCellW = gridW ? (gridW - 16) / 2 : 0;

  if (!items.length) {
    return (
      <Card>
        <div className="grid h-40 place-items-center px-4 text-center text-sm text-text-muted">
          <p>
            아직 추가된 차트가 없어요.
            <br />위에서 차트를 만들고 <span className="font-medium text-text">＋ 대시보드에 추가</span> 를 눌러 보세요.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <Card
      title="대시보드"
      subtitle={`${items.length}개 차트`}
      right={<Button variant="ghost" onClick={clearDashboard}>전체 비우기</Button>}
    >
      {/* grid-flow-row-dense: 히트맵이 2칸이 돼도 앞쪽 빈 칸을 뒤 카드가 메우도록(빈 칸 방지). */}
      <div ref={gridRef} className="grid grid-cols-1 gap-4 lg:grid-cols-2 lg:grid-flow-row-dense">
        {items.map((it) => {
          // 고정 스냅샷이 있으면 그걸로 렌더(전처리 바뀌어도 불변). 없으면(구버전 아이템) 라이브 d.
          const sd = it.snapshot ?? d;
          // 히트맵은 컬럼 수에 따라 1칸↔2칸을 스스로 판단하는 전용 카드로.
          if (it.chart === 'heatmap') {
            return <HeatmapDashCard key={it.id} sd={sd} it={it} oneCellW={oneCellW} onRemove={() => removeItem(it.id)} />;
          }
          const snc = sd.columns.filter((c) => c.type === 'int' || c.type === 'float').map((c) => c.name);
          return (
          <div
            key={it.id}
            className={`rounded-card border border-border bg-surface-muted/30 p-4 ${
              it.chart === 'line' || it.chart === 'area' ? 'lg:col-span-2' : ''
            }`}
          >
            <div className="mb-2 flex items-start justify-between gap-2">
              <h4 className="text-sm font-semibold text-text">{chartTitle(sd, it)}</h4>
              <button onClick={() => removeItem(it.id)} className="flex-none text-text-muted transition-colors hover:text-danger" title="삭제" aria-label="삭제">
                ✕
              </button>
            </div>
            <ManualChartView
              d={sd}
              chart={it.chart}
              v1={it.v1 ?? ''}
              v2={it.v2 ?? ''}
              cat={it.cat ?? ''}
              agg={it.agg ?? '개수'}
              date={it.date ?? ''}
              numericCols={snc}
              cumulative={it.cumulative}
              donut={it.donut}
            />
          </div>
          );
        })}
      </div>
    </Card>
  );
}

/* ───────────────── 직접 선택 모드 (A의 6종) ───────────────── */

export function ManualMode({
  d,
  numericCols,
  categoricalCols,
  dateCols,
  allCols,
}: {
  d: Dataset;
  numericCols: string[];
  categoricalCols: string[];
  dateCols: string[];
  allCols: string[];
}) {
  const { manualChart, setManualChart } = useDatasetStore();
  const addDashboardItem = useDatasetStore((s) => s.addDashboardItem);
  const [added, setAdded] = useState(false);
  const charts: { value: ManualChart; label: string }[] = [
    { value: 'histogram', label: '히스토그램' },
    { value: 'box', label: '박스플롯' },
    { value: 'scatter', label: '산점도' },
    { value: 'heatmap', label: '상관 히트맵' },
    { value: 'bar', label: '막대그래프' },
    { value: 'line', label: '선그래프' },
    { value: 'pie', label: '파이 차트' },
    { value: 'treemap', label: '트리맵' },
    { value: 'area', label: '누적 영역 그래프' },
  ];

  const [v1, setV1] = useState(numericCols[0] ?? allCols[0] ?? '');
  const [v2, setV2] = useState(numericCols[1] ?? numericCols[0] ?? '');
  const [cat, setCat] = useState(categoricalCols[0] ?? '');
  const [agg, setAgg] = useState('개수');
  const [date, setDate] = useState(dateCols[0] ?? allCols[0] ?? '');
  const [boxGroup, setBoxGroup] = useState(''); // 박스플롯 X(그룹) 컬럼 — '' = 그룹 없음(단일, 기존 동작). box 전용이라 cat 과 분리.
  const [showCumulative, setShowCumulative] = useState(false); // 막대그래프(개수) 누적비율선(파레토) 표시
  const [donut, setDonut] = useState(false); // 파이차트 → 도넛(가운데 컬럼명) 표시

  // 저카디널리티 컬럼 후보 — 문자/불리언 + 숫자 컬럼 중 고유값 MAX_GROUP_UNIQUE(15)개 이하만.
  //   박스플롯 그룹(X)·파이차트 범주 공용. 숫자도 포함하는 이유: 인코딩된 0/1·라인 1/2/3·월 1~12 처럼
  //   값 종류가 적은 숫자는 사실상 범주라 그룹/범주로 유용하다. 연속 숫자(온도 등, 고유값 수백)는 15개 상한에
  //   걸려 자동 제외되므로 박스·조각 폭주는 없다.
  //   고유값은 인라인 계산(Set 크기, 15 초과 시 조기 종료 → 35k 행에서도 빠름). ColumnMeta 에 저장하지 않는다.
  const lowCardPool = useMemo(() => [...categoricalCols, ...numericCols], [categoricalCols, numericCols]);
  const lowCardCols = useMemo(() => {
    return lowCardPool.filter((c) => {
      const seen = new Set<string>();
      for (const r of d.rows) {
        seen.add(String(r[c] ?? '(없음)'));
        if (seen.size > MAX_GROUP_UNIQUE) return false; // 16개째 발견 즉시 탈락(조기 종료)
      }
      return true;
    });
  }, [d.rows, lowCardPool]);
  const excludedLowCardCols = lowCardPool.length - lowCardCols.length; // 고유값 많아 제외된 컬럼 수(안내용)

  // 히스토그램 값 후보 — 수치형 중 고유값 MAX_HIST_UNIQUE(50)개 이하만. (ID·고분산 연속 등 값이 너무 많은 컬럼 제외)
  //   고유값은 인라인 계산(Set, 상한 초과 시 조기 종료). lowCardCols 와 동일 패턴.
  const histogramCols = useMemo(() => {
    return numericCols.filter((c) => {
      const seen = new Set<string>();
      for (const r of d.rows) {
        seen.add(String(r[c] ?? '(없음)'));
        if (seen.size > MAX_HIST_UNIQUE) return false; // 51개째 발견 즉시 탈락(조기 종료)
      }
      return true;
    });
  }, [d.rows, numericCols]);
  const excludedHistCols = numericCols.length - histogramCols.length; // 고유값 많아 제외된 수치형 컬럼 수(안내용)

  // 히스토그램 선택 시 현재 값(v1)이 후보에서 빠져 있으면(예: 기본값이 ID) 유효한 첫 컬럼으로 교정한다.
  //   안 하면 select 표시값(첫 옵션)과 실제 상태 v1(제외된 컬럼)이 어긋나 "클릭한 컬럼과 다른 차트"가 그려진다.
  useEffect(() => {
    if (manualChart === 'histogram' && histogramCols.length && !histogramCols.includes(v1)) setV1(histogramCols[0]);
  }, [manualChart, histogramCols, v1]);

  // 막대 범주(X) 후보 — 범주형+수치형 중 고유값 MAX_BAR_UNIQUE(50)개 이하만. (ID·연속형 등 고유값 많은 컬럼 제외)
  const barCatPool = useMemo(() => [...categoricalCols, ...numericCols], [categoricalCols, numericCols]);
  const barCatCols = useMemo(() => {
    return barCatPool.filter((c) => {
      const seen = new Set<string>();
      for (const r of d.rows) {
        seen.add(String(r[c] ?? '(없음)'));
        if (seen.size > MAX_BAR_UNIQUE) return false;
      }
      return true;
    });
  }, [d.rows, barCatPool]);
  const excludedBarCols = barCatPool.length - barCatCols.length; // 고유값 많아 제외된 범주 후보 수(안내용)

  // 막대 선택 시 현재 범주(cat)가 후보에서 빠져 있으면 유효한 첫 컬럼으로 교정(히스토그램과 동일한 desync 방지).
  useEffect(() => {
    if (manualChart === 'bar' && barCatCols.length && !barCatCols.includes(cat)) setCat(barCatCols[0]);
  }, [manualChart, barCatCols, cat]);

  return (
    <>
      <div className="mb-4">
        <Field label="차트 종류">
          <select value={manualChart} onChange={(e) => setManualChart(e.target.value as ManualChart)} className={selectCls}>
            {charts.map((c) => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
        </Field>
      </div>

      <Card>
        <div className="mb-4 flex flex-wrap gap-3">
          {manualChart === 'histogram' && <Sel label="값" value={v1} set={setV1} opts={histogramCols} d={d} />}
          {manualChart === 'box' && (
            <>
              <Sel label="값" value={v1} set={setV1} opts={numericCols} d={d} />
              <Sel label="그룹 (X, 선택)" value={boxGroup} set={setBoxGroup} opts={lowCardCols} d={d} emptyLabel="(그룹 없음)" />
            </>
          )}
          {manualChart === 'scatter' && (
            <>
              <Sel label="X축" value={v1} set={setV1} opts={numericCols} d={d} />
              <Sel label="Y축" value={v2} set={setV2} opts={numericCols} d={d} />
            </>
          )}
          {manualChart === 'bar' && (
            <>
              <Sel label="범주(X)" value={cat} set={setCat} opts={barCatCols} d={d} />
              <Field label="집계(Y)">
                <select value={agg} onChange={(e) => setAgg(e.target.value)} className={selectCls}>
                  <option value="개수">개수</option>
                  {numericCols.map((c) => (
                    <option key={c} value={c}>{labelOf(d, c)} 평균</option>
                  ))}
                </select>
              </Field>
              {agg === '개수' && (
                <Field label="옵션">
                  <label className="flex h-[38px] items-center gap-2 text-sm text-text">
                    <input type="checkbox" checked={showCumulative} onChange={(e) => setShowCumulative(e.target.checked)} className="accent-primary" />
                    누적비율선 (파레토)
                  </label>
                </Field>
              )}
            </>
          )}
          {manualChart === 'line' && (
            <>
              <Sel label="X축(기준)" value={date} set={setDate} opts={[...dateCols, ...allCols]} d={d} />
              <Sel label="Y축(평균)" value={v1} set={setV1} opts={numericCols} d={d} />
              <Sel label="계열 (선택)" value={cat} set={setCat} opts={lowCardCols} d={d} emptyLabel="(계열 없음)" />
            </>
          )}
          {manualChart === 'area' && (
            <>
              <Sel label="X축(시간/정렬)" value={date} set={setDate} opts={[...dateCols, ...allCols]} d={d} />
              <Sel label="그룹(누적)" value={cat} set={setCat} opts={lowCardCols} d={d} />
            </>
          )}
          {manualChart === 'heatmap' && <Sel label="기준(target) 컬럼" value={v1} set={setV1} opts={numericCols} d={d} />}
          {(manualChart === 'pie' || manualChart === 'treemap') && <Sel label="범주" value={cat} set={setCat} opts={lowCardCols} d={d} />}
          {manualChart === 'pie' && (
            <Field label="옵션">
              <label className="flex h-[38px] items-center gap-2 text-sm text-text">
                <input type="checkbox" checked={donut} onChange={(e) => setDonut(e.target.checked)} className="accent-primary" />
                도넛 차트
              </label>
            </Field>
          )}
        </div>
        {(manualChart === 'box' || manualChart === 'pie' || manualChart === 'treemap') && excludedLowCardCols > 0 && (
          <p className="mb-3 text-xs text-text-muted">고유값이 많은 컬럼(15개 초과)은 {manualChart === 'box' ? '그룹(X)' : '범주'}으로 쓸 수 없어 목록에서 제외했어요.</p>
        )}
        {manualChart === 'histogram' && excludedHistCols > 0 && (
          <p className="mb-3 text-xs text-text-muted">고유값이 많은 수치형 컬럼(50개 초과)은 값이 너무 많아 히스토그램 값 목록에서 제외했어요.</p>
        )}
        {manualChart === 'bar' && excludedBarCols > 0 && (
          <p className="mb-3 text-xs text-text-muted">고유값이 많은 컬럼(50개 초과)은 범주(X)로 쓰기 어려워 목록에서 제외했어요.</p>
        )}

        <ManualChartView d={d} chart={manualChart} v1={v1} v2={v2} cat={manualChart === 'box' ? boxGroup : cat} agg={agg} date={date} numericCols={numericCols} cumulative={showCumulative} donut={donut} />

        {/* 실시간 소견 — 입력(기준 컬럼 등)을 바꿀 때마다 즉시 갱신. 리포트 종합소견과 같은 chartInsight 사용(문구 일치).
            컬럼 미선택 등으로 소견이 비면 박스를 숨긴다(빈 상자 방지). */}
        {(() => {
          const ins = chartInsight(d, { id: '', chart: manualChart, v1, v2, cat: manualChart === 'box' ? boxGroup : cat, agg, date });
          return ins ? <p className="mt-3 rounded-btn border border-ai/30 bg-ai/5 p-2.5 text-sm text-text">{ins}</p> : null;
        })()}

        <div className="mt-4 flex items-center justify-end gap-3 border-t border-border pt-4">
          {added && <span className="text-sm text-success">✓ 대시보드에 추가됨</span>}
          <Button
            onClick={() => {
              addDashboardItem({ id: `${Date.now()}-${Math.round(Math.random() * 1e6)}`, chart: manualChart, v1, v2, cat: manualChart === 'box' ? boxGroup : cat, agg, date, cumulative: manualChart === 'bar' && agg === '개수' ? showCumulative : undefined, donut: manualChart === 'pie' ? donut : undefined });
              setAdded(true);
              window.setTimeout(() => setAdded(false), 1500);
            }}
          >
            ＋ 대시보드에 추가
          </Button>
        </div>
      </Card>
    </>
  );
}

function ManualChartInner({
  d,
  chart,
  v1,
  v2,
  cat,
  agg,
  date,
  numericCols,
  height,
  cumulative = false,
  donut = false,
}: {
  d: Dataset;
  chart: ManualChart;
  v1: string;
  v2: string;
  cat: string;
  agg: string;
  date: string;
  numericCols: string[];
  height?: number;
  cumulative?: boolean;
  donut?: boolean;
}) {
  if (chart === 'histogram') return v1 ? <Histogram d={d} name={v1} height={height} /> : <Empty />;
  if (chart === 'box') return v1 ? <BoxPlot d={d} name={v1} group={cat} /> : <Empty />;
  if (chart === 'scatter') return v1 && v2 ? <ScatterView d={d} x={v1} y={v2} height={height} /> : <Empty />;
  if (chart === 'heatmap') return numericCols.length >= 2 ? <Heatmap d={d} target={v1} /> : <Empty msg="수치형 컬럼이 2개 이상 필요합니다." />;
  if (chart === 'bar') return cat ? <CategoryBarAgg d={d} cat={cat} agg={agg} height={height} cumulative={cumulative} /> : <Empty />;
  if (chart === 'line') return date && v1 ? <LineView d={d} dateName={date} valueName={v1} groupName={cat} height={height} /> : <Empty />;
  if (chart === 'pie') return cat ? <CategoryPie d={d} name={cat} height={height} donut={donut} /> : <Empty msg="범주형 컬럼을 선택해 주세요." />;
  if (chart === 'treemap') return cat ? <CategoryTreemap d={d} name={cat} height={height} /> : <Empty msg="범주형 컬럼을 선택해 주세요." />;
  if (chart === 'area') return date && cat ? <StackedAreaView d={d} xName={date} groupName={cat} height={height} /> : <Empty msg="X축(시간)과 그룹 컬럼을 선택해 주세요." />;
  return <Empty />;
}

// 각 그래프 '컨테이너 폭'을 측정(디바운스)해 글씨 크기를 계산하고 Context로 내려준다.
// → 하위 recharts/커스텀 SVG 차트가 fontSize prop에 직접 적용(viewBox 통짜 확대 아님).
export function ManualChartView(props: Parameters<typeof ManualChartInner>[0]) {
  const [ref, w] = useElementWidth<HTMLDivElement>(0);
  const fonts = useMemo(() => chartFonts(w || 600), [w]); // 측정 전엔 기본폭 600 기준
  return (
    <div ref={ref} className="chart-fluid">
      <ChartFontCtx.Provider value={fonts}>{ManualChartInner(props)}</ChartFontCtx.Provider>
    </div>
  );
}

/* ───────────────── 차트 컴포넌트 ───────────────── */

function Histogram({ d, name, height = 380 }: { d: Dataset; name: string; height?: number }) {
  const f = useChartFonts();
  const data = histogramData(d, name, 14);
  if (!data.length) return <Empty />;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 10, right: 20, bottom: 28, left: 12 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="range" tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisX(labelOf(d, name), f.axis)} />
        <YAxis tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisY('빈도', f.axis)} />
        <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} />
        {/* maxBarSize: 막대가 몇 개 안 될 때(0/1 등) 가로로 과하게 늘어나지 않도록 폭 상한 */}
        <Bar dataKey="count" name={labelOf(d, name)} fill={COLORS[0]} radius={[4, 4, 0, 0]} maxBarSize={64}>{gradientCells(data.length, COLORS[0])}</Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

// 박스플롯 — 세로 방향(값=Y축, 그룹=X축). 단일(그룹 없음)·그룹 공용. 커스텀 SVG(Recharts 미사용) 유지.
//   ⚠ 통계는 boxStats·boxStatsBy(charts.ts) 그대로 — 여기서는 렌더 방향만 세운다. 모든 그룹이 같은 Y 스케일(높이 비교 가능).
function BoxPlot({ d, name, group }: { d: Dataset; name: string; group?: string }) {
  // SVG 실제 렌더 폭 측정(디바운스) → 글씨를 viewBox 스케일에 '역보정'해 화면에서 일정 px로 유지.
  //   (viewBox 통짜 확대로 글씨까지 늘어나는 것을 상쇄 — 작은 카드에서도 읽히는 크기 보장)
  const [svgRef, rw] = useElementWidth<SVGSVGElement>(720);
  // 단일이면 boxStats 1개를 배열로, 그룹이면 boxStatsBy(전부). 그리기 로직은 하나로 통일.
  const boxes = group
    ? boxStatsBy(d, name, group).map((b) => ({ ...b, label: b.group }))
    : (() => { const b = boxStats(d, name); return b ? [{ ...b, label: labelOf(d, name) }] : []; })();
  if (!boxes.length) return <Empty msg="표시할 수치 데이터가 없습니다." />;

  // 공통 Y 스케일 — 모든 박스의 min/max/이상치를 아우른다(그룹 ≤15·이상치 ≤200이라 spread 안전).
  let lo = Infinity;
  let hi = -Infinity;
  for (const b of boxes) {
    lo = Math.min(lo, b.min, ...b.outliers);
    hi = Math.max(hi, b.max, ...b.outliers);
  }
  const span = hi - lo || 1;

  const n = boxes.length;
  const rotate = n > 6; // 그룹이 많으면 X 라벨을 기울여 겹침 방지
  const W = 720;
  const padTop = 16;
  const padLeft = 56; // Y축 눈금 공간
  const padRight = 16;
  const padBottom = rotate ? 74 : 40; // 기운 라벨은 세로 공간 더 필요
  const plotH = 260;
  const H = padTop + plotH + padBottom;
  const plotW = W - padLeft - padRight;
  const slotW = plotW / n;
  const boxW = Math.min(46, slotW * 0.55);
  const sy = (v: number) => padTop + (1 - (v - lo) / span) * plotH; // 값↑ = 화면 위
  const cx = (i: number) => padLeft + slotW * (i + 0.5);
  const labelY = padTop + plotH + 14;

  // Y축 눈금 5개(균등). 통계값은 이미 소수1자리 반올림 범위.
  const ticks = Array.from({ length: 5 }, (_, i) => lo + (span * i) / 4);
  const fmt = (v: number) => (Math.abs(v) >= 100 ? Math.round(v) : Math.round(v * 10) / 10).toLocaleString();
  const trunc = (s: string) => (s.length > 10 ? `${s.slice(0, 9)}…` : s);
  // 화면 목표 글씨 10~13px → viewBox 역보정. rw(렌더폭) 대비 W(viewBox폭) 비율만큼 키워 둔다.
  const uFont = Math.max(10, Math.min(13, rw * 0.024)) * (W / (rw || W));

  return (
    <div className="overflow-x-auto">
      <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ minWidth: 480 }}>
        {/* Y축 눈금 + 가로 그리드 */}
        {ticks.map((t, i) => (
          <g key={i}>
            <line x1={padLeft} y1={sy(t)} x2={W - padRight} y2={sy(t)} stroke="var(--border)" strokeDasharray="3 3" />
            <text x={padLeft - 8} y={sy(t) + 3} fontSize={uFont} fill="var(--text-muted)" textAnchor="end">{fmt(t)}</text>
          </g>
        ))}
        {/* 박스들(세로) */}
        {boxes.map((b, i) => {
          const x = cx(i);
          // 그룹별 색 — 파이차트와 동일한 순환(COLORS[i % length]). 단일 박스(그룹 없음)는 기존 var(--primary) 그대로(회귀 방지).
          const color = group ? COLORS[i % COLORS.length] : 'var(--primary)';
          return (
            <g key={`${b.label}-${i}`}>
              {/* 수염(세로): 박스 위→최대수염, 박스 아래→최소수염 */}
              <line x1={x} y1={sy(b.whiskerHigh)} x2={x} y2={sy(b.q3)} stroke="var(--text-muted)" />
              <line x1={x} y1={sy(b.q1)} x2={x} y2={sy(b.whiskerLow)} stroke="var(--text-muted)" />
              {/* 수염 캡(가로) */}
              <line x1={x - 8} y1={sy(b.whiskerHigh)} x2={x + 8} y2={sy(b.whiskerHigh)} stroke="var(--text-muted)" />
              <line x1={x - 8} y1={sy(b.whiskerLow)} x2={x + 8} y2={sy(b.whiskerLow)} stroke="var(--text-muted)" />
              {/* 박스(q1~q3): q3 가 위(작은 y). 색은 그룹별(단일=primary) */}
              <rect x={x - boxW / 2} y={sy(b.q3)} width={boxW} height={Math.max(sy(b.q1) - sy(b.q3), 1)} fill={color} fillOpacity={0.18} stroke={color} />
              {/* 중앙값(가로선) — 그룹 색으로 진하게 */}
              <line x1={x - boxW / 2} y1={sy(b.median)} x2={x + boxW / 2} y2={sy(b.median)} stroke={color} strokeWidth={2} />
              {/* 이상치 — 그룹 색과 무관하게 var(--danger) 유지(모든 그룹에서 '이상치=경고'로 즉시 인지) */}
              {b.outliers.map((v, k) => (
                <circle key={k} cx={x} cy={sy(v)} r={2.5} fill="var(--danger)" fillOpacity={0.7} />
              ))}
              {/* X축 그룹 라벨 (많으면 -35° 기울임) */}
              <text
                x={x}
                y={labelY}
                fontSize={uFont}
                fill="var(--text)"
                textAnchor={rotate ? 'end' : 'middle'}
                transform={rotate ? `rotate(-35 ${x} ${labelY})` : undefined}
              >
                {trunc(b.label)}
              </text>
            </g>
          );
        })}
      </svg>
      <p className="mt-2 text-center text-sm text-text-muted">
        {group
          ? `${labelOf(d, group)}별 · 값 ${labelOf(d, name)} · 그룹 ${boxes.length}개`
          : `Q1 ${boxes[0].q1} · 중앙값 ${boxes[0].median} · Q3 ${boxes[0].q3} · IQR ${boxes[0].iqr} · 이상치 ${boxes[0].outlierCount}개`}
      </p>
    </div>
  );
}

function ScatterView({ d, x, y, height = 380 }: { d: Dataset; x: string; y: string; height?: number }) {
  const f = useChartFonts();
  const data = scatterData(d, x, y);
  const r = correlation(d, x, y);
  if (!data.length) return <Empty />;
  return (
    <>
      <ResponsiveContainer width="100%" height={height}>
        <ScatterChart margin={{ top: 10, right: 20, bottom: 28, left: 12 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
          <XAxis type="number" dataKey="x" name={labelOf(d, x)} tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisX(labelOf(d, x), f.axis)} />
          <YAxis type="number" dataKey="y" name={labelOf(d, y)} tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisY(labelOf(d, y), f.axis)} />
          <ZAxis range={[40, 40]} />
          <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} cursor={{ strokeDasharray: '3 3' }} />
          <Scatter data={data} fill={COLORS[0]} fillOpacity={0.5} />
        </ScatterChart>
      </ResponsiveContainer>
      <p className="mt-2 text-center text-sm text-text-muted">상관계수 r = {r}</p>
    </>
  );
}

// 대시보드 히트맵 카드 — '한 줄 전체(span)'로 띄울지 스스로 결정.
//   둘 중 하나라도 해당하면 한 줄 전체(lg:col-span-2):
//     1) 컬럼 수 ≥ HM.FULL_COLS (기본 8)
//     2) 한 칸에 넣었을 때(축소 전) 셀 크기 < HM.FULL_MIN_CELL (기본 36px)
//   컬럼이 적으면 한 칸 유지. 한 줄 전체가 되면 넓어진 폭으로 셀·글씨가 커진다(미리보기와 유사).
function HeatmapDashCard({ sd, it, oneCellW, onRemove }: { sd: Dataset; it: DashboardItem; oneCellW: number; onRemove: () => void }) {
  const { labels } = correlationMatrix(sd);
  const snc = sd.columns.filter((c) => c.type === 'int' || c.type === 'float').map((c) => c.name);
  const byCols = labels.length >= HM.FULL_COLS;
  const [full, setFull] = useState(byCols);
  useEffect(() => {
    if (!oneCellW) return;
    const cell = oneCellCellSize(labels, oneCellW); // 축소 전 셀 크기
    // 셀 크기 조건은 경계 떨림 방지(한 줄→한 칸 복귀는 FULL_HYST 만큼 여유가 생겨야).
    setFull((prev) => byCols || (prev ? cell < HM.FULL_MIN_CELL + HM.FULL_HYST : cell < HM.FULL_MIN_CELL));
  }, [labels, oneCellW, byCols]);
  return (
    <div className={`rounded-card border border-border bg-surface-muted/30 p-4 ${full ? 'lg:col-span-2' : ''}`}>
      <div className="mb-2 flex items-start justify-between gap-2">
        <h4 className="text-sm font-semibold text-text">{chartTitle(sd, it)}</h4>
        <button onClick={onRemove} className="flex-none text-text-muted transition-colors hover:text-danger" title="삭제" aria-label="삭제">
          ✕
        </button>
      </div>
      <ManualChartView d={sd} chart={it.chart} v1={it.v1 ?? ''} v2={it.v2 ?? ''} cat={it.cat ?? ''} agg={it.agg ?? '개수'} date={it.date ?? ''} numericCols={snc} cumulative={it.cumulative} donut={it.donut} />
    </div>
  );
}

function Heatmap({ d, target }: { d: Dataset; target?: string }) {
  const { labels, values, truncated } = correlationMatrix(d);
  const [ref, w] = useElementWidth<HTMLDivElement>(0); // 매트릭스 실제 폭(디바운스)

  if (!labels.length) return <div ref={ref}><Empty /></div>;
  const color = (v: number) => {
    const a = Math.abs(v);
    return v >= 0 ? `rgba(79,70,229,${a})` : `rgba(220,38,38,${a})`;
  };

  // 박스 폭에 맞춰 셀 크기 계산 — (전체폭 − 좌측 라벨열 − 셀 간격) / 컬럼 수
  const n = labels.length;
  // 좌측 라벨열 폭은 가장 긴 이름의 '실제 폭'에 맞춘다(측정은 안정적으로 기준 폰트로).
  const LABEL_W = labelColWidth(labels, HM.LABEL_FONT);
  const GAP = HM.CELL_GAP; // border-spacing-1
  const avail = Math.max(0, w - LABEL_W - GAP * (n + 1));
  // 셀 크기에 상한(MAX_CELL)을 둬, 컬럼이 적을 때 너비를 꽉 채우지 않고 히트맵이 작게 유지되도록 함.
  const MAX_CELL = HM.MAX_CELL;
  // 셀은 MIN_CELL 밑으로는 줄이지 않는다 → 더 좁으면 셀을 뭉개는 대신 히트맵이 가로 스크롤(overflow-x-auto)된다.
  const CELL = w ? Math.min(MAX_CELL, Math.max(HM.MIN_CELL, Math.floor(avail / n))) : HM.MIN_CELL;
  // 셀 숫자·라벨 글씨는 '셀 크기'에 비례(컨테이너 폭이 아니라). 셀 숫자 9~13, 라벨 10~13.
  const cellFont = Math.max(9, Math.min(13, Math.round(CELL / 4.5)));
  const labelFontR = Math.max(10, Math.min(13, Math.round(CELL * 0.22)));
  // 셀이 너무 작아 9px로도 '-0.01'이 안 들어가면 숫자를 숨기고 툴팁(title)으로만 보여준다.
  const showNum = CELL >= 28;
  // 히트맵이 '꽉 찬 크기'(셀=MAX_CELL)까지만 커지도록 상한. flex-1 이 이 폭까지만 늘어나
  // 더는 벌어지지 않으므로 오른쪽 패널이 바로 옆에 붙는다(가운데 빈 공간 제거).
  const fullW = LABEL_W + GAP * (n + 1) + n * MAX_CELL;

  return (
    <div className="heatmap-wrap">
    <div className="heatmap-split">
      <div ref={ref} className="heatmap-matrix min-w-0 overflow-x-auto" style={{ maxWidth: fullW }}>
      <table className="border-separate border-spacing-1" style={{ fontSize: cellFont }}>
        <thead>
          <tr>
            <th style={{ width: LABEL_W }} />
            {labels.map((l) => (
              <th key={l} className="p-0 align-bottom font-normal text-text-muted" title={l} style={{ fontSize: labelFontR }}>
                <div className="mx-auto whitespace-nowrap" style={{ writingMode: 'vertical-rl' }}>{l}</div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {values.map((row, i) => (
            <tr key={i}>
              <td className="pr-2 text-right text-text-muted" style={{ width: LABEL_W, fontSize: labelFontR }} title={labels[i]}>
                <div className="truncate">{labels[i]}</div>
              </td>
              {row.map((v, j) => (
                <td
                  key={j}
                  className="rounded text-center align-middle font-medium text-text"
                  style={{ background: color(v), width: CELL, height: CELL }}
                  title={`${labels[i]} × ${labels[j]} = ${v.toFixed(2)}`}
                >
                  {showNum ? v.toFixed(2) : ''}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {truncated > 0 && (
        <p className="mt-2 text-xs text-text-muted">수치형 컬럼이 많아 상위 {labels.length}개만 표시했어요 (그 외 {truncated}개 생략).</p>
      )}
      </div>
      <TargetCorrelation d={d} fixedTarget={target} />
    </div>
    </div>
  );
}

// target 컬럼 기준 상관계수 상·하위 10개 — 수치형 컬럼만.
//   기준 컬럼은 히트맵의 fixedTarget(it.v1)으로 항상 고정한다(드롭다운 없이 라벨만) → 리포트/빌더 모두 대시보드에 담긴 값 그대로.
//   fixedTarget 이 없거나 유효하지 않으면(구버전 아이템 등) 첫 수치형으로 폴백한다. 빌더에서 바꾸려면 위쪽 '기준(target) 컬럼' 셀렉터를 쓴다.
function TargetCorrelation({ d, fixedTarget }: { d: Dataset; fixedTarget?: string }) {
  const numCols = d.statistics.map((s) => ({ name: s.name, label: s.label }));
  const target = fixedTarget && numCols.some((c) => c.name === fixedTarget) ? fixedTarget : numCols[0]?.name ?? '';

  const { ok, items } = useMemo(() => targetCorrelations(d, target), [d, target]);

  // 강도(절댓값) 내림차순 상위 N개(최대 10)만 한 표로.
  const strong = useMemo(() => [...items].sort((a, b) => Math.abs(b.r) - Math.abs(a.r)), [items]);
  const N = Math.min(10, items.length);

  if (!numCols.length) return null;

  // 이 패널만 작게 + 패널 폭 기준 반응형(글씨는 corr-fluid 가 clamp 로 11~13px 제어). 히트맵 글씨는 불변.
  // table-fixed + truncate 로 긴 컬럼명은 한 줄 말줄임(…) 처리, title 로 전체 이름 표시.
  const CorrTable = ({ rows }: { rows: { name: string; label: string; r: number }[] }) => (
    <table className="w-full table-fixed">
      <thead>
        <tr className="border-b border-border text-left text-text-muted">
          <th className="py-1 pr-2 font-medium">컬럼</th>
          <th className="w-16 py-1 text-right font-medium">상관계수</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((it) => (
          <tr key={it.name} className="border-b border-border/50">
            <td className="truncate py-0.5 pr-2 text-text" title={it.label}>{it.label}</td>
            <td className={`py-0.5 text-right tabular-nums ${it.r >= 0 ? 'text-primary' : 'text-danger'}`}>{it.r.toFixed(2)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  return (
    <div className="heatmap-aside">
      <p className="mb-3 text-sm font-semibold text-text">
        <span className="text-text-muted">기준 컬럼 : </span>
        <span>{labelOf(d, target)}</span>
      </p>

      {!ok ? (
        <p className="text-sm text-warning">선택한 컬럼이 수치형이 아니라 상관계수를 계산할 수 없어요. 수치형 컬럼을 선택해 주세요.</p>
      ) : items.length === 0 ? (
        <p className="text-sm text-text-muted">비교할 다른 수치형 컬럼이 없습니다.</p>
      ) : (
        // 표가 길어 카드 높이를 넘으면 이 영역만 세로 스크롤.
        <div className="corr-fluid overflow-y-auto" style={{ maxHeight: 440 }}>
          <h4 className="corr-title mb-1.5 font-semibold text-text">상관계수 상위 {N}개 (강도 순)</h4>
          <CorrTable rows={strong.slice(0, N)} />
        </div>
      )}
    </div>
  );
}

function CategoryBar({ d, name, height = 380, cumulative = false }: { d: Dataset; name: string; height?: number; cumulative?: boolean }) {
  const f = useChartFonts();
  const data = barData(d, name);
  if (!data.length) return <Empty />;
  // 누적비율선(파레토) — barData 는 이미 내림차순 정렬이라, 위에서부터 누적 비율을 계산한다(오른쪽 축 0~100%).
  //   분모는 전체 행 수(모든 범주 합). barData 가 상위 12개만 보여주므로, 범주가 12개 초과면 선이 100%에 못 미치며
  //   이는 "상위 범주가 전체의 몇 %를 차지하는지"를 정확히 나타낸다(파레토 본래 의미).
  if (cumulative) {
    const total = d.rows.length;
    let run = 0;
    const pareto = data.map((x) => {
      run += x.count;
      return { ...x, cumPct: total ? Math.round((run / total) * 1000) / 10 : 0 };
    });
    return (
      <ResponsiveContainer width="100%" height={height}>
        <ComposedChart data={pareto} margin={{ top: 10, right: 44, bottom: 28, left: 12 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
          <XAxis dataKey="category" tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisX(labelOf(d, name), f.axis)} />
          <YAxis yAxisId="left" tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisY('빈도', f.axis)} />
          <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tickFormatter={(v) => `${v}%`} tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} />
          <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} formatter={(value, key) => (key === '누적비율' ? `${value}%` : value)} />
          <Legend verticalAlign="top" height={28} wrapperStyle={{ fontSize: f.legend }} />
          <Bar yAxisId="left" dataKey="count" name="빈도" fill={COLORS[0]} radius={[4, 4, 0, 0]}>{gradientCells(data.length, COLORS[0])}</Bar>
          <Line yAxisId="right" type="monotone" dataKey="cumPct" name="누적비율" stroke={COLORS[1]} strokeWidth={2} dot={{ r: 3 }} />
        </ComposedChart>
      </ResponsiveContainer>
    );
  }
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 10, right: 20, bottom: 28, left: 12 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="category" tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisX(labelOf(d, name), f.axis)} />
        <YAxis tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisY('빈도', f.axis)} />
        <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} />
        <Bar dataKey="count" name="빈도" fill={COLORS[0]} radius={[4, 4, 0, 0]}>{gradientCells(data.length, COLORS[0])}</Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

function CategoryBarAgg({ d, cat, agg, height = 380, cumulative = false }: { d: Dataset; cat: string; agg: string; height?: number; cumulative?: boolean }) {
  const f = useChartFonts();
  if (agg === '개수') return <CategoryBar d={d} name={cat} height={height} cumulative={cumulative} />;
  const data = groupMeanData(d, cat, agg);
  if (!data.length) return <Empty />;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 10, right: 20, bottom: 28, left: 12 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="group" tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisX(labelOf(d, cat), f.axis)} />
        <YAxis tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisY(`${labelOf(d, agg)} 평균`, f.axis)} />
        <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} />
        <Bar dataKey="mean" name={`${labelOf(d, agg)} 평균`} fill={COLORS[1]} radius={[4, 4, 0, 0]}>{gradientCells(data.length, COLORS[1])}</Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

function CategoryPie({ d, name, height = 360, donut = false }: { d: Dataset; name: string; height?: number; donut?: boolean }) {
  const f = useChartFonts();
  const data = pieData(d, name);
  if (!data.length) return <Empty />;
  // 도넛 중앙 컬럼명 — 짧으면 키우고(18px), 도넛 안(지름 136px)을 넘칠 만큼 길면 현재 크기(f.pie)로 유지.
  const centerLabel = labelOf(d, name);
  const centerFont = measureTextWidth(centerLabel, 18) <= 116 ? 18 : f.pie;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie data={data} dataKey="count" nameKey="category" cx="50%" cy="50%" innerRadius={donut ? 68 : 0} outerRadius={120} paddingAngle={donut ? 1 : 0} label>
          {data.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
          {donut && (
            <Label
              position="center"
              content={({ viewBox }) => {
                const vb = viewBox as { cx?: number; cy?: number };
                return (
                  <text x={vb.cx} y={vb.cy} textAnchor="middle" dominantBaseline="central" fill="var(--text)" fontSize={centerFont} fontWeight={600}>
                    {centerLabel}
                  </text>
                );
              }}
            />
          )}
        </Pie>
        <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} />
        <Legend wrapperStyle={{ fontSize: f.legend }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

// 트리맵 셀 — 사각형 크기 = 빈도, 색은 순환 팔레트. 칸이 충분히 크면 범주명·건수(%) 라벨 표시.
function TreemapCell(props: any) {
  const { x, y, width, height, index, name, value, total, labelFont = 12 } = props;
  const fill = COLORS[(index ?? 0) % COLORS.length];
  const pct = total ? Math.round((value / total) * 1000) / 10 : 0;
  // 칸이 글씨를 담기 충분할 때만 라벨 표시(작으면 숨김) — 폰트 크기에 맞춰 임계도 조정.
  const showName = width > labelFont * 3.8 && height > labelFont + 10;
  const showSub = width > labelFont * 5 && height > labelFont * 3.2;
  return (
    <g>
      <rect x={x} y={y} width={width} height={height} fill={fill} stroke="var(--surface)" strokeWidth={2} />
      {showName && (
        <text x={x + 6} y={y + labelFont + 4} fill="#fff" fontSize={labelFont} fontWeight={600}>{name}</text>
      )}
      {showSub && (
        <text x={x + 6} y={y + labelFont * 2 + 8} fill="#fff" fontSize={labelFont - 1} fillOpacity={0.85}>{value}건 ({pct}%)</text>
      )}
    </g>
  );
}

function StackedAreaView({ d, xName, groupName, height = 380 }: { d: Dataset; xName: string; groupName: string; height?: number }) {
  const f = useChartFonts();
  const { rows, groups } = stackedAreaData(d, xName, groupName);
  if (!rows.length || !groups.length) return <Empty />;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={rows} margin={{ top: 10, right: 20, bottom: 28, left: 12 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="x" tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisX(labelOf(d, xName), f.axis)} />
        <YAxis tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisY('건수', f.axis)} />
        <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} />
        {/* 범례를 상단에 둔다 — 기본(하단)이면 x축 제목과 겹친다 */}
        <Legend verticalAlign="top" height={28} wrapperStyle={{ fontSize: f.legend }} />
        {groups.map((g, i) => (
          <Area key={g} type="monotone" dataKey={g} name={g} stackId="1" stroke={COLORS[i % COLORS.length]} fill={COLORS[i % COLORS.length]} fillOpacity={0.7} />
        ))}
      </AreaChart>
    </ResponsiveContainer>
  );
}

function CategoryTreemap({ d, name, height = 380 }: { d: Dataset; name: string; height?: number }) {
  const f = useChartFonts();
  const data = pieData(d, name).map((x) => ({ name: x.category, size: x.count }));
  if (!data.length) return <Empty />;
  const total = d.rows.length; // 비율 분모 = 전체 행 수(파이/파레토와 동일 기준)
  return (
    <ResponsiveContainer width="100%" height={height}>
      <Treemap data={data} dataKey="size" nameKey="name" stroke="var(--surface)" content={<TreemapCell total={total} labelFont={f.dataLabel} />} isAnimationActive={false}>
        <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} formatter={(v: number) => `${v}건`} />
      </Treemap>
    </ResponsiveContainer>
  );
}

function LineView({ d, dateName, valueName, groupName, height = 380 }: { d: Dataset; dateName: string; valueName: string; groupName?: string; height?: number }) {
  const f = useChartFonts();
  // y값은 X 버킷별 평균이라, 축·범례·툴팁에 "(평균)"을 명시해 원값 오해를 막는다.
  const yLabel = `${labelOf(d, valueName)} (평균)`;

  // 계열(그룹) 지정 시 → 다중계열: 계열 값마다 선 1개(각 X 버킷 평균).
  if (groupName) {
    const { rows, groups } = multiLineData(d, dateName, valueName, groupName);
    if (!rows.length || !groups.length) return <Empty />;
    return (
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={rows} margin={{ top: 10, right: 20, bottom: 28, left: 12 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
          <XAxis dataKey="x" tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisX(labelOf(d, dateName), f.axis)} />
          <YAxis tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisY(yLabel, f.axis)} />
          <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} />
          {/* 범례 상단 — 기본(하단)이면 x축 제목과 겹친다(누적영역과 동일) */}
          <Legend verticalAlign="top" height={28} wrapperStyle={{ fontSize: f.legend }} />
          {groups.map((g, i) => (
            <Line key={g} type="monotone" dataKey={g} name={g} stroke={COLORS[i % COLORS.length]} strokeWidth={2} dot={{ r: 2 }} connectNulls />
          ))}
        </LineChart>
      </ResponsiveContainer>
    );
  }

  // 단일 계열(기존 동작)
  const data = lineData(d, dateName, valueName);
  if (!data.length) return <Empty />;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 10, right: 20, bottom: 28, left: 12 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="date" tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisX(labelOf(d, dateName), f.axis)} />
        <YAxis tick={{ fontSize: f.tick, fill: 'var(--text-muted)' }} label={axisY(yLabel, f.axis)} />
        <Tooltip contentStyle={{ ...tooltipStyle, fontSize: f.tooltip }} />
        <Line type="monotone" dataKey="value" name={yLabel} stroke={COLORS[0]} strokeWidth={2} dot={{ r: 3 }} />
      </LineChart>
    </ResponsiveContainer>
  );
}

/* ───────────────── 공용 ───────────────── */

const tooltipStyle = {
  background: 'var(--surface)',
  border: '1px solid var(--border)',
  borderRadius: 10,
  color: 'var(--text)',
  fontSize: 12,
};

// 축 컬럼명 라벨(Recharts XAxis/YAxis label) — fontSize 는 컨테이너 폭 기준으로 전달받는다.
const axisX = (value: string, fontSize = 12) => ({ value, position: 'insideBottom' as const, offset: -14, fill: 'var(--text-muted)', fontSize });
const axisY = (value: string, fontSize = 12) => ({ value, angle: -90, position: 'insideLeft' as const, fill: 'var(--text-muted)', fontSize, style: { textAnchor: 'middle' as const } });

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-text-muted">{label}</span>
      {children}
    </label>
  );
}

function Sel({ label, value, set, opts, d, emptyLabel }: { label: string; value: string; set: (v: string) => void; opts: string[]; d: Dataset; emptyLabel?: string }) {
  return (
    <Field label={label}>
      <select value={value} onChange={(e) => set(e.target.value)} className={selectCls}>
        {emptyLabel !== undefined && <option value="">{emptyLabel}</option>}
        {opts.map((o) => (
          <option key={o} value={o}>{labelOf(d, o)}</option>
        ))}
      </select>
    </Field>
  );
}

function Empty({ msg = '표시할 데이터가 없습니다. 변수를 선택해 주세요.' }: { msg?: string }) {
  return <div className="grid h-64 place-items-center text-sm text-text-muted">{msg}</div>;
}
