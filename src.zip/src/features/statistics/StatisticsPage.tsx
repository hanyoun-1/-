import { useMemo, useState } from 'react';
import PageHeader from '../../components/PageHeader';
import Card from '../../components/Card';
import NavFooter from '../../components/NavFooter';
import { useActiveDataset } from '../../hooks/useActiveDataset';
import { useStepStore } from '../../store/useStepStore';
import { isMissing } from '../../lib/dataQuality';
import type { StatRow } from '../../types';

const fmt = (n: number) => n.toLocaleString(undefined, { maximumFractionDigits: 2 });

// 수치형 기초통계 컬럼 정의(전부 한글, 왜도·첨도 제외)
const NUM_COLS: { key: keyof StatRow | 'count'; label: string }[] = [
  { key: 'count', label: '개수' },
  { key: 'mean', label: '평균' },
  { key: 'std', label: '표준편차' },
  { key: 'min', label: '최소' },
  { key: 'q1', label: '25%' },
  { key: 'median', label: '중앙값' },
  { key: 'q3', label: '75%' },
  { key: 'max', label: '최대' },
];

export default function StatisticsPage() {
  const d = useActiveDataset();
  const goto = useStepStore((s) => s.goto);
  const [selCat, setSelCat] = useState<string | null>(null); // 선택한 범주형 컬럼

  // 수치형: 각 변수의 유효(비결측) 개수
  const counts = useMemo(() => {
    const m = new Map<string, number>();
    if (!d) return m;
    for (const s of d.statistics) {
      let n = 0;
      for (const r of d.rows) {
        const v = r[s.name];
        if (!isMissing(v) && typeof v === 'number') n += 1;
      }
      m.set(s.name, n);
    }
    return m;
  }, [d]);

  // 범주형 컬럼 목록(가벼움) — 빈도 계산은 선택한 컬럼만 lazy하게 수행해 대용량에서 멈춤 방지
  const catCols = useMemo(() => (d ? d.columns.filter((c) => c.type === 'string' || c.type === 'bool') : []), [d]);
  const activeName = selCat && catCols.some((c) => c.name === selCat) ? selCat : catCols[0]?.name ?? null;
  const activeStats = useMemo(() => {
    if (!d || !activeName) return null;
    const col = catCols.find((c) => c.name === activeName)!;
    const map = new Map<string, number>();
    let total = 0;
    for (const r of d.rows) {
      if (isMissing(r[col.name])) continue;
      const k = String(r[col.name]);
      map.set(k, (map.get(k) ?? 0) + 1);
      total += 1;
    }
    const items = Array.from(map.entries())
      .map(([value, count]) => ({ value, count, pct: total ? Math.round((count / total) * 1000) / 10 : 0 }))
      .sort((a, b) => b.count - a.count);
    return { col, total, items };
  }, [d, catCols, activeName]);

  if (!d) return null;

  const RENDER_CAP = 300; // 표에 그릴 최대 항목 수(고유값 폭주 시 멈춤 방지)

  return (
    <>
      <PageHeader title="기초 통계" subtitle="수치형 변수의 기초통계량과 범주형 변수의 분포를 정리했어요." />

      {/* 좌우 2단(반응형: 좁으면 위아래 1단) — 좌: 수치형 / 우: 범주형 */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2 lg:items-stretch">
        {/* 왼쪽 컬럼: 수치형 기초통계량 */}
        <div>
          <h3 className="mb-3 text-base font-semibold text-text">수치형 기초통계량</h3>
          <Card>
            {d.statistics.length === 0 ? (
              <p className="text-sm text-text-muted">수치형 컬럼이 없습니다.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border text-left text-text-muted">
                      <th className="py-2 pr-4 font-medium">변수명</th>
                      {NUM_COLS.map((c) => (
                        <th key={c.label} className="py-2 pr-4 text-right font-medium tabular-nums">
                          {c.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {d.statistics.map((s) => (
                      <tr key={s.name} className="border-b border-border/60">
                        <td className="py-2.5 pr-4 font-medium text-text">{s.label}</td>
                        {NUM_COLS.map((c) => (
                          <td key={c.label} className="py-2.5 pr-4 text-right tabular-nums text-text">
                            {c.key === 'count' ? (counts.get(s.name) ?? 0).toLocaleString() : fmt(s[c.key] as number)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>

        {/* 오른쪽 컬럼: 범주형 요약 — lg에서 내용을 absolute로 띄워 행 높이 계산에서 제외
            → 행 높이는 수치형이 결정하고, 범주형은 그 셀을 채우며 내부 스크롤 */}
        <div className="lg:relative">
        <div className="flex flex-col lg:absolute lg:inset-0">
          <h3 className="mb-3 text-base font-semibold text-text">범주형 요약</h3>
          {catCols.length === 0 || !activeStats ? (
            <Card>
              <p className="text-sm text-text-muted">범주형 컬럼이 없습니다.</p>
            </Card>
          ) : (
            <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 md:grid-cols-[4fr_11fr]">
              {/* 좌측: 범주형 컬럼 리스트 */}
              <Card className="flex h-full min-h-0 flex-col">
                <ul className="min-h-0 flex-1 space-y-1 overflow-y-auto">
                  {catCols.map((col) => {
                    const on = col.name === activeStats.col.name;
                    return (
                      <li key={col.name}>
                        <button
                          onClick={() => setSelCat(col.name)}
                          className={`w-full rounded-btn px-3 py-2 text-left text-sm transition-colors ${
                            on ? 'bg-primary-soft font-semibold text-primary' : 'text-text hover:bg-surface-muted'
                          }`}
                        >
                          {col.label}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </Card>

              {/* 우측: 선택한 컬럼 상세 */}
              <div className="flex min-h-0 flex-col">
                <Card title={activeStats.col.label} subtitle={`${activeStats.items.length}개 항목 · 유효 ${activeStats.total.toLocaleString()}건`} className="flex h-full min-h-0 flex-col">
                  <div className="min-h-0 flex-1 overflow-y-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="sticky top-0 border-b border-border bg-surface text-left text-text-muted">
                          <th className="py-1.5 pr-4 font-medium">항목</th>
                          <th className="py-1.5 pr-10 text-right font-medium">빈도</th>
                          <th className="py-1.5 pr-12 text-right font-medium">비율</th>
                        </tr>
                      </thead>
                      <tbody>
                        {activeStats.items.slice(0, RENDER_CAP).map((it) => (
                          <tr key={it.value} className="border-b border-border/50">
                            <td className="py-1.5 pr-4 text-text">{it.value}</td>
                            <td className="py-1.5 pr-10 text-right tabular-nums text-text">{it.count.toLocaleString()}</td>
                            <td className="py-1.5 pr-12 text-right tabular-nums text-text-muted">{it.pct}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {activeStats.items.length > RENDER_CAP && (
                      <p className="mt-2 px-1 text-xs text-text-muted">
                        빈도 상위 {RENDER_CAP.toLocaleString()}개만 표시 · 나머지 {(activeStats.items.length - RENDER_CAP).toLocaleString()}개 항목 생략
                      </p>
                    )}
                  </div>
                </Card>
              </div>
            </div>
          )}
        </div>
        </div>
      </div>

      <NavFooter prevLabel="데이터 개요" nextLabel="전처리" onNext={() => goto('preprocess')} />
    </>
  );
}
