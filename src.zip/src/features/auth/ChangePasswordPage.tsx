import { useState, type FormEvent } from 'react';
import Button from '../../components/Button';
import BrandMark from '../../components/BrandMark';
import { changePasswordRequest } from '../../lib/auth/authApi';
import { useAuthStore } from '../../store/useAuthStore';

// 비밀번호 변경 화면.
//  · forced=true: must_change_password 강제 모드 — current_password 입력 없음, AuthGate 가 앱 대신 이 화면을 렌더.
//  · forced=false: 일반 변경 모드 — current_password 필수.
// 변경 성공 시 백엔드가 기존 refresh 를 폐기하므로, 재로그인 방식으로 마무리한다.
const inputCls =
  'w-full rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

const MIN_LEN = 8;

export default function ChangePasswordPage({ forced = false }: { forced?: boolean }) {
  const accessToken = useAuthStore((s) => s.accessToken);
  const logout = useAuthStore((s) => s.logout);

  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const tooShort = next.length > 0 && next.length < MIN_LEN;
  const mismatch = confirm.length > 0 && next !== confirm;
  const canSubmit =
    !busy &&
    next.length >= MIN_LEN &&
    next === confirm &&
    (forced || current.length > 0);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (next.length < MIN_LEN) return setError(`비밀번호는 ${MIN_LEN}자 이상이어야 합니다.`);
    if (next !== confirm) return setError('새 비밀번호가 일치하지 않습니다.');
    if (!accessToken) return setError('인증 정보가 없습니다. 다시 로그인해주세요.');

    setBusy(true);
    try {
      await changePasswordRequest(accessToken, next, forced ? undefined : current);
      setDone(true); // 성공 → 재로그인 안내 패널로 전환
    } catch (err) {
      setError(err instanceof Error ? err.message : '비밀번호 변경에 실패했습니다.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen place-items-center bg-bg px-4">
      <div className="w-full max-w-sm rounded-card border border-border bg-surface p-6 shadow-card">
        <div className="mb-5 flex items-center gap-2">
          <BrandMark className="h-8 w-8" />
          <span className="text-[34px] font-bold leading-none tracking-tight text-text">Elio</span>
        </div>

        {done ? (
          <>
            <h1 className="mb-1 text-base font-semibold text-text">비밀번호가 변경되었습니다</h1>
            <p className="mb-5 text-sm text-text-muted">보안을 위해 다시 로그인해주세요.</p>
            <Button className="w-full" onClick={() => void logout()}>
              로그인 화면으로
            </Button>
          </>
        ) : (
          <>
            <h1 className="mb-1 text-base font-semibold text-text">
              {forced ? '비밀번호 변경이 필요합니다' : '비밀번호 변경'}
            </h1>
            <p className="mb-5 text-sm text-text-muted">
              {forced
                ? '계속하려면 새 비밀번호를 설정하세요.'
                : '현재 비밀번호와 새 비밀번호를 입력하세요.'}
            </p>

            <form onSubmit={onSubmit} className="space-y-3">
              {!forced && (
                <div>
                  <span className="mb-1 block text-xs font-medium text-text-muted">현재 비밀번호</span>
                  <input
                    type="password"
                    autoComplete="current-password"
                    value={current}
                    onChange={(e) => setCurrent(e.target.value)}
                    className={inputCls}
                    placeholder="••••••••"
                    required
                  />
                </div>
              )}
              <div>
                <span className="mb-1 block text-xs font-medium text-text-muted">
                  새 비밀번호 ({MIN_LEN}자 이상)
                </span>
                <input
                  type="password"
                  autoComplete="new-password"
                  value={next}
                  onChange={(e) => setNext(e.target.value)}
                  className={inputCls}
                  placeholder="••••••••"
                  required
                />
              </div>
              <div>
                <span className="mb-1 block text-xs font-medium text-text-muted">새 비밀번호 확인</span>
                <input
                  type="password"
                  autoComplete="new-password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  className={inputCls}
                  placeholder="••••••••"
                  required
                />
              </div>

              {tooShort && <p className="text-sm text-danger">비밀번호는 {MIN_LEN}자 이상이어야 합니다.</p>}
              {mismatch && <p className="text-sm text-danger">새 비밀번호가 일치하지 않습니다.</p>}
              {error && <p className="text-sm text-danger">{error}</p>}

              <Button type="submit" loading={busy} disabled={!canSubmit} className="w-full">
                비밀번호 변경
              </Button>

              {forced && (
                <button
                  type="button"
                  onClick={() => void logout()}
                  className="w-full text-center text-xs text-text-muted hover:text-text"
                >
                  로그아웃
                </button>
              )}
            </form>
          </>
        )}
      </div>
    </div>
  );
}
