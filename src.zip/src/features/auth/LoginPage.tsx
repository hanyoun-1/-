import { useState, type FormEvent } from 'react';
import Button from '../../components/Button';
import BrandMark from '../../components/BrandMark';
import { useAuthStore } from '../../store/useAuthStore';

// 로그인 화면 — 미인증 시 AuthGate 가 이 화면만 렌더한다.
// 기존 디자인 토큰/공통 Button 재사용(새 디자인 시스템 만들지 않음).
const inputCls =
  'w-full rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

export default function LoginPage() {
  const login = useAuthStore((s) => s.login);
  const loading = useAuthStore((s) => s.loading);
  const sessionExpired = useAuthStore((s) => s.sessionExpired);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await login(email.trim(), password);
      // 성공 시 AuthGate 가 자동으로 앱 화면으로 전환(별도 이동 불필요).
    } catch (err) {
      // loginRequest 가 상태 코드로 매핑한 메시지를 표시(비활성 계정 안내 등).
      // 알 수 없는 오류는 일반 메시지로 통일(구체 사유 비노출).
      setError(err instanceof Error && err.message ? err.message : '이메일 또는 비밀번호가 올바르지 않습니다.');
    }
  };

  return (
    <div className="grid min-h-screen place-items-center bg-bg px-4">
      <div className="w-full max-w-sm rounded-card border border-border bg-surface p-6 shadow-card">
        <div className="mb-5 flex items-center gap-2">
          <BrandMark className="h-8 w-8" />
          <span className="text-[34px] font-bold leading-none tracking-tight text-text">Elio</span>
        </div>
        <h1 className="mb-1 text-base font-semibold text-text">로그인</h1>
        <p className="mb-5 text-sm text-text-muted">계정으로 로그인하세요.</p>

        {/* 세션 만료(계산/관리 요청 중 refresh 실패)로 돌아온 경우 안내 */}
        {sessionExpired && (
          <div className="mb-4 rounded-btn bg-warning/10 px-3 py-2 text-sm text-warning">
            세션이 만료되었습니다. 다시 로그인해주세요.
          </div>
        )}

        <form onSubmit={onSubmit} className="space-y-3">
          <div>
            <span className="mb-1 block text-xs font-medium text-text-muted">이메일</span>
            <input
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={inputCls}
              placeholder="admin@example.com"
              required
            />
          </div>
          <div>
            <span className="mb-1 block text-xs font-medium text-text-muted">비밀번호</span>
            <input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={inputCls}
              placeholder="••••••••"
              required
            />
          </div>

          {error && <p className="text-sm text-danger">{error}</p>}

          <Button type="submit" loading={loading} disabled={!email || !password} className="w-full">
            로그인
          </Button>
        </form>
      </div>
    </div>
  );
}
