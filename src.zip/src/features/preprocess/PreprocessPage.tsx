import { useEffect, useMemo, useRef, useState } from 'react';
import PageHeader from '../../components/PageHeader';
import Card from '../../components/Card';
import Button from '../../components/Button';
import { useActiveDataset } from '../../hooks/useActiveDataset';
import { useDatasetStore } from '../../store/useDatasetStore';
import { useStepStore } from '../../store/useStepStore';
import { columnHasTime, isMissing } from '../../lib/dataQuality';
import { downloadCsv, downloadXlsx } from '../../lib/cleanData';
import { applyStep as applyOneStep, countCastNulls, countOutOfRange, inferLagIntervals, sortRowsByTime, validateBins, validateFormula, validateNewColumnName } from '../../lib/preprocess';
import { useBusy } from '../../hooks/useBusy';
import BusyOverlay from '../../components/BusyOverlay';
import type { AppliedStep, CastType, DateFormat, Dataset, MissingMethod, PreprocessStep, Row } from '../../types';

const TABS = ['컬럼 편집', '결측치', '이상치', '수식', '구간화', '과거값', '인코딩', '스케일링'] as const;
type Tab = (typeof TABS)[number];

// 컬럼 타입 → 한글 라벨 (미리보기 헤더용). 알 수 없으면 원값 표시.
const TYPE_LABEL: Record<string, string> = { int: '정수', float: '실수', string: '문자', bool: '참/거짓', datetime: '날짜' };
const typeLabel = (t?: string) => (t ? TYPE_LABEL[t] ?? t : '');

// 미리보기 "표시 전용" 천단위 콤마 — rows·dtype 불변, 화면에 그릴 때만 적용(Excel 셀 서식 개념).
// 판정 순서 고정: dtype 게이트를 typeof보다 먼저 둬 datetime(epoch number여도)·str·category를 전부 제외.
// isId=true(식별자 컬럼): 사번·제품번호 등은 '수량'이 아니라 '코드'라 천단위 콤마를 붙이지 않는다(2026 → 2,026 방지).
function formatCell(v: unknown, dtype: string | undefined, isId = false): string {
  if (v === null || v === undefined) return ''; // 결측(호출부에서 이미 분기하지만 방어)
  if (dtype !== 'int' && dtype !== 'float') return String(v); // datetime·str·bool 등 원표시 유지
  if (typeof v !== 'number') return String(v);
  if (!Number.isFinite(v)) return String(v); // NaN·Infinity 기존 동작 유지
  if (isId) return String(v); // 식별자(ID): 콤마 없이 원값 그대로
  return v.toLocaleString('ko-KR', { maximumFractionDigits: 20 }); // 1,000 표준 표기 · 소수 반올림 방지로 명시
}

/* 작은 공용 폼 요소 */
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  // div 사용: <label>로 감싸면 빈 영역 클릭 시 첫 번째 버튼(전체 등)이 자동 클릭되는 문제 방지.
  return (
    <div className="block">
      <span className="mb-1 block text-xs font-medium text-text-muted">{label}</span>
      {children}
    </div>
  );
}
const selectCls =
  'w-full rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

// 가운데 기준(center-origin) 슬라이더 — 가운데=0, 오른쪽으로 갈수록 값↑.
// 강조선(fill)은 가운데에서 핸들 위치까지 양방향으로 균등하게 뻗어나간다(thumb 1개).
function CenterSlider({ value, max, onChange }: { value: number; max: number; onChange: (v: number) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const p = 50 + (Math.min(value, max) / max) * 50; // 핸들 위치(%) 50~100
  const fillLeft = 100 - p; // 가운데 기준 좌우 대칭
  const fillWidth = 2 * (p - 50);

  const setFromX = (clientX: number) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const ratio = (clientX - rect.left) / rect.width; // 0~1
    const k = ratio <= 0.5 ? 0 : ((ratio - 0.5) / 0.5) * max; // 오른쪽 절반만 사용
    onChange(Math.round(Math.min(max, Math.max(0, k)) * 10) / 10);
  };

  return (
    <div
      ref={ref}
      className="relative h-6 cursor-pointer select-none touch-none"
      onPointerDown={(e) => {
        dragging.current = true;
        (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
        setFromX(e.clientX);
      }}
      onPointerMove={(e) => dragging.current && setFromX(e.clientX)}
      onPointerUp={() => (dragging.current = false)}
    >
      <div className="absolute inset-x-0 top-1/2 h-1.5 -translate-y-1/2 rounded-full bg-surface-muted" />
      <div className="absolute left-1/2 top-1/2 h-3 w-px -translate-x-1/2 -translate-y-1/2 bg-border" />
      <div className="absolute top-1/2 h-1.5 -translate-y-1/2 rounded-full bg-primary" style={{ left: `${fillLeft}%`, width: `${fillWidth}%` }} />
      <div className="absolute top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-primary bg-surface shadow" style={{ left: `${p}%` }} />
    </div>
  );
}

// 전체 버튼 + 컬럼 체크박스 칩 (공용). counts 제공 시 컬럼명 옆에 고유값 수 뱃지 표시.
// vertical=true 면 한 줄에 하나씩(세로 목록)으로 배치.
function CheckboxChips({ cols, sel, setSel, nowrap, counts, vertical }: { cols: string[]; sel: string[]; setSel: (v: string[]) => void; nowrap?: boolean; counts?: Record<string, number>; vertical?: boolean }) {
  const all = sel.length === cols.length && cols.length > 0;
  const toggle = (c: string) => setSel(sel.includes(c) ? sel.filter((x) => x !== c) : [...sel, c]);

  if (vertical) {
    return (
      <div className="flex flex-col gap-1">
        <button
          onClick={() => setSel(all ? [] : [...cols])}
          className={`flex w-full items-center gap-2 rounded-btn border px-3 py-1.5 text-left text-sm font-medium transition-colors ${
            all ? 'border-primary bg-primary text-white' : 'border-primary/40 bg-primary-soft text-primary hover:bg-primary/20'
          }`}
        >
          <span className={`grid h-4 w-4 flex-none place-items-center rounded border text-[10px] ${all ? 'border-white bg-white text-primary' : 'border-primary'}`}>{all ? '✓' : ''}</span>
          전체
        </button>
        {cols.map((c) => {
          const on = sel.includes(c);
          return (
            <button
              key={c}
              onClick={() => toggle(c)}
              className={`flex w-full items-center gap-2 rounded-btn border px-3 py-1.5 text-left text-sm transition-colors ${
                on ? 'border-primary bg-primary-soft text-primary' : 'border-border bg-surface text-text hover:bg-surface-muted'
              }`}
            >
              <span className={`grid h-4 w-4 flex-none place-items-center rounded border text-[10px] ${on ? 'border-primary bg-primary text-white' : 'border-border'}`}>{on ? '✓' : ''}</span>
              <span className="truncate">{c}</span>
              {counts && counts[c] !== undefined && (
                <span className="ml-auto flex-none rounded bg-surface-muted px-1.5 py-0.5 text-[11px] tabular-nums text-text-muted">{counts[c].toLocaleString()}</span>
              )}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div className={`flex gap-2 ${nowrap ? 'flex-nowrap overflow-x-auto pb-1' : 'flex-wrap'}`}>
      <button
        onClick={() => setSel(all ? [] : [...cols])}
        className={`flex flex-none items-center gap-2 whitespace-nowrap rounded-btn border px-3 py-1.5 text-sm font-medium transition-colors ${
          all ? 'border-primary bg-primary text-white' : 'border-primary/40 bg-primary-soft text-primary hover:bg-primary/20'
        }`}
      >
        <span className={`grid h-4 w-4 place-items-center rounded border text-[10px] ${all ? 'border-white bg-white text-primary' : 'border-primary'}`}>{all ? '✓' : ''}</span>
        전체
      </button>
      {cols.map((c) => {
        const on = sel.includes(c);
        return (
          <button
            key={c}
            onClick={() => toggle(c)}
            className={`flex flex-none items-center gap-2 whitespace-nowrap rounded-btn border px-3 py-1.5 text-sm transition-colors ${
              on ? 'border-primary bg-primary-soft text-primary' : 'border-border bg-surface text-text hover:bg-surface-muted'
            }`}
          >
            <span className={`grid h-4 w-4 place-items-center rounded border text-[10px] ${on ? 'border-primary bg-primary text-white' : 'border-border'}`}>{on ? '✓' : ''}</span>
            {c}
            {counts && counts[c] !== undefined && (
              <span className="rounded bg-surface-muted px-1.5 py-0.5 text-[11px] tabular-nums text-text-muted">{counts[c].toLocaleString()}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}


export default function PreprocessPage() {
  const d = useActiveDataset();
  const { steps, addStep, undoStep, resetSteps } = useDatasetStore();
  const goto = useStepStore((s) => s.goto);

  if (!d) return null;

  return (
    <>
      <PageHeader title="전처리" subtitle="클릭으로 단계별로 적용하고, 마지막 단계는 되돌릴 수 있어요. 결과는 모든 화면에 반영됩니다." />

      <PreprocessEditor d={d} steps={steps} addStep={addStep} undoStep={undoStep} resetSteps={resetSteps} />

      {/* 푸터: 이전 / (전처리 데이터 저장 + 다음) */}
      <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-5">
        <Button variant="secondary" onClick={() => goto('statistics')}>← 기초 통계</Button>
        <div className="flex flex-col items-start gap-1">
          <span className="text-sm font-medium text-text-muted">전처리 데이터 내보내기</span>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => downloadCsv(d.rows, 'processed_data.csv')}>CSV로 저장</Button>
            <Button variant="secondary" onClick={() => downloadXlsx(d.rows, 'processed_data.xlsx')}>Excel로 저장</Button>
            <Button onClick={() => goto('visualize')}>시각화 →</Button>
          </div>
        </div>
      </div>
    </>
  );
}

// 전처리 편집 코어 — 적용 이력 + 5개 탭 + 미리보기. 데이터/스텝 액션을 주입받아
// 전처리 페이지와 병합 페이지 양쪽에서 재사용한다(둘 다 같은 activeDataset·steps 파이프라인을 공유).
export function PreprocessEditor({
  d,
  steps,
  addStep,
  undoStep,
  resetSteps,
}: {
  d: Dataset;
  steps: AppliedStep[];
  addStep: (step: PreprocessStep) => void;
  undoStep: () => void;
  resetSteps: () => void;
}) {
  const [tab, setTab] = useState<Tab>('결측치');
  const [sel, setSel] = useState<string[]>([]); // 좌측 공유 "대상 컬럼" 선택 (탭 변경 시 초기화)
  const [sortCols, setSortCols] = useState(false); // 컬럼 목록 표시 정렬(가나다순). 표시 전용 — 원본 순서·선택은 불변.
  const [busy, runBusy] = useBusy();
  // 적용은 전체 재프로파일이라 무거울 수 있어 스피너를 띄운 뒤 실행한다.
  const applyStep = (step: PreprocessStep) => runBusy(() => addStep(step));

  const numericCols = useMemo(() => d.columns.filter((c) => c.type === 'int' || c.type === 'float').map((c) => c.name), [d]);
  const categoricalCols = useMemo(() => d.columns.filter((c) => c.type === 'string' || c.type === 'bool').map((c) => c.name), [d]);
  const allCols = useMemo(() => d.columns.map((c) => c.name), [d]);
  // 래그 정렬 기준 후보 — datetime(형식 명확) + 숫자. 예측 화면 timeColOptions 와 같은 기준.
  //   ⚠ 형식이 애매한 날짜(dateFormat==='unknown')는 제외 → 잘못된 순서로 래그가 박히는 조용한 오류 차단.
  const timeCols = useMemo(
    () => d.columns.filter((c) => (c.type === 'datetime' && c.dateFormat !== 'unknown') || c.type === 'int' || c.type === 'float').map((c) => c.name),
    [d],
  );
  const hasAmbiguousDate = useMemo(() => d.columns.some((c) => c.type === 'datetime' && c.dateFormat === 'unknown'), [d]);
  const missCols = useMemo(() => d.columns.map((c) => c.name).filter((n) => d.rows.some((r) => isMissing(r[n]))), [d]);
  const dtypes = useMemo(() => Object.fromEntries(d.columns.map((c) => [c.name, c.type])), [d]);
  // 식별자(ID)로 인지된 컬럼 — 미리보기에서 천단위 콤마를 붙이지 않는다(코드성 숫자).
  const idCols = useMemo(() => new Set(d.columns.filter((c) => c.role === '식별자').map((c) => c.name)), [d]);

  // 미리보기 표시 정렬 — 래그가 적용됐으면 그 "정렬 기준 컬럼"으로 화면만 시간순 정렬한다(데이터·저장·export 불변).
  //   파일 순서가 시간순이 아니면 미리보기 첫 행이 "가장 이른 시점 행"(래그 값 null)이 되도록 맞춘다.
  //   가장 최근 래그 스텝의 sortBy 를 쓰되, 그 컬럼이 이후 삭제됐으면 정렬하지 않는다(표시할 축이 없음).
  const lagSortBy = useMemo<string | null>(() => {
    for (let i = steps.length - 1; i >= 0; i--) {
      const s = steps[i].step;
      if (s.type === 'lag') return allCols.includes(s.sortBy) ? s.sortBy : null;
    }
    return null;
  }, [steps, allCols]);
  // 표시용 사본만 정렬(sortRowsByTime 는 [...rows] 사본 반환). 래그 없으면 원본 그대로(동작 무변경).
  const orderedRows = useMemo(() => (lagSortBy ? sortRowsByTime(d.rows, lagSortBy) : d.rows), [lagSortBy, d.rows]);

  // 탭 변경 시 선택 초기화 (탭마다 대상 컬럼 집합이 다름)
  useEffect(() => { setSel([]); }, [tab]);

  // 인코딩 탭 전용: 컬럼별 고유값 수(.nunique()) — 무거우니 화면 먼저 그린 뒤 지연 계산
  const [uniqueCounts, setUniqueCounts] = useState<Record<string, number> | null>(null);
  useEffect(() => {
    if (tab !== '인코딩') { setUniqueCounts(null); return; }
    let cancelled = false;
    setUniqueCounts(null);
    const id = requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        const m: Record<string, number> = {};
        for (const c of categoricalCols) {
          const s = new Set<string>();
          for (const r of d.rows) if (!isMissing(r[c])) s.add(String(r[c]));
          m[c] = s.size;
        }
        if (!cancelled) setUniqueCounts(m);
      }),
    );
    return () => { cancelled = true; cancelAnimationFrame(id); };
  }, [tab, categoricalCols, d.rows]);

  // 탭별 좌측 "대상 컬럼" 박스 구성(목록/라벨/카운트/빈 메시지)
  const TAB_CFG: Record<Tab, { cols: string[]; label: string; counts?: Record<string, number>; emptyMsg: string; emptySuccess?: boolean }> = {
    결측치: { cols: missCols, label: '대상 컬럼 (체크 — 선택 시 미리보기에 해당 결측 행만, 복수=합집합)', emptyMsg: '결측치가 없습니다.', emptySuccess: true },
    '컬럼 편집': { cols: allCols, label: '컬럼 선택', emptyMsg: '컬럼이 없습니다.' },
    이상치: { cols: numericCols, label: '대상 컬럼 (체크 — 복수 선택)', emptyMsg: '수치형 컬럼이 없습니다.' },
    인코딩: { cols: categoricalCols, label: `대상 컬럼 (체크 — 복수 선택 · 숫자 = 고유값 수${uniqueCounts ? '' : ' · 계산 중…'})`, counts: uniqueCounts ?? undefined, emptyMsg: '범주형 컬럼이 없습니다.' },
    스케일링: { cols: numericCols, label: '대상 컬럼 (체크 — 복수 선택)', emptyMsg: '수치형 컬럼이 없습니다.' },
    구간화: { cols: numericCols, label: '대상 컬럼(숫자형) — 체크하여 선택(1개)', emptyMsg: '수치형 컬럼이 없습니다.' },
    수식: { cols: numericCols, label: '컬럼 클릭 시 수식에 삽입', emptyMsg: '수치형 컬럼이 없습니다.' },
    '과거값': { cols: numericCols, label: '대상 컬럼(숫자형) — 체크하여 선택(1개)', emptyMsg: '수치형 컬럼이 없습니다.' },
  };
  const cur = TAB_CFG[tab];
  const hasCols = cur.cols.length > 0;

  return (
    <>
      <div className="grid grid-cols-1 gap-5 md:grid-cols-[16rem_minmax(0,1fr)] md:items-stretch">
        {/* 왼쪽: 대상 컬럼 — 탭 공유 독립 박스(컬럼이 적어도 최소 높이 유지) */}
        <Card className="flex min-h-[30rem] flex-col">
          <div className="mb-2 flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-text-muted">{cur.label}</span>
            {hasCols && (
              <button
                type="button"
                onClick={() => setSortCols((v) => !v)}
                className={`flex-none rounded-btn border px-2 py-0.5 text-xs transition-colors ${
                  sortCols ? 'border-primary bg-primary-soft text-primary' : 'border-border bg-surface text-text-muted hover:bg-surface-muted'
                }`}
                title="컬럼 목록을 가나다순으로 정렬해 표시해요 (원본 순서·선택은 그대로)"
              >
                {sortCols ? '✓ 가나다순' : '가나다순'}
              </button>
            )}
          </div>
          <div className="pr-1">
            {hasCols ? (
              <CheckboxChips cols={sortCols ? [...cur.cols].sort((a, b) => a.localeCompare(b, 'ko')) : cur.cols} sel={sel} setSel={setSel} counts={cur.counts} vertical />
            ) : (
              <p className="text-sm text-text-muted">해당하는 컬럼이 없습니다.</p>
            )}
          </div>
        </Card>

        {/* 오른쪽: 적용 이력 / (탭+처리방법+적용) / 미리보기 — 미리보기는 대상 컬럼 높이까지 채움 */}
        <div className="flex min-h-0 min-w-0 flex-col gap-5">
          {/* 적용 이력 + 탭 박스: 가로 2단 배치 (각 박스 너비 ↓) */}
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-[4fr_5fr] lg:items-stretch">
          {/* 적용 이력 */}
          <Card
            title={`적용 이력 (${steps.length}단계)`}
            right={
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => runBusy(undoStep)} disabled={!steps.length}>
                  이전 단계 취소
                </Button>
                <Button variant="ghost" onClick={() => runBusy(resetSteps)} disabled={!steps.length}>
                  원본으로 되돌리기
                </Button>
              </div>
            }
          >
            {steps.length ? (
              <ol className="space-y-1 text-sm">
                {steps.map((s, i) => (
                  <li key={i} className="flex items-center gap-2 text-text">
                    <span className="grid h-5 w-5 flex-none place-items-center rounded-full bg-primary-soft text-xs text-primary">{i + 1}</span>
                    {s.log}
                  </li>
                ))}
              </ol>
            ) : (
              <p className="text-sm text-text-muted">아직 적용한 전처리가 없습니다.</p>
            )}
          </Card>

          {/* 탭 + 처리 방법 + 적용 */}
          <Card>
            <div className="mb-4 flex gap-1 rounded-btn border border-border bg-surface-muted p-1">
              {TABS.map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`flex-1 min-w-0 whitespace-nowrap rounded-chip px-4 py-1.5 text-center text-sm font-medium transition-all ${
                    tab === t ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {!hasCols ? (
              <p className={`text-sm ${cur.emptySuccess ? 'text-success' : 'text-text-muted'}`}>{cur.emptyMsg}</p>
            ) : (
              <>
                {tab === '결측치' && <MissingControls sel={sel} setSel={setSel} onApply={applyStep} />}
                {tab === '컬럼 편집' && <ColumnEditControls sel={sel} setSel={setSel} dtypes={dtypes} rows={d.rows} onApply={applyStep} />}
                {tab === '이상치' && <OutlierControls sel={sel} setSel={setSel} rows={d.rows} onApply={applyStep} />}
                {tab === '인코딩' && <EncodeControls sel={sel} setSel={setSel} counts={uniqueCounts} onApply={applyStep} />}
                {tab === '스케일링' && <ScaleControls sel={sel} setSel={setSel} onApply={applyStep} />}
                {tab === '구간화' && <BinningControls sel={sel} setSel={setSel} rows={d.rows} existingColumns={allCols} onApply={applyStep} />}
                {tab === '수식' && <FormulaControls sel={sel} setSel={setSel} columns={allCols} rows={d.rows} onApply={applyStep} />}
                {tab === '과거값' && <LagControls sel={sel} setSel={setSel} rows={d.rows} timeCols={timeCols} groupCols={categoricalCols} hasAmbiguousDate={hasAmbiguousDate} existingColumns={allCols} onApply={applyStep} />}
              </>
            )}
          </Card>
          </div>

          {/* 현재 데이터 미리보기 — 남은 공간을 채우되(flex-1), 과하게 쪼그라들지 않도록 최소 높이 보장 */}
          <div className="md:relative md:min-h-[24rem] md:flex-1">
          {(() => {
            const filtering = tab === '결측치' && sel.length > 0;
            // orderedRows: 래그 적용 시 시간순 정렬된 표시용 사본, 아니면 d.rows 원본(동작 무변경).
            const previewRows = filtering ? orderedRows.filter((r) => sel.some((c) => isMissing(r[c]))) : orderedRows;
            const highlight = new Set(sel);
            return (
              <Card
                title="현재 데이터 미리보기"
                subtitle={
                  filtering
                    ? `선택한 컬럼(${sel.join(', ')})에 결측이 있는 행 ${previewRows.length.toLocaleString()}개 — 상위 100개`
                    : `${d.rowCount.toLocaleString()}행 × ${d.colCount}열${lagSortBy ? ` · ${lagSortBy} 기준 시간순 표시` : ''}`
                }
                className="md:absolute md:inset-0 md:flex md:flex-col"
              >
                <div className="max-h-96 overflow-auto md:max-h-none md:min-h-0 md:flex-1">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="sticky top-0 border-b border-border bg-surface text-left text-text-muted">
                        {allCols.map((c) => (
                          <th key={c} className={`whitespace-nowrap px-3 py-2 font-medium ${highlight.has(c) ? 'text-warning' : ''}`}>
                            {/* 컬럼 편집 탭에서만 컬럼명 위에 타입 표시 */}
                            {tab === '컬럼 편집' && (
                              <span className="block text-[11px] font-normal text-text-muted">{typeLabel(dtypes[c])}</span>
                            )}
                            {c}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {previewRows.slice(0, 100).map((r, i) => (
                        <tr key={i} className="border-b border-border/50">
                          {allCols.map((c) => (
                            <td key={c} className={`whitespace-nowrap px-3 py-1.5 ${highlight.has(c) && isMissing(r[c]) ? 'bg-warning/10 text-warning' : 'text-text'}`}>
                              {isMissing(r[c]) ? <span className="text-text-muted">·</span> : formatCell(r[c], dtypes[c], idCols.has(c))}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            );
          })()}
          </div>
        </div>
      </div>

      <BusyOverlay show={busy} label="적용 중…" />
    </>
  );
}

/* ───────────────── 탭별 처리 컨트롤 (대상 컬럼은 좌측 공유 박스에서 선택) ───────────────── */

type ApplyFn = ReturnType<typeof useDatasetStore.getState>['addStep'];
type ControlsProps = { sel: string[]; setSel: (v: string[]) => void; onApply: ApplyFn };

function MissingControls({ sel, setSel, onApply }: ControlsProps) {
  const [method, setMethod] = useState<MissingMethod>('median');
  const [value, setValue] = useState('0');
  return (
    <Field label="처리 방법">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex flex-wrap gap-1 rounded-btn border border-border bg-surface-muted p-1">
          {([
            { v: 'drop', label: '행 삭제' },
            { v: 'mean', label: '평균' },
            { v: 'median', label: '중앙값' },
            { v: 'mode', label: '최빈값' },
            { v: 'value', label: '지정값' },
          ] as { v: MissingMethod; label: string }[]).map((o) => (
            <button
              key={o.v}
              onClick={() => setMethod(o.v)}
              className={`min-w-[6.5rem] rounded-chip px-4 py-1.5 text-center text-sm font-medium transition-all ${
                method === o.v ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text'
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>
        {method === 'value' && (
          <input value={value} onChange={(e) => setValue(e.target.value)} className={`${selectCls} min-w-[8rem] flex-1`} placeholder="채울 값" />
        )}
        <Button
          className="ml-auto flex-none whitespace-nowrap"
          disabled={!sel.length}
          onClick={() => {
            onApply({ type: 'missing', columns: sel, method, value: method === 'value' ? value : undefined });
            setSel([]);
          }}
        >
          결측치 처리 적용
        </Button>
      </div>
    </Field>
  );
}

function ColumnEditControls({ sel, setSel, dtypes, rows, onApply }: ControlsProps & { dtypes: Record<string, string>; rows: Record<string, unknown>[] }) {
  const [newName, setNewName] = useState('');
  const [castTo, setCastTo] = useState<CastType>('float');
  const [dateFmt, setDateFmt] = useState<'auto' | DateFormat>('auto'); // datetime 변환 시 날짜 형식(auto=자동 감지=기존 동작)
  const [extractNumber, setExtractNumber] = useState(false); // int/float 변환 시 "숫자만 추출" opt-in
  const renameTarget = sel.length === 1 ? sel[0] : null;
  const numericCast = castTo === 'int' || castTo === 'float';

  // datetime 변환 시 시각 보존 여부 자동 판정(정보성 안내용). 선택 컬럼 중 하나라도 시각이 있으면 안내.
  //   columnHasTime은 첫 시각값에서 조기 종료 → 가볍지만, 시각 없는 대용량 컬럼은 전수 스캔이라 useMemo로 캐시.
  const datetimeHasTime = useMemo(
    () => castTo === 'datetime' && sel.some((c) => columnHasTime(rows as Row[], c)),
    [castTo, sel, rows],
  );

  // 변환 실패(값이 있었는데 null이 되는) 개수 사전 경고 — int/float일 때만. 추출 체크 상태를 반영해
  // 재계산(체크하면 실패 수가 줄어드는 걸 눈으로 확인). 렌더 블로킹 방지로 이중 rAF(이상치 탭 선례).
  const [failInfo, setFailInfo] = useState<{ fails: number; total: number } | null>(null);
  useEffect(() => {
    if (!numericCast || !sel.length) { setFailInfo(null); return; }
    let cancelled = false;
    setFailInfo(null);
    const id = requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        let fails = 0;
        for (const c of sel) fails += countCastNulls(rows as Row[], c, castTo, extractNumber);
        if (!cancelled) setFailInfo({ fails, total: rows.length * sel.length });
      }),
    );
    return () => { cancelled = true; cancelAnimationFrame(id); };
  }, [rows, sel, castTo, extractNumber, numericCast]);

  return (
    <div>
      {/* 이름 변경 / 타입 변환 / 삭제 — 패널 폭에 따라 3단계로 세로 쌓기(컨테이너 쿼리) */}
      <div>
      <div className="coledit-wrap">
      <div className="coledit-outer">
        {/* 새 컬럼명 + 이름 변경 적용 (G1) */}
        <div className="flex flex-none items-center gap-2">
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            className="w-[7.5rem] flex-none rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none"
            placeholder={renameTarget ? `"${renameTarget}" 의 새 이름` : '새 컬럼명 (1개 선택)'}
            disabled={!renameTarget}
          />
          <Button
            className="min-w-[7.5rem] flex-none justify-center whitespace-nowrap"
            disabled={!renameTarget || !newName.trim()}
            onClick={() => { if (renameTarget) { onApply({ type: 'rename', from: renameTarget, to: newName.trim() }); setNewName(''); setSel([]); } }}
          >
            이름 변경 적용
          </Button>
        </div>
        {/* 나머지: 타입 변환 그룹(G2) + 선택 컬럼 삭제(G3) */}
        <div className="coledit-rest">
          {/* 타입 드롭다운 + 타입 변환 적용 (G2) */}
          <div className="flex flex-none items-center gap-2">
            <select
              value={castTo}
              onChange={(e) => setCastTo(e.target.value as CastType)}
              className="h-9 w-[7.5rem] flex-none rounded-btn border border-border bg-surface px-3 py-0 text-sm text-text focus:border-primary focus:outline-none"
              disabled={!sel.length}
              title={renameTarget ? `현재 타입: ${dtypes[renameTarget]}` : '선택한 컬럼들의 타입을 변환'}
            >
              <option value="float">실수(float)</option>
              <option value="int">정수(int)</option>
              <option value="str">문자(str)</option>
              <option value="datetime">날짜(datetime)</option>
              <option value="category">범주(category)</option>
            </select>
            {/* 날짜 형식 — datetime 변환일 때만. auto(기본)=자동 감지(기존 동작). 애매한 날짜는 직접 지정해 파싱. */}
            {castTo === 'datetime' && (
              <select
                value={dateFmt}
                onChange={(e) => setDateFmt(e.target.value as 'auto' | DateFormat)}
                className="h-9 w-[9rem] flex-none rounded-btn border border-border bg-surface px-3 py-0 text-sm text-text focus:border-primary focus:outline-none"
                disabled={!sel.length}
                title="날짜 표기 형식(자동 감지가 기본)"
              >
                <option value="auto">형식: 자동 감지</option>
                <option value="DMY">일-월-년 (DMY)</option>
                <option value="MDY">월-일-년 (MDY)</option>
                <option value="ISO">연-월-일 (ISO)</option>
              </select>
            )}
            <Button
              className="min-w-[7.5rem] flex-none justify-center whitespace-nowrap"
              disabled={!sel.length}
              onClick={() => {
                // datetime → dateFormat(형식 지정) · int/float → extractNumber(숫자 추출). 대상 타입 상호배타라 나란히 둔다.
                sel.forEach((c) =>
                  onApply({
                    type: 'astype',
                    column: c,
                    to: castTo,
                    ...(castTo === 'datetime' && dateFmt !== 'auto' ? { dateFormat: dateFmt } : {}),
                    ...(numericCast && extractNumber ? { extractNumber: true } : {}),
                  }),
                );
                setSel([]);
              }}
            >
              타입 변환 적용
            </Button>
          </div>
          {/* 선택 컬럼 삭제 (G3) */}
          <Button variant="danger" className="flex-none justify-center whitespace-nowrap" disabled={!sel.length} onClick={() => { onApply({ type: 'dropColumns', columns: sel }); setSel([]); }}>
            선택 컬럼 삭제 ({sel.length})
          </Button>
        </div>
      </div>
      </div>
      {/* 숫자 변환 옵션·경고 — int/float 선택 시에만 */}
      {numericCast && sel.length > 0 && (
        <div className="mt-2 space-y-1">
          <label className="flex items-center gap-2 text-xs text-text">
            <input
              type="checkbox"
              checked={extractNumber}
              onChange={(e) => setExtractNumber(e.target.checked)}
              className="h-3.5 w-3.5 accent-primary"
            />
            숫자만 추출 (예: &apos;1회&apos;→1, &apos;1,234&apos;→1234)
          </label>
          {failInfo === null ? (
            <p className="text-[11px] leading-tight text-text-muted">변환 실패 개수 확인 중…</p>
          ) : failInfo.fails > 0 ? (
            <p className="text-[11px] leading-tight text-warning">
              변환 실패 {failInfo.fails.toLocaleString()}개
              ({((failInfo.fails / Math.max(failInfo.total, 1)) * 100).toFixed(1)}%) → 결측이 됩니다
            </p>
          ) : null}
        </div>
      )}
      {/* 시각 보존 안내 — datetime + 시각 감지 시에만. 데이터가 보존되는 것이므로 정보(ℹ) 톤. */}
      {datetimeHasTime && (
        <p className="mt-2 text-[11px] leading-tight text-primary">
          시각 정보가 감지되었습니다 — 00:15:00 형태로 함께 보존됩니다.
        </p>
      )}
      <p className="mt-1 text-[11px] leading-tight text-text-muted">
        이름 변경은 컬럼 1개만 선택 시 가능합니다.
        {castTo === 'datetime' && ' · 05/06/2018처럼 5월 6일인지 6월 5일인지 알 수 없는 경우 날짜 형식을 직접 지정하세요.'}
      </p>
      </div>
    </div>
  );
}

function OutlierControls({ sel, setSel, rows, onApply }: ControlsProps & { rows: Record<string, unknown>[] }) {
  const [mode, setMode] = useState<'recommend' | 'iqr' | 'clip'>('recommend');
  const [k, setK] = useState(1.5);
  const [lower, setLower] = useState('');
  const [upper, setUpper] = useState('');

  // IQR 미리보기 — 선택 컬럼들 중 하나라도 경계를 벗어난 행 수(합집합).
  // 정렬 O(k·n log n)이 무거워 렌더에서 분리(인코딩 탭 nunique와 동일 패턴):
  // null = 계산 중(로딩) · 화면 먼저 그린 뒤 이중 rAF로 지연 계산.
  const [preview, setPreview] = useState<{ cnt: number; single: { c: string; lo: number; hi: number } | null } | null>(null);
  useEffect(() => {
    if (!sel.length) { setPreview(null); return; }
    let cancelled = false;
    setPreview(null);
    const id = requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        const fences = sel
          .map((c) => {
            const vals = rows.map((r) => Number(r[c])).filter((v) => !Number.isNaN(v)).sort((a, b) => a - b);
            if (vals.length < 4) return null;
            const q = (p: number) => { const pos = (vals.length - 1) * p; const b = Math.floor(pos); return vals[b + 1] !== undefined ? vals[b] + (pos - b) * (vals[b + 1] - vals[b]) : vals[b]; };
            const q1 = q(0.25), q3 = q(0.75), iqr = q3 - q1;
            return { c, lo: q1 - k * iqr, hi: q3 + k * iqr };
          })
          .filter((f): f is { c: string; lo: number; hi: number } => f !== null);
        if (!fences.length) { if (!cancelled) setPreview(null); return; }
        let cnt = 0;
        for (const r of rows) {
          for (const f of fences) {
            const v = Number(r[f.c]);
            if (!Number.isNaN(v) && (v < f.lo || v > f.hi)) { cnt++; break; }
          }
        }
        if (!cancelled) setPreview({ cnt, single: fences.length === 1 ? fences[0] : null });
      }),
    );
    return () => { cancelled = true; cancelAnimationFrame(id); };
  }, [rows, sel, k]);

  return (
    <div className="space-y-4">
      {/* 방식 — 3개 버튼 한 줄 */}
      <Field label="방식">
        <div className="grid grid-cols-3 gap-1 rounded-btn border border-border bg-surface-muted p-1">
          {([
            { v: 'recommend', label: '기본 추천값 적용 (IQR×1.5)' },
            { v: 'iqr', label: 'IQR 배수 (행 제거)' },
            { v: 'clip', label: '직접 범위 (경계값 자르기)' },
          ] as { v: 'recommend' | 'iqr' | 'clip'; label: string }[]).map((o) => (
            <button
              key={o.v}
              onClick={() => setMode(o.v)}
              className={`rounded-chip px-2 py-1.5 text-center text-sm font-semibold transition-all ${
                mode === o.v ? 'bg-primary text-white shadow-sm' : 'text-text hover:bg-surface'
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>
      </Field>

      {/* ③ 방식별 옵션 + 적용 버튼 (같은 줄, 버튼 오른쪽 끝) */}
      <div className="border-t border-border pt-4">
        {mode === 'recommend' && (
          <div className="flex items-center gap-4">
            <p className="flex-1 text-sm text-text-muted">
              기본 추천값(IQR×1.5) 기준으로 선택 컬럼의 이상치 행을 제거합니다.
              {preview
                ? <> 제거 대상 <span className="font-semibold text-warning">{preview.cnt.toLocaleString()}개</span>.</>
                : sel.length > 0 && <> 제거 대상 <span className="text-text-muted">계산 중…</span></>}
            </p>
            <Button className="flex-none" disabled={!sel.length} onClick={() => { sel.forEach((c) => onApply({ type: 'outlierIQR', column: c, k: 1.5 })); setSel([]); }}>이상치 제거 적용</Button>
          </div>
        )}

        {mode === 'iqr' && (
          <Field label={`IQR 배수 (k = ${k.toFixed(1)}) — 클수록 관대`}>
            <div className="flex items-center gap-4">
              <div className="flex-1"><CenterSlider value={k} max={3} onChange={setK} /></div>
              <Button className="flex-none" disabled={!sel.length} onClick={() => { sel.forEach((c) => onApply({ type: 'outlierIQR', column: c, k })); setSel([]); }}>이상치 제거 적용</Button>
            </div>
            {preview ? (
              <p className="mt-2 text-sm text-text-muted">
                제거 대상: <span className="font-semibold text-warning">{preview.cnt.toLocaleString()}개</span>
                {preview.single ? ` (정상 범위 ${preview.single.lo.toFixed(1)} ~ ${preview.single.hi.toFixed(1)})` : ' (선택 컬럼별 IQR 기준)'}
              </p>
            ) : sel.length > 0 && (
              <p className="mt-2 text-sm text-text-muted">제거 대상: <span className="text-text-muted">계산 중…</span></p>
            )}
          </Field>
        )}

        {mode === 'clip' && (
          <Field label="직접 범위 (경계값으로 자르기)">
            <div className="flex items-center gap-4">
              <div className="grid flex-1 grid-cols-2 gap-3 sm:max-w-md">
                <input value={lower} onChange={(e) => setLower(e.target.value)} className={selectCls} placeholder="하한 (예: 0)" />
                <input value={upper} onChange={(e) => setUpper(e.target.value)} className={selectCls} placeholder="상한 (예: 120)" />
              </div>
              <Button
                className="ml-auto flex-none whitespace-nowrap"
                disabled={!sel.length || (lower === '' && upper === '')}
                onClick={() => {
                  sel.forEach((c) => onApply({ type: 'outlierClip', column: c, lower: lower === '' ? null : Number(lower), upper: upper === '' ? null : Number(upper) }));
                  setSel([]);
                }}
              >
                이상치 제거 적용
              </Button>
            </div>
          </Field>
        )}
      </div>
    </div>
  );
}

function EncodeControls({ sel, setSel, counts, onApply }: ControlsProps & { counts: Record<string, number> | null }) {
  const [method, setMethod] = useState<'onehot' | 'label'>('onehot');
  // 선택 컬럼 중 고유값이 가장 많은 값(원-핫 경고용) — 고유값 수는 좌측 박스에서 계산해 전달받음
  const maxUnique = counts ? Math.max(0, ...sel.map((c) => counts[c] ?? 0)) : 0;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-[180px] flex-1">
          <Field label="방식">
            <div className="grid h-10 grid-cols-2 gap-1 rounded-btn border border-border bg-surface-muted p-1">
              {([
                { v: 'onehot', label: '원-핫(One-Hot)' },
                { v: 'label', label: '라벨(Label)' },
              ] as { v: 'onehot' | 'label'; label: string }[]).map((o) => (
                <button
                  key={o.v}
                  onClick={() => setMethod(o.v)}
                  className={`flex h-full items-center justify-center rounded-chip px-3 text-center text-sm font-medium transition-all ${
                    method === o.v ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text'
                  }`}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </Field>
        </div>
        <Button className="h-10 flex-none whitespace-nowrap" disabled={!sel.length} onClick={() => { sel.forEach((c) => onApply({ type: 'encode', column: c, method })); setSel([]); }}>
          인코딩 적용
        </Button>
      </div>
      {method === 'onehot' && maxUnique > 20 && (
        <p className="rounded-btn bg-warning/10 px-3 py-2 text-sm text-warning">
          고유값이 최대 {maxUnique}개인 컬럼이 있어요. 원-핫 인코딩 시 컬럼이 크게 늘어납니다. 라벨 인코딩을 고려하세요.
        </p>
      )}
    </div>
  );
}

function ScaleControls({ sel, setSel, onApply }: ControlsProps) {
  const [method, setMethod] = useState<'standard' | 'minmax'>('standard');
  return (
    <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-[180px] flex-1">
          <Field label="방식">
            <div className="grid h-10 grid-cols-2 gap-1 rounded-btn border border-border bg-surface-muted p-1">
              {([
                { v: 'standard', label: '표준화(Standard)' },
                { v: 'minmax', label: '정규화(MinMax)' },
              ] as { v: 'standard' | 'minmax'; label: string }[]).map((o) => (
                <button
                  key={o.v}
                  onClick={() => setMethod(o.v)}
                  className={`flex h-full items-center justify-center rounded-chip px-3 text-center text-sm font-medium transition-all ${
                    method === o.v ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text'
                  }`}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </Field>
        </div>
        <Button className="h-10 flex-none whitespace-nowrap" disabled={!sel.length} onClick={() => { onApply({ type: 'scale', columns: sel, method }); setSel([]); }}>
          스케일링 적용
        </Button>
    </div>
  );
}

// 간격 표시용 숫자 정리 — 정수에 근사하면 정수, 아니면 소수 2자리(부동소수 지터 흡수).
function cleanNum(x: number): string {
  const r = Math.abs(x - Math.round(x)) < 1e-9 ? Math.round(x) : Math.round(x * 100) / 100;
  return String(r);
}
// 밀리초 → 사람이 읽는 기간. 가장 큰 '깔끔한' 단위를 고른다. 월·년은 근사라 '약'을 붙이고, 정수 개월/년에 가까울 때만 승격.
//   예) 900000→"15분", 2700000→"45분", 86400000→"1일", 2.63e9→"약 1개월".
function humanizeMs(ms: number): string {
  const sec = ms / 1000, min = sec / 60, hr = min / 60, day = hr / 24;
  const yr = day / 365.25, mo = day / 30.44;
  const nearInt = (x: number) => Math.round(x) >= 1 && Math.abs(x - Math.round(x)) <= 0.1;
  if (day >= 300 && nearInt(yr)) return `약 ${Math.round(yr)}년`;
  if (day >= 25 && nearInt(mo)) return `약 ${Math.round(mo)}개월`;
  if (day >= 1) return `${cleanNum(day)}일`;
  if (hr >= 1) return `${cleanNum(hr)}시간`;
  if (min >= 1) return `${cleanNum(min)}분`;
  if (sec >= 1) return `${cleanNum(sec)}초`;
  return `${cleanNum(ms)}ms`;
}

// 래그 — sortBy 기준 시간순 정렬 후 'periods 시점 전' 값을 새 컬럼으로 생성(시계열 피처).
//   정렬 기준(sortBy)은 필수 — 정렬 안 하면 조용히 미래 값이 섞이므로 UI 로 강제한다.
function LagControls({ sel, rows, timeCols, groupCols, hasAmbiguousDate, existingColumns, onApply }: ControlsProps & { rows: Row[]; timeCols: string[]; groupCols: string[]; hasAmbiguousDate: boolean; existingColumns: string[] }) {
  const column = sel[0] ?? '';
  const [periods, setPeriods] = useState('1');
  const [sortBy, setSortBy] = useState('');
  const [groupBy, setGroupBy] = useState(''); // '' = 그룹 없음(전체 하나) — 기존 동작
  const [timeBased, setTimeBased] = useState(false); // 시간 기준(그리드 스냅) 토글 — 기본 off(=기존 positional)
  const [newColumn, setNewColumn] = useState('');
  const [pendingConfirm, setPendingConfirm] = useState(false);

  const p = Number(periods);
  const periodsOk = Number.isInteger(p) && p >= 1;
  // 대상 컬럼이 바뀌면 새 컬럼명 기본값 제안(사용자 수정 가능).
  useEffect(() => {
    if (column) setNewColumn(`${column}_${periodsOk ? p : 1}시점전`);
  }, [column, p, periodsOk]);
  // 데이터 간격(Δ) 조회 — 기존 헬퍼 재사용. periods 와 무관하게 rows·sortBy·groupBy 로만 계산(35k 행에서 키 입력마다 재계산 방지).
  //   periods 변경은 아래 표시 문구의 곱만 바뀌므로 이 무거운 계산은 다시 돌지 않는다.
  const intervalInfo = useMemo(
    () => (sortBy ? inferLagIntervals(rows, sortBy, groupBy || undefined) : null),
    [rows, sortBy, groupBy],
  );

  // 정렬 후보에서 대상 컬럼은 빼는 게 자연스럽다(자기 자신을 시간축으로 삼지 않음).
  const sortCandidates = timeCols.filter((c) => c !== column);
  // 그룹 후보: 범주형/문자열 컬럼(매장ID·설비ID 등). 대상·정렬기준 컬럼은 제외.
  const groupCandidates = groupCols.filter((c) => c !== column && c !== sortBy);
  const nameV = useMemo(() => validateNewColumnName(newColumn, existingColumns), [newColumn, existingColumns]);

  const selectionError =
    sel.length === 0 ? '대상 컬럼을 1개 선택하세요.' : sel.length > 1 ? `과거 시점 값은 대상 컬럼을 1개만 선택할 수 있습니다. 현재 ${sel.length}개 선택됨.` : null;
  const sortError = sortCandidates.length === 0 ? '정렬 기준으로 쓸 날짜·숫자 컬럼이 없습니다.' : !sortBy ? '정렬 기준 컬럼을 선택하세요 (과거 시점 값은 시간순 정렬이 전제입니다).' : null;
  const canApply = sel.length === 1 && periodsOk && !!sortBy && nameV.ok;

  useEffect(() => { setPendingConfirm(false); }, [newColumn, column, periods, sortBy, groupBy, timeBased, sel.length]);

  // 시간 기준(timeBased) 켰을 때 결측 사전 경고 — 실제 applyLag 를 임시 컬럼으로 돌려 null 개수를 센다(로직 드리프트 없음).
  //   렌더 블로킹 방지로 이중 rAF(변환 실패 경고 선례). off 이면 계산 안 함.
  const [nullInfo, setNullInfo] = useState<{ nulls: number; total: number } | null>(null);
  useEffect(() => {
    if (!timeBased || !canApply) { setNullInfo(null); return; }
    let cancelled = false;
    setNullInfo(null);
    const id = requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        const out = applyOneStep(rows, { type: 'lag', column, periods: p, sortBy, newColumn: '__lag_preview__', ...(groupBy ? { groupBy } : {}), timeBased: true });
        let nulls = 0;
        for (const r of out) if (isMissing(r['__lag_preview__'])) nulls++;
        if (!cancelled) setNullInfo({ nulls, total: out.length });
      }),
    );
    return () => { cancelled = true; cancelAnimationFrame(id); };
  }, [timeBased, canApply, rows, column, p, sortBy, groupBy]);

  const doApply = () => {
    // groupBy·timeBased 는 활성 시에만 실어 보낸다(비활성이면 필드 생략 → 기존 스텝과 동일, 하위호환).
    onApply({ type: 'lag', column, periods: p, sortBy, newColumn: newColumn.trim(), ...(groupBy ? { groupBy } : {}), ...(timeBased ? { timeBased: true } : {}) });
    setPendingConfirm(false);
  };
  const apply = () => {
    if (!canApply) return;
    if (nameV.isDuplicate) { setPendingConfirm(true); return; }
    doApply();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <Field label="몇 시점 전 (periods)">
          <input value={periods} onChange={(e) => setPeriods(e.target.value)} className={`${binInputCls} w-24`} placeholder="1" inputMode="numeric" />
        </Field>
        <Field label="정렬 기준 컬럼 (시간축)">
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className={`${binInputCls} w-52`} disabled={sortCandidates.length === 0}>
            <option value="">선택하세요</option>
            {sortCandidates.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="그룹 컬럼 (선택)">
          <select value={groupBy} onChange={(e) => setGroupBy(e.target.value)} className={`${binInputCls} w-52`} disabled={groupCandidates.length === 0}>
            <option value="">전체 (그룹 없음)</option>
            {groupCandidates.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="새 컬럼 이름">
          <input value={newColumn} onChange={(e) => setNewColumn(e.target.value)} className={`${binInputCls} w-52`} placeholder="예: 수율_1시점전" />
        </Field>
      </div>

      {/* 데이터 간격 안내 — 'N시점 전'이 실제로 얼마 전인지 표시(sortBy 선택 시). periods 변경 시 즉시 갱신. */}
      {sortBy && intervalInfo && (() => {
        const P = periodsOk ? p : 1;
        if (!intervalInfo.ok) {
          // 불규칙·데이터 부족 등 → 틀린 값 대신 정직하게 '판단 불가' 안내.
          return (
            <p className="rounded-btn bg-surface-muted/40 px-3 py-2 text-xs text-text-muted">
              데이터 간격을 자동으로 판단할 수 없습니다(간격이 불규칙하거나 유효 행이 부족). ‘{P}시점 전’이 실제로 얼마 전인지는 표시하지 않아요.
            </p>
          );
        }
        if (intervalInfo.axis === 'numeric') {
          // 숫자축(회차·순번 등) — 시간 단위로 오해하지 않도록 단위 없이 정직하게.
          if (!intervalInfo.uniform) {
            return (
              <p className="rounded-btn bg-primary-soft/30 px-3 py-2 text-xs text-text">
                데이터 간격: 그룹마다 다름 (약 {cleanNum(intervalInfo.min)} ~ {cleanNum(intervalInfo.max)}, 숫자축) — ‘{P}시점 전’은 그룹마다 달라요.
              </p>
            );
          }
          return (
            <p className="rounded-btn bg-primary-soft/30 px-3 py-2 text-xs text-text">
              데이터 간격: <b>{cleanNum(intervalInfo.min)}</b> (숫자축이라 시간 단위 아님) → <b>{P}시점 전 = {cleanNum(intervalInfo.min * P)} 간격 전</b>.
            </p>
          );
        }
        // datetime 축 — ms 를 사람이 읽는 기간으로.
        if (!intervalInfo.uniform) {
          return (
            <p className="rounded-btn bg-primary-soft/30 px-3 py-2 text-xs text-text">
              데이터 간격: 그룹마다 다름 ({humanizeMs(intervalInfo.min)} ~ {humanizeMs(intervalInfo.max)}) — ‘{P}시점 전’은 그룹마다 달라요.
            </p>
          );
        }
        const eq = timeBased ? '=' : '≈';
        return (
          <p className="rounded-btn bg-primary-soft/30 px-3 py-2 text-xs text-text">
            데이터 간격: <b>{humanizeMs(intervalInfo.min)}</b> → <b>{P}시점 전 {eq} {humanizeMs(intervalInfo.min * P)} 전</b>
            {!timeBased && <span className="text-text-muted"> (규칙적일 때 근사 — 결측 구간이 있으면 실제와 다를 수 있어요. ‘시간 간격 정확 반영’을 켜면 정확)</span>}
            .
          </p>
        );
      })()}

      <label className="flex items-start gap-2 text-sm text-text">
        <input type="checkbox" checked={timeBased} onChange={(e) => setTimeBased(e.target.checked)} className="mt-0.5 accent-primary" />
        <span>
          <span className="font-medium">시간 간격 정확 반영</span>
          <span className="ml-1 text-xs text-text-muted">— 결측 구간이 있어도 정확한 시간 전 값을 가져옵니다(빠진 시각은 결측). 시간 간격을 자동으로 추론합니다{groupBy ? ` (${groupBy}별 각자)` : ''}.</span>
        </span>
      </label>

      {hasAmbiguousDate && (
        <p className="text-xs text-warning">형식이 불분명한 날짜 컬럼이 있어 정렬 기준에서 제외했어요(예: 05/06/2018은 5월 6일인지 6월 5일인지 알 수 없음). 데이터 개요에서 형식을 지정하면 사용할 수 있습니다.</p>
      )}
      <p className="rounded-btn bg-surface-muted/40 px-3 py-2 text-xs text-text-muted">
        {groupBy ? (
          <>선택한 <b>{groupBy}별로 나눠</b> 각 그룹 안에서만 <b>정렬 기준 컬럼</b>으로 시간순 정렬한 뒤 <b>{periodsOk ? p : 1}시점 전</b> 값을 가져옵니다(그룹 경계를 넘지 않음). <b>각 그룹의 가장 이른 {periodsOk ? p : 1}개 행</b>은 이전 값이 없어 비어 있게(결측) 되며, 결측치 탭에서 제거·대체할 수 있어요.</>
        ) : (
          <>선택한 <b>정렬 기준 컬럼</b>으로 데이터를 시간순 정렬한 뒤 <b>{periodsOk ? p : 1}시점 전</b> 값을 가져옵니다. <b>가장 이른 시점의 {periodsOk ? p : 1}개 행</b>(정렬 기준 컬럼 기준)은 이전 값이 없어 비어 있게(결측) 되며, 결측치 탭에서 제거·대체할 수 있어요.</>
        )}
      </p>

      {timeBased && nullInfo && nullInfo.nulls > 0 && (
        (() => {
          const pct = (nullInfo.nulls / Math.max(nullInfo.total, 1)) * 100;
          const heavy = pct >= 50;
          return (
            <p className={`text-xs ${heavy ? 'text-danger' : 'text-warning'}`}>
              이 설정으로 {nullInfo.total.toLocaleString()}개 중 <b>{nullInfo.nulls.toLocaleString()}개</b>({pct.toFixed(1)}%)가 결측이 됩니다.
              {heavy && ' 데이터가 불규칙해 시간 기준이 안 맞을 수 있어요 — 정렬 기준·그룹을 확인하거나 시간 기준을 꺼보세요.'}
            </p>
          );
        })()
      )}

      {sel.length === 1 && nameV.isDuplicate && !pendingConfirm && (
        <p className="text-xs text-warning">'{newColumn.trim()}' 컬럼이 이미 있어 적용 시 덮어쓰기 확인을 받습니다.</p>
      )}
      {(selectionError || sortError || !nameV.ok || !periodsOk) && (
        <ul className="space-y-0.5 text-sm text-danger">
          {selectionError && <li>{selectionError}</li>}
          {!periodsOk && <li>몇 시점 전(periods)은 1 이상의 정수여야 합니다.</li>}
          {sortError && <li>{sortError}</li>}
          {!nameV.ok && <li>{nameV.error}</li>}
        </ul>
      )}

      {pendingConfirm ? (
        <div className="flex flex-wrap items-center justify-end gap-2">
          <span className="mr-auto text-sm text-warning">'{newColumn.trim()}' 컬럼을 덮어쓸까요?</span>
          <Button variant="secondary" onClick={() => setPendingConfirm(false)}>취소</Button>
          <Button onClick={doApply}>덮어쓰기</Button>
        </div>
      ) : (
        <div className="flex justify-end">
          <Button disabled={!canApply} onClick={apply}>과거 시점 값 컬럼 생성</Button>
        </div>
      )}
    </div>
  );
}

// 구간화 — 숫자 컬럼을 [min,max) 구간별 라벨로 나눠 새 컬럼 생성. (검증 헬퍼는 lib/preprocess에서)
const binInputCls = 'rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';
function BinningControls({ sel, rows, existingColumns, onApply }: ControlsProps & { rows: Row[]; existingColumns: string[] }) {
  // 대상 컬럼은 왼쪽 "대상 컬럼" 체크박스 선택(sel)에서 가져온다. 단일 대상 → 첫 번째 선택 컬럼.
  const column = sel[0] ?? '';
  const [newColumn, setNewColumn] = useState('');
  const [bins, setBins] = useState<{ min: string; max: string; label: string }[]>([{ min: '', max: '', label: '' }]);
  const [otherLabel, setOtherLabel] = useState('기타');
  const [pendingConfirm, setPendingConfirm] = useState(false); // 컬럼명 중복 시 덮어쓰기 확인 대기

  // 대상 컬럼이 바뀌면 새 컬럼명 기본값을 `${컬럼}_group` 으로 제안(사용자가 수정 가능).
  useEffect(() => {
    if (column) setNewColumn(`${column}_group`);
  }, [column]);

  const parseNum = (s: string) => (s.trim() === '' ? NaN : Number(s));
  const numericBins = useMemo(() => bins.map((b) => ({ min: parseNum(b.min), max: parseNum(b.max), label: b.label })), [bins]);
  const binsV = useMemo(() => validateBins(numericBins), [numericBins]);
  const nameV = useMemo(() => validateNewColumnName(newColumn, existingColumns), [newColumn, existingColumns]);
  // 구간 밖 값 개수 — 구간이 유효할 때만 계산(무효 구간이면 오해 소지).
  const oor = useMemo(() => (binsV.ok && column ? countOutOfRange(rows, column, numericBins) : null), [binsV.ok, column, rows, numericBins]);

  // 구간화는 대상 컬럼 "정확히 1개"만 허용(구간화 탭에서만 강제 — 다른 탭 다중 선택 불변).
  const selectionError =
    sel.length === 0
      ? '대상 컬럼을 1개 선택하세요.'
      : sel.length > 1
      ? `구간화는 대상 컬럼을 1개만 선택할 수 있습니다. 현재 ${sel.length}개 선택됨.`
      : null;

  const canApply = binsV.ok && nameV.ok && sel.length === 1;

  const setBin = (i: number, patch: Partial<{ min: string; max: string; label: string }>) =>
    setBins((prev) => prev.map((b, j) => (j === i ? { ...b, ...patch } : b)));
  const addBin = () => setBins((prev) => [...prev, { min: '', max: '', label: '' }]);
  const removeBin = (i: number) => setBins((prev) => (prev.length > 1 ? prev.filter((_, j) => j !== i) : prev));

  // 입력이 바뀌면 덮어쓰기 확인 대기 해제(오래된 확인 방지).
  useEffect(() => { setPendingConfirm(false); }, [newColumn, column, bins, otherLabel, sel.length]);

  const doApply = () => {
    onApply({
      type: 'binning',
      column,
      newColumn: newColumn.trim(),
      bins: numericBins,
      otherLabel: otherLabel.trim() || '기타',
    });
    setPendingConfirm(false);
  };
  const apply = () => {
    if (!canApply) return;
    if (nameV.isDuplicate) { setPendingConfirm(true); return; } // 중복 → 덮어쓰기 확인
    doApply();
  };

  return (
    <div className="space-y-4">
      {/* 새 컬럼명 · 기타 라벨 (대상 컬럼은 왼쪽 체크박스로 선택) */}
      <div className="flex flex-wrap items-end gap-3">
        <Field label="새 컬럼 이름">
          <input value={newColumn} onChange={(e) => setNewColumn(e.target.value)} className={`${binInputCls} w-52`} placeholder="예: age_group" />
        </Field>
        <Field label="구간 밖 라벨">
          <input value={otherLabel} onChange={(e) => setOtherLabel(e.target.value)} className={`${binInputCls} w-28`} placeholder="기타" />
        </Field>
      </div>

      {/* 구간 목록 (이상 ~ 미만) */}
      <div>
        <div className="mb-1 flex items-center justify-between">
          <span className="text-xs font-medium text-text-muted">구간 (min 이상 ~ max 미만)</span>
          <button type="button" onClick={addBin} className="text-xs font-medium text-primary hover:underline">＋ 구간 추가</button>
        </div>
        <div className="space-y-2">
          {bins.map((b, i) => (
            <div key={i} className="flex flex-wrap items-center gap-2">
              <input value={b.min} onChange={(e) => setBin(i, { min: e.target.value })} className={`${binInputCls} w-24`} placeholder="min" inputMode="decimal" />
              <span className="text-sm text-text-muted">이상 ~</span>
              <input value={b.max} onChange={(e) => setBin(i, { max: e.target.value })} className={`${binInputCls} w-24`} placeholder="max" inputMode="decimal" />
              <span className="text-sm text-text-muted">미만</span>
              <input value={b.label} onChange={(e) => setBin(i, { label: e.target.value })} className={`${binInputCls} w-40 flex-1`} placeholder="라벨(예: 청년)" />
              <button type="button" onClick={() => removeBin(i)} disabled={bins.length <= 1} className="flex-none rounded-btn px-2 py-1 text-sm text-text-muted transition-colors hover:text-danger disabled:opacity-30" title="구간 삭제" aria-label="구간 삭제">✕</button>
            </div>
          ))}
        </div>
      </div>

      {/* 구간 밖 값 경고 */}
      {oor && oor.outOfRange > 0 && (
        <p className="rounded-btn bg-warning/10 px-3 py-2 text-sm text-warning">
          정의된 구간 밖의 값 {oor.outOfRange.toLocaleString()}개가 있습니다. 적용하면 '{otherLabel.trim() || '기타'}'로 처리됩니다.
        </p>
      )}
      {/* 컬럼명 중복 안내(막지 않음 — 적용 시 덮어쓰기 확인) */}
      {sel.length === 1 && nameV.isDuplicate && !pendingConfirm && (
        <p className="text-xs text-warning">'{newColumn.trim()}' 컬럼이 이미 있어 적용 시 덮어쓰기 확인을 받습니다.</p>
      )}
      {/* 검증 오류(선택 컬럼 수 + 구간 + 컬럼명) — 같은 자리·같은 스타일 */}
      {(selectionError || !binsV.ok || !nameV.ok) && (
        <ul className="space-y-0.5 text-sm text-danger">
          {selectionError && <li>{selectionError}</li>}
          {!nameV.ok && <li>{nameV.error}</li>}
          {binsV.errors.map((e, i) => (
            <li key={i}>{e}</li>
          ))}
        </ul>
      )}

      {/* 덮어쓰기 확인(인라인) */}
      {pendingConfirm ? (
        <div className="flex flex-wrap items-center justify-end gap-2">
          <span className="mr-auto text-sm text-warning">이미 '{newColumn.trim()}' 컬럼이 있습니다. 덮어쓸까요?</span>
          <Button variant="secondary" onClick={() => setPendingConfirm(false)}>취소</Button>
          <Button variant="danger" onClick={doApply}>덮어쓰기</Button>
        </div>
      ) : (
        <div className="flex justify-end">
          <Button disabled={!canApply} onClick={apply}>구간화 적용</Button>
        </div>
      )}
    </div>
  );
}

// 수식 파생 컬럼 — 사칙연산·괄호·컬럼명으로 계산한 값을 새 컬럼으로 생성.
// 좌측 공유 체크박스(sel)를 "선택 유지"가 아니라 "수식에 삽입"으로 쓴다:
// sel 에 컬럼이 담기면 그 이름을 수식 칸 커서 위치에 넣고 즉시 setSel([])로 리셋.
function FormulaControls({ sel, setSel, columns, rows, onApply }: ControlsProps & { columns: string[]; rows: Row[] }) {
  const [newColumn, setNewColumn] = useState('');
  const [formula, setFormula] = useState('');
  const [pendingConfirm, setPendingConfirm] = useState(false); // 컬럼명 중복 시 덮어쓰기 확인 대기
  const inputRef = useRef<HTMLInputElement>(null);

  // 수식 칸 커서 위치(없으면 끝)에 text 삽입 후 캐럿을 삽입 뒤로 이동.
  const insertText = (text: string) => {
    const el = inputRef.current;
    const start = el?.selectionStart ?? formula.length;
    const end = el?.selectionEnd ?? formula.length;
    setFormula(formula.slice(0, start) + text + formula.slice(end));
    requestAnimationFrame(() => {
      if (!el) return;
      el.focus();
      const pos = start + text.length;
      try { el.setSelectionRange(pos, pos); } catch { /* noop */ }
    });
  };

  // 좌측 체크박스 클릭 → sel 에 담긴 컬럼을 수식에 삽입하고 선택 리셋(클릭 버스).
  useEffect(() => {
    if (sel.length === 0) return;
    insertText(sel.join(' '));
    setSel([]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sel]);

  const v = useMemo(() => validateFormula(formula, columns), [formula, columns]);
  const nameEmpty = newColumn.trim() === '';
  const isDuplicate = !nameEmpty && columns.includes(newColumn.trim());
  const canApply = v.ok && !nameEmpty;

  // 미리보기 — 유효한 수식이면 기존 엔진(applyOneStep)으로 첫 유효 행 결과 1건 계산.
  const previewVal = useMemo(() => {
    if (!canApply || rows.length === 0) return null;
    try {
      const out = applyOneStep(rows.slice(0, 200), { type: 'formula', newColumn: '__preview__', formula });
      const hit = out.find((r) => r['__preview__'] !== null && r['__preview__'] !== undefined);
      return hit ? (hit['__preview__'] as number) : null;
    } catch {
      return null;
    }
  }, [canApply, rows, formula]);

  // 입력이 바뀌면 확인 대기 해제(오래된 확인 방지 — 구간화와 동일).
  useEffect(() => { setPendingConfirm(false); }, [newColumn, formula]);

  const doApply = () => {
    onApply({ type: 'formula', newColumn: newColumn.trim(), formula });
    setPendingConfirm(false);
  };
  const apply = () => {
    if (!canApply) return;
    if (isDuplicate) { setPendingConfirm(true); return; } // 중복 → 덮어쓰기 확인
    doApply();
  };

  return (
    <div className="space-y-4">
      <Field label="새 컬럼 이름">
        <input value={newColumn} onChange={(e) => setNewColumn(e.target.value)} className={`${binInputCls} w-52`} placeholder="예: annual_income" />
      </Field>

      <Field label="수식 (컬럼·숫자·＋ － × ÷ 와 괄호)">
        <div className="flex items-center gap-2">
          <input
            ref={inputRef}
            value={formula}
            onChange={(e) => setFormula(e.target.value)}
            className={`${binInputCls} w-full flex-1 font-mono`}
            placeholder="예: (monthly_income - expense) * 12"
            spellCheck={false}
          />
          <button
            type="button"
            onClick={() => { setFormula(''); inputRef.current?.focus(); }}
            disabled={formula === ''}
            className="flex-none rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text-muted transition-colors hover:bg-surface-muted hover:text-danger disabled:opacity-30 disabled:cursor-not-allowed"
            title="수식 지우기"
          >
            지우기
          </button>
        </div>
      </Field>

      {/* 연산자 삽입 버튼 — mousedown preventDefault 로 입력 포커스·커서 유지 */}
      <div className="flex flex-wrap gap-1">
        {['+', '-', '*', '/', '(', ')'].map((op) => (
          <button
            key={op}
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => insertText(op)}
            className="rounded-btn border border-border bg-surface px-3 py-1 font-mono text-sm text-text transition-colors hover:bg-surface-muted"
          >
            {op}
          </button>
        ))}
        <span className="ml-1 self-center text-xs text-text-muted">왼쪽 컬럼을 클릭하면 수식에 삽입됩니다.</span>
      </div>

      {/* 컬럼명 중복 안내(막지 않음 — 적용 시 덮어쓰기 확인) */}
      {isDuplicate && !pendingConfirm && (
        <p className="text-xs text-warning">'{newColumn.trim()}' 컬럼이 이미 있어 적용 시 덮어쓰기 확인을 받습니다.</p>
      )}

      {/* 검증 오류 — BinningControls 와 같은 자리·스타일 */}
      {(nameEmpty || !v.ok) && (
        <ul className="space-y-0.5 text-sm text-danger">
          {nameEmpty && <li>새 컬럼 이름을 입력하세요.</li>}
          {v.errors.map((e, i) => (
            <li key={i}>{e}</li>
          ))}
        </ul>
      )}

      {/* 유효 상태·미리보기 */}
      {canApply && (
        <p className="rounded-btn bg-success/10 px-3 py-2 text-sm text-success">
          ✓ 수식이 유효합니다{previewVal !== null ? ` — 예상 결과 예시: ${previewVal}` : ''}
        </p>
      )}

      {/* 덮어쓰기 확인(인라인) — 구간화와 동일 패턴·스타일 */}
      {pendingConfirm ? (
        <div className="flex flex-wrap items-center justify-end gap-2">
          <span className="mr-auto text-sm text-warning">이미 '{newColumn.trim()}' 컬럼이 있습니다. 덮어쓸까요?</span>
          <Button variant="secondary" onClick={() => setPendingConfirm(false)}>취소</Button>
          <Button variant="danger" onClick={doApply}>덮어쓰기</Button>
        </div>
      ) : (
        <div className="flex justify-end">
          <Button disabled={!canApply} onClick={apply}>수식 컬럼 만들기</Button>
        </div>
      )}
    </div>
  );
}
