import { useEffect, useMemo, useRef, useState } from 'react';
import PageHeader from '../../components/PageHeader';
import Button from '../../components/Button';
import NavFooter from '../../components/NavFooter';
import DecisionTreeConcept from '../../components/DecisionTreeConcept';
import ActualVsPredScatter from '../predict/ActualVsPredScatter';
import { loadHyperparamSpecs, getSpec, formatUsedParams, type ModelSpec } from '../../lib/compute';
import { useActiveDataset } from '../../hooks/useActiveDataset';
import { useDatasetStore } from '../../store/useDatasetStore';
import { buildReportData, printReport } from '../../lib/report';
import { isMissing } from '../../lib/dataQuality';
import { applyStep } from '../../lib/preprocess';
import { chartInsight } from '../../lib/insights';
import { ManualChartView, chartTitle } from '../visualize/VisualizePage';
import type { Dataset, DashboardItem } from '../../types';
import type { PredictionContext } from '../../lib/models';

const labelOf = (d: Dataset, name?: string) => d.columns.find((c) => c.name === name)?.label ?? name ?? '';
const ALGO_LABEL: Record<string, string> = { linear: '선형회귀', rf: '랜덤 포레스트', knn: 'KNN 회귀', svr: 'SVM 회귀 (SVR)', ridge: 'Ridge 회귀', lasso: 'Lasso 회귀', elasticnet: 'ElasticNet', xgboost: 'XGBoost', lightgbm: 'LightGBM', catboost: 'CatBoost', mlp: 'MLP (신경망)', lstm: 'LSTM', transformer: 'Transformer' };
const CLS_ALGO_LABEL: Record<string, string> = { logistic: '로지스틱 회귀', rf: '랜덤 포레스트', knn: 'KNN 분류', svc: 'SVM 분류 (SVC)', dtree: '결정 트리', xgboost: 'XGBoost', lightgbm: 'LightGBM', catboost: 'CatBoost', mlp: 'MLP (신경망)' };

function Section({ no, title, children }: { no: number; title: string; children: React.ReactNode }) {
  return (
    <section className="mt-6 break-inside-avoid">
      <h3 className="mb-3 border-b border-border pb-1.5 text-base font-bold text-text">{no}. {title}</h3>
      {children}
    </section>
  );
}


export default function ReportPage() {
  const active = useActiveDataset();
  const original = useDatasetStore((s) => s.dataset);
  const steps = useDatasetStore((s) => s.steps);
  const dashboardItems = useDatasetStore((s) => s.dashboardItems);
  const predictionReports = useDatasetStore((s) => s.predictionReports);
  const removePredictionReport = useDatasetStore((s) => s.removePredictionReport);
  const clearPredictionReports = useDatasetStore((s) => s.clearPredictionReports);
  // "사용한 설정" 한글 라벨 포맷용 명세(캐시됨). 실패해도 조용히 무시 → 설정 요약만 생략(배지는 무관).
  const [specs, setSpecs] = useState<ModelSpec[] | null>(null);
  useEffect(() => {
    let alive = true;
    loadHyperparamSpecs().then((s) => { if (alive) setSpecs(s); }).catch(() => {});
    return () => { alive = false; };
  }, []);
  const reportRef = useRef<HTMLDivElement>(null);

  // 리포트 기준 데이터 = 현재 전처리본(예측 결과는 각 항목이 자기 데이터를 들고 있음)
  const d = active;

  // 데이터 개요 표 — 컬럼별 타입·역할·결측·이상치
  const colTable = useMemo(() => {
    if (!d) return [];
    const outMap = new Map(d.quality.outliers.map((o) => [o.name, o]));
    return d.columns.map((c) => {
      let miss = 0;
      for (const r of d.rows) if (isMissing(r[c.name])) miss += 1;
      const o = outMap.get(c.name);
      return {
        name: c.name,
        label: c.label,
        type: c.type,
        role: c.role,
        miss,
        missPct: d.rowCount ? Math.round((miss / d.rowCount) * 1000) / 10 : 0,
        outCount: o ? o.count : null,
        outPct: o ? o.ratio : null,
      };
    });
  }, [d]);

  // 전처리 이력 — 스텝별 처리 전/후 행 수
  const stepRows = useMemo(() => {
    if (!original) return [];
    let rows = original.rows;
    return steps.map((s) => {
      const before = rows.length;
      try {
        rows = applyStep(rows, s.step);
      } catch {
        /* 무시 */
      }
      return { log: s.log, before, after: rows.length };
    });
  }, [original, steps]);

  // 범주형 요약(기초 통계)
  const categorical = useMemo(() => {
    if (!d) return [];
    return d.columns
      .filter((c) => c.type === 'string' || c.type === 'bool')
      .map((c) => {
        const counts = new Map<string, number>();
        let total = 0;
        for (const r of d.rows) {
          if (isMissing(r[c.name])) continue;
          const k = String(r[c.name]);
          counts.set(k, (counts.get(k) ?? 0) + 1);
          total += 1;
        }
        const all = Array.from(counts.entries())
          .map(([value, count]) => ({ value, count, pct: total ? Math.round((count / total) * 1000) / 10 : 0 }))
          .sort((a, b) => b.count - a.count);
        const TOP = 8;
        const items = all.slice(0, TOP);
        const restList = all.slice(TOP);
        const rest = restList.length
          ? {
              distinct: restList.length,
              count: restList.reduce((s, x) => s + x.count, 0),
              pct: total ? Math.round((restList.reduce((s, x) => s + x.count, 0) / total) * 1000) / 10 : 0,
            }
          : null;
        return { label: c.label, total, uniqueCount: all.length, items, rest };
      });
  }, [d]);

  if (!d) return null;
  const data = buildReportData(d, steps);
  const outMap = new Map(d.quality.outliers.map((o) => [o.name, o]));

  // 종합 소견 초안(룰 기반) — 대시보드 그래프 + 예측 결과 종합
  const draft = buildDraft(d, predictionReports, dashboardItems);

  return (
    <>
      <PageHeader
        title="결과 리포트"
        subtitle="선택한 예측 데이터를 기준으로 전체 분석을 한 페이지로 정리했어요. 종합 소견은 직접 수정할 수 있습니다."
      />

      <div className="rounded-card border border-border bg-surface-muted p-4 md:p-6">
        <div ref={reportRef} className="mx-auto max-w-3xl rounded-card bg-surface p-6 text-text shadow-card md:p-8">
          <header className="border-b-2 border-primary pb-3">
            <h1 className="text-xl font-bold text-text">EDA 분석 결과 리포트</h1>
            <p className="mt-1 text-sm text-text-muted">{data.dataInfo.fileName} · {data.dataInfo.date}</p>
          </header>

          {/* 1. 분석 개요 */}
          <Section no={1} title="분석 개요">
            <dl className="grid grid-cols-1 gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
              <MetaRow term="분석 목적" defaultText="데이터 탐색 및 예측 분석" />
              <MetaRow term="데이터 출처" defaultText={data.dataInfo.fileName} />
              <div className="flex gap-2"><dt className="w-20 flex-none text-text-muted">분석 일시</dt><dd className="text-text">{data.dataInfo.date}</dd></div>
              <div className="flex gap-2"><dt className="w-20 flex-none text-text-muted">분석 도구</dt><dd className="text-text">Elio</dd></div>
            </dl>
          </Section>

          {/* 2. 데이터 개요 */}
          <Section no={2} title="데이터 개요">
            <p className="mb-2 text-sm text-text-muted">
              {data.dataInfo.rowCount.toLocaleString()}행 × {data.dataInfo.colCount}열 · 전체 결측률 {d.quality.missingPct}%
            </p>
            <div className="mb-3 overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border text-left text-text-muted">
                    <th className="py-1.5 pr-3 font-medium">컬럼</th>
                    <th className="py-1.5 pr-3 font-medium">타입</th>
                    <th className="py-1.5 pr-3 font-medium">분석 유형</th>
                    <th className="py-1.5 pr-3 text-right font-medium">결측 건수</th>
                    <th className="py-1.5 text-right font-medium">결측 비율</th>
                  </tr>
                </thead>
                <tbody>
                  {colTable.map((c) => (
                    <tr key={c.name} className="border-b border-border/60">
                      <td className="py-1.5 pr-3 font-medium text-text">{c.label}</td>
                      <td className="py-1.5 pr-3 text-text-muted">{c.type}</td>
                      <td className="py-1.5 pr-3 text-text-muted">{c.role}</td>
                      <td className="py-1.5 pr-3 text-right tabular-nums text-text">{c.miss.toLocaleString()}</td>
                      <td className="py-1.5 text-right tabular-nums">
                        <span className={c.missPct > 0 ? 'text-warning' : 'text-text-muted'}>{c.missPct}%</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>

          {/* 3. 기초 통계 */}
          <Section no={3} title="기초 통계">
            <h4 className="mb-1 text-sm font-semibold text-text">수치형 요약</h4>
            <div className="mb-4 overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border text-left text-text-muted">
                    {['변수', '평균', '표준편차', '최소', 'Q1', '중앙값', 'Q3', '최대', '이상치 수', '이상치 비율'].map((h) => <th key={h} className="py-1.5 pr-3 font-medium">{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {data.statistics.map((s) => {
                    const o = outMap.get(s.name);
                    return (
                      <tr key={s.name} className="border-b border-border/60 tabular-nums">
                        <td className="py-1.5 pr-3 font-medium text-text">{s.label}</td>
                        <td className="py-1.5 pr-3">{s.mean.toLocaleString()}</td>
                        <td className="py-1.5 pr-3">{s.std.toLocaleString()}</td>
                        <td className="py-1.5 pr-3">{s.min.toLocaleString()}</td>
                        <td className="py-1.5 pr-3">{s.q1.toLocaleString()}</td>
                        <td className="py-1.5 pr-3">{s.median.toLocaleString()}</td>
                        <td className="py-1.5 pr-3">{s.q3.toLocaleString()}</td>
                        <td className="py-1.5 pr-3">{s.max.toLocaleString()}</td>
                        <td className="py-1.5 pr-3">{(o?.count ?? 0).toLocaleString()}</td>
                        <td className="py-1.5 pr-3">
                          <span className={o && o.ratio > 0 ? 'text-warning' : 'text-text-muted'}>{o?.ratio ?? 0}%</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <h4 className="mb-1 text-sm font-semibold text-text">범주형 요약</h4>
            {categorical.length ? (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {categorical.map((c) => (
                  <div key={c.label} className="rounded-btn border border-border p-3">
                    <p className="mb-1 text-xs font-semibold text-text">
                      {c.label} <span className="font-normal text-text-muted">(총 {c.uniqueCount.toLocaleString()}개 항목)</span>
                    </p>
                    <div className="flex justify-between border-b border-border/60 pb-0.5 text-[10px] font-medium text-text-muted">
                      <span>항목</span>
                      <span>수(비율%)</span>
                    </div>
                    <ul className="space-y-0.5 pt-0.5 text-xs">
                      {c.items.map((it) => (
                        <li key={it.value} className="flex justify-between">
                          <span className="truncate pr-2 text-text">{it.value}</span>
                          <span className="flex-none tabular-nums text-text-muted">{it.count.toLocaleString()}({it.pct}%)</span>
                        </li>
                      ))}
                      {c.rest && (
                        <li className="flex justify-between border-t border-border/50 pt-0.5 text-text-muted">
                          <span>그 외 ({c.rest.distinct.toLocaleString()}개 항목)</span>
                          <span className="flex-none tabular-nums">{c.rest.count.toLocaleString()}({c.rest.pct}%)</span>
                        </li>
                      )}
                    </ul>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-text-muted">범주형 컬럼이 없습니다.</p>
            )}
          </Section>

          {/* 4. 전처리 이력 */}
          <Section no={4} title="전처리 이력">
            {stepRows.length ? (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-text-muted">
                    <th className="py-1.5 pr-3 font-medium">#</th>
                    <th className="py-1.5 pr-3 font-medium">처리 방법</th>
                    <th className="py-1.5 text-right font-medium">행 수 변화</th>
                  </tr>
                </thead>
                <tbody>
                  {stepRows.map((s, i) => (
                    <tr key={i} className="border-b border-border/60">
                      <td className="py-1.5 pr-3 text-text-muted">{i + 1}</td>
                      <td className="py-1.5 pr-3 text-text">{s.log}</td>
                      <td className="py-1.5 text-right tabular-nums text-text-muted">
                        {s.before.toLocaleString()} → <span className={s.after !== s.before ? 'font-semibold text-warning' : 'text-text'}>{s.after.toLocaleString()}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p className="text-sm text-text-muted">적용한 전처리가 없습니다.</p>
            )}
          </Section>

          {/* 5. 시각화 분석 */}
          <Section no={5} title="시각화 분석">
            {dashboardItems.length ? (
              <div className="space-y-4">
                {dashboardItems.map((it) => {
                  // 고정 스냅샷이 있으면 그걸로 렌더·해석(전처리 변경에도 불변). 없으면 라이브 d.
                  const sd = it.snapshot ?? d;
                  const snc = sd.columns.filter((c) => c.type === 'int' || c.type === 'float').map((c) => c.name);
                  return (
                  <div key={it.id} className="rounded-card border border-border p-4 break-inside-avoid">
                    <h4 className="mb-2 text-sm font-semibold text-text">{chartTitle(sd, it)}</h4>
                    <ManualChartView d={sd} chart={it.chart} v1={it.v1 ?? ''} v2={it.v2 ?? ''} cat={it.cat ?? ''} agg={it.agg ?? '개수'} date={it.date ?? ''} numericCols={snc} height={330} />
                    <p className="mt-2 flex items-start gap-2 rounded-btn border border-ai/30 bg-ai/5 p-2.5 text-sm text-text">
                      <span>{chartInsight(sd, it)}</span>
                    </p>
                  </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-text-muted">대시보드에 추가한 차트가 없습니다. (시각화 단계에서 차트를 추가하세요)</p>
            )}
          </Section>

          {/* 6. 예측 분석 */}
          <Section no={6} title="예측 분석">
            {predictionReports.length ? (
              <div className="space-y-4">
                {predictionReports.length > 1 && (
                  <div className="flex items-center justify-between print:hidden">
                    <span className="text-xs text-text-muted">{predictionReports.length}개 모델</span>
                    <Button variant="ghost" onClick={clearPredictionReports}>전체 비우기</Button>
                  </div>
                )}
                {predictionReports.map((p) => (
                  <div key={p.id} className="rounded-card border border-border p-4 break-inside-avoid">
                    <div className="mb-2 flex items-start justify-between gap-2">
                      <h4 className="text-sm font-semibold text-text">{p.label}</h4>
                      <button onClick={() => removePredictionReport(p.id)} className="flex-none text-text-muted transition-colors hover:text-danger print:hidden" title="삭제" aria-label="삭제">✕</button>
                    </div>
                    <PredictionReport ctx={p} specs={specs} />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-text-muted">추가된 예측 결과가 없습니다. 예측 분석 단계에서 모델을 학습한 뒤 ‘＋ 결과 리포트에 추가’를 누르세요.</p>
            )}
          </Section>

          {/* 7. 종합 소견 (편집 가능) */}
          <Section no={7} title="종합 소견">
            <p className="mb-2 text-xs text-text-muted print:hidden">↓ 아래 영역을 클릭해 직접 수정할 수 있어요. 수정한 내용이 PDF에 그대로 반영됩니다.</p>
            <div
              contentEditable
              suppressContentEditableWarning
              className="min-h-[6rem] whitespace-pre-wrap rounded-card border border-dashed border-border bg-surface-muted/30 p-4 text-sm leading-relaxed text-text outline-none focus:border-primary"
            >
              {draft}
            </div>
          </Section>

          <p className="mt-8 border-t border-border pt-3 text-center text-xs text-text-muted">
            본 리포트는 분석 결과만 포함하며 원본 데이터는 저장되지 않습니다. · Elio
          </p>
        </div>
      </div>

      {/* 맨 아래 — PDF 저장 */}
      <div className="mt-4 flex justify-end">
        <Button onClick={() => reportRef.current && printReport(reportRef.current, data.fileBase)}>PDF로 저장</Button>
      </div>

      <NavFooter prevLabel="예측 분석" hideNext />
    </>
  );
}

/* ───────────────── 보조 컴포넌트 ───────────────── */

// 편집 가능한 메타정보 한 줄
function MetaRow({ term, defaultText }: { term: string; defaultText: string }) {
  return (
    <div className="flex gap-2">
      <dt className="w-20 flex-none text-text-muted">{term}</dt>
      <dd
        contentEditable
        suppressContentEditableWarning
        className="flex-1 rounded border border-dashed border-transparent px-1 text-text outline-none hover:border-border focus:border-primary print:border-transparent"
      >
        {defaultText}
      </dd>
    </div>
  );
}

// 예측 분석 결과(선택된 예측 데이터 기준)
// 리포트용 "사용한 설정 · 표준화" 배지 줄 — 예측 화면과 동일 취지(칩 형태로 압축).
function UsedSettingsRow({ summary, scaled }: { summary: string; scaled?: boolean }) {
  if (!summary && typeof scaled !== 'boolean') return null;
  return (
    <div className="mb-2 flex flex-wrap gap-1.5">
      {summary && <span className="rounded-chip border border-ai/30 bg-ai/5 px-2 py-0.5 text-xs text-text">사용한 설정: {summary}</span>}
      {typeof scaled === 'boolean' && (
        <span className="rounded-chip border border-ai/30 bg-ai/5 px-2 py-0.5 text-xs text-text">{scaled ? '표준화 적용됨' : '표준화 미적용'}</span>
      )}
    </div>
  );
}

function PredictionReport({ ctx, specs }: { ctx: PredictionContext; specs: ModelSpec[] | null }) {
  const d = ctx.dataset;
  const tlabel = labelOf(d, ctx.target);

  if (ctx.task === 'reg' && ctx.reg) {
    const reg = ctx.reg;
    // 트리 앙상블(rf/gb)은 coef 자리에 변수 중요도(0~1, 양수)가 담긴다.
    const isTree = ctx.algo === 'rf' || ctx.algo === 'xgboost' || ctx.algo === 'lightgbm' || ctx.algo === 'catboost';
    // 계수(선형)·중요도(트리)가 실제로 있는지. KNN 은 둘 다 없어(coef=[]) 계수 리스트 대신 산점도를 보인다.
    //  (coefRows 는 features 를 map 하므로 길이가 항상 >0 → 존재 판정은 reg.coef 로 해야 한다.)
    const hasInfluence = Array.isArray(reg.coef) && reg.coef.length > 0;
    const maxAbs = Math.max(1e-9, ...reg.coef.map((c) => Math.abs(c)));
    const coefRows = reg.features
      .map((f, i) => ({ label: labelOf(d, f), coef: Math.round(reg.coef[i] * 10000) / 10000 }))
      .sort((a, b) => Math.abs(b.coef) - Math.abs(a.coef));
    return (
      <div>
        <p className="mb-2 text-sm">
          <span className="font-semibold text-text">{tlabel}</span> 예측 · 모델 <span className="rounded-chip bg-surface-muted px-2 py-0.5 text-xs">{ALGO_LABEL[ctx.algo ?? 'linear']} (회귀)</span>
        </p>
        <div className="mb-3 grid grid-cols-3 gap-2 text-center text-sm">
          <Stat label="R²" value={String(reg.r2)} />
          <Stat label="MAE" value={String(reg.mae)} />
          <Stat label="RMSE" value={String(reg.rmse)} />
        </div>
        <UsedSettingsRow summary={formatUsedParams(getSpec(specs, 'reg', ctx.algo ?? ''), reg.usedParams)} scaled={reg.scaled} />
        {reg.sampled && (
          <p className="mb-2 text-xs text-text-muted">데이터가 많아 학습에는 전체 {reg.sampled.total.toLocaleString()}행 중 {reg.sampled.used.toLocaleString()}행을 무작위 표본으로 사용했습니다.</p>
        )}
        {hasInfluence ? (
          <>
            <h4 className="mb-1 text-sm font-semibold text-text">{isTree ? '변수 중요도' : '영향 변수 (회귀계수)'}</h4>
            <ul className="space-y-1">
              {coefRows.map((c) => (
                <li key={c.label} className="flex items-center gap-2 text-sm">
                  <span className="w-24 flex-none truncate text-text">{c.label}</span>
                  <div className="relative h-3 flex-1 rounded bg-surface-muted">
                    {isTree ? (
                      // 중요도: 왼쪽부터 채우는 단색 막대
                      <div className="absolute left-0 top-0 h-3 rounded" style={{ width: `${(c.coef / maxAbs) * 100}%`, background: 'var(--primary)' }} />
                    ) : (
                      <>
                        <div className="absolute left-1/2 top-0 h-3 w-px bg-border" />
                        <div className="absolute top-0 h-3 rounded" style={c.coef >= 0 ? { left: '50%', width: `${(c.coef / maxAbs) * 50}%`, background: 'var(--primary)' } : { right: '50%', width: `${(Math.abs(c.coef) / maxAbs) * 50}%`, background: 'var(--danger)' }} />
                      </>
                    )}
                  </div>
                  <span className="w-14 flex-none text-right tabular-nums text-text-muted">{isTree ? `${Math.round(c.coef * 100)}%` : c.coef}</span>
                </li>
              ))}
            </ul>
          </>
        ) : (
          // 계수/중요도가 없는 모델(KNN 등): 계수 리스트 대신 실제vs예측 산점도(예측 결과 화면 렌더 재사용).
          <>
            <h4 className="mb-1 text-sm font-semibold text-text">실제값 vs 예측값</h4>
            <ActualVsPredScatter data={reg.actualVsPred} height={260} />
          </>
        )}
        <p className="mt-2 text-sm text-text-muted">
          {hasInfluence && coefRows[0] ? `${coefRows[0].label}의 ${isTree ? '중요도' : '영향'}가 가장 큽니다. ` : ''}모델 설명력(R²)은 {reg.r2}입니다.
        </p>
        {isTree && <DecisionTreeConcept algo={ctx.algo ?? 'rf'} task="reg" tree={reg.vizTree} targetLabel={tlabel} />}
      </div>
    );
  }

  if (ctx.task === 'cls' && ctx.cls) {
    const cls = ctx.cls;
    const isTreeCls = cls.algo === 'rf' || cls.algo === 'dtree' || cls.algo === 'xgboost' || cls.algo === 'lightgbm' || cls.algo === 'catboost';
    const inflRows = (cls.coef ?? [])
      .map((c) => ({ label: labelOf(d, c.name), value: Math.round(c.value * 10000) / 10000 }))
      .sort((a, b) => Math.abs(b.value) - Math.abs(a.value));
    const inflMax = Math.max(1e-9, ...inflRows.map((c) => Math.abs(c.value)));
    return (
      <div>
        <p className="mb-2 text-sm">
          <span className="font-semibold text-text">{tlabel}</span> 예측 · 모델 <span className="rounded-chip bg-surface-muted px-2 py-0.5 text-xs">{CLS_ALGO_LABEL[cls.algo ?? 'logistic']} (분류)</span>
        </p>
        <div className="mb-3 grid grid-cols-2 gap-2 text-center text-sm">
          <Stat label="정확도" value={`${Math.round(cls.accuracy * 1000) / 10}%`} />
          <Stat label="클래스 수" value={String(cls.classes.length)} />
        </div>
        <UsedSettingsRow summary={formatUsedParams(getSpec(specs, 'cls', cls.algo ?? ''), cls.usedParams)} scaled={cls.scaled} />
        {cls.sampled && (
          <p className="mb-2 text-xs text-text-muted">데이터가 많아 학습에는 전체 {cls.sampled.total.toLocaleString()}행 중 {cls.sampled.used.toLocaleString()}행을 무작위 표본으로 사용했습니다.</p>
        )}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {/* 혼동 행렬 */}
          <div>
            <h4 className="mb-1 text-sm font-semibold text-text">혼동 행렬 (행=실제 / 열=예측)</h4>
            <div className="overflow-x-auto">
              <table className="border-collapse text-xs">
                <thead>
                  <tr>
                    <th className="p-1.5" />
                    {cls.classes.map((c) => (
                      <th key={c} className="border border-border p-1.5 text-text-muted">{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cls.confusion.map((row, i) => (
                    <tr key={i}>
                      <th className="border border-border p-1.5 text-text-muted">{cls.classes[i]}</th>
                      {row.map((v, j) => (
                        <td
                          key={j}
                          className={`border border-border p-1.5 text-center tabular-nums ${i === j ? 'font-bold text-success' : 'text-text'}`}
                          style={{ background: i === j ? 'rgba(22,163,74,0.15)' : 'var(--surface-muted)' }}
                        >
                          {v}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* 클래스별 성능 */}
          <div>
            <h4 className="mb-1 text-sm font-semibold text-text">클래스별 성능</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border text-left text-text-muted">
                    <th className="py-1 pr-3 font-medium">클래스</th>
                    <th className="py-1 pr-3 text-right font-medium">정밀도</th>
                    <th className="py-1 pr-3 text-right font-medium">재현율</th>
                    <th className="py-1 pr-3 text-right font-medium">F1</th>
                    <th className="py-1 pr-3 text-right font-medium">AUC-ROC</th>
                    <th className="py-1 text-right font-medium">표본 수</th>
                  </tr>
                </thead>
                <tbody>
                  {cls.report.map((r) => (
                    <tr key={r.cls} className="border-b border-border/60 tabular-nums">
                      <td className="py-1 pr-3 text-text">{r.cls}</td>
                      <td className="py-1 pr-3 text-right">{r.precision}</td>
                      <td className="py-1 pr-3 text-right">{r.recall}</td>
                      <td className="py-1 pr-3 text-right">{r.f1}</td>
                      <td className="py-1 pr-3 text-right">{r.auc ?? '—'}</td>
                      <td className="py-1 text-right text-text-muted">{r.support}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {inflRows.length > 0 && (
          <div className="mt-3">
            <h4 className="mb-1 text-sm font-semibold text-text">{isTreeCls ? '변수 중요도' : '영향 변수 (표준화 계수)'}</h4>
            <ul className="space-y-1">
              {inflRows.map((c) => (
                <li key={c.label} className="flex items-center gap-2 text-sm">
                  <span className="w-24 flex-none truncate text-text">{c.label}</span>
                  <div className="relative h-3 flex-1 rounded bg-surface-muted">
                    {isTreeCls ? (
                      <div className="absolute left-0 top-0 h-3 rounded" style={{ width: `${(c.value / inflMax) * 100}%`, background: 'var(--primary)' }} />
                    ) : (
                      <>
                        <div className="absolute left-1/2 top-0 h-3 w-px bg-border" />
                        <div className="absolute top-0 h-3 rounded" style={c.value >= 0 ? { left: '50%', width: `${(c.value / inflMax) * 50}%`, background: 'var(--primary)' } : { right: '50%', width: `${(Math.abs(c.value) / inflMax) * 50}%`, background: 'var(--danger)' }} />
                      </>
                    )}
                  </div>
                  <span className="w-14 flex-none text-right tabular-nums text-text-muted">{isTreeCls ? `${Math.round(c.value * 100)}%` : c.value}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        {isTreeCls && <DecisionTreeConcept algo={cls.algo ?? 'rf'} task="cls" tree={cls.vizTree} targetLabel={tlabel} maxDepth={cls.usedParams?.max_depth} />}
        <p className="mt-2 text-sm text-text-muted">{CLS_ALGO_LABEL[cls.algo ?? 'logistic']} 모델의 테스트 정확도는 {(cls.accuracy * 100).toFixed(1)}%입니다.</p>
      </div>
    );
  }
  return <p className="text-sm text-text-muted">예측 결과가 없습니다.</p>;
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-btn border border-border p-2">
      <div className="text-xs text-text-muted">{label}</div>
      <div className="text-lg font-bold text-text">{value}</div>
    </div>
  );
}

/* ───────── 종합 소견(룰 기반, 정중체 ~습니다) ─────────
   대시보드 그래프와 예측 결과를 해석해 4단락(데이터 개요·시각화 소견·예측 소견·종합 결론)으로 종합한다.
   완전 범용: 공정 데이터가 아니어도 컬럼명만 바뀌어 그대로 동작한다. 편집 가능한 초안이므로 사용자가 보완할 수 있다. */

// 선형 계열(계수 부호=방향 의미). 트리 계열은 coef 에 중요도(양수)가 담겨 방향이 없다.
const isLinearReg = (algo?: string) => ['linear', 'ridge', 'lasso', 'elasticnet'].includes(algo ?? 'linear');

const r2Grade = (r2: number) => (r2 >= 0.9 ? '매우 높습니다' : r2 >= 0.7 ? '높습니다' : r2 >= 0.5 ? '보통입니다' : r2 >= 0.3 ? '낮습니다' : '매우 낮습니다');
const accGrade = (acc: number) => (acc >= 0.9 ? '매우 우수합니다' : acc >= 0.8 ? '우수합니다' : acc >= 0.7 ? '양호합니다' : '개선이 필요합니다');
const accPct = (acc: number) => (acc * 100).toFixed(1); // 정확도 소수점 1자리(예: 91.3)

// 예측 결과 1개 → 종합소견용 정중체 문장(등급·오차·핵심 변수·재현율 경고)
function predictionLine(ctx: PredictionContext): string {
  const cd = ctx.dataset;
  const L = (n?: string) => labelOf(cd, n);
  if (ctx.task === 'reg' && ctx.reg) {
    const reg = ctx.reg;
    const model = ALGO_LABEL[ctx.algo ?? 'linear'];
    // 회귀: 설명력(R²)·평균오차(MAE)·RMSE + 변수 기여(선형=방향/트리=중요도/그 외=미제공)
    let s = `'${L(ctx.target)}' 예측을 ${model} 모델로 수행한 결과, 설명력(R²)은 ${reg.r2}로 ${r2Grade(reg.r2)}. 평균 오차(MAE)는 ${reg.mae}, RMSE는 ${reg.rmse}입니다.`;
    if (Array.isArray(reg.coef) && reg.coef.length > 0) {
      const ranked = reg.features.map((f, i) => ({ label: L(f), v: reg.coef[i], abs: Math.abs(reg.coef[i]) })).sort((a, b) => b.abs - a.abs).slice(0, 2);
      s += isLinearReg(ctx.algo)
        ? ` 가장 영향이 큰 변수는 ${ranked.map((t) => `'${t.label}'(${t.v >= 0 ? '증가' : '감소'} 방향)`).join(', ')}입니다.`
        : ` 예측 기여도가 높은 변수는 ${ranked.map((t) => `'${t.label}'`).join(', ')}입니다.`;
    } else {
      s += ` 이 모델은 개별 변수의 기여도를 제공하지 않아 성능 지표로 평가했습니다.`;
    }
    return s;
  }
  if (ctx.task === 'cls' && ctx.cls) {
    const cls = ctx.cls;
    const model = CLS_ALGO_LABEL[cls.algo ?? 'logistic'];
    // 분류: 정확도(소수1자리)·클래스 수 + 판별 변수 + 재현율 낮은 클래스 경고
    let s = `'${L(ctx.target)}' 분류를 ${model} 모델로 수행한 결과, 정확도는 ${accPct(cls.accuracy)}%로 ${accGrade(cls.accuracy)}. 총 ${cls.classes.length}개 클래스를 구분합니다.`;
    if (Array.isArray(cls.coef) && cls.coef.length > 0) {
      const top = [...cls.coef].sort((a, b) => Math.abs(b.value) - Math.abs(a.value))[0];
      if (top) s += ` 판별에 가장 크게 작용한 변수는 '${labelOf(cd, top.name)}'입니다.`;
    }
    const worst = [...(cls.report ?? [])].sort((a, b) => a.recall - b.recall)[0];
    if (worst && worst.recall < 0.7) s += ` 다만 '${worst.cls}' 클래스의 재현율이 ${worst.recall}로 낮아 일부를 놓칠 수 있습니다.`;
    return s;
  }
  return '';
}

// 종합 결론 — 대표 모델(회귀 R²최고·분류 정확도최고) 기준으로 한두 문장 정리
function conclusionLine(reports: PredictionContext[]): string {
  if (!reports.length) {
    return '· 본 리포트는 데이터의 분포와 변수 간 관계를 중심으로 정리하였습니다. 예측 모델을 학습하면 핵심 영향 변수까지 함께 분석할 수 있습니다.';
  }
  const parts: string[] = [];
  const regs = reports.filter((r) => r.task === 'reg' && r.reg);
  const clss = reports.filter((r) => r.task === 'cls' && r.cls);
  if (regs.length) {
    const best = regs.map((r) => ({ r, r2: r.reg!.r2 })).sort((a, b) => b.r2 - a.r2)[0].r;
    const reg = best.reg!;
    let drv = '';
    if (Array.isArray(reg.coef) && reg.coef.length > 0) {
      const top = reg.features.map((f, i) => ({ label: labelOf(best.dataset, f), abs: Math.abs(reg.coef[i]) })).sort((a, b) => b.abs - a.abs)[0];
      if (top) drv = ` '${top.label}' 등이 핵심 영향 변수로 나타났습니다.`;
    }
    parts.push(`'${labelOf(best.dataset, best.target)}'은(는) ${r2Grade(reg.r2)}(R² ${reg.r2}) 수준으로 예측할 수 있으며,${drv}`);
  }
  if (clss.length) {
    const best = clss.map((r) => ({ r, acc: r.cls!.accuracy })).sort((a, b) => b.acc - a.acc)[0].r;
    parts.push(`'${labelOf(best.dataset, best.target)}' 분류는 정확도 ${accPct(best.cls!.accuracy)}% 수준으로 확인되었습니다.`);
  }
  return '· ' + parts.join(' ');
}

// 종합 소견 초안 — 대시보드 그래프·예측 결과를 4단락으로 종합(정중체).
function buildDraft(d: Dataset, reports: PredictionContext[], items: DashboardItem[]): string {
  const out: string[] = [];

  out.push('■ 데이터 개요');
  out.push(`· ${d.fileName} 데이터는 총 ${d.rowCount.toLocaleString()}건, ${d.colCount}개 변수로 구성되어 있습니다.`);
  out.push(`· 전체 결측률은 ${d.quality.missingPct}%이며, 이상치는 ${d.quality.outlierCount.toLocaleString()}건이 탐지되었습니다.`);

  out.push('', `■ 시각화 소견${items.length ? ` (그래프 ${items.length}개)` : ''}`);
  if (items.length) {
    for (const it of items) { const line = chartInsight(it.snapshot ?? d, it); if (line) out.push(`· ${line}`); }
  } else {
    out.push('· 대시보드에 추가된 그래프가 없습니다.');
  }

  out.push('', '■ 예측 소견');
  if (reports.length) {
    for (const ctx of reports) { const line = predictionLine(ctx); if (line) out.push(`· ${line}`); }
  } else {
    out.push('· 예측 분석은 수행되지 않았습니다.');
  }

  out.push('', '■ 종합 결론', conclusionLine(reports));
  out.push('', '(이 영역을 클릭해 의견을 자유롭게 보완하실 수 있습니다.)');
  return out.join('\n');
}
