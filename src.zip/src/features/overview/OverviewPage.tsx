import { useMemo } from 'react';
import PageHeader from '../../components/PageHeader';
import Card from '../../components/Card';
import KpiCard from '../../components/KpiCard';
import NavFooter from '../../components/NavFooter';
import { useActiveDataset } from '../../hooks/useActiveDataset';
import { useStepStore } from '../../store/useStepStore';
import { isMissing } from '../../lib/dataQuality';
import type { ColumnType, ColumnRole } from '../../types';

const typeLabel: Record<ColumnType, string> = {
  int: '정수',
  float: '실수',
  string: '문자(범주)',
  bool: '예/아니오',
  datetime: '날짜',
};

const typeColor: Record<ColumnType, string> = {
  int: 'bg-blue-500/10 text-blue-500',
  float: 'bg-blue-500/10 text-blue-500',
  string: 'bg-cyan-500/10 text-cyan-600',
  bool: 'bg-violet-500/10 text-violet-500',
  datetime: 'bg-fuchsia-500/10 text-fuchsia-500',
};

const roleColor: Record<ColumnRole, string> = {
  식별자: 'bg-surface-muted text-text-muted',
  수치형: 'bg-blue-500/10 text-blue-500',
  범주형: 'bg-cyan-500/10 text-cyan-600',
  날짜형: 'bg-fuchsia-500/10 text-fuchsia-500',
  '예측 후보': 'bg-warning/15 text-warning',
};

function Chip({ text, cls }: { text: string; cls: string }) {
  return <span className={`rounded-chip px-2 py-0.5 text-xs font-medium ${cls}`}>{text}</span>;
}

export default function OverviewPage() {
  const d = useActiveDataset();
  const goto = useStepStore((s) => s.goto);

  // 컬럼별 결측치 수·비율(A의 컬럼정보)
  const colInfo = useMemo(() => {
    if (!d) return [];
    return d.columns.map((c) => {
      let miss = 0;
      for (const r of d.rows) if (isMissing(r[c.name])) miss += 1;
      const pct = d.rowCount ? Math.round((miss / d.rowCount) * 1000) / 10 : 0;
      return { ...c, miss, pct };
    });
  }, [d]);

  // 타입별 컬럼 수 + 비율 (존재하는 타입만)
  const typeStats = useMemo(() => {
    if (!d) return [];
    const order: { type: ColumnType; label: string }[] = [
      { type: 'int', label: '정수' },
      { type: 'float', label: '실수' },
      { type: 'string', label: '문자' },
      { type: 'bool', label: '예/아니오' },
      { type: 'datetime', label: '날짜' },
    ];
    return order.map(({ type, label }) => {
      const count = d.columns.filter((c) => c.type === type).length;
      return { label, count, pct: d.colCount ? Math.round((count / d.colCount) * 1000) / 10 : 0 };
    });
  }, [d]);

  if (!d) return null;

  return (
    <>
      <PageHeader title="데이터 개요" subtitle={`${d.fileName} 의 전체 구성과 컬럼 정보를 한눈에 정리했어요.`} />

      {/* 좌: 데이터 크기·전체 데이터·총 컬럼수·타입별 수 (세로) / 우: 컬럼 정보 */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-9">
        {/* 왼쪽 세로 스택 */}
        <div className="space-y-4 lg:col-span-2">
          <KpiCard label="데이터 크기" value={`${d.sizeMB} MB`} hint="대략적 메모리 크기" accent="text-ai" />
          <KpiCard label="전체 데이터" value={d.rowCount.toLocaleString()} hint="행(레코드) 수" />
          <KpiCard label="총 컬럼수" value={d.colCount} hint="변수(열) 수" accent="text-success" />

          {/* 타입별 수 — 세로 배치 */}
          <div className="rounded-card border border-border bg-surface p-5 shadow-card">
            <div className="mb-3 flex items-center gap-2 text-sm text-text-muted">
              타입별 수
            </div>
            <ul className="space-y-1.5">
              {typeStats.map((t) => (
                <li key={t.label} className="flex items-center justify-between border-b border-border/50 pb-1.5 text-sm last:border-0 last:pb-0">
                  <span className="text-text-muted">{t.label}</span>
                  <span className="tabular-nums text-text">
                    <span className="font-semibold">{t.count}개</span>
                    <span className="ml-2 text-xs text-text-muted">{t.pct}%</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* 오른쪽: 컬럼 정보 (변수=행) */}
        <div className="lg:col-span-7">
          <Card title="컬럼 정보" subtitle="각 변수의 타입·결측치·역할을 정리했어요.">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-text-muted">
                    <th className="py-2 pr-4 font-medium">컬럼명</th>
                    <th className="py-2 pr-4 font-medium">타입</th>
                    <th className="py-2 pr-4 font-medium">분석 유형</th>
                    <th className="py-2 pr-8 text-right font-medium">결측치 수</th>
                    <th className="py-2 pr-10 text-right font-medium">결측치 비율</th>
                  </tr>
                </thead>
                <tbody>
                  {colInfo.map((c) => (
                    <tr key={c.name} className="border-b border-border/60">
                      <td className="py-2.5 pr-4">
                        <span className="font-medium text-text">{c.name}</span>
                        {c.label !== c.name && <span className="ml-2 text-xs text-text-muted">{c.label}</span>}
                      </td>
                      <td className="whitespace-nowrap py-2.5 pr-4">
                        <Chip text={typeLabel[c.type]} cls={typeColor[c.type]} />
                      </td>
                      <td className="whitespace-nowrap py-2.5 pr-4">
                        <Chip text={c.role === '예측 후보' ? '예측 후보' : c.role} cls={roleColor[c.role]} />
                      </td>
                      <td className="py-2.5 pr-8 text-right tabular-nums text-text">{c.miss.toLocaleString()}</td>
                      <td className="py-2.5 pr-10 text-right tabular-nums">
                        <span className={c.pct > 0 ? 'text-warning' : 'text-text-muted'}>{c.pct}%</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>

      <NavFooter prevLabel="데이터 업로드" nextLabel="기초 통계" onNext={() => goto('statistics')} />
    </>
  );
}
