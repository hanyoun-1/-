import type { HyperparamDef, ModelSpec, ParamValues } from '../../lib/compute';
import { fmtDuration } from '../../lib/compute';

const selectCls =
  'rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

interface Props {
  spec: ModelSpec; // 선택된 (task, algo) 명세
  value: ParamValues; // 현재 파라미터 값(name → 값)
  onChange: (next: ParamValues) => void;
  tunable?: boolean; // 자동 최적화 지원 모델(rf·xgb·gb·lightgbm·catboost·mlp)이면 토글 노출
  tune?: boolean; // 자동 최적화 켜짐 여부
  onTuneChange?: (v: boolean) => void; // 토글 변경
  tuneApprox?: boolean; // 서브샘플 튜닝 모델(svr·svc) — '근사값' 고지
  tuneLstm?: boolean; // LSTM(딥러닝, 연속 서브샘플) — 최대 5분 + 연속 3000행 근사 고지
  tuneTransformer?: boolean; // Transformer(표 데이터 딥러닝, 랜덤 서브샘플) — 최대 5분 + 랜덤 3000행 근사 고지
  tuneMaxSec?: number; // 이 모델의 튜닝 timeout(초) — 고지의 '최대 N분'을 백엔드와 동기화(tuneTimeoutSec). 없으면 60 폴백.
}

// 명세 주도 하이퍼파라미터 입력 패널 — widget 에 따라 컨트롤을 렌더한다.
// 값은 슬라이더/드롭다운/라디오로만 조절되어 범위 밖 입력이 원천 차단된다(백엔드도 재검증).
export default function HyperparamPanel({ spec, value, onChange, tunable = false, tune = false, onTuneChange, tuneApprox = false, tuneLstm = false, tuneTransformer = false, tuneMaxSec = 60 }: Props) {
  const set = (name: string, v: string | number | null) => onChange({ ...value, [name]: v });
  const resetDefaults = () => {
    const d: ParamValues = {};
    for (const p of spec.params) d[p.name] = p.default;
    onChange(d);
  };

  return (
    <div className="rounded-card border border-border bg-surface-muted/40 p-4">
      <div className="mb-3 flex items-center justify-between gap-2">
        <div>
          <h4 className="text-sm font-semibold text-text">세부 설정</h4>
          <p className="text-xs text-text-muted">조정하지 않으면 권장값으로 학습돼요.</p>
        </div>
        <div className="flex flex-none items-center gap-3">
          {tunable && onTuneChange && (
            <label className="flex items-center gap-1.5 whitespace-nowrap text-xs font-medium text-text">
              <input type="checkbox" checked={tune} onChange={(e) => onTuneChange(e.target.checked)} className="accent-primary" />
              자동 최적화 (Optuna)
            </label>
          )}
          {!tune && (
            <button type="button" onClick={resetDefaults} className="whitespace-nowrap text-xs font-medium text-primary hover:underline">
              기본값으로 초기화
            </button>
          )}
        </div>
      </div>

      {tune ? (
        // 자동 최적화 켜짐: 수동 슬라이더 비활성(숨김) + 안내. 학습 후 찾은 값은 결과 화면에 표시된다.
        <p className="rounded-btn bg-surface px-3 py-2 text-xs text-text-muted">
          최적값을 자동으로 탐색합니다 ({tuneLstm ? '순차' : '5-fold'} 교차검증, 최대 {fmtDuration(tuneMaxSec)}). 슬라이더는 잠시 꺼두고, 학습 후 찾은 값을 결과에 보여드려요.
          {tuneLstm ? (
            <span className="mt-1 block text-warning">※ LSTM 자동최적화는 딥러닝이라 시간이 오래 걸립니다(최대 5분). 일부 연속 구간(3,000행)으로 탐색한 근사값이며, 최종 학습은 전체 데이터입니다.</span>
          ) : tuneTransformer ? (
            <span className="mt-1 block text-warning">※ Transformer 자동최적화는 딥러닝이라 시간이 오래 걸립니다(최대 5분). 일부 표본(3,000행)으로 탐색한 근사값이며, 최종 학습은 전체 데이터입니다.</span>
          ) : tuneApprox ? (
            <span className="mt-1 block text-warning">※ 일부 표본(svr 3,000·svc 5,000행)으로 탐색한 근사 최적값입니다(최종 학습은 전체 데이터).</span>
          ) : null}
        </p>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {spec.params.map((p) => (
            <ParamControl key={p.name} def={p} value={value[p.name]} onChange={(v) => set(p.name, v)} />
          ))}
        </div>
      )}
    </div>
  );
}

function ParamControl({ def, value, onChange }: { def: HyperparamDef; value: string | number | null | undefined; onChange: (v: string | number | null) => void }) {
  // 미지정(undefined)만 기본값으로 폴백. 명시적 null(예: "제한 없음")은 그대로 보존한다(?? 사용 금지).
  const cur = value === undefined ? def.default : value;

  return (
    <label className="block">
      <span className="mb-1 flex items-baseline justify-between gap-2">
        <span className="text-xs font-medium text-text">{def.label}</span>
        {(def.widget === 'slider' || def.widget === 'number' || def.widget === 'log-slider') && (
          <span className="text-xs tabular-nums text-text-muted">
            {cur}
            {def.min !== undefined && def.max !== undefined && (
              <span className="ml-1 text-text-muted/70">({def.min}~{def.max})</span>
            )}
          </span>
        )}
      </span>

      {def.widget === 'slider' && (
        <input
          type="range"
          min={def.min}
          max={def.max}
          step={def.step ?? 1}
          value={Number(cur)}
          onChange={(e) => onChange(def.type === 'int' ? Math.round(Number(e.target.value)) : Number(e.target.value))}
          className="w-full accent-primary"
        />
      )}

      {/* log-slider: 슬라이더 위치 t∈[0,1] ↔ 값 = 10^(log10(min) + t·(log10(max)-log10(min))). 값은 float 로 저장. */}
      {def.widget === 'log-slider' && (() => {
        const lmin = Math.log10(def.min ?? 0.1);
        const lmax = Math.log10(def.max ?? 100);
        const span = lmax - lmin || 1;
        const v = Math.min(def.max ?? Infinity, Math.max(def.min ?? -Infinity, Number(cur)));
        const t = (Math.log10(v) - lmin) / span; // 값 → 슬라이더 위치(역매핑)
        return (
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={Number.isFinite(t) ? Math.min(1, Math.max(0, t)) : 0}
            onChange={(e) => {
              const val = Math.pow(10, lmin + Number(e.target.value) * span);
              onChange(Number(val.toPrecision(3))); // 유효숫자 3자리로 깔끔한 float 저장(예: 0.316, 3.16, 31.6)
            }}
            className="w-full accent-primary"
          />
        );
      })()}

      {def.widget === 'number' && (
        <input
          type="number"
          min={def.min}
          max={def.max}
          step={def.step ?? 1}
          value={Number(cur)}
          onChange={(e) => onChange(def.type === 'int' ? Math.round(Number(e.target.value)) : Number(e.target.value))}
          className={`${selectCls} w-full`}
        />
      )}

      {def.widget === 'dropdown' && (
        <select
          value={String(cur)}
          onChange={(e) => onChange(coerceChoice(def, e.target.value))}
          className={`${selectCls} w-full`}
        >
          {def.choices?.map((c) => (
            <option key={String(c.value)} value={String(c.value)}>{c.label}</option>
          ))}
        </select>
      )}

      {def.widget === 'radio' && (
        <div className="flex flex-wrap gap-3 pt-1">
          {def.choices?.map((c) => (
            <label key={String(c.value)} className="flex items-center gap-1.5 text-sm text-text">
              <input
                type="radio"
                name={def.name}
                checked={String(cur) === String(c.value)}
                onChange={() => onChange(c.value)}
                className="accent-primary"
              />
              {c.label}
            </label>
          ))}
        </div>
      )}

      {/* enum-or-number: 선택지(scale/auto/제한 없음 등) 또는 "직접 입력"→숫자칸. 값은 문자열/숫자/null 단일 필드.
          type 이 enum_or_int 면 정수(step=1·반올림), enum_or_float 면 실수(step=any). */}
      {def.widget === 'enum-or-number' && (() => {
        const MANUAL = '__manual__';
        const isInt = def.type === 'enum_or_int';
        const isManual = typeof cur === 'number';
        const min = def.min ?? 0;
        const max = def.max ?? 1;
        const clamp = (n: number) => Math.min(max, Math.max(min, isInt ? Math.round(n) : n));
        const startVal = () => (typeof cur === 'number' ? cur : isInt ? min : clamp(0.1));
        // 비활성 시 오해 방지: 값칸은 비우고 현재 선택지 라벨(예: "제한 없음")을 placeholder 로 보여준다.
        //   전송 값은 이 칸이 아니라 상위 param 상태(cur)에서 나온다 → disabled 라 onChange 가 안 뛰어 잔값이 섞이지 않는다.
        const curChoiceLabel = def.choices?.find((c) => c.value === cur)?.label ?? String(cur);
        return (
          // 드롭다운(좌 50%) + 직접 입력 칸(우 50%)을 한 행에. 좁으면 세로 스택(flex-col → sm:flex-row).
          <div className="flex flex-col gap-2 sm:flex-row">
            <select
              value={isManual ? MANUAL : String(cur)}
              onChange={(e) => {
                if (e.target.value === MANUAL) onChange(startVal()); // 직접 입력 전환
                else onChange(coerceChoice(def, e.target.value));
              }}
              className={`${selectCls} min-w-0 flex-1`}
            >
              {def.choices?.map((c) => (
                <option key={String(c.value)} value={String(c.value)}>{c.label}</option>
              ))}
              <option value={MANUAL}>직접 입력</option>
            </select>
            {/* 선택지(제한 없음 등) 모드에서도 칸을 숨기지 않고 disabled 로 남긴다(값 전송은 param 상태 기준이라 무영향). */}
            <input
              type="number"
              min={min}
              max={max}
              step={isInt ? 1 : 'any'}
              disabled={!isManual}
              value={isManual ? Number(cur) : ''}
              placeholder={isManual ? undefined : curChoiceLabel}
              onChange={(e) => onChange(isInt ? Math.round(Number(e.target.value)) : Number(e.target.value))}
              className={`${selectCls} min-w-0 flex-1 disabled:cursor-not-allowed disabled:opacity-50`}
            />
          </div>
        );
      })()}

      {/* enum-or-slider: enum-or-number 와 동일한 드롭다운(선택지 + "직접 입력")이되, 직접 입력을 고르면
          숫자칸 대신 슬라이더가 뜬다(rf max_depth·max_features). 저장 값 형식은 enum-or-number 와 같다
          (문자열 "sqrt"/"log2" · 숫자 · null) → 백엔드 검증(type 기준)·usedParams 는 그대로 동작한다.
          현재값 표시는 이 블록 안에서 직접 한다(공유 헤더는 slider 계열 전용이라 건드리지 않음) →
          문자열 선택 중에는 숫자가 뜨지 않는다. */}
      {def.widget === 'enum-or-slider' && (() => {
        const MANUAL = '__manual__';
        const isInt = def.type === 'enum_or_int';
        const isManual = typeof cur === 'number'; // 값이 숫자면 슬라이더 모드(별도 state 없음)
        const min = def.min ?? 0;
        const max = def.max ?? 1;
        const clamp = (n: number) => Math.min(max, Math.max(min, isInt ? Math.round(n) : n));
        const startVal = () => (typeof cur === 'number' ? cur : isInt ? min : clamp(0.1));
        return (
          <div className="space-y-2">
            <select
              value={isManual ? MANUAL : String(cur)}
              onChange={(e) => {
                if (e.target.value === MANUAL) onChange(startVal()); // 직접 입력 전환
                else onChange(coerceChoice(def, e.target.value));
              }}
              className={`${selectCls} w-full`}
            >
              {def.choices?.map((c) => (
                <option key={String(c.value)} value={String(c.value)}>{c.label}</option>
              ))}
              <option value={MANUAL}>직접 입력</option>
            </select>
            {isManual && (
              <div>
                <div className="mb-1 flex items-baseline justify-end">
                  <span className="text-xs tabular-nums text-text-muted">
                    {cur}
                    <span className="ml-1 text-text-muted/70">({min}~{max})</span>
                  </span>
                </div>
                <input
                  type="range"
                  min={min}
                  max={max}
                  step={def.step ?? (isInt ? 1 : 0.05)}
                  value={Number(cur)}
                  onChange={(e) => onChange(clamp(Number(e.target.value)))}
                  className="w-full accent-primary"
                />
              </div>
            )}
          </div>
        );
      })()}

      {def.help && <span className="mt-1 block text-xs text-text-muted">{def.help}</span>}
    </label>
  );
}

// enum select 는 문자열만 다루므로, 원래 choice 의 타입(숫자/문자/null)을 복원한다.
function coerceChoice(def: HyperparamDef, raw: string): string | number | null {
  const hit = def.choices?.find((c) => String(c.value) === raw);
  return hit ? hit.value : raw;
}
