import { useState } from 'react';
import Button from '../../components/Button';

interface Props {
  features: string[]; // 학습에 사용한 수치형 피처(순서 유지)
  labels: Record<string, string>; // name → 표시명
  means: number[]; // 각 피처 기본값(평균)
  isReg: boolean;
  // 로컬=동기, 서버=원격(Promise). 둘 다 지원.
  predict: (x: number[]) => number | string | Promise<number | string>;
  targetLabel: string; // 목표(예측 대상) 컬럼 표시명
}

// A의 "새 값으로 예측해 보기" — 입력값을 넣고 학습된 모델로 즉시(또는 서버 왕복) 예측.
export default function PredictForm({ features, labels, means, isReg, predict, targetLabel }: Props) {
  const [vals, setVals] = useState<string[]>(features.map((_, i) => String(Math.round(means[i] * 100) / 100)));
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function run() {
    const x = vals.map((v, i) => {
      const n = Number(v);
      return Number.isNaN(n) ? means[i] : n;
    });
    setError(null);
    setBusy(true);
    try {
      const out = await predict(x); // 로컬이면 즉시, 서버면 원격 왕복
      setResult(isReg ? `${typeof out === 'number' ? Math.round(out * 1000) / 1000 : out}` : String(out));
    } catch (e) {
      // 서버 모델 만료(MissingModelError)·네트워크 오류 등 → 재학습/재시도 유도
      setResult(null);
      setError(e instanceof Error ? e.message : '예측에 실패했습니다. 모델을 다시 학습해 주세요.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-text-muted">아래 값을 넣고 예측 버튼을 누르세요. (기본값은 각 변수의 평균)</p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {features.map((f, i) => (
          <label key={f} className="block">
            <span className="mb-1 block text-xs font-medium text-text-muted">{labels[f] ?? f}</span>
            <input
              value={vals[i]}
              onChange={(e) => setVals((prev) => prev.map((v, j) => (j === i ? e.target.value : v)))}
              className="w-full rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none"
            />
          </label>
        ))}
      </div>
      <Button onClick={run} loading={busy}>예측 실행</Button>
      {error !== null && (
        <p className="text-sm text-danger">{error}</p>
      )}
      {result !== null && (
        <div className="rounded-card border border-primary/30 bg-primary-soft p-4">
          <div className="text-xs text-text-muted">{isReg ? '예측 결과' : '예측 분류'}</div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-sm font-medium text-text">{targetLabel} :</span>
            <span className="text-lg font-bold text-primary">{result}</span>
          </div>
        </div>
      )}
    </div>
  );
}
