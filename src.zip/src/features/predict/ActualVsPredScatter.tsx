import { CartesianGrid, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from 'recharts';

// 실제=예측 기준선(y=x) 구간 좌표 — 예측 결과 화면(RegResultView)의 refSegment 와 동일 로직.
function refSegment(data: { actual: number; pred: number }[]) {
  if (!data.length) return [{ x: 0, y: 0 }, { x: 1, y: 1 }];
  let lo = Infinity;
  let hi = -Infinity;
  for (const p of data) {
    lo = Math.min(lo, p.actual, p.pred);
    hi = Math.max(hi, p.actual, p.pred);
  }
  return [{ x: lo, y: lo }, { x: hi, y: hi }];
}

// 실제값 vs 예측값 산점도 — 예측 결과 화면의 인라인 렌더를 컴포넌트로 추출해 재사용한다.
// (계수/중요도가 없는 모델(KNN 등)의 결과·리포트 표시에 공용으로 쓴다.)
export default function ActualVsPredScatter({ data, height = 300 }: { data: { actual: number; pred: number }[]; height?: number }) {
  const seg = refSegment(data);
  const lo = seg[0].x;
  const hi = seg[1].x;
  return (
    <>
      <ResponsiveContainer width="100%" height={height}>
        <ScatterChart margin={{ top: 10, right: 24, bottom: 28, left: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
          <XAxis
            type="number"
            dataKey="actual"
            name="실제값"
            domain={[lo, hi]}
            tick={{ fontSize: 11, fill: 'var(--text-muted)' }}
            label={{ value: '실제값', position: 'insideBottom', offset: -14, fill: 'var(--text-muted)', fontSize: 12 }}
          />
          <YAxis
            type="number"
            dataKey="pred"
            name="예측값"
            domain={[lo, hi]}
            tick={{ fontSize: 11, fill: 'var(--text-muted)' }}
            label={{ value: '예측값', angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 12, style: { textAnchor: 'middle' } }}
          />
          <ZAxis range={[40, 40]} />
          <Tooltip contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, fontSize: 12 }} />
          {/* 이상선 x=y (예측=실제) */}
          <ReferenceLine
            segment={[{ x: lo, y: lo }, { x: hi, y: hi }]}
            stroke="var(--danger)"
            strokeWidth={1.5}
            strokeDasharray="5 5"
            ifOverflow="extendDomain"
          />
          <Scatter data={data} fill="var(--primary)" fillOpacity={0.5} />
        </ScatterChart>
      </ResponsiveContainer>
      <p className="mt-1 text-center text-xs text-text-muted">
        점이 <span className="text-danger">빨간 점선(예측=실제)</span> 에 가까울수록 예측이 정확해요.
      </p>
    </>
  );
}
