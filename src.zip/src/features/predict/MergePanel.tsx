import { useRef, useState } from 'react';
import Button from '../../components/Button';
import { useBusy } from '../../hooks/useBusy';
import { parseFile } from '../../lib/parseFile';
import { profileDataset } from '../../lib/profile';
import { joinByKey, concatRows, type JoinType, type DupMode } from '../../lib/merge';
import type { Dataset, Row } from '../../types';

const selectCls = 'rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';
const MAX_FILES = 10;

interface ExtraFile {
  id: string;
  name: string;
  rows: Row[];
  cols: string[];
  baseKey: string; // 기준(기존 데이터 또는 기준 파일)의 key
  extraKey: string; // 이 파일의 key
  joinType: JoinType;
  dupMode: DupMode; // 컬럼명 충돌 처리 방식
}

interface Props {
  base: Dataset | null; // 현재(전처리된) 데이터 — 없으면 첫 파일이 기준 파일이 된다.
  onMerged: (d: Dataset | null) => void; // 병합 결과 또는 해제(null)
}

let uid = 0;
const nextId = () => `f${uid++}`;

type MergeMode = 'join' | 'concat'; // join=컬럼 늘리기(가로) / concat=행 이어붙이기(세로)

// 파일 병합 — 최대 10개를 순서대로 붙인다.
//   join: key 기준 컬럼 결합(LEFT 기본 + INNER 옵션). concat: 같은 형식 데이터를 행으로 이어붙임(컬럼 합집합).
// base 가 없으면(업로드 안 함) 첫 번째 파일이 기준 파일이 되고 나머지가 그 위에 붙는다.
export default function MergePanel({ base, onMerged }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [mode, setMode] = useState<MergeMode>('join');
  const [extras, setExtras] = useState<ExtraFile[]>([]);
  const [info, setInfo] = useState<{ total: number; added: string[]; files: number } | null>(null);
  const [error, setError] = useState('');
  const [loadingFile, setLoadingFile] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [applying, runApply] = useBusy();

  // 기준 컬럼: base 가 있으면 base 컬럼, 없으면 첫 파일(기준 파일)의 컬럼.
  const primaryCols = base ? base.columns.map((c) => c.name) : extras[0]?.cols ?? [];
  // base 없이 index 0 인 파일은 "기준 파일"(key 설정 불필요)
  const isPrimary = (i: number) => !base && i === 0;

  // 설정이 바뀌면 이전 병합 결과는 무효 → 해제
  const invalidate = () => {
    setInfo(null);
    onMerged(null);
  };

  // 병합 방식 전환 — 이전 결과 무효화(설정 변경과 동일 취급).
  function switchMode(m: MergeMode) {
    if (m === mode) return;
    setMode(m);
    setError('');
    invalidate();
  }

  async function addFiles(files: File[]) {
    if (!files.length) return;
    setError('');
    invalidate();
    const room = MAX_FILES - extras.length;
    if (room <= 0) {
      setError(`파일은 최대 ${MAX_FILES}개까지 추가할 수 있어요.`);
      return;
    }
    const accepted = files.slice(0, room);
    const skipped = files.length - accepted.length;
    setLoadingFile(true);
    try {
      const parsed: ExtraFile[] = [];
      for (const file of accepted) {
        try {
          const { rows } = await parseFile(file);
          if (!rows.length) throw new Error('비어 있음');
          const cols = Object.keys(rows[0]);
          parsed.push({ id: nextId(), name: file.name, rows, cols, baseKey: '', extraKey: '', joinType: 'left', dupMode: 'suffix' });
        } catch {
          setError(`'${file.name}' 파일을 읽지 못했어요.`);
        }
      }
      if (parsed.length) {
        setExtras((prev) => {
          const combined = [...prev, ...parsed];
          // 기준 컬럼 확정(base 우선, 없으면 합친 목록의 첫 파일)
          const pCols = base ? base.columns.map((c) => c.name) : combined[0]?.cols ?? [];
          const pk = pCols[0] ?? '';
          return combined.map((e, idx) => {
            if (!base && idx === 0) return e; // 기준 파일은 key 불필요
            if (e.baseKey || e.extraKey) return e; // 이미 설정된(기존) 파일은 유지
            return { ...e, baseKey: pk, extraKey: e.cols.find((c) => c === pk) ?? e.cols[0] ?? '' };
          });
        });
      }
      if (skipped > 0) setError(`최대 ${MAX_FILES}개까지만 추가돼요. ${skipped}개는 제외했습니다.`);
    } finally {
      setLoadingFile(false);
    }
  }

  function updateExtra(id: string, patch: Partial<ExtraFile>) {
    setExtras((prev) => prev.map((e) => (e.id === id ? { ...e, ...patch } : e)));
    invalidate();
  }

  function removeExtra(id: string) {
    setExtras((prev) => prev.filter((e) => e.id !== id));
    invalidate();
  }

  function clearAll() {
    setExtras([]);
    invalidate();
    setError('');
  }

  // key 조인 + 재프로파일은 데이터가 크면 무거우므로 스피너를 띄운 뒤 실행한다.
  function applyMerge() {
    if (!extras.length) return;
    // 기준 rows/이름 + 붙일 파일 목록 결정
    let rows: Row[];
    let baseName: string;
    let joinFiles: ExtraFile[];
    if (base) {
      rows = base.rows;
      baseName = base.fileName;
      joinFiles = extras;
    } else {
      rows = extras[0].rows;
      baseName = extras[0].name;
      joinFiles = extras.slice(1);
    }
    const added: string[] = [];
    for (const ex of joinFiles) {
      if (mode === 'concat') {
        // 행 이어붙이기: key 불필요. 컬럼 합집합으로 정렬해 아래로 붙인다.
        const res = concatRows(rows, ex.rows);
        rows = res.rows;
        for (const c of res.addedColumns) if (!added.includes(c)) added.push(c);
        continue;
      }
      if (!ex.baseKey || !ex.extraKey) {
        setError(`'${ex.name}'의 key 컬럼을 선택하세요.`);
        onMerged(null);
        return;
      }
      const res = joinByKey(rows, ex.rows, ex.baseKey, ex.extraKey, ex.joinType, ex.dupMode);
      if (!res.rows.length) {
        setError(`'${ex.name}' 병합에서 매칭되는 행이 없어 결과가 비었습니다. key 컬럼을 확인하세요.`);
        onMerged(null);
        return;
      }
      rows = res.rows;
      added.push(...res.addedColumns);
    }
    setError('');
    setInfo({ total: rows.length, added, files: extras.length });
    const names = joinFiles.map((e) => e.name);
    const fileName = names.length ? `${baseName} + ${names.join(' + ')}` : baseName;
    onMerged(profileDataset(fileName, rows));
    // 성공 시에만 병합 대상 파일 목록을 비운다(승격된 데이터에 재병합 누적 방지).
    //   실패 경로(위 key 미선택·매칭 0건)는 이미 return 하므로 여기 도달하지 않아 목록이 유지된다.
    setExtras([]);
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files ?? []);
    if (files.length) void addFiles(files);
  }

  return (
    <div className="space-y-4 rounded-card border border-border bg-surface-muted/40 p-4">
      {/* 병합 방식 선택 */}
      <div>
        <div className="inline-flex rounded-btn border border-border bg-surface p-1 text-sm font-medium">
          <button
            type="button"
            onClick={() => switchMode('join')}
            className={`rounded-btn px-3 py-1.5 transition-colors ${mode === 'join' ? 'bg-primary text-white' : 'text-text-muted hover:text-text'}`}
          >
            컬럼 늘리기 (조인)
          </button>
          <button
            type="button"
            onClick={() => switchMode('concat')}
            className={`rounded-btn px-3 py-1.5 transition-colors ${mode === 'concat' ? 'bg-primary text-white' : 'text-text-muted hover:text-text'}`}
          >
            행 이어붙이기
          </button>
        </div>
        <p className="mt-1.5 text-xs text-text-muted">
          {mode === 'join'
            ? 'key 컬럼을 기준으로 다른 파일의 컬럼을 옆에 붙입니다(가로 결합).'
            : '같은 형식의 데이터를 아래로 이어붙여 행을 늘립니다(세로 결합). 컬럼이 다르면 없는 값은 빈 칸으로 채웁니다.'}
        </p>
      </div>

      {/* 드롭존 + 파일 선택 */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={`rounded-card border-2 border-dashed p-6 text-center transition-colors ${
          dragOver ? 'border-primary bg-primary/5' : 'border-border'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          multiple
          className="hidden"
          onChange={(e) => { void addFiles(Array.from(e.target.files ?? [])); e.target.value = ''; }}
        />
        <p className="text-sm text-text-muted">파일을 여기로 끌어다 놓거나</p>
        <Button variant="secondary" loading={loadingFile} onClick={() => inputRef.current?.click()} className="mt-2" disabled={extras.length >= MAX_FILES}>
          {base ? '병합할 파일 선택' : '파일 선택'}
        </Button>
        <p className="mt-2 text-xs text-text-muted">CSV · Excel · 여러 개 선택 가능 ({extras.length}/{MAX_FILES})</p>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}

      {/* 파일별 key 설정 */}
      {extras.map((ex, i) => (
        <div key={ex.id} className="space-y-3 rounded-card border border-border bg-surface p-3">
          <div className="flex items-center justify-between gap-2">
            <span className="truncate text-sm font-medium text-text">
              {isPrimary(i) && <span className="mr-1.5 rounded-chip bg-primary/10 px-2 py-0.5 text-xs text-primary">기준 파일</span>}
              {i + 1}. {ex.name} <span className="text-text-muted">· {ex.rows.length.toLocaleString()}행</span>
            </span>
            <button type="button" onClick={() => removeExtra(ex.id)} className="flex-none text-xs text-danger hover:underline">
              제거
            </button>
          </div>

          {mode === 'join' && !isPrimary(i) && (
            <>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-1 block text-xs font-medium text-text-muted">{base ? '기존 데이터 key' : '기준 파일 key'}</span>
                  <select value={ex.baseKey} onChange={(e) => updateExtra(ex.id, { baseKey: e.target.value })} className={`${selectCls} w-full`}>
                    {primaryCols.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="mb-1 block text-xs font-medium text-text-muted">새 파일 key</span>
                  <select value={ex.extraKey} onChange={(e) => updateExtra(ex.id, { extraKey: e.target.value })} className={`${selectCls} w-full`}>
                    {ex.cols.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </label>
              </div>

              <label className="flex items-center gap-2 text-sm text-text">
                <input
                  type="checkbox"
                  checked={ex.joinType === 'inner'}
                  onChange={(e) => updateExtra(ex.id, { joinType: e.target.checked ? 'inner' : 'left' })}
                  className="accent-primary"
                />
                매칭되는 행만 남기기 (INNER) — 체크 해제 시 기존 행 전부 유지(LEFT)
              </label>

              <label className="block">
                <span className="mb-1 block text-xs font-medium text-text-muted">이름이 같은 컬럼이 있을 때</span>
                <select value={ex.dupMode} onChange={(e) => updateExtra(ex.id, { dupMode: e.target.value as DupMode })} className={`${selectCls} w-full sm:w-80`}>
                  <option value="suffix">별도 컬럼으로 보존 (_2, _3 …)</option>
                  <option value="overwrite">기존 컬럼 덮어쓰기 (값 완전 교체)</option>
                </select>
              </label>
            </>
          )}
        </div>
      ))}

      {extras.length > 0 && (
        <div className="flex gap-2">
          <Button loading={applying} onClick={() => runApply(applyMerge)}>병합 적용</Button>
          <Button variant="ghost" onClick={clearAll}>전체 해제</Button>
        </div>
      )}

      {info && (
        <p className="rounded-btn bg-success/10 px-3 py-2 text-sm text-success">
          {mode === 'concat'
            ? `✓ 행 이어붙이기 완료 — 파일 ${info.files}개 · 결과 ${info.total.toLocaleString()}행${info.added.length ? ` · 새 컬럼 ${info.added.length}개: ${info.added.join(', ')}` : ''}`
            : `✓ 병합 완료 — 파일 ${info.files}개 · 결과 ${info.total.toLocaleString()}행 · 추가 컬럼 ${info.added.length}개${info.added.length ? `: ${info.added.join(', ')}` : ''}`}
        </p>
      )}
    </div>
  );
}
