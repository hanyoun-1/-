import { useEffect, useMemo, useRef, useState } from 'react';
import { Bar, BarChart, CartesianGrid, ComposedChart, Legend, Line, LineChart, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis, ReferenceLine } from 'recharts';
import PageHeader from '../../components/PageHeader';
import Card from '../../components/Card';
import Button from '../../components/Button';
import NavFooter from '../../components/NavFooter';
import InsightCard from '../../components/InsightCard';
import SegmentedControl from '../../components/SegmentedControl';
import DecisionTreeConcept from '../../components/DecisionTreeConcept';
import PredictForm from './PredictForm';
import HyperparamPanel from './HyperparamPanel';
import { useActiveDataset } from '../../hooks/useActiveDataset';
import { useStepStore } from '../../store/useStepStore';
import { useDatasetStore } from '../../store/useDatasetStore';
import { useBusy } from '../../hooks/useBusy';
import { isMissing, parseDateValue } from '../../lib/dataQuality';
import type { ClsAlgo, ClsResult, PredictionContext, RegAlgo, RegResult } from '../../lib/models';
import {
  runRegression,
  runClassification,
  resumeRegression,
  resumeClassification,
  loadHyperparamSpecs,
  getSpec,
  defaultParams,
  formatUsedParams,
  estimateLstmSeconds,
  LSTM_TIME_LIMIT_SEC,
  estimateTransformerSeconds,
  TRANSFORMER_TIME_LIMIT_SEC,
  tuneTimeoutSec,
  fmtDuration,
  CancelledError,
  type ModelSpec,
  type ParamValues,
  type NormalizedRegression,
  type NormalizedClassification,
} from '../../lib/compute';
import { useTrainingJobStore, type Trained, type TrainingJobCtx } from '../../store/useTrainingJobStore';
import type { Dataset } from '../../types';

const selectCls = 'rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

// 다시보기(U3)에서 ClsResultView 에 넘길 안정적 빈 means 참조.
//   저장 리포트엔 means 가 없고 확률곡선(probaFn)도 없어 실제로 쓰이지 않지만, 새 [] 리터럴을 매 렌더
//   넘기면 ProbabilityCurveView 의 effect 의존성(means)이 계속 바뀌어 루프가 되므로 고정 참조를 쓴다.
const EMPTY_MEANS: number[] = [];

// 알고리즘 표시 라벨(내부 키→한글). 결과 뷰·리포트 추가 등에서 공용.
const REG_ALGO_LABEL: Record<string, string> = { linear: '선형회귀', rf: '랜덤 포레스트', knn: 'KNN 회귀', svr: 'SVM 회귀 (SVR)', ridge: 'Ridge 회귀', lasso: 'Lasso 회귀', elasticnet: 'ElasticNet', xgboost: 'XGBoost', lightgbm: 'LightGBM', catboost: 'CatBoost', mlp: 'MLP (신경망)', lstm: 'LSTM', transformer: 'Transformer' };
const CLS_ALGO_LABEL: Record<string, string> = { logistic: '로지스틱 회귀', rf: '랜덤 포레스트', knn: 'KNN 분류', svc: 'SVM 분류 (SVC)', dtree: '결정 트리', xgboost: 'XGBoost', lightgbm: 'LightGBM', catboost: 'CatBoost', mlp: 'MLP (신경망)' };

// 시퀀스(시계열 전용) 회귀 모델 메타 — 시간 순서 컬럼 필수·순차분할 강제 가드용. ★ LSTM 만 해당(Transformer 는 표 데이터라 제외).
type SeqModel = { label: string };

function toNum(v: unknown): number | null {
  if (isMissing(v)) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  const n = Number(v);
  return Number.isNaN(n) ? null : n;
}

// Trained 타입은 전역 store(useTrainingJobStore)로 옮겼다 — 학습 결과를 페이지 이동에도 보존하기 위함.

// 서버 결과 정규화(norm) → Trained 객체. 학습 경로(train)와 복원 경로(resumeFlow)가 공유해 동일하게 재구성한다.
type RegMeta = { algo: RegAlgo; features: string[]; means: number[]; n: number; timeCol?: string; timeLabels?: string[]; spec?: ModelSpec };
function buildTrainedReg(norm: NormalizedRegression, m: RegMeta): Trained {
  const reg: RegResult = {
    algo: m.algo,
    features: m.features,
    coef: norm.coef ?? [],
    intercept: norm.intercept,
    r2: norm.metrics.r2,
    mae: norm.metrics.mae,
    rmse: norm.metrics.rmse,
    actualVsPred: norm.actualVsPred,
    n: m.n,
    sampled: norm.sampled,
    vizTree: norm.vizTree,
    sequentialSplit: norm.sequentialSplit, // 시간순 분할 에코 → 결과 화면 시간축 선그래프 분기용
  };
  return {
    isReg: true,
    features: m.features,
    means: m.means,
    predict: norm.predict,
    reg,
    serverModelId: norm.modelId,
    usedParams: norm.usedParams,
    bestParams: norm.bestParams,
    paramSpec: m.spec,
    scaled: norm.scaled,
    timeCol: m.timeCol,
    timeLabels: m.timeLabels,
  };
}

type ClsMeta = { algo: ClsAlgo; features: string[]; means: number[]; n: number; spec?: ModelSpec };
function buildTrainedCls(norm: NormalizedClassification, m: ClsMeta): Trained {
  const cls: ClsResult = {
    features: m.features,
    classes: norm.classes,
    accuracy: norm.accuracy,
    confusion: norm.confusion,
    report: norm.report,
    n: m.n,
    algo: m.algo,
    sampled: norm.sampled,
    coef: norm.coef,
    vizTree: norm.vizTree,
  };
  return {
    isReg: false,
    features: m.features,
    means: m.means,
    predict: norm.predict,
    probaFn: norm.predictProba,
    cls,
    serverModelId: norm.modelId,
    usedParams: norm.usedParams,
    bestParams: norm.bestParams,
    paramSpec: m.spec,
    scaled: norm.scaled,
  };
}

export default function PredictPage() {
  const base = useActiveDataset();
  const goto = useStepStore((s) => s.goto);
  const addPredictionReport = useDatasetStore((s) => s.addPredictionReport);
  const predictionReports = useDatasetStore((s) => s.predictionReports);

  // 예측 데이터 = 현재 전처리 반영된 activeDataset(병합했다면 이미 승격되어 여기 반영됨).
  const d = base;

  const [task, setTask] = useState<'reg' | 'cls'>('reg');
  const [target, setTarget] = useState<string>('');
  const [features, setFeatures] = useState<string[] | null>(null); // null = 전체 선택
  const [algo, setAlgo] = useState<RegAlgo>('linear');
  const [clsAlgo, setClsAlgo] = useState<ClsAlgo>('logistic');
  const [testRatio, setTestRatio] = useState(0.2);
  const [trained, setTrained] = useState<Trained | null>(null);
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null); // 목록에서 다시보기로 선택한 리포트
  const [error, setError] = useState('');
  // 하이퍼파라미터 명세(백엔드 단일 원천). null=미로드, [] 가능. 실패 시 specsError.
  const [specs, setSpecs] = useState<ModelSpec[] | null>(null);
  const [specsError, setSpecsError] = useState(false);
  const [params, setParams] = useState<ParamValues>({}); // 현재 알고리즘의 조정값(knn 등)
  const [tune, setTune] = useState(false); // 자동 하이퍼파라미터 튜닝(Optuna). rf·xgb 만. 알고리즘 변경 시 리셋.
  const [tuneProgress, setTuneProgress] = useState<{ done: number; total: number; best: number | null } | null>(null); // 비동기 튜닝 진행률(폴링)
  const [scale, setScale] = useState(true); // 표준화(스케일링) 체크 상태 — 기본 켜짐(W2)
  const [sequentialSplit, setSequentialSplit] = useState(false); // 시간순 분할(시계열) — 기본 꺼짐(랜덤 분할 유지)
  const [timeCol, setTimeCol] = useState<string>(''); // 시간 기준 정렬 컬럼 — '' = 정렬 안 함(기본). sequentialSplit 과 함께일 때만 적용.
  const [timeNote, setTimeNote] = useState(''); // 시간 정렬 시 제외된 행 안내(결측·파싱 실패). 없으면 빈 문자열.
  // 서버 학습 실패 시 재시도 배너용. (학습은 항상 백엔드 → 브라우저 폴백 없음)
  const [serverError, setServerError] = useState<{ message: string } | null>(null);
  const [addedToReport, setAddedToReport] = useState(false);
  const [busy, runBusy] = useBusy();
  const abortRef = useRef<AbortController | null>(null); // 진행 중 학습의 취소 컨트롤러(폴링·요청 중단용)
  const [cancelled, setCancelled] = useState(false); // 취소 안내 표시

  // 비동기 학습 전역 store — jobId·진행률·완료결과를 페이지 이동(언마운트)에도 보존. 복귀 시 재폴링/복원.
  const jobStartJob = useTrainingJobStore((s) => s.startJob);
  const jobSetProgress = useTrainingJobStore((s) => s.setProgress);
  const jobCompleteJob = useTrainingJobStore((s) => s.completeJob);
  const jobClearJob = useTrainingJobStore((s) => s.clearJob);
  const restoredRef = useRef(false); // 마운트당 복원 1회만 시도(중복 폴링 방지)

  // 데이터셋 지문 — 복귀 시 데이터가 바뀌었으면 옛 결과를 박지 않도록 판정하는 키.
  const datasetKey = d ? `${d.fileName}#${d.rows.length}#${d.columns.length}` : '';

  // 명세 1회 로드·캐시(모듈 캐시라 재진입해도 재요청 안 함). 실패 시 KNN 옵션 비활성 + 안내.
  useEffect(() => {
    let alive = true;
    loadHyperparamSpecs()
      .then((s) => { if (alive) setSpecs(s); })
      .catch(() => { if (alive) setSpecsError(true); });
    return () => { alive = false; };
  }, []);

  // 이미 시작된 비동기 job 을 이어받아 복원한다(새 학습 시작 아님). done→결과, running→폴링 재개, failed/cancelled→그에 맞게.
  async function resumeFlow(jobId: string, ctx: TrainingJobCtx) {
    abortRef.current = new AbortController(); // 복귀 후에도 취소 가능하도록 컨트롤러 재생성
    setServerError(null);
    setCancelled(false);
    const spec = getSpec(specs, ctx.task, ctx.algo);
    const onProg = (done: number, total: number, best: number | null) => {
      setTuneProgress({ done, total, best });
      useTrainingJobStore.getState().setProgress({ done, total, best }); // 진행률도 store 에 갱신(다시 이동 시 이어보기)
    };
    try {
      if (ctx.task === 'reg') {
        const norm = await resumeRegression(jobId, onProg, abortRef.current.signal);
        const t = buildTrainedReg(norm, { algo: ctx.algo as RegAlgo, features: ctx.features, means: ctx.means, n: ctx.n, timeCol: ctx.timeCol, spec });
        setTrained(t);
        jobCompleteJob(t);
      } else {
        const norm = await resumeClassification(jobId, ctx.features, onProg, abortRef.current.signal);
        const t = buildTrainedCls(norm, { algo: ctx.algo as ClsAlgo, features: ctx.features, means: ctx.means, n: ctx.n, spec });
        setTrained(t);
        jobCompleteJob(t);
      }
    } catch (e) {
      if (e instanceof CancelledError) { setCancelled(true); setTuneProgress(null); jobClearJob(); return; }
      const msg = e instanceof Error ? e.message : '알 수 없는 오류';
      // 만료/부재(404) → 되살릴 게 없으니 조용히 초기화. 그 외(진짜 실패)만 재시도 배너.
      if (msg.includes('404')) { setTuneProgress(null); jobClearJob(); return; }
      setServerError({ message: msg });
      jobClearJob();
    } finally {
      abortRef.current = null;
    }
  }

  // 페이지 복귀 복원 — 마운트 시 전역 store 에 보존된 job 이 있으면 재폴링/결과복원(명세 준비 후 1회).
  //   ⚠ 데이터셋이 바뀌었으면 옛 결과를 박지 않고 정리(맥락 불일치 방지).
  useEffect(() => {
    if (restoredRef.current) return;
    if (!d) return; // 데이터 준비 후
    if (specs === null && !specsError) return; // 명세 준비(성공/실패) 후 — paramSpec 정확도 위해
    restoredRef.current = true;
    const js = useTrainingJobStore.getState();
    if (!js.ctx) return; // 보존된 학습 없음
    if (js.ctx.datasetKey !== datasetKey) { jobClearJob(); return; } // 데이터셋 바뀜 → 폐기
    const c = js.ctx;
    // 화면을 학습 맥락으로 되돌린다(결과 라벨·입력이 복원 결과와 일치하도록).
    setTask(c.task);
    if (c.task === 'reg') setAlgo(c.algo as RegAlgo);
    else setClsAlgo(c.algo as ClsAlgo);
    setTarget(c.target);
    setFeatures(c.features);
    setTestRatio(c.testRatio);
    setTune(c.tune);
    setScale(c.scale ?? true);
    setSequentialSplit(c.sequentialSplit);
    setTimeCol(c.timeCol ?? '');
    setParams(c.params ?? {});
    if (js.result) { setTrained(js.result); return; } // 완료 결과 → 네트워크 없이 즉시 복원
    if (js.jobId) {
      // 진행 중 → 진행률 즉시 표시 + 재폴링(runBusy 로 busy=true → fieldset 잠금 재적용).
      if (js.progress) setTuneProgress(js.progress);
      const jid = js.jobId;
      void runBusy(() => resumeFlow(jid, c));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [d, specs, specsError, datasetKey]);

  // 활성 판정 — 백엔드 명세가 있으면 사용 가능(학습은 항상 백엔드).
  //   명세 로딩 실패(백엔드 미연결) 시에만 비활성 → 아래 modelDisabledReason 으로 원인을 안내한다.
  const modelAvailable = (t: 'reg' | 'cls', a: string): boolean => !!getSpec(specs, t, a);
  // 백엔드 연결 여부 — 모든 학습이 백엔드에서 돌아가므로, 명세 로드 성공(=백엔드 응답) 시에만 학습 가능.
  //   linear/rf/logistic 은 명세가 없거나 있어도 항상 켜져 있던 과거(브라우저 학습) 잔재라, 이 플래그로 함께 가드한다.
  const backendReady = specs !== null && !specsError;
  const knnAvailable = modelAvailable('reg', 'knn');
  const clsKnnAvailable = modelAvailable('cls', 'knn');
  const svrAvailable = modelAvailable('reg', 'svr');
  const svcAvailable = modelAvailable('cls', 'svc');
  const ridgeAvailable = modelAvailable('reg', 'ridge');
  const lassoAvailable = modelAvailable('reg', 'lasso');
  const elasticnetAvailable = modelAvailable('reg', 'elasticnet'); // ElasticNet 회귀(server 전용). 회귀 전용 모델이라 분류 플래그 없음.
  const dtreeAvailable = modelAvailable('cls', 'dtree');
  const xgboostRegAvailable = modelAvailable('reg', 'xgboost'); // XGBoost 회귀(server 전용)
  const xgboostClsAvailable = modelAvailable('cls', 'xgboost'); // XGBoost 분류(server 전용)
  const lightgbmRegAvailable = modelAvailable('reg', 'lightgbm'); // LightGBM 회귀(server 전용)
  const lightgbmClsAvailable = modelAvailable('cls', 'lightgbm'); // LightGBM 분류(server 전용)
  const catboostRegAvailable = modelAvailable('reg', 'catboost'); // CatBoost 회귀(server 전용)
  const catboostClsAvailable = modelAvailable('cls', 'catboost'); // CatBoost 분류(server 전용)
  const mlpRegAvailable = modelAvailable('reg', 'mlp'); // MLP 회귀(server 전용)
  const mlpClsAvailable = modelAvailable('cls', 'mlp'); // MLP 분류(server 전용)
  const lstmRegAvailable = modelAvailable('reg', 'lstm'); // LSTM 회귀(시계열, server 전용). 회귀 전용 → 분류 플래그 없음.
  const transformerRegAvailable = modelAvailable('reg', 'transformer'); // Transformer 회귀(시퀀스, server 전용). 회귀 전용.
  const modelDisabledReason = specsError
    ? '백엔드에 연결할 수 없습니다. 서버 상태를 확인해 주세요.'
    : specs === null
    ? '모델 목록을 불러오는 중…'
    : '';
  // 현재 선택 모델의 명세 → 하이퍼파라미터 패널·스케일링·params·배지 판단(knn/svr/svc 공통).
  const curSpec = task === 'reg' ? getSpec(specs, 'reg', algo) : getSpec(specs, 'cls', clsAlgo);
  const supportsScaling = !!curSpec?.supports_scaling;
  // 튜닝 패널·params 전송용 명세 — 학습이 항상 백엔드라 명세가 있으면 언제나 패널을 띄우고 params 를 보낸다.
  const panelSpec = curSpec;
  // 자동 튜닝(Optuna) 가능 모델 — rf·xgb(빠름, 60초) + gb·lightgbm·catboost·mlp·svr·svc(느림, 최대 3분). 그 외엔 토글 미노출.
  const curAlgo = task === 'reg' ? algo : clsAlgo;
  // LSTM은 시계열 전용(윈도우=연속 시점) — 시간 순서 기준 컬럼이 필수이고, 그 컬럼으로 정렬+순차분할해야 의미가 있다.
  const lstmSelected = task === 'reg' && algo === 'lstm';
  const transformerSelected = task === 'reg' && algo === 'transformer'; // Transformer(표 데이터) — 자동튜닝 대상(랜덤 서브샘플·일반 CV·근사값).
  // 시퀀스(시계열 전용) 모델 — 시간 순서 컬럼 필수·순차분할 강제. ★ LSTM 만(Transformer 는 표 데이터라 일반 모델처럼 동작).
  const seqModel: SeqModel | null = task === 'reg' && algo === 'lstm' ? { label: 'LSTM' } : null;
  const seqSelected = seqModel !== null;
  const tuneApprox = curAlgo === 'svr' || curAlgo === 'svc'; // 서브샘플 튜닝 → 근사 최적값(전체 데이터 튜닝인 rf~mlp와 구분)
  const tuneSlow = curAlgo === 'lightgbm' || curAlgo === 'catboost' || curAlgo === 'mlp' || tuneApprox;
  // 딥러닝 자동튜닝 — lstm·transformer 는 최대 5분(timeout 300초) + 서브샘플(3,000행) → 근사값. lstm=연속(순차 CV), transformer=랜덤(일반 CV).
  const tunable = curAlgo === 'rf' || curAlgo === 'xgboost' || tuneSlow || lstmSelected || transformerSelected;

  // 타깃 후보·기본 선택
  const columns = d?.columns ?? [];
  const numericNames = useMemo(() => columns.filter((c) => c.type === 'int' || c.type === 'float' || c.type === 'bool').map((c) => c.name), [columns]);

  // 값 종류가 적은(≤20) 수치형 컬럼 — CSV로 내보낸 0/1 범주가 수치형으로 추론돼도
  // 분류 목표로 쓸 수 있게 후보에 포함한다(모델은 라벨을 문자열로 처리).
  const lowCardNumeric = useMemo(() => {
    if (!d) return [] as string[];
    const out: string[] = [];
    for (const c of columns) {
      if (c.type !== 'int' && c.type !== 'float') continue;
      const seen = new Set<string>();
      for (const r of d.rows) {
        const v = r[c.name];
        if (v === null || v === undefined || v === '') continue;
        seen.add(String(v));
        if (seen.size > 20) break;
      }
      if (seen.size >= 2 && seen.size <= 20) out.push(c.name);
    }
    return out;
  }, [d, columns]);

  // 값 종류가 적은(2~20) 문자열 컬럼만 분류 목표 후보로 — date(특이형식)·ID·UUID 등 고유값 많은 문자열이
  //   목표로 뽑혀 클래스가 수만 개가 되면 혼동행렬(클래스²)·계수행렬이 폭발해 백엔드가 OOM 으로 죽는다.
  //   lowCardNumeric 과 동일 패턴(Set + 조기 종료). 35k 행에서도 상한 초과 시 즉시 break 라 빠르다.
  const lowCardString = useMemo(() => {
    if (!d) return [] as string[];
    const out: string[] = [];
    for (const c of columns) {
      if (c.type !== 'string') continue;
      const seen = new Set<string>();
      for (const r of d.rows) {
        const v = r[c.name];
        if (v === null || v === undefined || v === '') continue;
        seen.add(String(v));
        if (seen.size > 20) break;
      }
      if (seen.size >= 2 && seen.size <= 20) out.push(c.name);
    }
    return out;
  }, [d, columns]);
  // 고유값이 많아 분류 목표 후보에서 제외된 컬럼 수(안내용).
  //   문자열: 고유값 20 초과로 제외된 수. datetime: 타입상 항상 목표에서 빠지고 본질적으로 고유값이 많으므로 함께 센다.
  //   ⚠ 문자열만 세면, 날짜 인식(DATE_RE) 범위에 따라 같은 날짜가 string↔datetime 으로 달리 잡혀 안내 문구가 들쭉날쭉해진다.
  const excludedStringCols = useMemo(
    () =>
      columns.filter((c) => c.type === 'string').length -
      lowCardString.length +
      columns.filter((c) => c.type === 'datetime').length,
    [columns, lowCardString],
  );

  // 타깃 후보: 회귀 → 수치형만 / 분류 → bool(항상) + 고유값 적은 문자열·수치형(클래스 폭주 방지)
  const targetOptions =
    task === 'reg'
      ? columns.filter((c) => c.type === 'int' || c.type === 'float').map((c) => c.name)
      : [...columns.filter((c) => c.type === 'bool').map((c) => c.name), ...lowCardString, ...lowCardNumeric];
  const curTarget = targetOptions.includes(target) ? target : targetOptions[0] ?? '';
  const featurePool = numericNames.filter((n) => n !== curTarget);
  const curFeatures = features === null ? featurePool : features.filter((f) => featurePool.includes(f));
  // 시간 추정 대상(딥러닝) — 학습 전 예상 시간 표시·한도 초과 차단. LSTM·Transformer 공통(표 데이터 transformer 도 대용량·다피처면 무거움).
  //   ⚠ LSTM 은 기존과 동일(같은 추정함수·한도·팁 → 같은 추정·메시지). Transformer 는 표 데이터라 피처수(curFeatures.length)로 추정.
  const estModel: { estimate: (rows: number) => { seconds: number; overLimit: boolean; tooShort: boolean }; limit: number; overLimitTip: string } | null =
    task !== 'reg'
      ? null
      : algo === 'lstm'
      ? { estimate: (rows) => estimateLstmSeconds(rows, testRatio, panelSpec ? params : undefined), limit: LSTM_TIME_LIMIT_SEC, overLimitTip: 'window·은닉 크기·층수' }
      : algo === 'transformer'
      ? { estimate: (rows) => estimateTransformerSeconds(rows, testRatio, panelSpec ? params : undefined, curFeatures.length), limit: TRANSFORMER_TIME_LIMIT_SEC, overLimitTip: '모델 차원(d_model)·층수' }
      : null;

  // 시간 컬럼 후보 — datetime(형식이 명확한 것) + 숫자(int/float). 숫자 포함 이유: 회차·배치번호 같은 순번도 시간축.
  //   타깃 제외. ⚠ datetime 이라도 형식이 애매(dateFormat==='unknown', 예: 05/06/2018)면 후보에서 뺀다 → 조용한 오정렬 차단.
  const timeColCandidates = columns.filter(
    (c) => (c.type === 'datetime' || c.type === 'int' || c.type === 'float') && c.name !== curTarget,
  );
  const timeColOptions = timeColCandidates.filter((c) => c.type !== 'datetime' || c.dateFormat !== 'unknown').map((c) => c.name);
  // 형식이 애매해서 제외된 날짜 컬럼이 있는지(안내 문구용).
  const hasAmbiguousDate = timeColCandidates.some((c) => c.type === 'datetime' && c.dateFormat === 'unknown');
  const timeColMeta = columns.find((c) => c.name === timeCol);
  const timeColType = timeColMeta?.type;
  const timeColFormat = timeColMeta?.dateFormat; // datetime 정렬 시 parseDateValue 에 넘길 형식
  const curTimeCol = timeColOptions.includes(timeCol) ? timeCol : ''; // 후보에서 사라졌으면(타깃 전환·애매) 정렬 안 함으로 폴백

  if (!d) return null;

  const ALGO_LABEL: Record<string, string> = { linear: '선형회귀', rf: '랜덤 포레스트', knn: 'KNN 회귀', svr: 'SVM 회귀 (SVR)', ridge: 'Ridge 회귀', lasso: 'Lasso 회귀', elasticnet: 'ElasticNet', xgboost: 'XGBoost', lightgbm: 'LightGBM', catboost: 'CatBoost', mlp: 'MLP (신경망)', lstm: 'LSTM', transformer: 'Transformer' };

  function addToReport() {
    if (!d || !trained) return;
    const tlabel = d.columns.find((c) => c.name === curTarget)?.label ?? curTarget;
    const modelName = trained.isReg ? `${ALGO_LABEL[algo]} (회귀)` : `${CLS_ALGO_LABEL[clsAlgo]} (분류)`;
    addPredictionReport({
      id: `${Date.now()}-${Math.round(Math.random() * 1e6)}`,
      label: `${tlabel} · ${modelName}`,
      dataset: d,
      task: trained.isReg ? 'reg' : 'cls',
      target: curTarget,
      features: trained.features,
      algo: trained.isReg ? algo : undefined,
      // 리포트에도 사용한 설정(usedParams)·표준화 여부(scaled)를 함께 저장(reg/cls 에 병합).
      reg: trained.reg ? { ...trained.reg, usedParams: trained.usedParams, scaled: trained.scaled } : undefined,
      cls: trained.cls ? { ...trained.cls, usedParams: trained.usedParams, scaled: trained.scaled } : undefined,
    });
    setAddedToReport(true);
  }

  async function train() {
    if (!d) return;
    setError('');
    setTimeNote('');
    setServerError(null);
    setTrained(null);
    setCancelled(false);
    setTuneProgress(null); // 새 학습 시작 → 이전 진행률 초기화
    jobClearJob(); // 이전 비동기 job/결과 잔재 제거(아래에서 새 jobId 확보 시 다시 세팅)
    abortRef.current = new AbortController(); // 이번 학습의 취소 컨트롤러
    setSelectedReportId(null); // 새 학습 시 저장 리포트 다시보기 모드를 벗어난다
    setAddedToReport(false);
    const isReg = task === 'reg';
    const numFeatures = curFeatures;
    if (!numFeatures.length) {
      setError('수치형 입력 변수를 1개 이상 선택하세요. (범주형은 전처리 > 인코딩에서 변환하세요)');
      return;
    }
    // 시퀀스 모델 오용 가드 — 시계열 전용이라 시간 순서 기준 컬럼이 없으면 윈도우가 파일/셔플 순서로 만들어져 무의미하다. 학습 차단.
    if (seqModel && !curTimeCol) {
      setError(`${seqModel.label}은 시계열(시간 순서) 데이터 전용입니다. 아래 "시간 순서 기준 컬럼"에서 시간축 컬럼을 지정해야 학습할 수 있어요. (순서 없는 데이터에는 부적합합니다.)`);
      return;
    }
    // 시계열: sequentialSplit(또는 LSTM) + 시간 컬럼 선택 시, 그 컬럼 기준으로 행을 시간순 정렬한 사본을 학습에 쓴다.
    //   LSTM 은 시계열 전용이라 항상 시간순 정렬 + 순차 분할로 보낸다(seqSend). datetime → parseDateValue, 숫자 → toNum.
    //   조건 미충족이면 d.rows 원본 순서 그대로 → 기존 동작과 동일(랜덤 분할 경로 무영향).
    //   JS sort 는 안정 정렬(ES2019) → 같은 시간 값끼리는 원래 파일 순서가 유지된다.
    const seqSend = sequentialSplit || seqSelected; // LSTM(시퀀스)은 순차 분할 강제(윈도우 순서 보존). 그 외(transformer 포함)는 사용자 선택. 학습 로직은 불변.
    let sourceRows = d.rows;
    let timeDropped = 0;
    if (seqSend && curTimeCol) {
      const keyOf = (r: (typeof d.rows)[number]): number | null => {
        const v = r[curTimeCol];
        if (isMissing(v)) return null;
        // datetime 은 컬럼 형식(timeColFormat)대로 파싱(DD/MM 오해석·UTC 밀림 방지), 숫자는 toNum.
        const k = timeColType === 'datetime' ? parseDateValue(String(v), timeColFormat ?? 'ISO') : toNum(v);
        return k === null || Number.isNaN(k) ? null : k;
      };
      const withKey = d.rows.map((r) => ({ r, k: keyOf(r) }));
      timeDropped = withKey.filter((x) => x.k === null).length;
      sourceRows = withKey
        .filter((x): x is { r: (typeof d.rows)[number]; k: number } => x.k !== null)
        .sort((a, b) => a.k - b.k)
        .map((x) => x.r);
    }
    setTimeNote(timeDropped > 0 ? `시간 컬럼 값이 없거나 해석되지 않아 ${timeDropped}개 행을 제외하고 정렬했어요.` : '');
    // 데이터 구성
    const X: number[][] = [];
    const yNum: number[] = [];
    const yStr: string[] = [];
    const xTimeLabels: string[] = []; // X 와 동일 순서·개수의 시간 컬럼 원본 표시값(시간축 그래프 x축 라벨용)
    for (const r of sourceRows) {
      const tv = r[curTarget];
      if (isMissing(tv)) continue;
      const xv = numFeatures.map((f) => toNum(r[f]));
      if (xv.some((v) => v === null)) continue;
      if (isReg) {
        const yv = toNum(tv);
        if (yv === null) continue;
        yNum.push(yv);
      } else {
        yStr.push(String(tv));
      }
      X.push(xv as number[]);
      if (curTimeCol) xTimeLabels.push(String(r[curTimeCol] ?? ''));
    }
    if (X.length < 10) {
      // 왜 학습 행이 적은지 진단해서 사용자에게 원인+해결법을 안내
      const total = d.rows.length;
      let targetMissing = 0;
      let targetPresent = 0;
      const featMiss = numFeatures.map(() => 0);
      for (const r of d.rows) {
        if (isMissing(r[curTarget])) { targetMissing++; continue; }
        targetPresent++;
        numFeatures.forEach((f, j) => { if (toNum(r[f]) === null) featMiss[j] += 1; });
      }
      const denom = Math.max(targetPresent, 1);
      const offenders = numFeatures
        .map((f, j) => ({ f, miss: featMiss[j] }))
        .filter((o) => o.miss > 0)
        .sort((a, b) => b.miss - a.miss)
        .slice(0, 3)
        .map((o) => `${labels[o.f] ?? o.f}(결측 ${Math.round((o.miss / denom) * 100)}%)`);

      let msg = `학습에 사용할 수 있는 행이 ${X.length}개뿐입니다(최소 10개 필요). `;
      if (targetMissing > total * 0.5) {
        msg += `목표 변수 '${labels[curTarget] ?? curTarget}'의 결측이 ${Math.round((targetMissing / Math.max(total, 1)) * 100)}%로 많습니다. 전처리 > 결측치 처리로 채우거나 다른 목표 변수를 선택하세요.`;
      } else if (offenders.length) {
        msg += `결측이 많은 입력 변수 때문일 수 있습니다: ${offenders.join(', ')}. 이 변수를 입력에서 제외하거나, 전처리 > 결측치 처리(중앙값/최빈값)로 채운 뒤 다시 시도하세요.`;
      } else {
        msg += '원본 데이터의 유효 행 자체가 적습니다.';
      }
      setError(msg);
      return;
    }
    const means = numFeatures.map((_, j) => X.reduce((s, r) => s + r[j], 0) / X.length);

    // ⚠ 시퀀스 모델 자원 방어(프론트 1차): 학습 시작 전 예상 시간을 추정해 한도 초과면 차단(백엔드도 400 이중 방어).
    //   실제 학습 행수(X.length)로 계산. 시퀀스 모델(LSTM·Transformer) 외엔 안 걸림.
    if (isReg && estModel) {
      const est = estModel.estimate(X.length);
      if (est.overLimit) {
        setError(
          `예상 학습 시간이 약 ${Math.round(est.seconds)}초로 한도(${estModel.limit}초)를 넘어요. ` +
            `${estModel.overLimitTip}를 낮추거나 데이터를 줄여 주세요.`,
        );
        return;
      }
    }

    // 학습 맥락 — 비동기 job 시작 시 store 에 보관(페이지 이동 후 복원용). means·행수 등 결과 재구성에 필요한 값 포함.
    const timeColUsed = seqSend && curTimeCol ? curTimeCol : undefined;
    // 시간축 그래프 x축 라벨 — 시간순 분할이면 테스트셋 = 정렬된 X 의 뒤 n_test 개(백엔드 train_test_split_sequential 과 동일 규칙).
    //   그 구간의 시간 컬럼 원본값을 넘겨 x축을 순번 대신 실제 날짜/시간으로 표시한다(회귀 + 시간 컬럼 지정 시).
    const timeAxisLabels =
      isReg && timeColUsed && xTimeLabels.length === X.length
        ? xTimeLabels.slice(X.length - Math.max(1, Math.round(X.length * testRatio)))
        : undefined;
    const jobCtx: TrainingJobCtx = {
      datasetKey,
      task,
      algo: isReg ? algo : clsAlgo,
      target: curTarget,
      features: numFeatures,
      means,
      n: X.length,
      testRatio,
      tune: tunable && tune,
      scale: supportsScaling ? scale : undefined,
      sequentialSplit: seqSend,
      timeCol: timeColUsed,
      params: panelSpec ? params : undefined,
    };
    // onJobId 는 비동기(tune) 경로에서만 불린다 → 그때만 store 에 진행 중 job 을 기록(동기 학습은 복원 대상 아님).
    let asyncJobId: string | null = null;
    const onJobId = (jobId: string) => { asyncJobId = jobId; jobStartJob(jobId, jobCtx); };
    const onProg = (done: number, total: number, best: number | null) => {
      setTuneProgress({ done, total, best });
      if (asyncJobId) jobSetProgress({ done, total, best }); // 진행률도 store 에(복귀 즉시 표시)
    };

    try {
      if (isReg) {
        // 회귀: 컴퓨트 어댑터에 위임(항상 백엔드 학습).
        const norm = await runRegression({
          X,
          y: yNum,
          algo,
          target: curTarget,
          features: numFeatures,
          testRatio,
          params: panelSpec ? params : undefined, // 수동 하이퍼파라미터(명세 있는 모델)
          scale: supportsScaling ? scale : undefined, // 표준화(지원 모델만; 미지원은 서버가 무시)
          sequentialSplit: seqSend, // 시간순 분할(시계열). LSTM(회귀)은 강제 true(윈도우 순서 보존), 그 외는 사용자 선택(기본 false).
          tune: tunable && tune, // 자동 튜닝(rf·xgb 만; 그 외는 서버가 무시)
          onProgress: onProg, // 비동기 튜닝 진행률(+ store 갱신)
          onJobId, // jobId 통지 → 전역 보존(복원용)
          signal: abortRef.current?.signal, // 취소 신호(폴링·요청 중단)
        });
        const t = buildTrainedReg(norm, { algo, features: numFeatures, means, n: X.length, timeCol: timeColUsed, timeLabels: timeAxisLabels, spec: panelSpec });
        setTrained(t);
        if (asyncJobId) jobCompleteJob(t); // 비동기 결과만 보존(완료 결과 복원용). ctx 는 유지.
      } else {
        // 분류: 컴퓨트 어댑터에 위임(항상 백엔드 학습).
        const norm = await runClassification({
          X,
          y: yStr,
          algo: clsAlgo,
          target: curTarget,
          features: numFeatures,
          testRatio,
          params: panelSpec ? params : undefined, // 수동 하이퍼파라미터(명세 있는 모델)
          scale: supportsScaling ? scale : undefined, // 표준화(지원 모델만; 미지원은 서버가 무시)
          sequentialSplit: seqSend, // 시간순 분할(시계열). LSTM(회귀)은 강제 true(윈도우 순서 보존), 그 외는 사용자 선택(기본 false).
          tune: tunable && tune, // 자동 튜닝(rf·xgb 만; 그 외는 서버가 무시)
          onProgress: onProg, // 비동기 튜닝 진행률(+ store 갱신)
          onJobId, // jobId 통지 → 전역 보존(복원용)
          signal: abortRef.current?.signal, // 취소 신호(폴링·요청 중단)
        });
        const t = buildTrainedCls(norm, { algo: clsAlgo, features: numFeatures, means, n: X.length, spec: panelSpec });
        setTrained(t);
        if (asyncJobId) jobCompleteJob(t); // 비동기 결과만 보존(완료 결과 복원용). ctx 는 유지.
      }
    } catch (e) {
      // 사용자 취소: 오류가 아니라 정상 중단 → 서버 오류 배너 대신 취소 안내만 띄우고 결과는 그대로 비운다.
      if (e instanceof CancelledError) {
        setCancelled(true);
        setTuneProgress(null);
        jobClearJob(); // 취소 → 진행 상태 정리(다음 학습에 잔재 없게)
        return;
      }
      const msg = e instanceof Error ? e.message : '알 수 없는 오류';
      // 학습은 항상 백엔드 → 실패는 곧 서버/네트워크 문제. 재시도 배너로 안내한다(브라우저 폴백 없음).
      setServerError({ message: msg });
      jobClearJob(); // 실패 → 진행 상태 정리
    } finally {
      abortRef.current = null; // 이번 학습 종료(성공·실패·취소) → 컨트롤러 해제
    }
  }

  // 학습 취소: 진행 중 폴링·요청을 중단시킨다(abort → CancelledError 로 train() catch 도달).
  //   비동기 튜닝이면 pollTrainingJob 이 이때 백엔드에도 협조적 취소(POST /train/cancel)를 요청해 서버 잡도 멈춘다.
  //   (진행 중이던 trial 1개는 완주 후 멈춤 — Optuna study.stop 특성. 결과는 어느 쪽이든 반영 안 함.)
  function cancelTraining() {
    abortRef.current?.abort();
  }

  const labels = Object.fromEntries(columns.map((c) => [c.name, c.label]));

  // 다시보기(U3): 선택된 리포트. 삭제 등으로 사라졌으면 자동으로 없음 처리(=현재 화면).
  const selectedReport = selectedReportId ? predictionReports.find((p) => p.id === selectedReportId) ?? null : null;

  return (
    <>
      <PageHeader title="예측 분석" subtitle="회귀·분류 모델을 학습하고 새 값으로 예측해 보세요." />

      {/* 1) 타깃·피처·모델 */}
      <Card title="1) 타깃 · 피처 · 모델 설정">
        {/* 학습(busy) 중에는 fieldset 으로 모든 입력을 한 번에 잠근다(개별 disabled 대신 누락 없이 차단).
            학습·취소 버튼은 fieldset 밖(아래 footer)에 두어 잠겨도 눌리게 한다. min-w-0: flex/grid 부모에서 오버플로 방지. */}
        <fieldset disabled={busy} className="min-w-0 space-y-4">
          <div>
            <span className="mb-1 block text-xs font-medium text-text-muted">문제 유형</span>
            <SegmentedControl
              value={task}
              onChange={(v) => {
                const nt = v as 'reg' | 'cls';
                setTask(nt);
                setTrained(null);
                // 문제 유형 전환 시, 새 유형의 현재 알고리즘 명세 기준으로 파라미터 초기화(명세 없으면 비움).
                setParams(defaultParams(nt === 'reg' ? getSpec(specs, 'reg', algo) : getSpec(specs, 'cls', clsAlgo)));
                setTune(false); // 태스크 전환 시 자동 튜닝 토글 리셋
                setScale(true); // 표준화 기본 켜짐으로 리셋
                setTimeCol(''); // 문제 유형 전환 시 시간 컬럼도 초기화(타깃 후보가 바뀌므로). algo 전환은 컬럼과 무관해 유지.
              }}
              options={[
                { value: 'reg', label: '회귀 (수치 예측)' },
                { value: 'cls', label: '분류 (범주 예측)' },
              ]}
            />
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1 block text-xs font-medium text-text-muted">목표(target) 변수</span>
              <select value={curTarget} onChange={(e) => { setTarget(e.target.value); setTrained(null); }} className={`${selectCls} w-full`}>
                {targetOptions.map((c) => (
                  <option key={c} value={c}>{labels[c] ?? c}</option>
                ))}
              </select>
              {task === 'cls' && excludedStringCols > 0 && (
                <span className="mt-1 block text-xs text-text-muted">고유값이 많은 컬럼(20개 초과, 예: 날짜·ID)은 분류 목표로 쓸 수 없어 제외했어요.</span>
              )}
            </label>
            {task === 'reg' ? (
              <label className="block">
                <span className="mb-1 block text-xs font-medium text-text-muted">알고리즘</span>
                <select
                  value={algo}
                  onChange={(e) => {
                    const next = e.target.value as RegAlgo;
                    setAlgo(next);
                    setTrained(null);
                    // 알고리즘 전환 시 파라미터 초기화: 명세 있으면 기본값, 없으면 비움(knn/svr 공통).
                    setParams(defaultParams(getSpec(specs, 'reg', next)));
                    setTune(false); // 알고리즘 변경 시 자동 튜닝 토글 리셋
                    setScale(true); // 표준화 기본 켜짐으로 리셋
                  }}
                  className={`${selectCls} w-full`}
                >
                  <option value="linear" disabled={!backendReady}>
                    선형회귀{!backendReady ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="rf" disabled={!backendReady}>
                    랜덤 포레스트{!backendReady ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="knn" disabled={!knnAvailable}>
                    KNN 회귀{!knnAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="svr" disabled={!svrAvailable}>
                    SVM 회귀 (SVR){!svrAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="ridge" disabled={!ridgeAvailable}>
                    Ridge 회귀{!ridgeAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="lasso" disabled={!lassoAvailable}>
                    Lasso 회귀{!lassoAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="elasticnet" disabled={!elasticnetAvailable}>
                    ElasticNet{!elasticnetAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="xgboost" disabled={!xgboostRegAvailable}>
                    XGBoost{!xgboostRegAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="lightgbm" disabled={!lightgbmRegAvailable}>
                    LightGBM{!lightgbmRegAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="catboost" disabled={!catboostRegAvailable}>
                    CatBoost{!catboostRegAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="mlp" disabled={!mlpRegAvailable}>
                    MLP (신경망){!mlpRegAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="lstm" disabled={!lstmRegAvailable}>
                    LSTM{!lstmRegAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="transformer" disabled={!transformerRegAvailable}>
                    Transformer{!transformerRegAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                </select>
                {(estModel || (tune && tunable)) && (() => {
                  // 예상 시간 표시 — 슬라이더·행수·토글에 반응(전체 행수 기준 근사).
                  // 자동최적화 ON: 모든 튜닝 모델에 예상 시간 표시.
                  if (tune && tunable) {
                    const tuneSec = tuneTimeoutSec(curAlgo);
                    // 추정 함수 있는 모델(lstm·transformer): 튜닝 timeout + 최종 학습(1 fit) 합산 표시.
                    if (estModel) {
                      const est = estModel.estimate(d.rows.length);
                      if (est.tooShort) return null;
                      return (
                        <span className="mt-1 block text-xs text-text-muted">
                          예상 시간: 약 {fmtDuration(tuneSec + est.seconds)} (자동 최적화 {fmtDuration(tuneSec)} + 학습 {fmtDuration(est.seconds)})
                        </span>
                      );
                    }
                    // 추정 함수 없는 모델(rf·xgb·gb·lightgbm·catboost·mlp·svr): 학습 시간 미상이라 합산하지 않고 튜닝 시간을 하한으로 표시.
                    //   '이상 (자동 최적화 + 학습)' 로 실제는 학습이 더해져 더 걸린다는 점을 오해 없이 전달.
                    return (
                      <span className="mt-1 block text-xs text-text-muted">
                        예상 시간: 약 {fmtDuration(tuneSec)} 이상 (자동 최적화 + 학습)
                      </span>
                    );
                  }
                  // 자동최적화 OFF: 추정 함수 있는 모델(lstm·transformer)만 1 fit 예상 시간(기존 그대로). 그 외는 표시 없음.
                  if (!estModel) return null;
                  const est = estModel.estimate(d.rows.length);
                  if (est.tooShort) return null;
                  return (
                    <span className={`mt-1 block text-xs ${est.overLimit ? 'text-danger' : 'text-text-muted'}`}>
                      예상 학습 시간: 약 {Math.round(est.seconds)}초
                      {est.overLimit && ` — 한도(${estModel.limit}초) 초과. ${estModel.overLimitTip}를 낮추거나 데이터를 줄이세요.`}
                    </span>
                  );
                })()}
                {modelDisabledReason && (
                  <span className="mt-1 block text-xs text-danger">{modelDisabledReason}</span>
                )}
              </label>
            ) : (
              <label className="block">
                <span className="mb-1 block text-xs font-medium text-text-muted">알고리즘</span>
                <select
                  value={clsAlgo}
                  onChange={(e) => {
                    const next = e.target.value as ClsAlgo;
                    setClsAlgo(next);
                    setTrained(null);
                    setParams(defaultParams(getSpec(specs, 'cls', next)));
                    setTune(false); // 알고리즘 변경 시 자동 튜닝 토글 리셋
                    setScale(true); // 표준화 기본 켜짐으로 리셋
                  }}
                  className={`${selectCls} w-full`}
                >
                  <option value="logistic" disabled={!backendReady}>
                    로지스틱 회귀{!backendReady ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="rf" disabled={!backendReady}>
                    랜덤 포레스트{!backendReady ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="knn" disabled={!clsKnnAvailable}>
                    KNN 분류{!clsKnnAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="svc" disabled={!svcAvailable}>
                    SVM 분류 (SVC){!svcAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="dtree" disabled={!dtreeAvailable}>
                    결정 트리{!dtreeAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="xgboost" disabled={!xgboostClsAvailable}>
                    XGBoost{!xgboostClsAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="lightgbm" disabled={!lightgbmClsAvailable}>
                    LightGBM{!lightgbmClsAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="catboost" disabled={!catboostClsAvailable}>
                    CatBoost{!catboostClsAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                  <option value="mlp" disabled={!mlpClsAvailable}>
                    MLP (신경망){!mlpClsAvailable ? ' (서버 모드 전용)' : ''}
                  </option>
                </select>
                {modelDisabledReason && (
                  <span className="mt-1 block text-xs text-danger">{modelDisabledReason}</span>
                )}
              </label>
            )}
          </div>

          <div>
            <div className="mb-1">
              <span className="text-xs font-medium text-text-muted">입력(feature) 변수 — 수치형만 (체크 선택)</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {featurePool.length === 0 && <p className="text-sm text-text-muted">사용 가능한 수치형 변수가 없습니다.</p>}
              {/* 전체 선택/해제 — 변수 칩과 같은 형태이되 중립(회색) 색으로 구분. 동작(토글)·라벨 로직은 기존 그대로.
                  체크 사각형: 전부 선택 ✓ / 일부 – (indeterminate) / 없음 빈칸. */}
              {featurePool.length > 0 && (
                <button
                  type="button"
                  onClick={() => setFeatures(curFeatures.length === featurePool.length ? [] : [...featurePool])}
                  className="flex items-center gap-2 rounded-btn border border-border bg-surface-muted px-3 py-1.5 text-sm font-medium text-text-muted transition-colors hover:bg-border"
                >
                  <span
                    className={`grid h-4 w-4 place-items-center rounded border text-[10px] ${
                      curFeatures.length === 0 ? 'border-border' : 'border-text-muted bg-text-muted text-surface'
                    }`}
                  >
                    {curFeatures.length === featurePool.length ? '✓' : curFeatures.length === 0 ? '' : '–'}
                  </span>
                  {curFeatures.length === featurePool.length ? '전체 해제' : '전체 선택'}
                </button>
              )}
              {featurePool.map((c) => {
                const on = curFeatures.includes(c);
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setFeatures(on ? curFeatures.filter((f) => f !== c) : [...curFeatures, c])}
                    className={`flex items-center gap-2 rounded-btn border px-3 py-1.5 text-sm transition-colors ${
                      on ? 'border-primary bg-primary-soft text-primary' : 'border-border bg-surface text-text hover:bg-surface-muted'
                    }`}
                  >
                    <span className={`grid h-4 w-4 place-items-center rounded border text-[10px] ${on ? 'border-primary bg-primary text-white' : 'border-border'}`}>
                      {on ? '✓' : ''}
                    </span>
                    {labels[c] ?? c}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 백엔드 명세가 있는 모델이면 명세 주도 하이퍼파라미터 패널을 렌더한다(위젯은 명세의 widget 값으로 자동 선택). */}
          {panelSpec && <HyperparamPanel spec={panelSpec} value={params} onChange={setParams} tunable={tunable} tune={tune} onTuneChange={setTune} tuneApprox={tuneApprox} tuneLstm={lstmSelected} tuneTransformer={transformerSelected} tuneMaxSec={tuneTimeoutSec(curAlgo)} />}
          {/* 테스트 비율 + 시간순 분할 + 입력 변수 표준화 — 넓으면 가로 3열(슬라이더 좌·시간순 분할·표준화), 좁으면 세로 스택.
              각 열이 체크박스+설명을 품어 높이가 다르므로 items-start 로 위쪽 정렬. 시간순 분할은 LSTM(!seqModel)에서 숨기고, 표준화는 supportsScaling 모델에서만 노출 — 빠진 열은 flex-1 이 자동으로 메운다. */}
          <div className="flex flex-col gap-2 sm:flex-row sm:items-start">
            <label className="block min-w-0 flex-1 sm:max-w-md">
              <span className="mb-1 block text-xs font-medium text-text-muted">테스트 비율: {Math.round(testRatio * 100)}%</span>
              <input type="range" min={0.1} max={0.5} step={0.05} value={testRatio} onChange={(e) => setTestRatio(Number(e.target.value))} className="w-full accent-primary" />
            </label>
            {!seqModel && (
              <div className="min-w-0 flex-1">
                <label className="flex cursor-pointer items-center gap-2">
                  <input type="checkbox" checked={sequentialSplit} onChange={(e) => setSequentialSplit(e.target.checked)} className="accent-primary" />
                  <span className="whitespace-nowrap text-sm text-text">시간순 분할 (시계열 데이터)</span>
                </label>
                <p className="mt-0.5 text-xs text-text-muted">데이터를 섞지 않고 앞쪽으로 학습, 뒤쪽으로 평가합니다. 시계열 데이터에서 켜세요. 아래에서 시간 컬럼을 고르면 그 기준으로 자동 정렬합니다.</p>
              </div>
            )}
            {supportsScaling && (
              <div className="min-w-0 flex-1">
                <label className="flex cursor-pointer items-center gap-2">
                  <input type="checkbox" checked={scale} onChange={(e) => setScale(e.target.checked)} className="accent-primary" />
                  <span className="whitespace-nowrap text-sm text-text">입력 변수 표준화</span>
                </label>
                {/* 모델별 안내(명세 scaling_help). 없으면 기본 문구 폴백. */}
                <p className="mt-0.5 text-xs text-text-muted">{curSpec?.scaling_help ?? 'KNN·SVM 같은 모델은 변수 크기를 맞추면 정확도가 올라가요. 보통 켜두는 걸 권장해요.'}</p>
              </div>
            )}
          </div>
          {busy && tunable && tune && tuneProgress && (
            <p className="text-sm text-ai">
              최적화 중: {tuneProgress.done}/{tuneProgress.total} trial
              {tuneProgress.best !== null ? ` · 현재 최고 ${Math.round(tuneProgress.best * 10000) / 10000}` : ''}
            </p>
          )}
          {(sequentialSplit || seqSelected) && (
            <label className={`block max-w-[30rem] ${seqSelected ? '' : 'ml-6'}`}>
              <span className="mb-1 block text-xs font-medium text-text-muted">{seqSelected ? '시간 순서 기준 컬럼 (필수)' : '시간 컬럼 (정렬 기준)'}</span>
              {timeColOptions.length === 0 ? (
                <span className="text-xs text-warning">
                  {seqSelected
                    ? `시간축으로 쓸 날짜·숫자 컬럼이 없어요. 순서 없는 데이터라면 ${seqModel?.label} 대신 다른 모델을 쓰세요.`
                    : '정렬 기준으로 쓸 날짜·숫자 컬럼이 없어요. 현재 순서 그대로 앞/뒤로 나눕니다.'}
                </span>
              ) : (
                <>
                  <select value={curTimeCol} onChange={(e) => setTimeCol(e.target.value)} className={`${selectCls} w-full`}>
                    <option value="">{seqSelected ? '컬럼을 선택하세요' : '정렬 안 함 (현재 순서)'}</option>
                    {timeColOptions.map((name) => (
                      <option key={name} value={name}>{labels[name] ?? name}</option>
                    ))}
                  </select>
                  <span className="mt-0.5 block text-xs text-text-muted">선택한 컬럼 기준으로 데이터를 정렬한 뒤 앞쪽으로 학습, 뒤쪽으로 평가합니다.</span>
                </>
              )}
              {seqSelected && !curTimeCol && timeColOptions.length > 0 && (
                <span className="mt-1 block text-xs text-warning">시간 순서 기준 컬럼을 지정하세요 (미지정 시 {seqModel?.label} 학습이 진행되지 않습니다).</span>
              )}
              {hasAmbiguousDate && (
                <span className="mt-1 block text-xs text-warning">
                  형식이 불분명한 날짜 컬럼이 있어 제외했어요(예: 05/06/2018은 5월 6일인지 6월 5일인지 알 수 없음). 데이터 개요에서 형식을 지정하면 사용할 수 있습니다.
                </span>
              )}
            </label>
          )}
          {timeNote && <p className="text-xs text-text-muted">{timeNote}</p>}
          {error && <p className="text-sm text-danger">{error}</p>}
          {serverError && (
            <div className="mt-1 rounded-btn border border-danger/30 bg-danger/5 p-3 text-sm">
              <p className="text-danger">서버 계산 실패: {serverError.message}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Button variant="secondary" onClick={() => runBusy(() => train())}>다시 시도</Button>
              </div>
              <p className="mt-1 text-xs text-text-muted">모델 학습은 백엔드에서 수행됩니다. 백엔드 상태를 확인한 뒤 다시 시도해 주세요.</p>
            </div>
          )}
        </fieldset>

        {/* 학습·취소 버튼 — fieldset 밖. 학습 중엔 입력이 잠기지만 '학습 취소'는 눌러야 하므로 여기에 둔다. 카드 안 오른쪽 아래 정렬(justify-end). */}
        <div className="mt-4 flex flex-wrap items-center justify-end gap-3">
          <Button loading={busy} disabled={!backendReady} onClick={() => runBusy(train)}>모델 학습</Button>
          {busy && (
            <Button variant="secondary" onClick={cancelTraining}>학습 취소</Button>
          )}
        </div>
        {cancelled && (
          <p className="mt-2 text-sm text-warning">
            학습이 취소되었습니다. 서버에도 중단을 요청했어요 — 자동 최적화는 진행 중이던 한 단계를 마치고 멈춥니다(결과는 반영되지 않습니다).
          </p>
        )}
      </Card>

      {/* 리포트에 담은 모델 — 항상 표시(U2). 클릭 시 다시보기 선택/해제 토글(U3). */}
      <ReportModelList
        selectedId={selectedReportId}
        onSelect={(id) => setSelectedReportId((cur) => (cur === id ? null : id))}
      />

      {selectedReport ? (
        <SavedReportView report={selectedReport} onBack={() => setSelectedReportId(null)} specs={specs} />
      ) : (
      <>
      {/* 2) 결과 */}
      {trained?.reg && <RegResultView reg={trained.reg} labels={labels} target={curTarget} usedParams={trained.usedParams} bestParams={trained.bestParams} paramSpec={trained.paramSpec} scaled={trained.scaled} timeCol={trained.timeCol} timeLabels={trained.timeLabels} />}
      {trained?.cls && <ClsResultView cls={trained.cls} d={d} target={curTarget} means={trained.means} labels={labels} probaFn={trained.probaFn} usedParams={trained.usedParams} bestParams={trained.bestParams} paramSpec={trained.paramSpec} scaled={trained.scaled} />}

      {/* 리포트에 추가 */}
      {trained && (
        <div className="mt-3 flex items-center justify-end gap-3">
          {addedToReport && <span className="text-sm text-success">✓ 결과 리포트에 추가됨</span>}
          <Button variant="secondary" onClick={addToReport} disabled={addedToReport}>＋ 결과 리포트에 추가</Button>
        </div>
      )}

      {/* 3) 새 값 예측 */}
      {trained && (
        <Card title="3) 새 값으로 예측해 보기" className="mt-5">
          <PredictForm features={trained.features} labels={labels} means={trained.means} isReg={trained.isReg} predict={trained.predict} targetLabel={labels[curTarget] ?? curTarget} />
        </Card>
      )}
      </>
      )}

      <NavFooter prevLabel="데이터 병합" nextLabel="결과 리포트" onNext={() => goto('report')} />
    </>
  );
}

/* ───────────────── 결과 뷰 ───────────────── */

// 표준화 적용 여부 배지(W2). scaled 가 boolean 일 때만 표시(미해당 모델은 undefined → 숨김).
function ScaledBadge({ scaled }: { scaled?: boolean }) {
  if (typeof scaled !== 'boolean') return null;
  return (
    <p className="mt-3 rounded-btn border border-ai/30 bg-ai/5 px-3 py-2 text-sm text-text">
      {scaled ? '입력 변수 표준화 적용됨 (StandardScaler)' : '입력 변수 표준화 미적용'}
    </p>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-card border border-border bg-surface p-4">
      <div className="text-xs text-text-muted">{label}</div>
      <div className="mt-1 text-2xl font-bold text-text">{value}</div>
    </div>
  );
}

function RegResultView({ reg, labels, target, usedParams, bestParams, paramSpec, scaled, timeCol, timeLabels }: { reg: RegResult; labels: Record<string, string>; target: string; usedParams?: ParamValues; bestParams?: ParamValues; paramSpec?: ModelSpec; scaled?: boolean; timeCol?: string; timeLabels?: string[] }) {
  const coefRows = reg.features
    .map((f, i) => ({ name: f, label: labels[f] ?? f, coef: Math.round(reg.coef[i] * 10000) / 10000 }))
    .sort((a, b) => Math.abs(b.coef) - Math.abs(a.coef));
  const usedSummary = formatUsedParams(paramSpec, usedParams);
  const tunedSummary = bestParams ? formatUsedParams(paramSpec, bestParams) : ''; // 자동 튜닝으로 찾은 값(투명성 표시)
  // 산점도 축 범위(실제·예측 공통) — x=y 대각선이 모서리까지 그려지도록 도메인 고정
  const seg = refSegment(reg.actualVsPred);
  const lo = seg[0].x;
  const hi = seg[1].x;
  // 시간축 그래프 데이터 — timeLabels 가 있으면 x축을 실제 날짜/시간으로, 없으면 순번으로 폴백.
  const hasTimeAxis = Array.isArray(timeLabels) && timeLabels.length > 0;
  const timeChartData = reg.actualVsPred.map((d, i) => ({
    idx: i + 1,
    label: hasTimeAxis ? timeLabels![i] ?? String(i + 1) : String(i + 1),
    actual: d.actual,
    pred: d.pred,
  }));
  // 라벨이 겹치지 않게 약 8개만 표시(interval = 건너뛸 개수).
  const timeTickInterval = Math.max(0, Math.ceil(timeChartData.length / 8) - 1);
  // 표 인라인 막대 길이 정규화용 — 계수 절댓값 최대
  const maxAbs = Math.max(1e-9, ...coefRows.map((c) => Math.abs(c.coef)));
  // 트리 앙상블(rf/gb)은 선형 계수가 없어 coef 자리에 변수 중요도(0~1, 양수)가 담긴다.
  const isTree = reg.algo === 'rf' || reg.algo === 'xgboost' || reg.algo === 'lightgbm' || reg.algo === 'catboost';
  // 계수(선형)·중요도(트리)가 실제로 있는지. KNN 은 둘 다 없어(coef=[]) 영향도 섹션 전체를 숨긴다.
  //  (coefRows 는 features 를 map 하므로 길이가 항상 >0 → 존재 판정은 reg.coef 로 해야 한다.)
  const hasInfluence = Array.isArray(reg.coef) && reg.coef.length > 0;
  return (
    <Card title={`2) 학습 결과 — 회귀 (${REG_ALGO_LABEL[reg.algo] ?? reg.algo})`} className="mt-5">
      <div className="grid grid-cols-3 gap-3">
        <Metric label="R² (설명력)" value={String(reg.r2)} />
        <Metric label="MAE (평균 절대 오차)" value={String(reg.mae)} />
        <Metric label="RMSE (평균 제곱근 오차)" value={String(reg.rmse)} />
      </div>
      {reg.sampled && (
        <p className="mt-3 rounded-btn bg-primary-soft px-3 py-2 text-sm text-primary">
          데이터가 많아 학습에는 전체 {reg.sampled.total.toLocaleString()}행 중 {reg.sampled.used.toLocaleString()}행을 무작위 표본으로 사용했어요. (성능·반응속도를 위한 처리이며, 평가는 별도 테스트 데이터로 진행됩니다)
        </p>
      )}
      {bestParams && tunedSummary ? (
        <p className="mt-3 rounded-btn border border-ai/30 bg-ai/5 px-3 py-2 text-sm text-text">
          자동 최적화(Optuna)로 찾은 설정: <span className="font-medium">{tunedSummary}</span>
        </p>
      ) : usedSummary ? (
        <p className="mt-3 rounded-btn border border-ai/30 bg-ai/5 px-3 py-2 text-sm text-text">
          사용한 설정: <span className="font-medium">{usedSummary}</span>
        </p>
      ) : null}
      {reg.algo === 'lstm' && timeCol && (
        <p className="mt-2 text-xs text-text-muted">시간 순서 기준: <span className="font-medium">{labels[timeCol] ?? timeCol}</span> (이 컬럼 순서로 시계열 윈도우를 만들었습니다)</p>
      )}
      <ScaledBadge scaled={scaled} />

      <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-2">
        <div>
          <h4 className="mb-2 text-sm font-semibold text-text">실제값 vs 예측값</h4>
          <ResponsiveContainer width="100%" height={300}>
            <ScatterChart margin={{ top: 10, right: 24, bottom: 28, left: 16 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis
                type="number"
                dataKey="actual"
                name="실제값"
                domain={[lo, hi]}
                tick={{ fontSize: 11, fill: 'var(--text-muted)' }}
                label={{ value: '실제값', position: 'insideBottom', offset: -14, fill: 'var(--text-muted)', fontSize: 12 }}
              />
              <YAxis
                type="number"
                dataKey="pred"
                name="예측값"
                domain={[lo, hi]}
                tick={{ fontSize: 11, fill: 'var(--text-muted)' }}
                label={{ value: '예측값', angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 12, style: { textAnchor: 'middle' } }}
              />
              <ZAxis range={[40, 40]} />
              <Tooltip contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, fontSize: 12 }} />
              {/* 이상선 x=y (예측=실제) */}
              <ReferenceLine
                segment={[{ x: lo, y: lo }, { x: hi, y: hi }]}
                stroke="var(--danger)"
                strokeWidth={1.5}
                strokeDasharray="5 5"
                ifOverflow="extendDomain"
              />
              <Scatter data={reg.actualVsPred} fill="var(--primary)" fillOpacity={0.5} />
            </ScatterChart>
          </ResponsiveContainer>
          <p className="mt-1 text-center text-xs text-text-muted">
            점이 <span className="text-danger">빨간 점선(예측=실제)</span> 에 가까울수록 예측이 정확해요.
          </p>
        </div>
        {hasInfluence && (
        <div>
          <h4 className="mb-2 text-sm font-semibold text-text">{isTree ? '변수 중요도' : '회귀계수 (영향도)'}</h4>
          {isTree ? (
            <>
              {/* 트리 앙상블: 변수 중요도 가로 막대그래프 */}
              <ResponsiveContainer width="100%" height={Math.max(180, coefRows.length * 34)}>
                <BarChart data={coefRows} layout="vertical" margin={{ top: 4, right: 16, bottom: 4, left: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                  <XAxis type="number" domain={[0, 'dataMax']} tickFormatter={(v) => `${Math.round(v * 100)}%`} tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
                  <YAxis type="category" dataKey="label" width={110} tick={{ fontSize: 11, fill: 'var(--text)' }} />
                  <Tooltip contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, fontSize: 12 }} formatter={(v: number) => [`${(v * 100).toFixed(1)}%`, '중요도']} />
                  <Bar dataKey="coef" fill="var(--primary)" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
              <p className="mt-1 text-xs text-text-muted">막대가 길수록 예측에 더 크게 기여한 변수입니다 (분산 감소 기준, 전체 합 = 100%).</p>
            </>
          ) : (
            <>
              <div>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border text-left text-text-muted">
                      <th className="py-2 pr-3 font-medium">변수</th>
                      <th className="py-2 pr-3 font-medium">영향도</th>
                      <th className="py-2 text-right font-medium">계수</th>
                    </tr>
                  </thead>
                  <tbody>
                    {coefRows.map((c) => (
                      <tr key={c.name} className="border-b border-border/50">
                        <td className="whitespace-nowrap py-2 pr-3 text-text">{c.label}</td>
                        <td className="w-1/2 py-2 pr-3">
                          <div className="relative h-3 w-full rounded bg-surface-muted">
                            {/* 0 기준선(가운데) */}
                            <div className="absolute left-1/2 top-0 h-3 w-px bg-border" />
                            <div
                              className="absolute top-0 h-3 rounded"
                              style={
                                c.coef >= 0
                                  ? { left: '50%', width: `${(c.coef / maxAbs) * 50}%`, background: 'var(--primary)' }
                                  : { right: '50%', width: `${(Math.abs(c.coef) / maxAbs) * 50}%`, background: 'var(--danger)' }
                              }
                            />
                          </div>
                        </td>
                        <td className="py-2 text-right tabular-nums text-text">{c.coef}</td>
                      </tr>
                    ))}
                    <tr>
                      <td className="py-2 pr-3 text-text-muted">(절편)</td>
                      <td className="py-2 pr-3" />
                      <td className="py-2 text-right tabular-nums text-text-muted">{Math.round(reg.intercept * 10000) / 10000}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="mt-1 text-xs text-text-muted">가운데 0 기준 · 오른쪽 파랑(+) / 왼쪽 빨강(−) · 막대가 길수록 영향 큼</p>
            </>
          )}
        </div>
        )}
      </div>

      {/* 시간축 예측 — 시간순 분할(sequentialSplit)일 때만. 테스트셋이 시간순이라 actualVsPred 순서 = 시간 순서.
          시간 컬럼을 지정했으면 x축에 실제 날짜/시간(timeLabels)을 표시하고, 없으면 순번으로 폴백. */}
      {reg.sequentialSplit && reg.actualVsPred.length > 0 && (
        <div className="mt-5">
          <h4 className="mb-2 text-sm font-semibold text-text">시간축 예측 (테스트 구간)</h4>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={timeChartData} margin={{ top: 10, right: 24, bottom: hasTimeAxis ? 48 : 28, left: 16 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              {hasTimeAxis ? (
                <XAxis
                  dataKey="label"
                  type="category"
                  interval={timeTickInterval}
                  angle={-30}
                  textAnchor="end"
                  height={64}
                  tick={{ fontSize: 10, fill: 'var(--text-muted)' }}
                  label={{ value: labels[timeCol ?? ''] ?? timeCol ?? '시간', position: 'insideBottom', offset: 0, fill: 'var(--text-muted)', fontSize: 12 }}
                />
              ) : (
                <XAxis
                  dataKey="idx"
                  type="number"
                  domain={[1, 'dataMax']}
                  tick={{ fontSize: 11, fill: 'var(--text-muted)' }}
                  label={{ value: '순번 (시간 흐름)', position: 'insideBottom', offset: -14, fill: 'var(--text-muted)', fontSize: 12 }}
                />
              )}
              <YAxis
                domain={[lo, hi]}
                tick={{ fontSize: 11, fill: 'var(--text-muted)' }}
                label={{ value: labels[target] ?? target, angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 12, style: { textAnchor: 'middle' } }}
              />
              <Tooltip contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, fontSize: 12 }} />
              {/* Legend 를 상단에 둔다 — 기본(bottom)이면 하단의 x축 라벨·캡션과 겹친다. */}
              <Legend verticalAlign="top" height={28} wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="actual" name="실제값" stroke="var(--primary)" strokeWidth={1.5} dot={false} />
              <Line type="monotone" dataKey="pred" name="예측값" stroke="var(--danger)" strokeWidth={1.5} strokeDasharray="5 5" dot={false} />
            </LineChart>
          </ResponsiveContainer>
          <p className="mt-1 text-center text-xs text-text-muted">
            테스트 구간을 시간순으로 표시합니다. x축은 {hasTimeAxis ? `${labels[timeCol ?? ''] ?? timeCol ?? '시간'} 값` : '순번'}이며, <span className="text-primary">실제선</span>과 <span className="text-danger">예측선</span>이 붙을수록 예측이 정확해요.
          </p>
        </div>
      )}

      {isTree && <DecisionTreeConcept algo={reg.algo} task="reg" tree={reg.vizTree} targetLabel={labels[target] ?? target} />}

      <div className="mt-4">
        <InsightCard>
          {hasInfluence && coefRows[0]
            ? `${coefRows[0].label}의 ${isTree ? '중요도' : '영향(계수 절댓값)'}가 가장 큽니다. 모델 설명력(R²)은 ${reg.r2} 입니다.`
            : reg.algo === 'knn'
            ? `KNN은 가까운 이웃을 기반으로 예측하며, 변수별 계수는 제공하지 않습니다. 모델 설명력(R²)은 ${reg.r2} 입니다.`
            : `모델 설명력(R²)은 ${reg.r2} 입니다.`}
        </InsightCard>
      </div>
    </Card>
  );
}

// 실제=예측 기준선(y=x) 구간 좌표
function refSegment(data: { actual: number; pred: number }[]) {
  if (!data.length) return [{ x: 0, y: 0 }, { x: 1, y: 1 }];
  let lo = Infinity;
  let hi = -Infinity;
  for (const p of data) {
    lo = Math.min(lo, p.actual, p.pred);
    hi = Math.max(hi, p.actual, p.pred);
  }
  return [{ x: lo, y: lo }, { x: hi, y: hi }];
}

function ClsResultView({ cls, d, target, means, labels, probaFn, usedParams, bestParams, paramSpec, scaled }: { cls: ClsResult; d: Dataset; target: string; means: number[]; labels: Record<string, string>; probaFn?: (X: number[][]) => number[][] | Promise<number[][]>; usedParams?: ParamValues; bestParams?: ParamValues; paramSpec?: ModelSpec; scaled?: boolean }) {
  const algoLabel = CLS_ALGO_LABEL[cls.algo ?? 'logistic'];
  // 트리 계열(변수 중요도·트리 시각화 있음): rf/gb + 결정 트리(dtree).
  const isTree = cls.algo === 'rf' || cls.algo === 'dtree' || cls.algo === 'xgboost' || cls.algo === 'lightgbm' || cls.algo === 'catboost';
  // 변수 영향도: 트리=중요도(양수), 이진 로지스틱=표준화 계수(부호). cls.coef가 있을 때만 표시(KNN 은 없어 자동 생략).
  const inflRows = (cls.coef ?? [])
    .map((c) => ({ name: c.name, label: labels[c.name] ?? c.name, value: Math.round(c.value * 10000) / 10000 }))
    .sort((a, b) => Math.abs(b.value) - Math.abs(a.value));
  const inflMax = Math.max(1e-9, ...inflRows.map((c) => Math.abs(c.value)));
  const usedSummary = formatUsedParams(paramSpec, usedParams);
  const tunedSummary = bestParams ? formatUsedParams(paramSpec, bestParams) : ''; // 자동 튜닝으로 찾은 값(투명성 표시)
  return (
    <Card title={`2) 학습 결과 — 분류 (${algoLabel})`} className="mt-5">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Metric label="정확도(Accuracy)" value={`${Math.round(cls.accuracy * 1000) / 10}%`} />
        <Metric label="클래스 수" value={String(cls.classes.length)} />
      </div>
      {cls.sampled && (
        <p className="mt-3 rounded-btn bg-primary-soft px-3 py-2 text-sm text-primary">
          데이터가 많아 학습에는 전체 {cls.sampled.total.toLocaleString()}행 중 {cls.sampled.used.toLocaleString()}행을 무작위 표본으로 사용했어요. (성능·반응속도를 위한 처리이며, 평가는 별도 테스트 데이터로 진행됩니다)
        </p>
      )}
      {bestParams && tunedSummary ? (
        <p className="mt-3 rounded-btn border border-ai/30 bg-ai/5 px-3 py-2 text-sm text-text">
          자동 최적화(Optuna)로 찾은 설정: <span className="font-medium">{tunedSummary}</span>
        </p>
      ) : usedSummary ? (
        <p className="mt-3 rounded-btn border border-ai/30 bg-ai/5 px-3 py-2 text-sm text-text">
          사용한 설정: <span className="font-medium">{usedSummary}</span>
        </p>
      ) : null}
      <ScaledBadge scaled={scaled} />

      <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-2">
        <div>
          <h4 className="mb-2 text-sm font-semibold text-text">혼동 행렬</h4>
          <div className="overflow-x-auto">
            <div className="inline-block">
            <table className="border-collapse text-sm">
              <thead>
                <tr>
                  <th className="p-2" />
                  <th className="p-2" />
                  <th colSpan={cls.classes.length} className="border-b-2 border-primary/40 p-2 text-center text-xs font-semibold text-primary">예측값 (Predicted)</th>
                </tr>
                <tr>
                  <th className="p-2" />
                  <th className="p-2" />
                  {cls.classes.map((c) => (
                    <th key={c} className="border border-border p-2 text-text-muted">{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {cls.confusion.map((row, i) => (
                  <tr key={i}>
                    {i === 0 && (
                      <th rowSpan={cls.classes.length} className="relative w-6 border-r-2 border-primary/40 p-0">
                        <span
                          className="absolute left-1/2 top-1/2 whitespace-nowrap text-xs font-semibold text-primary"
                          style={{ transform: 'translate(-50%, -50%) rotate(-90deg)' }}
                        >
                          실제값 (Actual)
                        </span>
                      </th>
                    )}
                    <th className="border border-border p-2 font-medium text-text-muted">{cls.classes[i]}</th>
                    {row.map((v, j) => (
                      <td
                        key={j}
                        className={`h-16 w-16 border border-border text-center text-base tabular-nums ${i === j ? 'font-bold text-success' : 'text-text'}`}
                        style={{ background: i === j ? 'rgba(22,163,74,0.15)' : 'var(--surface-muted)' }}
                      >
                        {v}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-1.5 text-center text-xs text-text-muted">대각선(초록)이 맞춘 개수</p>
            </div>
          </div>
        </div>
        <div>
          <h4 className="mb-2 text-sm font-semibold text-text">상세 리포트</h4>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-text-muted">
                <th className="py-2 pr-3 font-medium">클래스</th>
                <th className="py-2 pr-3 text-right font-medium">정밀도</th>
                <th className="py-2 pr-3 text-right font-medium">재현율</th>
                <th className="py-2 pr-3 text-right font-medium">F1</th>
                <th className="py-2 pr-3 text-right font-medium">AUC-ROC</th>
                <th className="py-2 text-right font-medium">표본 수</th>
              </tr>
            </thead>
            <tbody>
              {cls.report.map((r) => (
                <tr key={r.cls} className="border-b border-border/50">
                  <td className="py-2 pr-3 text-text">{r.cls}</td>
                  <td className="py-2 pr-3 text-right tabular-nums">{r.precision}</td>
                  <td className="py-2 pr-3 text-right tabular-nums">{r.recall}</td>
                  <td className="py-2 pr-3 text-right tabular-nums">{r.f1}</td>
                  <td className="py-2 pr-3 text-right tabular-nums">{r.auc ?? '—'}</td>
                  <td className="py-2 text-right tabular-nums text-text-muted">{r.support}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {inflRows.length > 0 && (
        <div className="mt-6 border-t border-border pt-5">
          <h4 className="mb-2 text-sm font-semibold text-text">{isTree ? '변수 중요도' : '영향 변수 (표준화 계수)'}</h4>
          {isTree ? (
            <>
              <ResponsiveContainer width="100%" height={Math.max(180, inflRows.length * 34)}>
                <BarChart data={inflRows} layout="vertical" margin={{ top: 4, right: 16, bottom: 4, left: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                  <XAxis type="number" domain={[0, 'dataMax']} tickFormatter={(v) => `${Math.round(v * 100)}%`} tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
                  <YAxis type="category" dataKey="label" width={110} tick={{ fontSize: 11, fill: 'var(--text)' }} />
                  <Tooltip contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, fontSize: 12 }} formatter={(v: number) => [`${(v * 100).toFixed(1)}%`, '중요도']} />
                  <Bar dataKey="value" fill="var(--primary)" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
              <p className="mt-1 text-xs text-text-muted">막대가 길수록 분류에 더 크게 기여한 변수입니다 (분산 감소 기준, 전체 합 = 100%).</p>
            </>
          ) : (
            <>
              <ul className="space-y-1">
                {inflRows.map((c) => (
                  <li key={c.name} className="flex items-center gap-2 text-sm">
                    <span className="w-28 flex-none truncate text-text">{c.label}</span>
                    <div className="relative h-3 flex-1 rounded bg-surface-muted">
                      <div className="absolute left-1/2 top-0 h-3 w-px bg-border" />
                      <div className="absolute top-0 h-3 rounded" style={c.value >= 0 ? { left: '50%', width: `${(c.value / inflMax) * 50}%`, background: 'var(--primary)' } : { right: '50%', width: `${(Math.abs(c.value) / inflMax) * 50}%`, background: 'var(--danger)' }} />
                    </div>
                    <span className="w-14 flex-none text-right tabular-nums text-text-muted">{c.value}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-1 text-xs text-text-muted">표준화 계수 기준 · <span className="text-primary">오른쪽 파랑(+)</span>이면 양성 확률↑, <span className="text-danger">왼쪽 빨강(−)</span>이면 양성 확률↓ · 막대가 길수록 영향 큼</p>
            </>
          )}
        </div>
      )}

      {cls.classes.length === 2 && (
        <ProbabilityCurveView cls={cls} d={d} target={target} means={means} labels={labels} probaFn={probaFn} />
      )}

      {isTree && <DecisionTreeConcept algo={cls.algo ?? 'rf'} task="cls" tree={cls.vizTree} targetLabel={labels[target] ?? target} maxDepth={usedParams?.max_depth} />}

      <div className="mt-4">
        <InsightCard>{`${algoLabel} 모델의 테스트 정확도는 약 ${Math.round(cls.accuracy * 100)}% 입니다.`}</InsightCard>
      </div>
    </Card>
  );
}

// 이진 분류 확률 시각화 — 선택 피처에 대한 양성 확률 곡선 + 실제값(0/1) 산점도.
// 곡선은 선택 피처만 변화시키고 나머지 피처는 평균으로 고정. 로지스틱=S자, 트리 앙상블=계단형.
function ProbabilityCurveView({ cls, d, target, means, labels, probaFn }: { cls: ClsResult; d: Dataset; target: string; means: number[]; labels: Record<string, string>; probaFn?: (X: number[][]) => number[][] | Promise<number[][]> }) {
  const [feat, setFeat] = useState(cls.features[0] ?? '');
  const j = cls.features.indexOf(feat);
  const posClass = cls.classes[cls.classes.length - 1]; // 정렬상 두 번째가 양성
  const negClass = cls.classes[0];
  const posIdx = cls.classes.length - 1;

  // 산점도(실제값)와 x축 범위는 동기 계산.
  const { points, lo, hi } = useMemo(() => {
    const pts: { x: number; y: number }[] = [];
    let xlo = Infinity;
    let xhi = -Infinity;
    for (const r of d.rows) {
      const xv = toNum(r[feat]);
      const tv = r[target];
      if (xv === null || isMissing(tv)) continue;
      if (pts.length < 600) pts.push({ x: xv, y: String(tv) === posClass ? 1 : 0 });
      xlo = Math.min(xlo, xv);
      xhi = Math.max(xhi, xv);
    }
    return { points: pts, lo: xlo, hi: xhi };
  }, [d, feat, target, posClass]);

  // 확률 곡선은 probaFn 경유(로컬=동기 / 서버=원격 비동기). 그리드 60점을 한 번에 조회.
  const [curve, setCurve] = useState<{ x: number; p: number }[]>([]);
  useEffect(() => {
    let cancelled = false;
    if (!probaFn || j < 0 || !Number.isFinite(lo) || hi <= lo) {
      setCurve([]);
      return;
    }
    const N = 60;
    const xs: number[] = [];
    const grid: number[][] = [];
    for (let i = 0; i <= N; i++) {
      const x = lo + ((hi - lo) * i) / N;
      const xVec = means.slice();
      xVec[j] = x;
      xs.push(x);
      grid.push(xVec);
    }
    Promise.resolve(probaFn(grid))
      .then((mat) => {
        if (cancelled) return;
        setCurve(xs.map((x, i) => ({ x, p: Math.round((mat[i]?.[posIdx] ?? 0) * 1000) / 1000 })));
      })
      .catch(() => {
        if (!cancelled) setCurve([]);
      });
    return () => {
      cancelled = true;
    };
  }, [j, lo, hi, means, posIdx, probaFn]);

  if (j < 0 || !probaFn) return null;
  const featLabel = labels[feat] ?? feat;

  return (
    <div className="mt-6 border-t border-border pt-5">
      <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
        <h4 className="text-sm font-semibold text-text">예측 확률 곡선 — 양성 확률 P({posClass})</h4>
        <label className="block">
          <span className="mb-1 block text-xs font-medium text-text-muted">기준 변수 (X축)</span>
          <select value={feat} onChange={(e) => setFeat(e.target.value)} className={selectCls}>
            {cls.features.map((f) => (
              <option key={f} value={f}>{labels[f] ?? f}</option>
            ))}
          </select>
        </label>
      </div>

      <ResponsiveContainer width="100%" height={320}>
        <ComposedChart margin={{ top: 10, right: 24, bottom: 28, left: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
          <XAxis
            type="number"
            dataKey="x"
            name={featLabel}
            domain={['dataMin', 'dataMax']}
            tick={{ fontSize: 11, fill: 'var(--text-muted)' }}
            label={{ value: featLabel, position: 'insideBottom', offset: -14, fill: 'var(--text-muted)', fontSize: 12 }}
          />
          <YAxis
            type="number"
            domain={[0, 1]}
            ticks={[0, 0.25, 0.5, 0.75, 1]}
            tick={{ fontSize: 11, fill: 'var(--text-muted)' }}
            label={{ value: `P(${posClass})`, angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 12, style: { textAnchor: 'middle' } }}
          />
          <ZAxis range={[36, 36]} />
          <Tooltip contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, fontSize: 12 }} />
          {/* 결정 경계 0.5 */}
          <ReferenceLine y={0.5} stroke="var(--danger)" strokeDasharray="5 5" strokeWidth={1.5} />
          {/* 실제값(0=음성, 1=양성) 산점도 */}
          <Scatter name="실제값" data={points} dataKey="y" fill="var(--primary)" fillOpacity={0.35} />
          {/* 예측 확률 곡선(로지스틱=S자, 트리 앙상블=계단형) */}
          <Line type="monotone" data={curve} dataKey="p" stroke="var(--ai)" strokeWidth={2.5} dot={false} name="양성 확률" isAnimationActive={false} />
        </ComposedChart>
      </ResponsiveContainer>
      <p className="mt-1 text-center text-xs text-text-muted">
        보라색 곡선 = {featLabel}에 따른 <span className="text-ai">P({posClass})</span> · <span className="text-danger">빨간 점선(0.5)</span> 위면 {posClass}, 아래면 {negClass}로 예측 · 점은 실제값(위=양성, 아래=음성) · 나머지 변수는 평균 고정
      </p>
    </div>
  );
}

// 리포트에 담은 모델 — 예측 페이지 상단의 항상 보이는 목록 Card(U2).
//   학습 여부와 무관하게 표시되며, 새로고침 후에도 유지된다(U1 영속화).
//   행 클릭 → 저장된 결과 다시보기 선택/해제(U3). 선택된 행은 하이라이트.
function ReportModelList({ selectedId, onSelect }: { selectedId: string | null; onSelect: (id: string) => void }) {
  const reports = useDatasetStore((s) => s.predictionReports);
  const remove = useDatasetStore((s) => s.removePredictionReport);
  const clear = useDatasetStore((s) => s.clearPredictionReports);
  return (
    <Card
      title={`리포트에 담은 모델 (${reports.length})`}
      className="mt-5"
      right={reports.length ? <Button variant="ghost" onClick={clear}>전체 비우기</Button> : undefined}
    >
      {reports.length === 0 ? (
        <p className="text-sm text-text-muted">
          아직 리포트에 담은 모델이 없습니다. 모델을 학습한 뒤 ‘＋ 결과 리포트에 추가’를 누르면 여기에 쌓여요.
        </p>
      ) : (
        <ul className="divide-y divide-border/60">
          {reports.map((p) => {
            const active = p.id === selectedId;
            return (
              <li key={p.id}>
                <div
                  role="button"
                  tabIndex={0}
                  onClick={() => onSelect(p.id)}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelect(p.id); } }}
                  className={`flex cursor-pointer items-center justify-between gap-3 rounded-btn px-2 py-2 transition-colors ${
                    active ? 'bg-primary-soft ring-1 ring-primary/40' : 'hover:bg-surface-muted'
                  }`}
                  title={active ? '클릭하면 다시보기를 닫습니다' : '클릭하면 저장된 결과를 다시 봅니다'}
                >
                  <span className={`text-sm ${active ? 'font-semibold text-primary' : 'text-text'}`}>{p.label}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-sm tabular-nums text-text-muted">
                      {p.task === 'reg' && p.reg ? `R² ${p.reg.r2}` : p.cls ? `정확도 ${Math.round(p.cls.accuracy * 100)}%` : ''}
                    </span>
                    <button
                      onClick={(e) => { e.stopPropagation(); remove(p.id); }}
                      className="flex-none text-text-muted transition-colors hover:text-danger"
                      title="삭제"
                      aria-label="삭제"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}

// 저장된 리포트 다시보기(U3) — 저장된 reg/cls 로 결과 뷰를 재렌더한다.
//   labels 는 저장된 dataset.columns 에서 파생. 미저장 항목(probaFn·predict·usedParams)은
//   뷰가 자동으로 숨기거나(배지·확률곡선) 아래 안내로 대체(새 값 예측). 저장 구조는 변경하지 않는다.
function SavedReportView({ report, onBack, specs }: { report: PredictionContext; onBack: () => void; specs: ModelSpec[] | null }) {
  const labels = Object.fromEntries(report.dataset.columns.map((c) => [c.name, c.label]));
  return (
    <>
      <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-card border border-primary/30 bg-primary-soft px-4 py-3">
        <span className="text-sm text-text">
          저장된 리포트 다시보기 · <span className="font-semibold">{report.label}</span>
        </span>
        <Button variant="secondary" onClick={onBack}>← 현재 분석으로 돌아가기</Button>
      </div>

      {/* 저장된 usedParams·scaled 를 결과 뷰로 전달 → "사용한 설정"·"표준화" 배지 표시(뷰는 무수정). */}
      {report.reg && <RegResultView reg={report.reg} labels={labels} target={report.target} usedParams={report.reg.usedParams} paramSpec={getSpec(specs, 'reg', report.algo ?? '')} scaled={report.reg.scaled} />}
      {report.cls && <ClsResultView cls={report.cls} d={report.dataset} target={report.target} means={EMPTY_MEANS} labels={labels} usedParams={report.cls.usedParams} paramSpec={getSpec(specs, 'cls', report.cls.algo ?? '')} scaled={report.cls.scaled} />}

      <Card title="새 값으로 예측해 보기" className="mt-5">
        <p className="text-sm text-text-muted">
          이 결과는 저장된 리포트예요. 새 값 예측은 모델을 다시 학습해야 가능합니다. (예측 분석에서 같은 설정으로 학습해 주세요.)
        </p>
      </Card>
    </>
  );
}
