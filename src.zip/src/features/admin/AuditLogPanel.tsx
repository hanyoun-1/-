import { useEffect, useMemo, useState } from 'react';
import { listAuditLogs, type AuditAction, type AuditLogOut, type OrganizationOut } from '../../lib/admin/adminApi';

const PAGE_SIZE = 30;

const ROLE_LABEL: Record<string, string> = { admin: '관리자', instructor: '담당자', member: '멤버' };
const ACTION_LABEL: Record<AuditAction, string> = {
  create_user: '발급',
  change_role: '역할 변경',
  deactivate: '비활성화',
  activate: '활성화',
  reset_password: '비번 재발급',
};

// 역할 변경 detail("member→instructor")을 한글로 매핑. 그 외는 원문 그대로.
function formatDetail(log: AuditLogOut): string {
  if (!log.detail) return '—';
  if (log.action === 'change_role' && log.detail.includes('→')) {
    const [a, b] = log.detail.split('→');
    return `${ROLE_LABEL[a] ?? a}→${ROLE_LABEL[b] ?? b}`;
  }
  return log.detail;
}

// 감사 로그 조회(조회 전용). 스코프(admin 전체 / 담당자 자기 기업)는 백엔드가 강제.
export default function AuditLogPanel({ orgs }: { orgs: OrganizationOut[] }) {
  const [logs, setLogs] = useState<AuditLogOut[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);

  const orgName = useMemo(() => new Map(orgs.map((o) => [o.id, o.name])), [orgs]);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(null);
    listAuditLogs({ limit: PAGE_SIZE, offset })
      .then((rows) => {
        if (alive) setLogs(rows);
      })
      .catch((e) => {
        if (alive) setError(e instanceof Error ? e.message : '감사 로그를 불러오지 못했습니다.');
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [offset]);

  const page = offset / PAGE_SIZE + 1;
  const hasNext = logs.length === PAGE_SIZE; // 가득 찼으면 다음 페이지가 있을 수 있음(heuristic)
  const orgLabel = (id: string | null) => (id ? orgName.get(id) ?? '—' : '—');

  return (
    <div className="rounded-card border border-border bg-surface p-6 shadow-card">
      <div className="mb-4">
        <h2 className="text-base font-semibold text-text">감사 로그</h2>
        <p className="mt-1 text-sm text-text-muted">계정 발급·역할 변경·비활성화·비번 재발급 등 관리 동작 기록(조회 전용).</p>
      </div>

      {loading ? (
        <p className="text-sm text-text-muted">불러오는 중…</p>
      ) : error ? (
        <p className="text-sm text-danger">{error}</p>
      ) : logs.length === 0 ? (
        <p className="text-sm text-text-muted">감사 로그가 없습니다.</p>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-border text-xs text-text-muted">
                  <th className="px-2 py-2 font-medium">시간</th>
                  <th className="px-2 py-2 font-medium">행위자</th>
                  <th className="px-2 py-2 font-medium">동작</th>
                  <th className="px-2 py-2 font-medium">대상</th>
                  <th className="px-2 py-2 font-medium">기업</th>
                  <th className="px-2 py-2 font-medium">상세</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((l) => (
                  <tr key={l.id} className="border-b border-border/60">
                    <td className="px-2 py-2 text-text-muted">{new Date(l.created_at).toLocaleString()}</td>
                    <td className="px-2 py-2 text-text">
                      {l.actor_email ?? '—'}
                      {l.actor_role && (
                        <span className="ml-1 text-xs text-text-muted">({ROLE_LABEL[l.actor_role] ?? l.actor_role})</span>
                      )}
                    </td>
                    <td className="px-2 py-2 text-text-muted">{ACTION_LABEL[l.action] ?? l.action}</td>
                    <td className="px-2 py-2 text-text-muted">{l.target_email ?? '—'}</td>
                    <td className="px-2 py-2 text-text-muted">{orgLabel(l.organization_id)}</td>
                    <td className="px-2 py-2 text-text-muted">{formatDetail(l)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 페이지네이션(limit/offset) — 이전/다음 */}
          {(offset > 0 || hasNext) && (
            <div className="mt-3 flex items-center justify-end gap-2 text-sm">
              <button
                type="button"
                disabled={offset <= 0}
                onClick={() => setOffset(Math.max(0, offset - PAGE_SIZE))}
                className="rounded-btn border border-border bg-surface px-3 py-1 text-text-muted transition-colors hover:bg-surface-muted hover:text-text disabled:opacity-40"
              >
                이전
              </button>
              <span className="text-text-muted">{page} 페이지</span>
              <button
                type="button"
                disabled={!hasNext}
                onClick={() => setOffset(offset + PAGE_SIZE)}
                className="rounded-btn border border-border bg-surface px-3 py-1 text-text-muted transition-colors hover:bg-surface-muted hover:text-text disabled:opacity-40"
              >
                다음
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
