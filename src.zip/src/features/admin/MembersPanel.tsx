import { Fragment, useEffect, useMemo, useState, type FormEvent } from 'react';
import Button from '../../components/Button';
import { useAuthStore } from '../../store/useAuthStore';
import {
  activateUser,
  createUser,
  deactivateUser,
  listUsers,
  resetUserPassword,
  updateUser,
  type GroupOut,
  type OrganizationOut,
  type UserOut,
  type UserRole,
  type UserUpdateInput,
} from '../../lib/admin/adminApi';

const inputCls =
  'w-full rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';
// 필터 바용 — w-full 없이(가로 배치), 폭은 각 컨트롤에서 지정.
const filterCls =
  'rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

const ROLE_LABEL: Record<UserRole, string> = { admin: '관리자', instructor: '담당자', member: '멤버' };
// 발급 가능한 역할 옵션(관리자만 전체 선택 가능).
const ADMIN_ROLE_OPTIONS: UserRole[] = ['member', 'instructor', 'admin'];

// 기업(orgs)·그룹(groups)은 상위(AdminPage)에서 공유로 받는다 → 다른 패널에서 만든
// 기업/그룹이 이 발급 폼 드롭다운에도 즉시 반영된다. 멤버 목록만 자체 로드.
export default function MembersPanel({ orgs, groups }: { orgs: OrganizationOut[]; groups: GroupOut[] }) {
  const myRole = useAuthStore((s) => s.user?.role);
  const myOrgId = useAuthStore((s) => s.user?.organization_id ?? null);
  const myId = useAuthStore((s) => s.user?.id ?? null);
  const isAdmin = myRole === 'admin';

  const [members, setMembers] = useState<UserOut[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 검색·필터·페이지 상태
  const PAGE_SIZE = 20;
  const [search, setSearch] = useState('');
  const [fRole, setFRole] = useState<'all' | UserRole>('all');
  const [fStatus, setFStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [fOrg, setFOrg] = useState('all');
  const [fGroup, setFGroup] = useState('all');
  const [page, setPage] = useState(1);

  // 발급 폼
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [role, setRole] = useState<UserRole>('member');
  const [orgId, setOrgId] = useState('');
  const [groupId, setGroupId] = useState('');
  const [creating, setCreating] = useState(false);
  const [createErr, setCreateErr] = useState<string | null>(null);
  const [issued, setIssued] = useState<{ email: string; tempPassword: string } | null>(null);
  const [copied, setCopied] = useState(false);

  // 행 관리 액션 상태
  const [confirm, setConfirm] = useState<{ id: string; action: 'deactivate' | 'reset' } | null>(null);
  const [rowBusy, setRowBusy] = useState<string | null>(null);
  const [rowErr, setRowErr] = useState<{ id: string; msg: string } | null>(null);

  // 행 인라인 편집 상태
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editGroupId, setEditGroupId] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('member');
  const [editBusy, setEditBusy] = useState(false);
  const [editErr, setEditErr] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const orgName = useMemo(() => new Map(orgs.map((o) => [o.id, o.name])), [orgs]);
  const groupName = useMemo(() => new Map(groups.map((g) => [g.id, g.name])), [groups]);

  // 담당자는 자기 기업으로 고정.
  const effectiveOrgId = isAdmin ? orgId : myOrgId ?? '';
  const groupOptions = useMemo(
    () => groups.filter((g) => g.organization_id === effectiveOrgId),
    [groups, effectiveOrgId],
  );

  const loadMembers = async () => {
    setMembers(await listUsers());
  };

  // 멤버 목록만 자체 로드(기업·그룹은 상위 공유 props).
  const loadMembersInit = async () => {
    setLoading(true);
    setError(null);
    try {
      setMembers(await listUsers());
    } catch (e) {
      setError(e instanceof Error ? e.message : '멤버 목록을 불러오지 못했습니다.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadMembersInit();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 기업이 바뀌면 그룹 선택 초기화(다른 기업 그룹이 남지 않도록).
  useEffect(() => {
    setGroupId('');
  }, [effectiveOrgId]);

  const onCreate = async (e: FormEvent) => {
    e.preventDefault();
    setCreateErr(null);
    setIssued(null);
    setCopied(false);
    const mail = email.trim();
    if (!mail) return;

    setCreating(true);
    try {
      const created = await createUser({
        email: mail,
        role: isAdmin ? role : 'member', // 담당자는 멤버 고정
        username: username.trim() || null,
        organization_id: effectiveOrgId || null,
        group_id: groupId || null,
      });
      if (created.temp_password) {
        setIssued({ email: created.email, tempPassword: created.temp_password });
      }
      // 폼 초기화(기업/역할은 유지 — 연속 발급 편의).
      setEmail('');
      setUsername('');
      setGroupId('');
      await loadMembers();
    } catch (e2) {
      setCreateErr(e2 instanceof Error ? e2.message : '멤버 발급에 실패했습니다.');
    } finally {
      setCreating(false);
    }
  };

  const copyTemp = async () => {
    if (!issued) return;
    try {
      await navigator.clipboard.writeText(issued.tempPassword);
      setCopied(true);
    } catch {
      /* 클립보드 미지원 — 사용자가 직접 복사 */
    }
  };

  const soleName = (id: string | null, map: Map<string, string>) => (id ? map.get(id) ?? '—' : '—');

  // 활성/비활성 토글(활성화는 안전 동작 → 확인 없이 즉시).
  const runToggleActive = async (m: UserOut, activate: boolean) => {
    setRowBusy(m.id);
    setRowErr(null);
    try {
      const updated = activate ? await activateUser(m.id) : await deactivateUser(m.id);
      setMembers((prev) => prev.map((x) => (x.id === updated.id ? updated : x)));
    } catch (e) {
      setRowErr({ id: m.id, msg: e instanceof Error ? e.message : '처리에 실패했습니다.' });
    } finally {
      setRowBusy(null);
      setConfirm(null);
    }
  };

  const runReset = async (m: UserOut) => {
    setRowBusy(m.id);
    setRowErr(null);
    try {
      const tempPassword = await resetUserPassword(m.id);
      setIssued({ email: m.email, tempPassword });
      setMembers((prev) => prev.map((x) => (x.id === m.id ? { ...x, must_change_password: true } : x)));
    } catch (e) {
      setRowErr({ id: m.id, msg: e instanceof Error ? e.message : '비번 재발급에 실패했습니다.' });
    } finally {
      setRowBusy(null);
      setConfirm(null);
    }
  };

  // 편집 시 선택 가능한 역할(편의 — 실제 강제는 백엔드). 관리자=전체, 담당자=멤버/담당자만.
  const roleOptions: UserRole[] = isAdmin ? ['member', 'instructor', 'admin'] : ['member', 'instructor'];

  const startEdit = (m: UserOut) => {
    setEditId(m.id);
    setEditName(m.username ?? '');
    setEditGroupId(m.group_id ?? '');
    setEditRole(m.role);
    setEditErr(null);
    setNotice(null);
  };
  const cancelEdit = () => {
    setEditId(null);
    setEditErr(null);
  };

  const saveEdit = async (m: UserOut) => {
    setEditErr(null);
    // 변경된 필드만 payload 로(PATCH 부분 수정).
    const payload: UserUpdateInput = {};
    const newName = editName.trim();
    if (newName !== (m.username ?? '')) payload.username = newName || null;
    if (editGroupId !== (m.group_id ?? '')) payload.group_id = editGroupId || null;
    const roleChanged = m.id !== myId && editRole !== m.role;
    if (roleChanged) payload.role = editRole;

    if (Object.keys(payload).length === 0) {
      cancelEdit();
      return;
    }
    setEditBusy(true);
    try {
      const updated = await updateUser(m.id, payload);
      setMembers((prev) => prev.map((x) => (x.id === updated.id ? updated : x)));
      setEditId(null);
      setNotice(roleChanged ? '역할이 변경되어 해당 멤버는 다시 로그인해야 합니다.' : null);
    } catch (e) {
      setEditErr(e instanceof Error ? e.message : '수정에 실패했습니다.');
    } finally {
      setEditBusy(false);
    }
  };

  // ── 검색·필터·페이지네이션(프론트 처리) ──────────────────
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return members.filter((m) => {
      if (q && !`${m.username ?? ''} ${m.email}`.toLowerCase().includes(q)) return false;
      if (fRole !== 'all' && m.role !== fRole) return false;
      if (fStatus === 'active' && !m.is_active) return false;
      if (fStatus === 'inactive' && m.is_active) return false;
      if (isAdmin && fOrg !== 'all' && m.organization_id !== fOrg) return false; // 기업 필터는 관리자만
      if (fGroup !== 'all' && m.group_id !== fGroup) return false;
      return true;
    });
  }, [members, search, fRole, fStatus, fOrg, fGroup, isAdmin]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageItems = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  // 필터·검색이 바뀌면 1페이지로 리셋.
  useEffect(() => {
    setPage(1);
  }, [search, fRole, fStatus, fOrg, fGroup]);
  // 기업 필터가 바뀌면 그룹 필터 초기화(다른 기업 그룹이 남지 않도록).
  useEffect(() => {
    setFGroup('all');
  }, [fOrg]);

  // 그룹 필터 옵션: 관리자가 특정 기업을 고르면 그 기업 그룹만.
  const groupFilterOptions = isAdmin && fOrg !== 'all' ? groups.filter((g) => g.organization_id === fOrg) : groups;

  const resetFilters = () => {
    setSearch('');
    setFRole('all');
    setFStatus('all');
    setFOrg('all');
    setFGroup('all');
  };

  return (
    <div className="rounded-card border border-border bg-surface p-6 shadow-card">
      <div className="mb-4">
        <h2 className="text-base font-semibold text-text">멤버</h2>
        <p className="mt-1 text-sm text-text-muted">
          {isAdmin ? '계정을 발급하고 관리합니다.' : '자기 기업의 멤버를 발급·조회합니다.'}
        </p>
      </div>

      {/* 발급 폼 */}
      <form onSubmit={onCreate} className="mb-4 space-y-3">
        {/* 1줄: 이메일 | 이름 */}
        <div className="flex flex-wrap gap-3">
          <div className="min-w-[14rem] flex-[2]">
            <span className="mb-1 block text-xs font-medium text-text-muted">이메일</span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={inputCls}
              placeholder="member@example.com"
            />
          </div>
          <div className="min-w-[10rem] flex-1">
            <span className="mb-1 block text-xs font-medium text-text-muted">이름(선택)</span>
            <input value={username} onChange={(e) => setUsername(e.target.value)} className={inputCls} placeholder="표시 이름" />
          </div>
        </div>

        {/* 2줄: 기업 | 역할 | 그룹 */}
        <div className="flex flex-wrap gap-3">
          <div className="min-w-[10rem] flex-1">
            <span className="mb-1 block text-xs font-medium text-text-muted">기업</span>
            {isAdmin ? (
              <select value={orgId} onChange={(e) => setOrgId(e.target.value)} className={inputCls}>
                <option value="">(선택 안 함)</option>
                {orgs.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.name}
                  </option>
                ))}
              </select>
            ) : (
              <input value={myOrgId ? orgName.get(myOrgId) ?? '내 기업' : '소속 기업 없음'} disabled className={`${inputCls} opacity-70`} />
            )}
          </div>
          <div className="min-w-[10rem] flex-1">
            <span className="mb-1 block text-xs font-medium text-text-muted">역할</span>
            {isAdmin ? (
              <select value={role} onChange={(e) => setRole(e.target.value as UserRole)} className={inputCls}>
                {ADMIN_ROLE_OPTIONS.map((r) => (
                  <option key={r} value={r}>
                    {ROLE_LABEL[r]}
                  </option>
                ))}
              </select>
            ) : (
              <input value="멤버" disabled className={`${inputCls} opacity-70`} />
            )}
          </div>
          <div className="min-w-[10rem] flex-1">
            <span className="mb-1 block text-xs font-medium text-text-muted">그룹(선택)</span>
            <select
              value={groupId}
              onChange={(e) => setGroupId(e.target.value)}
              className={inputCls}
              disabled={!effectiveOrgId}
            >
              <option value="">(선택 안 함)</option>
              {groupOptions.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {createErr && <p className="text-sm text-danger">{createErr}</p>}
        {!isAdmin && !myOrgId && (
          <p className="text-sm text-warning">소속 기업이 없어 멤버를 발급할 수 없습니다.</p>
        )}

        <div className="flex justify-end">
          <Button type="submit" loading={creating} disabled={!email.trim() || (!isAdmin && !myOrgId)}>
            멤버 발급
          </Button>
        </div>
      </form>

      {/* 임시 비밀번호 1회 표시 */}
      {issued && (
        <div className="mb-4 rounded-btn border border-primary/40 bg-primary-soft p-4">
          <p className="text-sm font-medium text-primary">‘{issued.email}’ 임시 비밀번호가 발급되었습니다.</p>
          <div className="mt-2 flex items-center gap-2">
            <code className="flex-1 truncate rounded-btn border border-border bg-surface px-3 py-2 font-mono text-sm text-text">
              {issued.tempPassword}
            </code>
            <Button variant="secondary" onClick={() => void copyTemp()}>
              {copied ? '복사됨' : '복사'}
            </Button>
          </div>
          <p className="mt-2 text-xs text-text-muted">
            이 임시 비밀번호는 지금만 확인할 수 있습니다. 멤버에게 전달하세요. (최초 로그인 시 변경이 필요합니다.)
          </p>
        </div>
      )}

      {/* 역할 변경 등 안내 */}
      {notice && (
        <div className="mb-3 flex items-center justify-between gap-2 rounded-btn bg-warning/10 px-3 py-2 text-sm text-warning">
          <span>ⓘ {notice}</span>
          <button type="button" onClick={() => setNotice(null)} className="text-xs text-text-muted hover:text-text">
            닫기
          </button>
        </div>
      )}

      {/* 멤버 목록 */}
      {loading ? (
        <p className="text-sm text-text-muted">불러오는 중…</p>
      ) : error ? (
        <p className="text-sm text-danger">{error}</p>
      ) : members.length === 0 ? (
        <p className="text-sm text-text-muted">발급된 멤버가 없습니다.</p>
      ) : (
        <>
          {/* 검색·필터 바 — 한 줄 가로 배치(좁으면 자동 줄바꿈) */}
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className={`${filterCls} w-56`}
              placeholder="이름·이메일 검색"
            />
            {isAdmin && (
              <select value={fOrg} onChange={(e) => setFOrg(e.target.value)} className={`${filterCls} w-36`}>
                <option value="all">기업 전체</option>
                {orgs.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.name}
                  </option>
                ))}
              </select>
            )}
            <select value={fGroup} onChange={(e) => setFGroup(e.target.value)} className={`${filterCls} w-36`}>
              <option value="all">그룹 전체</option>
              {groupFilterOptions.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>
            <select value={fRole} onChange={(e) => setFRole(e.target.value as 'all' | UserRole)} className={`${filterCls} w-28`}>
              <option value="all">역할 전체</option>
              <option value="admin">관리자</option>
              <option value="instructor">담당자</option>
              <option value="member">멤버</option>
            </select>
            <select value={fStatus} onChange={(e) => setFStatus(e.target.value as 'all' | 'active' | 'inactive')} className={`${filterCls} w-28`}>
              <option value="all">상태 전체</option>
              <option value="active">활성</option>
              <option value="inactive">비활성</option>
            </select>
            <button
              type="button"
              onClick={resetFilters}
              className="ml-auto rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text-muted transition-colors hover:bg-surface-muted hover:text-text"
            >
              필터 초기화
            </button>
          </div>

          <p className="mb-2 text-xs text-text-muted">
            전체 {members.length}명 중 {filtered.length}명
          </p>

          {filtered.length === 0 ? (
            <p className="text-sm text-text-muted">조건에 맞는 멤버가 없습니다.</p>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-border text-xs text-text-muted">
                <th className="px-2 py-2 font-medium">이메일</th>
                <th className="px-2 py-2 font-medium">역할</th>
                <th className="px-2 py-2 font-medium">이름</th>
                <th className="px-2 py-2 font-medium">기업</th>
                <th className="px-2 py-2 font-medium">그룹</th>
                <th className="px-2 py-2 font-medium">상태</th>
                <th className="px-2 py-2 font-medium">비번 변경</th>
                <th className="px-2 py-2 font-medium">관리</th>
              </tr>
            </thead>
            <tbody>
              {pageItems.map((m) => {
                const isSelf = m.id === myId;
                const busy = rowBusy === m.id;
                const pending = confirm?.id === m.id ? confirm.action : null;
                const editing = editId === m.id;
                const editGroupOptions = groups.filter((g) => g.organization_id === m.organization_id);
                return (
                  <Fragment key={m.id}>
                  <tr className={`border-b border-border/60 ${m.is_active ? '' : 'opacity-60'}`}>
                    <td className="px-2 py-2 text-text">{m.email}</td>
                    <td className="px-2 py-2 text-text-muted">{ROLE_LABEL[m.role]}</td>
                    <td className="px-2 py-2 text-text-muted">{m.username?.trim() ? m.username : '—'}</td>
                    <td className="px-2 py-2 text-text-muted">{soleName(m.organization_id, orgName)}</td>
                    <td className="px-2 py-2 text-text-muted">{soleName(m.group_id, groupName)}</td>
                    <td className="px-2 py-2">
                      <span className={m.is_active ? 'text-success' : 'text-text-muted'}>
                        {m.is_active ? '활성' : '비활성'}
                      </span>
                    </td>
                    <td className="px-2 py-2 text-text-muted">{m.must_change_password ? '필요' : '—'}</td>
                    <td className="px-2 py-2">
                      {pending ? (
                        // 인라인 확인(비활성화·비번 재발급)
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs text-warning">
                            {pending === 'deactivate' ? '비활성화할까요?' : '비번을 재발급할까요?'}
                          </span>
                          <button
                            type="button"
                            onClick={() => setConfirm(null)}
                            className="rounded-btn border border-border bg-surface px-2 py-1 text-xs text-text-muted hover:bg-surface-muted"
                          >
                            취소
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() =>
                              pending === 'deactivate' ? void runToggleActive(m, false) : void runReset(m)
                            }
                            className="rounded-btn bg-danger px-2 py-1 text-xs text-white hover:opacity-90 disabled:opacity-40"
                          >
                            {pending === 'deactivate' ? '비활성화' : '재발급'}
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-wrap items-center gap-2">
                          {m.is_active ? (
                            <button
                              type="button"
                              disabled={isSelf || busy}
                              title={isSelf ? '자기 계정은 비활성화할 수 없습니다' : undefined}
                              onClick={() => setConfirm({ id: m.id, action: 'deactivate' })}
                              className="rounded-btn border border-border bg-surface px-2 py-1 text-xs text-text-muted transition-colors hover:bg-surface-muted hover:text-danger disabled:cursor-not-allowed disabled:opacity-40"
                            >
                              비활성화
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => void runToggleActive(m, true)}
                              className="rounded-btn border border-border bg-surface px-2 py-1 text-xs text-success transition-colors hover:bg-surface-muted disabled:opacity-40"
                            >
                              활성화
                            </button>
                          )}
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => setConfirm({ id: m.id, action: 'reset' })}
                            className="rounded-btn border border-border bg-surface px-2 py-1 text-xs text-text-muted transition-colors hover:bg-surface-muted hover:text-text disabled:opacity-40"
                          >
                            비번 재발급
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => (editId === m.id ? cancelEdit() : startEdit(m))}
                            className={`rounded-btn border px-2 py-1 text-xs transition-colors disabled:opacity-40 ${
                              editId === m.id
                                ? 'border-primary bg-primary-soft text-primary'
                                : 'border-border bg-surface text-text-muted hover:bg-surface-muted hover:text-text'
                            }`}
                          >
                            수정
                          </button>
                        </div>
                      )}
                      {rowErr?.id === m.id && <p className="mt-1 text-xs text-danger">{rowErr.msg}</p>}
                    </td>
                  </tr>

                  {editing && (
                    <tr className="border-b border-border/60 bg-surface-muted/40">
                      <td colSpan={8} className="px-3 py-3">
                        <div className="flex flex-wrap items-end gap-3">
                          <div>
                            <span className="mb-1 block text-xs font-medium text-text-muted">이름</span>
                            <input
                              value={editName}
                              onChange={(e) => setEditName(e.target.value)}
                              className={`${inputCls} w-40`}
                              placeholder="이름(비우면 해제)"
                            />
                          </div>
                          <div>
                            <span className="mb-1 block text-xs font-medium text-text-muted">그룹</span>
                            <select
                              value={editGroupId}
                              onChange={(e) => setEditGroupId(e.target.value)}
                              className={`${inputCls} w-40`}
                            >
                              <option value="">그룹 없음</option>
                              {editGroupOptions.map((g) => (
                                <option key={g.id} value={g.id}>
                                  {g.name}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <span className="mb-1 block text-xs font-medium text-text-muted">역할</span>
                            <select
                              value={editRole}
                              onChange={(e) => setEditRole(e.target.value as UserRole)}
                              disabled={isSelf}
                              title={isSelf ? '자기 계정의 역할은 변경할 수 없습니다' : undefined}
                              className={`${inputCls} w-32 disabled:opacity-60`}
                            >
                              {roleOptions.map((r) => (
                                <option key={r} value={r}>
                                  {ROLE_LABEL[r]}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button variant="secondary" onClick={cancelEdit}>
                              취소
                            </Button>
                            <Button loading={editBusy} onClick={() => void saveEdit(m)}>
                              저장
                            </Button>
                          </div>
                          <span className="text-xs text-text-muted">역할 변경 시 재로그인 필요</span>
                        </div>
                        {editErr && <p className="mt-2 text-sm text-danger">{editErr}</p>}
                      </td>
                    </tr>
                  )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
              </div>

              {/* 페이지네이션 — 여러 페이지일 때만 */}
              {totalPages > 1 && (
                <div className="mt-3 flex items-center justify-end gap-2 text-sm">
                  <button
                    type="button"
                    disabled={safePage <= 1}
                    onClick={() => setPage(safePage - 1)}
                    className="rounded-btn border border-border bg-surface px-3 py-1 text-text-muted transition-colors hover:bg-surface-muted hover:text-text disabled:opacity-40"
                  >
                    이전
                  </button>
                  <span className="text-text-muted">
                    {safePage} / {totalPages}
                  </span>
                  <button
                    type="button"
                    disabled={safePage >= totalPages}
                    onClick={() => setPage(safePage + 1)}
                    className="rounded-btn border border-border bg-surface px-3 py-1 text-text-muted transition-colors hover:bg-surface-muted hover:text-text disabled:opacity-40"
                  >
                    다음
                  </button>
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}
