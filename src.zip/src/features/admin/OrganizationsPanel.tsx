import { useState, type FormEvent } from 'react';
import Button from '../../components/Button';
import { createOrganization, type OrganizationOut } from '../../lib/admin/adminApi';

const inputCls =
  'w-full rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

// 기업 관리 — 목록 + (관리자만) 추가. 목록/로딩/에러는 상위(AdminPage)에서 공유로 받는다
// (멤버 폼과 동일한 기업 데이터를 쓰고, 새 기업 추가 시 두 화면 동시 반영).
export default function OrganizationsPanel({
  role,
  orgs,
  loading,
  error,
  selectedId,
  onSelect,
  onCreated,
}: {
  role: string | undefined;
  orgs: OrganizationOut[];
  loading: boolean;
  error: string | null;
  selectedId: string | null;
  onSelect: (org: OrganizationOut) => void;
  onCreated: (org: OrganizationOut) => void;
}) {
  const isAdmin = role === 'admin';
  const [name, setName] = useState('');
  const [creating, setCreating] = useState(false);
  const [createErr, setCreateErr] = useState<string | null>(null);

  const onCreate = async (e: FormEvent) => {
    e.preventDefault();
    setCreateErr(null);
    const trimmed = name.trim();
    if (!trimmed) return;
    setCreating(true);
    try {
      const org = await createOrganization(trimmed);
      setName('');
      onCreated(org); // 상위 공유 목록 갱신 + 선택
    } catch (e2) {
      setCreateErr(e2 instanceof Error ? e2.message : '기업 추가에 실패했습니다.');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="rounded-card border border-border bg-surface p-6 shadow-card">
      <div className="mb-4">
        <h2 className="text-base font-semibold text-text">기업</h2>
        <p className="mt-1 text-sm text-text-muted">
          {isAdmin ? '기업을 등록하고 선택하세요.' : '소속 기업입니다.'}
        </p>
      </div>

      {isAdmin && (
        <form onSubmit={onCreate} className="mb-4 flex items-start gap-2">
          <div className="flex-1">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className={inputCls}
              placeholder="기업 이름"
            />
            {createErr && <p className="mt-1 text-sm text-danger">{createErr}</p>}
          </div>
          <Button type="submit" loading={creating} disabled={!name.trim()}>
            기업 추가
          </Button>
        </form>
      )}

      {loading ? (
        <p className="text-sm text-text-muted">불러오는 중…</p>
      ) : error ? (
        <p className="text-sm text-danger">{error}</p>
      ) : orgs.length === 0 ? (
        <p className="text-sm text-text-muted">등록된 기업이 없습니다.</p>
      ) : (
        <ul className="divide-y divide-border">
          {orgs.map((o) => (
            <li key={o.id}>
              <button
                type="button"
                onClick={() => onSelect(o)}
                className={`flex w-full items-center justify-between gap-3 px-2 py-2.5 text-left text-sm transition-colors ${
                  selectedId === o.id ? 'bg-primary-soft text-primary' : 'text-text hover:bg-surface-muted'
                }`}
              >
                <span className="truncate font-medium">{o.name}</span>
                <span className="flex-none text-xs text-text-muted">
                  {new Date(o.created_at).toLocaleDateString()}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
