import { useEffect, useState, type FormEvent } from 'react';
import Button from '../../components/Button';
import { createGroup, type GroupOut, type OrganizationOut } from '../../lib/admin/adminApi';

const inputCls =
  'w-full rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text focus:border-primary focus:outline-none';

// 그룹 관리 — 선택한 기업의 그룹 목록 + 추가(관리자·담당자). 담당자는 자기 기업만(백엔드 강제).
// 목록/로딩/에러는 상위(AdminPage)에서 공유로 받는다(전체 groups). 표시는 선택 기업으로 필터.
// 생성 시 onCreated 로 상위 공유 목록을 갱신 → MembersPanel 발급 폼에도 즉시 반영.
export default function GroupsPanel({
  org,
  groups,
  loading,
  error,
  onCreated,
}: {
  org: OrganizationOut | null;
  groups: GroupOut[];
  loading: boolean;
  error: string | null;
  onCreated: (group: GroupOut) => void;
}) {
  const [name, setName] = useState('');
  const [creating, setCreating] = useState(false);
  const [createErr, setCreateErr] = useState<string | null>(null);

  // 선택 기업이 바뀌면 입력/에러 초기화.
  useEffect(() => {
    setName('');
    setCreateErr(null);
  }, [org?.id]);

  const shown = org ? groups.filter((g) => g.organization_id === org.id) : [];

  const onCreate = async (e: FormEvent) => {
    e.preventDefault();
    if (!org) return;
    setCreateErr(null);
    const trimmed = name.trim();
    if (!trimmed) return;
    setCreating(true);
    try {
      const g = await createGroup(org.id, trimmed);
      setName('');
      onCreated(g); // 상위 공유 목록 갱신(GroupsPanel·MembersPanel 동시 반영)
    } catch (e2) {
      setCreateErr(e2 instanceof Error ? e2.message : '그룹 추가에 실패했습니다.');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="rounded-card border border-border bg-surface p-6 shadow-card">
      <div className="mb-4">
        <h2 className="text-base font-semibold text-text">그룹</h2>
        <p className="mt-1 text-sm text-text-muted">
          {org ? `‘${org.name}’ 기업의 그룹` : '왼쪽에서 기업을 선택하세요.'}
        </p>
      </div>

      {!org ? (
        <p className="text-sm text-text-muted">기업을 선택하면 그룹을 관리할 수 있습니다.</p>
      ) : (
        <>
          <form onSubmit={onCreate} className="mb-4 flex items-start gap-2">
            <div className="flex-1">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={inputCls}
                placeholder="그룹 이름"
              />
              {createErr && <p className="mt-1 text-sm text-danger">{createErr}</p>}
            </div>
            <Button type="submit" loading={creating} disabled={!name.trim()}>
              그룹 추가
            </Button>
          </form>

          {loading ? (
            <p className="text-sm text-text-muted">불러오는 중…</p>
          ) : error ? (
            <p className="text-sm text-danger">{error}</p>
          ) : shown.length === 0 ? (
            <p className="text-sm text-text-muted">이 기업에 등록된 그룹이 없습니다.</p>
          ) : (
            <ul className="divide-y divide-border">
              {shown.map((g) => (
                <li key={g.id} className="flex items-center justify-between gap-3 px-2 py-2.5 text-sm">
                  <span className="truncate font-medium text-text">{g.name}</span>
                  <span className="flex-none text-xs text-text-muted">
                    {new Date(g.created_at).toLocaleDateString()}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </>
      )}
    </div>
  );
}
