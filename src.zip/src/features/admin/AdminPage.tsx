import { useEffect, useState } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { useAdminStore } from '../../store/useAdminStore';
import OrganizationsPanel from './OrganizationsPanel';
import GroupsPanel from './GroupsPanel';
import MembersPanel from './MembersPanel';
import AuditLogPanel from './AuditLogPanel';
import { listGroups, listOrganizations, type GroupOut, type OrganizationOut } from '../../lib/admin/adminApi';

// 역할 표시 라벨(내부 값은 영어 유지).
const ROLE_LABEL: Record<string, string> = { admin: '관리자', instructor: '담당자', member: '멤버' };

// 관리 화면 — 기업/그룹/멤버 관리. 분석 흐름과 분리된 별도 뷰.
// 기업 목록(orgs)을 여기서 한 번 로드해 OrganizationsPanel·MembersPanel 이 공유한다
// (멤버 폼 드롭다운이 기업 패널과 동일 데이터를 쓰고, 새 기업 추가가 즉시 반영되도록).
export default function AdminPage() {
  const role = useAuthStore((s) => s.user?.role);
  const closeAdmin = useAdminStore((s) => s.closeAdmin);

  const [tab, setTab] = useState<'manage' | 'audit'>('manage');

  const [orgs, setOrgs] = useState<OrganizationOut[]>([]);
  const [orgsLoading, setOrgsLoading] = useState(true);
  const [orgsError, setOrgsError] = useState<string | null>(null);
  const [selectedOrg, setSelectedOrg] = useState<OrganizationOut | null>(null);

  // 그룹도 기업과 동일하게 공유 state 로 소유 → GroupsPanel 에서 만든 그룹이
  // MembersPanel 발급 폼 드롭다운에 즉시 반영된다. listGroups()(전체)는 스코프 반영(admin 전체 / instructor 자기 기업).
  const [groups, setGroups] = useState<GroupOut[]>([]);
  const [groupsLoading, setGroupsLoading] = useState(true);
  const [groupsError, setGroupsError] = useState<string | null>(null);

  const loadOrgs = async () => {
    setOrgsLoading(true);
    setOrgsError(null);
    try {
      const list = await listOrganizations();
      setOrgs(list);
      // 선택이 없으면 첫 기업 자동 선택(그룹 패널 편의).
      setSelectedOrg((cur) => cur ?? list[0] ?? null);
    } catch (e) {
      setOrgsError(e instanceof Error ? e.message : '기업 목록을 불러오지 못했습니다.');
    } finally {
      setOrgsLoading(false);
    }
  };

  const loadGroups = async () => {
    setGroupsLoading(true);
    setGroupsError(null);
    try {
      setGroups(await listGroups());
    } catch (e) {
      setGroupsError(e instanceof Error ? e.message : '그룹 목록을 불러오지 못했습니다.');
    } finally {
      setGroupsLoading(false);
    }
  };

  useEffect(() => {
    void loadOrgs();
    void loadGroups();
  }, []);

  const handleOrgCreated = (org: OrganizationOut) => {
    setOrgs((prev) => [...prev, org]);
    setSelectedOrg(org);
  };

  const handleGroupCreated = (group: GroupOut) => {
    setGroups((prev) => [...prev, group]);
  };

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-text">관리</h1>
          <p className="mt-1 text-sm text-text-muted">
            기업과 그룹을 관리합니다{role ? ` · ${ROLE_LABEL[role] ?? role}` : ''}
          </p>
        </div>
        <button
          type="button"
          onClick={closeAdmin}
          className="flex-none rounded-btn border border-border bg-surface px-3 py-2 text-sm text-text-muted transition-colors hover:bg-surface-muted hover:text-text"
        >
          ← 분석 화면으로
        </button>
      </div>

      {/* 탭: 관리 / 감사 로그 */}
      <div className="mb-5 inline-flex flex-wrap gap-1 rounded-btn border border-border bg-surface-muted p-1">
        {(['manage', 'audit'] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={`rounded-chip px-4 py-1.5 text-sm font-medium transition-all ${
              tab === t ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text'
            }`}
          >
            {t === 'manage' ? '관리' : '감사 로그'}
          </button>
        ))}
      </div>

      {tab === 'manage' ? (
        <>
          <div className="grid gap-5 md:grid-cols-2">
            <OrganizationsPanel
              role={role}
              orgs={orgs}
              loading={orgsLoading}
              error={orgsError}
              selectedId={selectedOrg?.id ?? null}
              onSelect={setSelectedOrg}
              onCreated={handleOrgCreated}
            />
            <GroupsPanel
              org={selectedOrg}
              groups={groups}
              loading={groupsLoading}
              error={groupsError}
              onCreated={handleGroupCreated}
            />
          </div>

          <div className="mt-5">
            <MembersPanel orgs={orgs} groups={groups} />
          </div>
        </>
      ) : (
        <AuditLogPanel orgs={orgs} />
      )}
    </div>
  );
}
