import { useRef, useState } from 'react';
import PageHeader from '../../components/PageHeader';
import Button from '../../components/Button';
import { useDatasetStore } from '../../store/useDatasetStore';
import { useStepStore } from '../../store/useStepStore';
import { parseFile } from '../../lib/parseFile';

export default function UploadPage() {
  const { loadRows, loadSample } = useDatasetStore();
  const goto = useStepStore((s) => s.goto);
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  // 가짜 %(setInterval) 대신 실제 처리 단계를 표시한다. 파싱·분석은 동기라 진짜 진행률을
  // 못 그리므로 정직하게 단계 라벨 + 불확정 표시로 보여준다.
  const [phase, setPhase] = useState<'idle' | 'parsing' | 'analyzing'>('idle');
  const [fileName, setFileName] = useState('');
  const [error, setError] = useState('');
  const [warnings, setWarnings] = useState<string[]>([]);

  // 이중 requestAnimationFrame — 라벨 setState가 실제로 페인트된 뒤 무거운 동기 작업을 돌린다
  // (이상치/인코딩 탭과 동일한 검증된 패턴). 두 프레임 양보로 리페인트를 보장.
  const nextPaint = () =>
    new Promise<void>((res) => requestAnimationFrame(() => requestAnimationFrame(() => res())));

  async function handleFile(file: File) {
    setError('');
    setWarnings([]);
    setFileName(file.name);
    try {
      // parseFile은 내부에서 읽기+파싱(동기)을 함께 한다 → 'parsing' 하나로 묶고,
      // 라벨을 먼저 페인트한 뒤 파싱을 실행해 화면이 얼지 않게 한다.
      setPhase('parsing');
      await nextPaint();
      const { rows, warnings: w } = await parseFile(file);
      if (!rows.length) throw new Error('데이터가 비어 있는 것 같아요.');
      // profileDataset(loadRows)도 동기라 '분석 중' 라벨을 먼저 페인트한 뒤 실행.
      setPhase('analyzing');
      await nextPaint();
      loadRows(file.name, rows);
      if (w.length) {
        // 검증 경고가 있으면 사용자에게 알리고 진행 여부를 묻는다(데이터는 이미 로드됨)
        setPhase('idle');
        setWarnings(w);
      } else {
        setTimeout(() => goto('overview'), 350);
      }
    } catch (e) {
      setPhase('idle');
      setError(e instanceof Error ? e.message : '파일을 읽지 못했어요.');
    }
  }

  async function useSample() {
    setError('');
    setWarnings([]);
    setFileName('customers_2025.csv');
    // 샘플 생성 + profileDataset(동기) 전에 '분석 중' 라벨을 먼저 페인트.
    setPhase('analyzing');
    await nextPaint();
    loadSample();
    setTimeout(() => goto('overview'), 300);
  }

  return (
    <>
      <PageHeader
        title="데이터 업로드"
        subtitle="분석할 데이터를 업로드하세요. 개요·통계·시각화·예측까지 이어집니다."
      />

      {warnings.length > 0 ? (
        <div className="rounded-card border border-warning/40 bg-surface p-8 shadow-card">
          <p className="flex items-center gap-2 text-base font-semibold text-text">
            업로드는 됐지만 확인할 점이 있어요
          </p>
          <p className="mt-1 text-sm text-text-muted">{fileName}</p>
          <ul className="mt-4 space-y-2">
            {warnings.map((w, i) => (
              <li key={i} className="flex items-start gap-2 rounded-btn bg-warning/10 px-3 py-2 text-sm text-text">
                <span aria-hidden>•</span>
                <span>{w}</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-text-muted">
            그대로 진행하거나, 파일 인코딩(UTF-8 권장)·컬럼명을 정리해 다시 올릴 수 있어요.
          </p>
          <div className="mt-5 flex gap-2">
            <Button onClick={() => goto('overview')}>이대로 계속하기 →</Button>
            <Button
              variant="secondary"
              onClick={() => {
                setWarnings([]);
                setFileName('');
              }}
            >
              다른 파일 선택
            </Button>
          </div>
        </div>
      ) : phase === 'idle' ? (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            const f = e.dataTransfer.files?.[0];
            if (f) handleFile(f);
          }}
          className={`flex flex-col items-center justify-center rounded-card border-2 border-dashed p-16 text-center transition-all
            ${dragging ? 'border-primary bg-primary-soft' : 'border-border bg-surface'}`}
        >
          <p className="text-lg font-semibold text-text">
            파일을 여기로 끌어다 놓으세요
          </p>
          <p className="mt-1 text-sm text-text-muted">CSV · XLSX · XLS 지원 (최대 50MB 권장)</p>
          <input
            ref={inputRef}
            type="file"
            accept=".csv,.xlsx,.xls"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
          <Button className="mt-5" onClick={() => inputRef.current?.click()}>
            파일 선택
          </Button>
          {error && <p className="mt-4 text-sm text-danger">{error}</p>}

          <div className="mt-8 text-sm text-text-muted">
            처음이신가요?{' '}
            <button
              onClick={useSample}
              className="font-medium text-primary underline-offset-2 hover:underline"
            >
              샘플 데이터로 둘러보기
            </button>
          </div>
        </div>
      ) : (
        <div className="rounded-card border border-border bg-surface p-10 shadow-card">
          <p className="font-medium text-text">
            {fileName} · {phase === 'parsing' ? '파싱 중…' : '데이터 분석 중…'}
          </p>
          <p className="mt-2 text-sm text-text-muted">
            {phase === 'parsing'
              ? '파일을 읽고 표 형태로 바꾸는 중이에요…'
              : '컬럼 종류·품질을 파악하고 있어요…'}
          </p>
        </div>
      )}
    </>
  );
}
