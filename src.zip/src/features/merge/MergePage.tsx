import PageHeader from '../../components/PageHeader';
import Card from '../../components/Card';
import NavFooter from '../../components/NavFooter';
import MergePanel from '../predict/MergePanel';
import { ManualMode, Dashboard } from '../visualize/VisualizePage';
import { PreprocessEditor } from '../preprocess/PreprocessPage';
import { useActiveDataset } from '../../hooks/useActiveDataset';
import { useDatasetStore } from '../../store/useDatasetStore';
import type { Dataset } from '../../types';

// 선택 단계 — 시각화와 예측 사이. key 컬럼 기준으로 파일을 붙여 예측용 데이터를 만든다.
// 업로드한 데이터가 없으면 첫 파일이 기준 파일이 되어, 업로드 없이 병합만으로도 시작할 수 있다.
// 병합을 적용하면 그 결과가 곧바로 기준 데이터(activeDataset)로 승격돼 모든 화면에서 쓰인다(스토어 setMergedBase).
export default function MergePage() {
  const base = useActiveDataset();
  const setMergedBase = useDatasetStore((s) => s.setMergedBase);
  const mergeApplied = useDatasetStore((s) => s.mergeApplied);
  const mergedResetSteps = useDatasetStore((s) => s.mergedResetSteps);

  // 승격으로 병합본이 곧 activeDataset(base) → 항상 최신 데이터를 본다(낡은 mergedDataset 제거).
  const used = base;

  return (
    <>
      <PageHeader
        title="데이터 병합"
        subtitle="다른 파일을 key 컬럼 기준으로 붙여 예측용 데이터를 만들 수 있어요. 업로드한 데이터가 없어도 파일을 올려 바로 병합할 수 있습니다."
      />

      <Card title={base ? '파일 병합 (선택)' : '파일 병합'}>
        <p className="mb-4 text-sm text-text-muted">
          {base
            ? '예측에 활용할 컬럼이 다른 파일에 있다면 여기서 합치세요. 병합하지 않으면 전처리한 현재 데이터로 예측합니다.'
            : '업로드한 데이터가 없어요. 파일을 올리면 첫 번째 파일이 기준이 되고, 나머지를 key 기준으로 붙입니다. 병합 결과로 바로 예측할 수 있어요.'}
        </p>
        <MergePanel base={base} onMerged={setMergedBase} />

        <p className="mt-4 text-sm">
          예측에 사용될 데이터:{' '}
          {used ? (
            <>
              <span className="font-medium text-text">{used.fileName}</span>{' '}
              <span className="text-text-muted">({used.rowCount.toLocaleString()}행 × {used.colCount}열)</span>
              {mergeApplied && <span className="ml-2 rounded-chip bg-success/10 px-2 py-0.5 text-xs text-success">병합됨</span>}
            </>
          ) : (
            <span className="text-text-muted">아직 없음 — 파일을 병합하거나 업로드하세요.</span>
          )}
        </p>

        {/* 병합 적용 후 안내(정보 톤) — 병합본이 모든 단계에 적용됐고(전처리 이력이 있었다면 반영되어 초기화됨),
            아래 편집·시각화가 전처리·시각화 단계와 같은 데이터를 공유함을 알린다. */}
        {mergeApplied && (
          <div className="mt-4 rounded-btn border border-primary/30 bg-primary-soft px-3 py-2.5 text-xs text-text">
            <p>이 병합 데이터가 <b>개요·기초 통계·시각화·예측·결과 리포트</b> 등 모든 단계에 적용됐어요. 아래 편집·시각화는 전처리·시각화 단계와 같은 데이터를 공유합니다.</p>
            {mergedResetSteps > 0 && (
              <p className="mt-1 text-text-muted">
                이전에 적용한 전처리 {mergedResetSteps}단계는 병합 데이터에 이미 반영되어 이전 전처리 이력이 초기화됐습니다.
              </p>
            )}
          </div>
        )}
      </Card>

      {/* 편집·시각화는 병합 여부와 무관하게 활성 데이터가 있으면 항상 노출(자동 승격으로 병합본=메인 데이터).
          전처리 페이지·시각화 페이지와 같은 상태를 공유하는 같은 기능이다. */}
      {base && (
        <div className="mt-5">
          <h3 className="mb-1 text-base font-semibold text-text">전처리</h3>
          <p className="mb-3 text-xs text-text-muted">전처리 단계와 같은 편집이에요. 여기서 하든 전처리 화면에서 하든 이력이 하나로 쌓입니다.</p>
          <MergeEditor />
        </div>
      )}

      {base && <MergeVisualize d={base} />}

      <NavFooter prevLabel="시각화" nextLabel="예측 분석" />
    </>
  );
}

// 병합 데이터 편집 — 메인 전처리 파이프라인(activeDataset·steps)을 그대로 공유한다.
//   전처리 페이지와 완전히 같은 상태를 써서, 어느 쪽에서 편집하든 이력이 하나로 쌓이고 리포트 §4에도 함께 표시된다.
function MergeEditor() {
  const d = useActiveDataset();
  const { steps, addStep, undoStep, resetSteps } = useDatasetStore();
  if (!d) return null;
  return (
    <PreprocessEditor d={d} steps={steps} addStep={addStep} undoStep={undoStep} resetSteps={resetSteps} />
  );
}

// 병합 데이터 시각화 — 메인 시각화(전역 dashboardItems·manualChart)를 데이터 소스만 activeDataset 으로 재사용.
function MergeVisualize({ d }: { d: Dataset }) {
  const numericCols = d.columns.filter((c) => c.type === 'int' || c.type === 'float').map((c) => c.name);
  const categoricalCols = d.columns.filter((c) => c.type === 'string' || c.type === 'bool').map((c) => c.name);
  const dateCols = d.columns.filter((c) => c.type === 'datetime').map((c) => c.name);
  const allCols = d.columns.map((c) => c.name);

  return (
    <Card title="시각화 (선택)" className="mt-5">
      <p className="mb-3 text-xs text-text-muted">시각화 단계와 같은 대시보드를 공유해요 — 여기서 추가한 차트가 시각화 화면·결과 리포트에도 나타납니다.</p>
      <h3 className="mb-3 text-base font-semibold text-text">차트 만들기</h3>
      <ManualMode d={d} numericCols={numericCols} categoricalCols={categoricalCols} dateCols={dateCols} allCols={allCols} />

      <h3 className="mb-3 mt-8 text-base font-semibold text-text">대시보드</h3>
      <Dashboard d={d} />
    </Card>
  );
}
