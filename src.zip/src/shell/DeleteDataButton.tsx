import { useState } from 'react';
import Button from '../components/Button';
import { useDatasetStore } from '../store/useDatasetStore';

// 상단 우측 "데이터 삭제" — 확인 모달 후 데이터(IndexedDB 포함) 삭제 + 업로드 화면으로.
// 새로고침해도 데이터는 유지되며, 이 버튼으로만 명시적으로 삭제한다.
export default function DeleteDataButton() {
  const [open, setOpen] = useState(false);
  const deleteData = useDatasetStore((s) => s.deleteData);
  const hasData = useDatasetStore((s) => !!s.dataset);

  if (!hasData) return null;

  return (
    <>
      <Button variant="ghost" onClick={() => setOpen(true)} className="whitespace-nowrap" title="업로드한 데이터를 삭제합니다">
        데이터 삭제
      </Button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 fade-in" role="dialog" aria-modal="true" onClick={() => setOpen(false)}>
          <div className="w-full max-w-sm rounded-card border border-border bg-surface p-6 shadow-card" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-base font-semibold text-text">데이터 삭제</h3>
            <p className="mt-2 text-sm leading-relaxed text-text-muted">
              업로드한 데이터와 전처리 내용이 모두 삭제됩니다.
              <br />
              계속하시겠습니까?
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setOpen(false)}>취소</Button>
              <Button variant="danger" onClick={() => { deleteData(); setOpen(false); }}>삭제</Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
