import ThemeToggle from './ThemeToggle';
import ProgressStepper from './ProgressStepper';
import DeleteDataButton from './DeleteDataButton';
import BrandMark from '../components/BrandMark';
import { useDatasetStore } from '../store/useDatasetStore';
import { useAuthStore } from '../store/useAuthStore';
import { useAdminStore } from '../store/useAdminStore';

// 관리 화면 진입/복귀 — 관리자(admin)·담당자(instructor)에게만 노출.
function AdminToggle() {
  const role = useAuthStore((s) => s.user?.role);
  const open = useAdminStore((s) => s.open);
  const openAdmin = useAdminStore((s) => s.openAdmin);
  const closeAdmin = useAdminStore((s) => s.closeAdmin);
  if (role !== 'admin' && role !== 'instructor') return null;
  return (
    <button
      type="button"
      onClick={() => (open ? closeAdmin() : openAdmin())}
      className={`rounded-btn border px-2.5 py-1 text-xs transition-colors ${
        open
          ? 'border-primary bg-primary-soft text-primary'
          : 'border-border bg-surface text-text-muted hover:bg-surface-muted hover:text-text'
      }`}
    >
      {open ? '← 분석' : '관리'}
    </button>
  );
}

// 로그인 사용자 표시 + 로그아웃.
function UserMenu() {
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  if (!user) return null;
  return (
    <div className="flex items-center gap-2">
      <span className="hidden max-w-[12rem] truncate text-xs text-text-muted sm:inline" title={user.email}>
        {user.username || user.email}
      </span>
      <button
        type="button"
        onClick={() => void logout()}
        className="rounded-btn border border-border bg-surface px-2.5 py-1 text-xs text-text-muted transition-colors hover:bg-surface-muted hover:text-danger"
      >
        로그아웃
      </button>
    </div>
  );
}

// 상단 Sticky Header — (1행) 브랜드/파일명 + 사용자·테마, (2행) Progress Stepper.
export default function Topbar() {
  const fileName = useDatasetStore((s) => s.dataset?.fileName);
  const adminOpen = useAdminStore((s) => s.open);
  const role = useAuthStore((s) => s.user?.role);
  // 관리 뷰가 실제로 렌더되는 조건(App 과 동일 가드)일 때만 스테퍼를 숨긴다.
  const showAdmin = adminOpen && (role === 'admin' || role === 'instructor');
  return (
    <header className="sticky top-0 z-30 flex-none border-b border-border bg-surface">
      {/* 1행: 브랜드/파일명 + 관리·사용자·테마 토글 */}
      <div className="flex h-14 items-center gap-4 px-5">
        <div className="flex min-w-0 shrink items-center gap-2 text-sm">
          <BrandMark className="h-[31px] w-[31px]" />
          {/* 아이콘은 바깥 items-center 로 Elio 와 세로 중앙 유지. 텍스트끼리만 baseline 정렬해 파일명을 Elio 아래줄에 붙인다. */}
          <div className="flex min-w-0 items-baseline gap-2">
            <span className="flex-none text-3xl font-bold leading-none tracking-tight text-text">Elio</span>
            {fileName && (
              <span className="max-w-[14rem] truncate text-xs text-text-muted">{fileName}</span>
            )}
          </div>
        </div>
        <div className="ml-auto flex shrink-0 items-center gap-3">
          <AdminToggle />
          <UserMenu />
          <ThemeToggle />
        </div>
      </div>

      {/* 2행: Progress Stepper + (우측 끝) 새 데이터 불러오기 — 관리 화면에선 숨김 */}
      {!showAdmin && (
        <div className="flex items-center gap-3 border-t border-border px-3 py-2.5">
          <div className="min-w-0 flex-1">
            <ProgressStepper />
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <DeleteDataButton />
          </div>
        </div>
      )}
    </header>
  );
}
