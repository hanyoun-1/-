import { useThemeStore } from '../store/useThemeStore';

export default function ThemeToggle() {
  const { theme, set } = useThemeStore();
  return (
    <div className="inline-flex rounded-btn border border-border bg-surface-muted p-1 text-sm">
      <button
        onClick={() => set('light')}
        className={`rounded-chip px-3 py-1 transition-all ${
          theme === 'light' ? 'bg-surface text-text shadow-sm' : 'text-text-muted'
        }`}
      >
        ☀ Light
      </button>
      <button
        onClick={() => set('dark')}
        className={`rounded-chip px-3 py-1 transition-all ${
          theme === 'dark' ? 'bg-surface text-text shadow-sm' : 'text-text-muted'
        }`}
      >
        🌙 Dark
      </button>
    </div>
  );
}
