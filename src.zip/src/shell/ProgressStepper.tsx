import { Fragment } from 'react';
import { STEPS, useStepStore } from '../store/useStepStore';

// 상단 Progress Stepper — 원형(완료 ● / 현재 ◉ / 미완료 ○) + 연결선(완료 ━ / 미완료 ─),
// 단계명은 원형 아래에 표시. 각 단계 클릭 이동. 모바일 가로 스크롤. (Zustand 연동)
export default function ProgressStepper() {
  const { current, goto } = useStepStore();
  const currentIdx = STEPS.findIndex((s) => s.id === current);

  return (
    <div className="overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      <nav aria-label="진행 단계" className="mx-auto flex w-max items-start">
        {STEPS.map((step, i) => {
          const isCurrent = i === currentIdx;
          const isDone = i < currentIdx;
          return (
            <Fragment key={step.id}>
              {/* 연결선: 완료 구간(현재 단계까지)은 primary, 이후는 얇은 border */}
              {i > 0 && (
                <div
                  aria-hidden
                  className={`mt-3.5 h-0.5 w-8 flex-none rounded-full transition-colors sm:w-14 ${
                    i <= currentIdx ? 'bg-primary' : 'bg-border'
                  }`}
                />
              )}
              <button
                onClick={() => goto(step.id)}
                aria-current={isCurrent ? 'step' : undefined}
                title={step.label}
                className="flex w-20 flex-none cursor-pointer flex-col items-center gap-1.5 sm:w-28"
              >
                {/* 원형: ● 완료(채움) · ◉ 현재(테두리+중앙 점) · ○ 미완료(테두리) */}
                <span
                  className={`grid h-7 w-7 flex-none place-items-center rounded-full border-2 transition-colors ${
                    isDone
                      ? 'border-primary bg-primary'
                      : isCurrent
                        ? 'border-primary bg-surface'
                        : 'border-border bg-surface'
                  }`}
                >
                  {isCurrent && <span className="h-2.5 w-2.5 rounded-full bg-primary" />}
                </span>
                {/* 단계명: 원형 아래 */}
                <span
                  className={`max-w-full truncate text-center text-sm leading-tight transition-colors ${
                    isCurrent
                      ? 'font-semibold text-primary'
                      : isDone
                        ? 'text-text'
                        : 'text-text-muted'
                  }`}
                >
                  {step.label}
                </span>
              </button>
            </Fragment>
          );
        })}
      </nav>
    </div>
  );
}
