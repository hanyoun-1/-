import Topbar from './Topbar';
import type { ReactNode } from 'react';

// 좌측 Sidebar를 제거하고, 상단 Sticky Header(Top Progress Navigation) 중심의 단일 컬럼 구조.
export default function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-screen flex-col overflow-hidden bg-bg">
      <Topbar />
      <main className="flex-1 overflow-y-auto px-5 py-7 md:px-8">
        <div className="mx-auto w-full">{children}</div>
      </main>
    </div>
  );
}
