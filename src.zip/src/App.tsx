import { useEffect, useState } from 'react';
import AppShell from './shell/AppShell';
import { useStepStore } from './store/useStepStore';
import { useDatasetStore } from './store/useDatasetStore';
import { useAdminStore } from './store/useAdminStore';
import { useAuthStore } from './store/useAuthStore';
import AdminPage from './features/admin/AdminPage';
import UploadPage from './features/upload/UploadPage';
import OverviewPage from './features/overview/OverviewPage';
import StatisticsPage from './features/statistics/StatisticsPage';
import PreprocessPage from './features/preprocess/PreprocessPage';
import VisualizePage from './features/visualize/VisualizePage';
import MergePage from './features/merge/MergePage';
import PredictPage from './features/predict/PredictPage';
import ReportPage from './features/report/ReportPage';

export default function App() {
  const current = useStepStore((s) => s.current);
  const next = useStepStore((s) => s.next);
  const prev = useStepStore((s) => s.prev);
  const hydrated = useDatasetStore((s) => s.hydrated);
  const hasData = useDatasetStore((s) => !!s.activeDataset);
  const adminOpen = useAdminStore((s) => s.open);
  const role = useAuthStore((s) => s.user?.role);
  // 방어 가드: 관리자·담당자만 관리 뷰 렌더(버튼 미노출과 이중). 멤버는 open 이 남아 있어도 진입 불가.
  const showAdmin = adminOpen && (role === 'admin' || role === 'instructor');

  // 단계 전환 시 버퍼링 화면 — 실제로 렌더 중인 단계(rendered)를 store의 current와 분리.
  // current가 바뀌면 그 렌더에서 즉시 switching=true(스피너)가 되고, 무거운 페이지는
  // 두 프레임 뒤에 렌더한다. (effect로 켜면 무거운 렌더가 먼저 끝나버려 스피너가 늦게 뜸)
  const [rendered, setRendered] = useState(current);
  const switching = rendered !== current;
  useEffect(() => {
    if (rendered === current) return;
    const id = requestAnimationFrame(() => requestAnimationFrame(() => setRendered(current)));
    return () => cancelAnimationFrame(id);
  }, [current, rendered]);

  // 좌우 방향키로 단계 이동(입력 요소 포커스 시 비활성)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      const tag = t?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || t?.isContentEditable) return;
      if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        next();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        prev();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [next, prev]);

  // 복원이 끝나기 전(저장 데이터가 있을 수 있음)엔 로딩 표시 — 흰 화면/깜빡임 방지.
  // 업로드 단계는 데이터가 없어도 바로 보여준다.
  const restoring = !hydrated && current !== 'upload' && !hasData;
  const loading = restoring || switching;

  return (
    <AppShell>
      {showAdmin ? (
        <AdminPage />
      ) : loading ? (
        <div className="grid h-[60vh] place-items-center">
          <div className="flex items-center gap-3 text-text-muted">
            <svg className="h-5 w-5 animate-spin text-primary" viewBox="0 0 24 24" fill="none" aria-hidden>
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
            </svg>
            <span className="text-sm">{restoring ? '데이터 불러오는 중…' : '화면 준비 중…'}</span>
          </div>
        </div>
      ) : (
        <div key={rendered} className="fade-in">
          {rendered === 'upload' && <UploadPage />}
          {rendered === 'overview' && <OverviewPage />}
          {rendered === 'statistics' && <StatisticsPage />}
          {rendered === 'preprocess' && <PreprocessPage />}
          {rendered === 'visualize' && <VisualizePage />}
          {rendered === 'merge' && <MergePage />}
          {rendered === 'predict' && <PredictPage />}
          {rendered === 'report' && <ReportPage />}
        </div>
      )}
    </AppShell>
  );
}
