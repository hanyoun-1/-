import type { Row } from '../types';

// 비전공자 데모용 고객 더미 데이터 생성기.
// 실제 업로드한 것처럼 보이도록 현실적인 분포로 구성한다.
const REGIONS = ['서울', '경기', '부산', '대구', '광주', '대전', '인천'];
// 실제 주민등록인구(2024, 근사) 기준 가중치 — 균등이 아니라 현실적인 인구 비율로 뽑는다. 단위 천명(근사).
//   순서는 REGIONS 와 동일: 경기>서울>부산>인천>대구>대전≈광주.
const REGION_WEIGHTS = [9380, 13630, 3290, 2370, 1419, 1442, 3000];
const REGION_TOTAL = REGION_WEIGHTS.reduce((s, w) => s + w, 0);
const REGION_CUM = REGION_WEIGHTS.reduce<number[]>((acc, w) => (acc.push((acc[acc.length - 1] ?? 0) + w), acc), []);
const GENDERS = ['남성', '여성'];

// 가중 랜덤 선택 — r(0~1)에 인구 가중치를 반영해 지역을 뽑는다(rand() 한 번만 소비 → 다른 컬럼 난수열 불변).
function pickRegion(r: number): string {
  const x = r * REGION_TOTAL;
  for (let k = 0; k < REGIONS.length; k++) if (x < REGION_CUM[k]) return REGIONS[k];
  return REGIONS[REGIONS.length - 1];
}

// 간단한 의사난수(시드 고정) — 새로고침해도 동일한 데모 데이터 유지
function seeded(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => (s = (s * 16807) % 2147483647) / 2147483647;
}

export function generateSampleRows(n = 12840): Row[] {
  const rand = seeded(42);
  const rows: Row[] = [];
  for (let i = 0; i < n; i++) {
    const age = Math.round(18 + Math.pow(rand(), 1.4) * 61); // 18~79, 20~40 비중↑
    // 소득(만원) — 나이가 많을수록 높아지도록: 나이 기저(0~1400) + 무작위 변동(0~600). rand() 호출 수는 그대로(1회) 유지.
    const income = Math.round(50 + ((age - 18) / 61) * 1400 + Math.pow(rand(), 1.8) * 600);
    const visits = Math.round(rand() * 18);
    const tenureMonths = Math.round(rand() * 29); // 가입 기간(개월)

    // 구매 확률: 소득·방문 높을수록↑
    const buyScore = income / 2000 + visits / 18 + rand() * 0.5;
    const purchased = buyScore > 0.9;

    // 이탈: 방문 적고 가입 오래된 고객↑
    const churnScore = (1 - visits / 18) * 0.6 + (tenureMonths / 29) * 0.4 + rand() * 0.3;
    const churned = churnScore > 0.85;

    // 월 매출: 소득·방문 기반 + 드문 이상치. 소득 계수 0.03 → 소득이 매출의 주요 동력(산점도에서 뚜렷한 우상향).
    let revenue = purchased ? 2 + visits * 0.9 + income * 0.03 + rand() * 4 : rand() * 1.5;
    if (rand() > 0.985) revenue += 30 + rand() * 50; // 드문 이상치(정상 범위 위 → 이상치 탐지 데모용)

    const year = 2023 + Math.floor(rand() * 3); // 2023~2025
    const month = 1 + Math.floor(rand() * 12);
    const day = 1 + Math.floor(rand() * 28);
    const signup = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

    rows.push({
      customer_id: 100000 + i,
      age,
      gender: GENDERS[Math.floor(rand() * GENDERS.length)],
      region: pickRegion(rand()),
      signup_date: signup,
      monthly_income: income,
      visit_count: visits,
      tenure_months: tenureMonths,
      purchased,
      churned,
      monthly_revenue: Math.round(revenue * 10) / 10,
    });
  }

  // 의도적으로 결측치/중복치 주입(품질 데모용)
  for (let i = 0; i < rows.length; i++) {
    if (rand() < 0.042) rows[i].monthly_income = null; // 약 4.2% 결측
  }
  // 중복 324건 주입
  const dupBase = rows.slice(0, 324).map((r) => ({ ...r }));
  rows.push(...dupBase);

  return rows;
}

export const SAMPLE_FILE_NAME = 'customers_2025.csv';
