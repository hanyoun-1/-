# 폰트 파일 위치 (Pretendard, 오프라인)

이 폴더에 **Pretendard woff2** 파일을 넣으면 폐쇄망에서도 폰트가 정상 표시됩니다.
(저장소에는 폰트 바이너리를 포함하지 않습니다.)

## 넣을 파일
- `Pretendard-Regular.woff2` (400)
- `Pretendard-Medium.woff2` (500)
- `Pretendard-SemiBold.woff2` (600)
- `Pretendard-Bold.woff2` (700)

## 받는 곳
https://github.com/orioncactus/pretendard → `dist/web/static/woff2/`

## 동작
- `src/index.css` 의 `@font-face` 가 `/fonts/*.woff2` 를 참조합니다.
- **파일이 없어도** `font-family` 폴백 체인(`Inter, system-ui, sans-serif`)으로
  자동 대체되어 화면이 깨지지 않습니다. (오프라인 필수 요건 아님, 있으면 브랜드 폰트 적용)

## 서브경로 배포 시
`vite.config.ts` 의 `base` 를 서브경로로 두는 경우, index.css 의 `/fonts/` 절대경로도
동일 서브경로로 맞춰야 합니다. (루트 `/` 배포면 수정 불필요)
